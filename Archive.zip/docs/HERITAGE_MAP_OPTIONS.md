# Heritage Map / Family Tree Implementation Options

## Problem Statement

Need a family tree/organizational chart component that works with:

- Server-side rendering (React SSR)
- PDF generation via Puppeteer
- No browser DOM APIs

## Library Evaluation

### ❌ Not Suitable for SSR/PDF

1. **react-organizational-chart**
   - Pros: Popular, good API
   - Cons: Requires DOM measurements, won't render in SSR
2. **react-family-tree**
   - Pros: Specifically for family trees
   - Cons: Uses canvas/DOM APIs, SSR incompatible

3. **d3-org-chart**
   - Pros: Powerful, flexible
   - Cons: D3 requires DOM, complex for SSR

4. **elkjs / react-flow**
   - Pros: Advanced layout algorithms
   - Cons: Requires browser environment, overkill for simple trees

### ✅ Suitable Approaches

1. **Custom Pure-SVG Solution** (RECOMMENDED)
   - Pure SVG with inline styles
   - No DOM dependencies
   - Full control over layout
   - Works perfectly with SSR

2. **CSS Grid/Flexbox + SVG Lines**
   - Use CSS for positioning
   - SVG for connection lines
   - Simple and maintainable

3. **react-simple-tree-menu** + Custom Rendering
   - Use only the tree data structure
   - Custom render with SVG
   - More complex than needed

## Recommended Implementation: Pure SVG Solution

### Architecture

```
HeritageMap Component
├── Calculate tree layout (positions for each node)
├── Render SVG container
│   ├── Connection lines (SVG paths)
│   └── Family member nodes (circles + text)
└── Use inline styles only (no Tailwind)
```

### Why This Works

1. **Pure SVG** - Renders perfectly in Puppeteer
2. **Calculated Layout** - No DOM measurements needed
3. **Inline Styles** - No CSS compilation issues
4. **Simple Algorithm** - Level-based positioning

### Layout Algorithm

```typescript
// Simple horizontal tree layout
- Generation 0: y = 100
- Generation 1: y = 300
- Generation 2: y = 500
- X spacing: 150px per person
- Center each generation horizontally
```

### SVG Connection Lines

```typescript
// Vertical line from parent to child
<line
  x1={parentX}
  y1={parentY + avatarRadius}
  x2={childX}
  y2={childY - avatarRadius}
  stroke="#e5e7eb"
  strokeWidth="2"
/>
```

## Alternative: Simpler Grid Layout (Current Approach - BROKEN)

The current implementation uses flexbox which breaks because:

- Tailwind classes don't work in SSR
- Relative positioning doesn't work well
- Connection lines misaligned

## Implementation Plan

### Option A: Keep Simple, Fix Styling (FAST - 15 min)

- Remove all Tailwind classes
- Use pure inline styles
- Simple horizontal layout per generation
- Basic SVG lines for connections

### Option B: Full SVG Tree (BEST - 30 min)

- Calculate all positions mathematically
- Render everything in SVG
- Professional appearance
- Full control

### Option C: Use External Service (AVOID)

- Generate tree image externally
- Embed as base64 image
- Loses interactivity
- Extra dependency

## Recommendation: Implement Option A (Simple Fix)

Keep the current component structure but:

1. Remove all `className` props
2. Use only inline `style` props
3. Use simple math for positioning
4. Test SVG line rendering

If that still has issues, then implement Option B (Full SVG).

## Example Code: Simple Fix

```typescript
export const HeritageMap: React.FC<HeritageMapProps> = ({ data }) => {
  const { title, members } = data;

  // Group by generation
  const generations = /* grouping logic */;

  return (
    <div style={getCardStyle()}>
      <h3 style={getTitleStyle()}>{title}</h3>
      <div style={{ padding: '40px 20px' }}>
        {generations.map((gen, genIndex) => (
          <div key={gen.generation}>
            {/* Generation label */}
            <div style={{
              fontSize: '14px',
              fontWeight: '600',
              color: '#6b7280',
              marginBottom: '20px',
              textAlign: 'center'
            }}>
              Generation {gen.generation + 1}
            </div>

            {/* Members row */}
            <div style={{
              display: 'flex',
              justifyContent: 'center',
              gap: '60px',
              marginBottom: genIndex < generations.length - 1 ? '60px' : '0'
            }}>
              {gen.members.map((member) => (
                <div key={member.id}>
                  <Avatar
                    initials={member.initials}
                    name={member.name}
                    size={80}
                    bgColor={getColorForIndex(memberIndex)}
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
```

## Testing

Generate PDF and verify:

- ✅ All avatars visible
- ✅ Names displayed under avatars
- ✅ Generation labels clear
- ✅ Proper spacing
- ✅ No overlapping elements

---

**Next Step:** Implement simple fix and test. If still broken, escalate to full SVG solution.
