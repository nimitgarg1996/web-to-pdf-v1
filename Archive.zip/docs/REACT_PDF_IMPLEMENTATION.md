# @react-pdf/renderer Implementation Guide

## Project Gutenberg - Estate Planning Report Engine

This document explains the technical implementation of high-quality PDF report generation using `@react-pdf/renderer`.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Tech Stack](#tech-stack)
3. [Why @react-pdf/renderer?](#why-react-pdfrenderer)
4. [Directory Structure](#directory-structure)
5. [Theme System](#theme-system)
6. [Component Implementation](#component-implementation)
7. [SVG Graphics for Charts](#svg-graphics-for-charts)
8. [Layout System](#layout-system)
9. [API Integration](#api-integration)
10. [Best Practices & Gotchas](#best-practices--gotchas)
11. [Performance](#performance)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        API Layer                                 │
│  POST /api/v1/generate-estate-report                            │
│  GET  /api/v1/estate-report-sample                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PDF Renderer Service                          │
│  src/pdf/pdf-renderer.service.ts                                │
│  - Receives report data (EstateReportProps)                     │
│  - Creates React element tree                                    │
│  - Calls renderToBuffer() to generate PDF                       │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Document Component                            │
│  EstateReportDocument                                           │
│  - Multi-page Document wrapper                                  │
│  - Page headers/footers                                         │
│  - Composes all section components                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    UI Components                                 │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐            │
│  │  DonutChart  │ │ TrustCards   │ │ EntityChart  │            │
│  └──────────────┘ └──────────────┘ └──────────────┘            │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐            │
│  │  AssetTable  │ │ HeritageMap  │ │ EstateFlow   │            │
│  └──────────────┘ └──────────────┘ └──────────────┘            │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Theme System                                  │
│  - Color palette (primary, secondary, neutral, accent)          │
│  - Typography (font sizes, weights)                             │
│  - Common styles (card, table, badges)                          │
└─────────────────────────────────────────────────────────────────┘
```

---

## Tech Stack

### Core Libraries

| Library               | Version | Purpose                    |
| --------------------- | ------- | -------------------------- |
| `@react-pdf/renderer` | ^3.x    | Core PDF generation engine |
| `react`               | ^18.x   | Component framework        |
| `typescript`          | ^5.x    | Type safety                |
| `express`             | ^4.x    | API server                 |

### Key Imports from @react-pdf/renderer

```typescript
import {
  Document, // Root PDF document
  Page, // Individual page
  View, // Container (like div)
  Text, // Text content
  Svg, // SVG container
  Path, // SVG paths (for charts)
  Circle, // SVG circles
  Line, // SVG lines
  G, // SVG group
  StyleSheet, // CSS-in-JS styles
  renderToBuffer, // Server-side rendering
} from "@react-pdf/renderer";
```

---

## Why @react-pdf/renderer?

### Comparison with Alternatives

| Feature            | @react-pdf/renderer | Puppeteer            | html-pdf  |
| ------------------ | ------------------- | -------------------- | --------- |
| Browser Required   | ❌ No               | ✅ Yes               | ✅ Yes    |
| CSS Support        | Flexbox subset      | Full CSS             | Full CSS  |
| Chart Libraries    | SVG primitives      | Recharts, D3         | Any       |
| Performance        | ~300ms              | ~3-5s                | ~2-3s     |
| Memory Usage       | Low                 | High (browser)       | Medium    |
| Server-side Only   | ✅ Yes              | ❌ No                | ✅ Yes    |
| Predictable Output | ✅ Yes              | ⚠️ Browser-dependent | ⚠️ Varies |

### Key Benefits

1. **No Browser Required**: Pure Node.js rendering
2. **Predictable Layout**: Flexbox-based, no CSS quirks
3. **Fast**: ~300ms for 6-page report
4. **Small File Size**: ~21KB for complete report
5. **Pixel-Perfect**: Vector-based rendering

---

## Directory Structure

```
src/pdf/
├── theme.ts                      # Design tokens & common styles
├── pdf-renderer.service.ts       # PDF generation service
└── components/
    ├── EstateReportDocument.tsx  # Main document wrapper
    ├── DonutChart.tsx            # SVG donut chart
    ├── TrustDetailCard.tsx       # Trust detail cards
    ├── EntityStructureChart.tsx  # Entity icons with progress
    ├── AssetTable.tsx            # Grouped data table
    ├── HeritageMap.tsx           # Family tree with connections
    └── EstateFlowDiagram.tsx     # Estate flow visualization
```

---

## Theme System

### File: `src/pdf/theme.ts`

```typescript
// Color Palette
export const pdfColors = {
  primary: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
  },
  secondary: {
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
  },
  // ... more colors
};

// Typography
export const pdfFonts = {
  size: {
    xs: 9,
    sm: 10,
    base: 11,
    lg: 14,
    xl: 18,
    "2xl": 24,
    "3xl": 30,
  },
  weight: {
    normal: "normal",
    medium: "medium",
    semibold: "semibold",
    bold: "bold",
  },
};

// Common Styles
export const commonStyles = StyleSheet.create({
  card: {
    backgroundColor: pdfColors.white,
    borderRadius: 8,
    padding: 20,
    border: `1px solid ${pdfColors.neutral[200]}`,
  },
  cardTitle: {
    fontSize: pdfFonts.size.lg,
    fontWeight: "bold",
    color: pdfColors.neutral[900],
    marginBottom: 16,
  },
  // ... more styles
});
```

### Design Principles

1. **Centralized Tokens**: All colors, fonts, and spacing in one place
2. **Consistent Naming**: Matches Tailwind CSS conventions
3. **Reusable Styles**: `commonStyles` for shared patterns
4. **Type Safety**: Full TypeScript support

---

## Component Implementation

### 1. DonutChart (SVG-based)

**File**: `src/pdf/components/DonutChart.tsx`

#### Challenge

@react-pdf/renderer doesn't support Recharts or D3. Charts must be built with SVG primitives.

#### Solution

Custom arc calculation using trigonometry:

```typescript
function describeArc(
  cx: number, // Center X
  cy: number, // Center Y
  radius: number, // Circle radius
  startAngle: number, // Start angle in degrees
  endAngle: number, // End angle in degrees
): string {
  const start = polarToCartesian(cx, cy, radius, endAngle);
  const end = polarToCartesian(cx, cy, radius, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

  return [
    "M",
    start.x,
    start.y,
    "A",
    radius,
    radius,
    0,
    largeArcFlag,
    0,
    end.x,
    end.y,
  ].join(" ");
}

function polarToCartesian(cx, cy, radius, angleInDegrees) {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180;
  return {
    x: cx + radius * Math.cos(angleInRadians),
    y: cy + radius * Math.sin(angleInRadians),
  };
}
```

#### Rendering

```tsx
<Svg width={chartSize} height={chartSize}>
  {segments.map((segment, index) => {
    const path = describeArc(center, center, radius, startAngle, endAngle);
    return (
      <Path
        key={index}
        d={path}
        stroke={segment.color}
        strokeWidth={strokeWidth}
        fill="none"
      />
    );
  })}
  {/* Center label */}
  <Circle cx={center} cy={center} r={innerRadius} fill="white" />
</Svg>
```

---

### 2. TrustDetailCard

**File**: `src/pdf/components/TrustDetailCard.tsx`

#### Features

- Colored badges (blue, green, teal, purple)
- Property-value pairs
- Grid layout for multiple cards

```tsx
// Badge colors mapping
const badgeColors: Record<string, { bg: string; text: string }> = {
  blue: { bg: pdfColors.secondary[500], text: pdfColors.white },
  green: { bg: "#22c55e", text: pdfColors.white },
  teal: { bg: pdfColors.primary[500], text: pdfColors.white },
  purple: { bg: "#a855f7", text: pdfColors.white },
};

// Badge component
<View style={[styles.badge, { backgroundColor: colors.bg }]}>
  <Text style={[styles.badgeText, { color: colors.text }]}>{badge.label}</Text>
</View>;
```

---

### 3. EntityStructureChart

**File**: `src/pdf/components/EntityStructureChart.tsx`

#### SVG Icons

Custom icons for different entity types:

```typescript
const EntityIcon: React.FC<{ type: string; color: string }> = ({ type, color }) => {
  const bgColor = `${color}20`; // 20% opacity background

  switch (type) {
    case "trust":
      return (
        <Svg width={50} height={50}>
          <Circle cx={25} cy={25} r={25} fill={bgColor} />
          {/* Briefcase icon paths */}
          <Path d="M12 20h26v18H12z" stroke={color} fill="none" />
          <Path d="M18 20v-4h14v4" stroke={color} fill="none" />
        </Svg>
      );
    case "business":
      // Building icon...
    case "individual":
      // Person icon...
  }
};
```

#### Progress Bars

```tsx
<View style={styles.progressBarContainer}>
  <View style={[styles.progressBar, { backgroundColor: `${color}30` }]}>
    <View
      style={[
        styles.progressFill,
        {
          width: `${percentage}%`,
          backgroundColor: color,
        },
      ]}
    />
  </View>
  <Text style={styles.percentageLabel}>{percentage}%</Text>
</View>
```

---

### 4. AssetTable

**File**: `src/pdf/components/AssetTable.tsx`

#### Features

- Grouped rows with group headers
- Subtotals with highlighted background
- Currency formatting
- Column alignment (left, center, right)

```typescript
// Currency formatter
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

// Subtotal row styling
const subtotalStyles = {
  backgroundColor: pdfColors.primary[50],
  fontWeight: "semibold",
};
```

---

### 5. HeritageMap (Family Tree)

**File**: `src/pdf/components/HeritageMap.tsx`

#### Position Calculation

Members are positioned based on generation and index:

```typescript
function calculateMemberPositions(sortedGenerations) {
  const positions = new Map<string, { x: number; y: number }>();

  sortedGenerations.forEach(({ generation, members }, genIndex) => {
    // Calculate row width
    const rowWidth =
      members.length * CARD_WIDTH + (members.length - 1) * CARD_GAP;
    // Center the row
    const startX = (CHART_WIDTH - rowWidth) / 2 + CARD_WIDTH / 2;
    // Y position based on generation
    const y = HEADER_HEIGHT + genIndex * GENERATION_HEIGHT + AVATAR_SIZE / 2;

    members.forEach((member, memberIndex) => {
      const x = startX + memberIndex * (CARD_WIDTH + CARD_GAP);
      positions.set(member.id, { x, y });
    });
  });

  return positions;
}
```

#### Connection Lines

Three types of lines connect family members:

```typescript
// 1. Spouse line (horizontal between partners)
lines.push({
  x1: spouse1Pos.x + AVATAR_SIZE / 2,
  y1: spouse1Pos.y,
  x2: spouse2Pos.x - AVATAR_SIZE / 2,
  y2: spouse2Pos.y,
  color: pdfColors.primary[500], // Teal
});

// 2. Parent-child vertical line
lines.push({
  x1: parentPos.x,
  y1: parentPos.y + AVATAR_SIZE / 2,
  x2: parentPos.x,
  y2: midY,
  color: pdfColors.neutral[300], // Gray
});

// 3. Horizontal connector at midpoint
lines.push({
  x1: parentPos.x,
  y1: midY,
  x2: childPos.x,
  y2: midY,
  color: pdfColors.neutral[300],
});
```

#### Rendering with SVG Overlay

```tsx
<View style={[styles.chartContainer, { height: totalHeight }]}>
  {/* SVG layer for connection lines */}
  <Svg style={styles.svgContainer} width={CHART_WIDTH} height={totalHeight}>
    {allLines.map((line, index) => (
      <Line
        key={index}
        x1={line.x1}
        y1={line.y1}
        x2={line.x2}
        y2={line.y2}
        stroke={line.color}
        strokeWidth={2}
      />
    ))}
  </Svg>

  {/* Content layer with avatars and names */}
  <View style={styles.generationsContainer}>
    {/* ... generation rows ... */}
  </View>
</View>
```

---

### 6. EstateFlowDiagram

**File**: `src/pdf/components/EstateFlowDiagram.tsx`

#### Two-Column Layout

```tsx
<View style={styles.columnsContainer}>
  {/* Left Column - Estates */}
  <View style={styles.column}>
    <Text style={styles.columnTitle}>ESTATES</Text>
    {leftColumn.nodes.map((node) => (
      <FlowNodeCard key={node.id} {...node} variant="primary" />
    ))}
  </View>

  {/* Right Column - Beneficiaries */}
  <View style={styles.column}>
    <Text style={styles.columnTitle}>BENEFICIARIES</Text>
    {rightColumn.nodes.map((node) => (
      <FlowNodeCard key={node.id} {...node} variant="light" />
    ))}
  </View>
</View>
```

---

## SVG Graphics for Charts

### Key SVG Primitives

| Primitive  | Usage          | Example                                                  |
| ---------- | -------------- | -------------------------------------------------------- |
| `<Svg>`    | Container      | `<Svg width={200} height={200}>`                         |
| `<Circle>` | Dots, avatars  | `<Circle cx={100} cy={100} r={50} fill="blue" />`        |
| `<Line>`   | Connections    | `<Line x1={0} y1={0} x2={100} y2={100} stroke="gray" />` |
| `<Path>`   | Complex shapes | `<Path d="M 10 10 L 90 90" stroke="black" />`            |
| `<Rect>`   | Rectangles     | `<Rect x={0} y={0} width={50} height={30} fill="red" />` |
| `<G>`      | Grouping       | `<G transform="translate(50,50)">...</G>`                |

### Arc Path Commands (for Donut Charts)

```
M x y        - Move to (x, y)
A rx ry     - Arc with radius rx, ry
  rotation  - X-axis rotation
  large-arc - 0 for small arc, 1 for large arc
  sweep     - 0 for counter-clockwise, 1 for clockwise
  x y       - End point
```

Example:

```
M 150 50 A 100 100 0 1 0 50 150
```

---

## Layout System

### Flexbox in @react-pdf/renderer

Only a subset of CSS Flexbox is supported:

| Supported        | Not Supported               |
| ---------------- | --------------------------- |
| `flexDirection`  | `gap` (use margins instead) |
| `justifyContent` | CSS Grid                    |
| `alignItems`     | `position: fixed`           |
| `flexWrap`       | `float`                     |
| `flex`           | Complex transforms          |
| `alignSelf`      |                             |

### Page Layout

```tsx
<Page size="LETTER" style={styles.page}>
  {/* Header - fixed at top */}
  <PageHeader />

  {/* Content - fills remaining space */}
  <View style={{ flex: 1 }}>{children}</View>

  {/* Footer - fixed at bottom */}
  <PageFooter pageNumber={1} />
</Page>
```

### Card Layout

```typescript
const cardStyle = {
  backgroundColor: "#ffffff",
  borderRadius: 8,
  padding: 20,
  border: "1px solid #e5e5e5",
  marginBottom: 16,
};
```

---

## API Integration

### Endpoint: Generate Estate Report

```typescript
// POST /api/v1/generate-estate-report
router.post("/generate-estate-report", async (req, res) => {
  const startTime = Date.now();

  try {
    const reportData: EstateReportProps = req.body || sampleEstateReportData;

    // Generate PDF
    const pdfBuffer = await generatePdfWithReactPdf(reportData);

    // Set headers
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="estate-report.pdf"',
    );
    res.setHeader("X-Render-Time-Ms", Date.now() - startTime);

    return res.send(pdfBuffer);
  } catch (error) {
    // Error handling...
  }
});
```

### PDF Generation Service

```typescript
// src/pdf/pdf-renderer.service.ts
import { renderToBuffer } from "@react-pdf/renderer";

export async function generatePdfWithReactPdf(
  data: EstateReportProps,
): Promise<Buffer> {
  const document = React.createElement(
    EstateReportDocument,
    data,
  ) as React.ReactElement;

  const buffer = await renderToBuffer(document);
  return Buffer.from(buffer);
}
```

---

## Best Practices & Gotchas

### ✅ Do's

1. **Use StyleSheet.create()** for type-safe styles
2. **Pre-calculate positions** for SVG elements
3. **Use fixed dimensions** for charts (no responsive containers)
4. **Inline all styles** - no external CSS
5. **Test with actual data** - edge cases matter

### ❌ Don'ts

1. **Don't use CSS classes** - only inline styles work
2. **Don't use `gap` property** - use margins instead
3. **Don't use external images without caching** - slow
4. **Don't use complex transforms** - limited support
5. **Don't rely on browser fonts** - use registered fonts

### Common Pitfalls

```typescript
// ❌ Wrong - gap not supported
<View style={{ flexDirection: "row", gap: 16 }}>

// ✅ Correct - use margins
<View style={{ flexDirection: "row" }}>
  <View style={{ marginRight: 16 }}>Child 1</View>
  <View>Child 2</View>
</View>
```

```typescript
// ❌ Wrong - conditional returns false
!isPrimary && styles.lightBackground;

// ✅ Correct - use ternary
!isPrimary ? styles.lightBackground : {};
```

---

## Performance

### Benchmarks

| Metric                   | Value              |
| ------------------------ | ------------------ |
| 6-page report generation | ~300-350ms         |
| File size                | ~21KB              |
| Memory usage             | ~50MB (no browser) |
| Concurrent reports       | Scales linearly    |

### Optimization Tips

1. **Memoize calculations** - position calculations, color mappings
2. **Minimize re-renders** - use React.memo for components
3. **Stream large documents** - use renderToStream for huge reports
4. **Cache fonts** - register fonts once at startup

---

## Data Contract

### EstateReportProps

```typescript
interface EstateReportProps {
  clientName: string;
  reportTitle: string;
  reportDate: string;
  brandName: string;

  overview: {
    donutChart: {
      title: string;
      centerLabel: string;
      centerValue: number;
      segments: Array<{
        name: string;
        value: number;
        color: string;
        percentage: number;
      }>;
    };
  };

  trustDetails: {
    pageTitle: string;
    cards: Array<TrustCard>;
  };

  entityStructure: {
    title: string;
    entities: Array<Entity>;
  };

  assetTable: {
    title: string;
    columns: Array<Column>;
    groups: Array<RowGroup>;
  };

  estateFlow: {
    title: string;
    totalValue: number;
    leftColumn: FlowColumn;
    rightColumn: FlowColumn;
  };

  heritageMap: {
    title: string;
    members: Array<FamilyMember>;
  };
}
```

---

## Conclusion

This implementation provides a robust, type-safe, and performant solution for generating complex financial PDF reports. Key advantages:

1. **No browser dependency** - Pure server-side rendering
2. **Consistent output** - Same result on any environment
3. **Fast** - Sub-second generation times
4. **Maintainable** - React component architecture
5. **Extensible** - Easy to add new components

For questions or contributions, refer to the source files in `src/pdf/`.
