# Implementing Complex Estate Planning Reports

Analysis and implementation strategy for wealth management style PDFs based on the provided design.

---

## Image Analysis

### What I See in Your Design

The image shows professional estate planning reports with these key visualizations:

#### 1. **Main Estate Overview (Center)**

- **Donut/Ring Chart** showing $398M estate breakdown
- Multi-segment rings (red, dark teal, light teal)
- Center label with total value
- Legend on the right with:
  - Inside Estate: $334.5M (83.99%)
  - Outside Estate: $63.7M (16.01%)
  - Federal Estate Taxes: $131.8M
- **Stacked Bar Chart** (vertical) on right side
- Color-coded boxes showing estate components

#### 2. **Trust Details Page (Left)**

- "The Doe Family Trust Additional Details"
- Multi-column layout (3-4 columns)
- Hierarchical information structure
- Text-heavy with headers and body content
- Trust types: Credit Shelter Trust, Survivor's Trust, etc.

#### 3. **Entity Structure Chart (Bottom Left)**

- 4 trust entities displayed horizontally
- Each with:
  - Icon (briefcase/folder)
  - Trust name
  - Date
  - Ownership percentage bar
- Organizational chart style

#### 4. **Asset Ownership Table (Bottom Center)**

- Complex data table
- Multiple columns (10+)
- Dollar amounts formatted
- Row grouping/categorization
- Color-coded rows (alternate shading)

#### 5. **Heritage Map (Bottom Right)**

- Family tree / inheritance diagram
- Circular avatars with initials
- Names below each avatar
- Connection lines showing relationships
- Hierarchical structure (grandparents → parents → children)

---

## Current POC Capabilities vs. Required Features

### ✅ Already Supported

- Basic bar charts (simple, not stacked)
- Line charts
- Financial tables (basic)
- Currency formatting
- Multi-page PDFs
- CSS layouts

### ❌ Need to Add

1. **Donut/Ring Charts** (multi-segment circular)
2. **Stacked Bar Charts** (vertical/horizontal)
3. **Progress Bars** (entity ownership %)
4. **Icon Libraries** (briefcase, person, folder icons)
5. **Organizational Charts** (entity structure)
6. **Family Tree/Hierarchy Diagrams** (heritage map)
7. **Complex Multi-Column Tables** (asset ownership)
8. **Avatar Components** (circular with initials)
9. **Advanced Typography** (multiple heading levels, body text)
10. **Color-Coded Sections** (boxes with different backgrounds)

---

## Implementation Strategy

### Phase 1: Chart Enhancements

#### A. Donut/Ring Charts (Recharts)

**Library:** Recharts supports this via `<PieChart>` with `innerRadius`

```typescript
import { PieChart, Pie, Cell, Legend } from 'recharts';

interface DonutChartData {
  name: string;
  value: number;
  color: string;
}

export const DonutChart: React.FC<{ data: DonutChartData[] }> = ({ data }) => {
  const total = data.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="chart-container">
      <PieChart width={400} height={400}>
        <Pie
          data={data}
          cx={200}
          cy={200}
          innerRadius={120}  // Creates the "donut hole"
          outerRadius={180}
          paddingAngle={2}
          dataKey="value"
        >
          {data.map((entry, index) => (
            <Cell key={index} fill={entry.color} />
          ))}
        </Pie>
        {/* Center label */}
        <text
          x={200}
          y={190}
          textAnchor="middle"
          dominantBaseline="middle"
          style={{ fontSize: 14, fill: '#666' }}
        >
          Estimated Total Portfolio
        </text>
        <text
          x={200}
          y={210}
          textAnchor="middle"
          dominantBaseline="middle"
          style={{ fontSize: 24, fontWeight: 'bold' }}
        >
          ${total.toLocaleString()}
        </text>
      </PieChart>
    </div>
  );
};
```

**Schema:**

```typescript
const DonutChartSchema = z.object({
  type: z.literal("CHART_DONUT"),
  data: z.object({
    title: z.string(),
    centerLabel: z.string().optional(),
    segments: z.array(
      z.object({
        name: z.string(),
        value: z.number(),
        color: z.string(),
        percentage: z.number().optional(),
      }),
    ),
  }),
});
```

#### B. Stacked Bar Charts

```typescript
import { BarChart, Bar, XAxis, YAxis } from 'recharts';

export const StackedBarChart: React.FC<Props> = ({ data, series }) => {
  return (
    <BarChart data={data} layout="vertical">
      <XAxis type="number" />
      <YAxis type="category" dataKey="category" />
      {series.map((s) => (
        <Bar
          key={s.name}
          dataKey={s.name}
          stackId="a"  // All bars with same stackId will stack
          fill={s.color}
        />
      ))}
    </BarChart>
  );
};
```

---

### Phase 2: Organizational Components

#### A. Entity Structure Chart

**Approach:** Use Flexbox layout with custom icons

```typescript
interface EntityNode {
  name: string;
  date: string;
  ownership: number; // 0-100
  icon: 'briefcase' | 'folder' | 'building';
}

export const EntityChart: React.FC<{ entities: EntityNode[] }> = ({ entities }) => {
  return (
    <div className="entity-chart flex justify-between">
      {entities.map((entity) => (
        <div key={entity.name} className="entity-node">
          {/* Icon */}
          <div className="entity-icon">
            {entity.icon === 'briefcase' && <BriefcaseIcon />}
          </div>

          {/* Name */}
          <h4>{entity.name}</h4>
          <p className="text-sm text-gray-600">{entity.date}</p>

          {/* Progress bar */}
          <div className="progress-bar">
            <div
              className="progress-fill"
              style={{ width: `${entity.ownership}%` }}
            />
          </div>
          <p className="text-sm">{entity.ownership}%</p>
        </div>
      ))}
    </div>
  );
};
```

**CSS for Progress Bar:**

```css
.progress-bar {
  width: 100%;
  height: 8px;
  background: #e5e7eb;
  border-radius: 4px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: #1e40af;
  transition: width 0.3s ease;
}
```

#### B. Heritage Map (Family Tree)

**Approach:** SVG-based diagram or CSS Grid

**Option 1: React component with SVG lines**

```typescript
interface FamilyMember {
  id: string;
  name: string;
  initials: string;
  parentId?: string;
  generation: number; // 0 = grandparents, 1 = parents, 2 = children
}

export const HeritageMap: React.FC<{ members: FamilyMember[] }> = ({ members }) => {
  // Group by generation
  const generations = groupByGeneration(members);

  return (
    <div className="heritage-map">
      <svg className="connection-lines">
        {/* Draw lines between connected members */}
        {members.map((member) => {
          if (member.parentId) {
            return <LineConnector key={member.id} from={member.parentId} to={member.id} />;
          }
        })}
      </svg>

      {generations.map((gen, level) => (
        <div key={level} className="generation-row">
          {gen.map((member) => (
            <Avatar
              key={member.id}
              initials={member.initials}
              name={member.name}
            />
          ))}
        </div>
      ))}
    </div>
  );
};
```

**Option 2: Use a library**

- **react-organizational-chart** - Org chart library
- **react-family-tree** - Family tree specific
- **d3-hierarchy** - Low-level control with D3.js

**Recommended:** Build custom with CSS Grid + SVG for PDF reliability

```typescript
export const Avatar: React.FC<{ initials: string; name: string }> = ({ initials, name }) => {
  return (
    <div className="avatar-container">
      <div className="avatar-circle">
        <span>{initials}</span>
      </div>
      <p className="avatar-name">{name}</p>
    </div>
  );
};
```

**CSS:**

```css
.avatar-circle {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: #1e40af;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 20px;
}

.avatar-name {
  text-align: center;
  margin-top: 8px;
  font-size: 12px;
}
```

---

### Phase 3: Advanced Tables

#### Complex Multi-Column Table

Your Asset Ownership table has:

- Row grouping (expandable sections?)
- Alternating row colors
- Multiple data types (text, currency, percentages)
- Column alignment (left, right, center)
- Subtotals

**Enhanced Table Component:**

```typescript
interface ComplexTableColumn {
  key: string;
  label: string;
  format: 'text' | 'currency' | 'percentage' | 'number';
  align?: 'left' | 'center' | 'right';
  width?: string;
}

interface TableRowGroup {
  groupName: string;
  rows: Record<string, any>[];
  showSubtotal?: boolean;
}

export const ComplexTable: React.FC<{
  columns: ComplexTableColumn[];
  groups: TableRowGroup[];
}> = ({ columns, groups }) => {
  return (
    <table className="complex-table">
      <thead>
        <tr>
          {columns.map((col) => (
            <th
              key={col.key}
              style={{
                textAlign: col.align || 'left',
                width: col.width
              }}
            >
              {col.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {groups.map((group, groupIndex) => (
          <React.Fragment key={groupIndex}>
            {/* Group header */}
            <tr className="group-header">
              <td colSpan={columns.length}>
                <strong>{group.groupName}</strong>
              </td>
            </tr>

            {/* Group rows */}
            {group.rows.map((row, rowIndex) => (
              <tr
                key={rowIndex}
                className={rowIndex % 2 === 0 ? 'bg-gray-50' : 'bg-white'}
              >
                {columns.map((col) => (
                  <td
                    key={col.key}
                    style={{ textAlign: col.align }}
                  >
                    {formatValue(row[col.key], col.format)}
                  </td>
                ))}
              </tr>
            ))}

            {/* Subtotal row */}
            {group.showSubtotal && (
              <tr className="subtotal-row">
                <td><strong>Subtotal</strong></td>
                {columns.slice(1).map((col) => (
                  <td key={col.key}>
                    {calculateSubtotal(group.rows, col.key, col.format)}
                  </td>
                ))}
              </tr>
            )}
          </React.Fragment>
        ))}
      </tbody>
    </table>
  );
};
```

---

### Phase 4: Icon System

#### Options for Icons in PDF

**Option 1: SVG Icons (Recommended)**

- Inline SVG in React components
- Scales perfectly in PDF
- No external dependencies

```typescript
export const BriefcaseIcon: React.FC<{ size?: number }> = ({ size = 24 }) => {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M14 6V4h-4v2h4zM4 8v11h16V8H4zm16-2c1.11 0 2 .89 2 2v11c0 1.11-.89 2-2 2H4c-1.11 0-2-.89-2-2l.01-11c0-1.11.88-2 1.99-2h4V4c0-1.11.89-2 2-2h4c1.11 0 2 .89 2 2v2h4z"/>
    </svg>
  );
};

export const PersonIcon: React.FC<{ size?: number }> = ({ size = 24 }) => {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
    </svg>
  );
};
```

**Option 2: Icon Font (like Font Awesome)**

- Easier to use
- May not render perfectly in PDF
- Requires font loading

**Option 3: Icon Library**

- **react-icons** - Large collection (Font Awesome, Material, etc.)
- **heroicons** - Tailwind's icon set
- **lucide-react** - Modern icon library

```typescript
import { Briefcase, User, Building } from 'react-icons/fa';

export const EntityIcon: React.FC<{ type: string }> = ({ type }) => {
  const IconComponent = {
    briefcase: Briefcase,
    user: User,
    building: Building
  }[type];

  return <IconComponent size={32} color="#1e40af" />;
};
```

---

### Phase 5: Multi-Column Text Layouts

For the "Trust Details" section with 3-4 columns:

```typescript
export const MultiColumnText: React.FC<{
  title: string;
  columns: Array<{ header: string; content: string[] }>;
}> = ({ title, columns }) => {
  return (
    <div className="multi-column-section">
      <h2>{title}</h2>
      <div className="columns-container">
        {columns.map((col, index) => (
          <div key={index} className="column">
            <h3>{col.header}</h3>
            {col.content.map((item, i) => (
              <p key={i}>{item}</p>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
```

**CSS for columns:**

```css
.columns-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  page-break-inside: avoid;
}

.column {
  break-inside: avoid; /* Prevent column splitting across pages */
}
```

---

## Recommended Libraries to Add

### 1. React Icons

```bash
npm install react-icons
```

**Why:** 10,000+ icons from Font Awesome, Material, etc.

### 2. D3.js (Optional - for complex diagrams)

```bash
npm install d3 @types/d3
```

**Why:** Full control over custom visualizations (family trees, org charts)

### 3. React Flow (Optional - for diagrams)

```bash
npm install reactflow
```

**Why:** Interactive node-based diagrams, good for org charts

---

## Updated Zod Schemas

```typescript
// Donut Chart
export const DonutChartSchema = z.object({
  type: z.literal("CHART_DONUT"),
  data: z.object({
    title: z.string(),
    centerLabel: z.string().optional(),
    centerValue: z.number().optional(),
    segments: z.array(
      z.object({
        name: z.string(),
        value: z.number(),
        color: z.string(),
        percentage: z.number().optional(),
      }),
    ),
  }),
});

// Entity Structure
export const EntityChartSchema = z.object({
  type: z.literal("ENTITY_CHART"),
  data: z.object({
    title: z.string(),
    entities: z.array(
      z.object({
        name: z.string(),
        date: z.string(),
        ownership: z.number().min(0).max(100),
        icon: z.enum(["briefcase", "folder", "building", "user"]),
      }),
    ),
  }),
});

// Heritage Map
export const HeritageMapSchema = z.object({
  type: z.literal("HERITAGE_MAP"),
  data: z.object({
    title: z.string(),
    members: z.array(
      z.object({
        id: z.string(),
        name: z.string(),
        initials: z.string().length(2),
        parentId: z.string().optional(),
        generation: z.number().min(0),
      }),
    ),
  }),
});

// Complex Table
export const ComplexTableSchema = z.object({
  type: z.literal("COMPLEX_TABLE"),
  data: z.object({
    title: z.string(),
    columns: z.array(
      z.object({
        key: z.string(),
        label: z.string(),
        format: z.enum(["text", "currency", "percentage", "number"]),
        align: z.enum(["left", "center", "right"]).optional(),
        width: z.string().optional(),
      }),
    ),
    groups: z.array(
      z.object({
        groupName: z.string(),
        rows: z.array(z.record(z.union([z.string(), z.number()]))),
        showSubtotal: z.boolean().optional(),
      }),
    ),
  }),
});

// Update main union
export const ComponentSchema = z.discriminatedUnion("type", [
  // Existing
  ExecutiveSummarySchema,
  FinancialTableSchema,
  BarChartDoubleSchema,
  TrendLineChartSchema,
  // New
  DonutChartSchema,
  EntityChartSchema,
  HeritageMapSchema,
  ComplexTableSchema,
]);
```

---

## Implementation Roadmap

### Week 1: Chart Enhancements

- [ ] Add Donut Chart component with Recharts
- [ ] Add Stacked Bar Chart variant
- [ ] Test both in PDF output
- [ ] Update schemas and stitcher

### Week 2: Icon System & Basic Diagrams

- [ ] Install react-icons
- [ ] Create icon component wrapper
- [ ] Build Entity Chart component
- [ ] Add progress bar atom
- [ ] Test in PDF

### Week 3: Complex Tables

- [ ] Build ComplexTable component
- [ ] Add row grouping logic
- [ ] Implement subtotal calculations
- [ ] Style alternating rows
- [ ] Test page breaks with large tables

### Week 4: Family Tree

- [ ] Design Heritage Map layout
- [ ] Build Avatar component
- [ ] Implement connection lines (SVG or CSS)
- [ ] Test hierarchical positioning
- [ ] Ensure PDF rendering quality

### Week 5: Multi-Column Layouts

- [ ] Build multi-column text component
- [ ] Test CSS column breaks
- [ ] Ensure print-friendly layout
- [ ] Add to component registry

### Week 6: Integration & Polish

- [ ] Create sample "Estate Report" manifest
- [ ] Test full report generation
- [ ] Optimize PDF performance
- [ ] Fix any rendering issues
- [ ] Document new components

---

## Sample JSON Manifest for Estate Report

```json
{
  "report_title": "Estimated Estate Overview",
  "subtitle": "John Doe & Jane Doe",
  "pages": [
    {
      "layout": "single_column",
      "components": [
        {
          "type": "CHART_DONUT",
          "data": {
            "title": "Estimated Total Portfolio",
            "centerLabel": "Total Estate Value",
            "centerValue": 398304420,
            "segments": [
              {
                "name": "Inside Estate",
                "value": 334531600,
                "color": "#0d9488",
                "percentage": 83.99
              },
              {
                "name": "Outside Estate",
                "value": 63772820,
                "color": "#5eead4",
                "percentage": 16.01
              },
              {
                "name": "Federal Estate Tax",
                "value": 131852640,
                "color": "#dc2626"
              }
            ]
          }
        }
      ]
    },
    {
      "layout": "single_column",
      "components": [
        {
          "type": "ENTITY_CHART",
          "data": {
            "title": "Entity Structure Chart",
            "entities": [
              {
                "name": "The Daniel Doe Irrevocable Trust",
                "date": "dtd 4/1/2018",
                "ownership": 45,
                "icon": "briefcase"
              },
              {
                "name": "The Andrew Doe Irrevocable Trust",
                "date": "dtd 4/1/2018",
                "ownership": 55,
                "icon": "briefcase"
              }
            ]
          }
        }
      ]
    },
    {
      "layout": "single_column",
      "components": [
        {
          "type": "HERITAGE_MAP",
          "data": {
            "title": "Heritage Map",
            "members": [
              {
                "id": "john",
                "name": "John Doe",
                "initials": "JD",
                "generation": 0
              },
              {
                "id": "jane",
                "name": "Jane Doe",
                "initials": "JD",
                "generation": 0
              },
              {
                "id": "daniel",
                "name": "Daniel Doe",
                "initials": "DD",
                "parentId": "john",
                "generation": 1
              }
            ]
          }
        }
      ]
    }
  ]
}
```

---

## Challenges & Solutions

### Challenge 1: SVG Rendering in PDF

**Problem:** Complex SVGs may not render correctly in Puppeteer

**Solutions:**

- Keep SVGs simple
- Use Recharts (battle-tested with Puppeteer)
- Test frequently
- Consider Canvas fallback for complex diagrams

### Challenge 2: Icon Fonts in PDF

**Problem:** Icon fonts might not load in headless Chrome

**Solutions:**

- Use inline SVG icons (recommended)
- Bundle fonts locally
- Use react-icons with tree shaking

### Challenge 3: Family Tree Layout

**Problem:** Calculating positions for connected nodes

**Solutions:**

- Use CSS Grid for basic positioning
- D3.js hierarchy for complex trees
- Pre-calculate positions on server
- Use react-organizational-chart library

### Challenge 4: Page Breaks with Complex Components

**Problem:** Donut charts or org charts split across pages

**Solutions:**

```css
.donut-chart-container,
.entity-chart,
.heritage-map {
  page-break-inside: avoid;
  break-inside: avoid;
}
```

### Challenge 5: Performance with Many Components

**Problem:** Large reports may take 10+ seconds

**Solutions:**

- Implement caching
- Use browser pool (multiple Puppeteer instances)
- Lazy render (generate sections on demand)
- Optimize React rendering (memoization)

---

## Estimated Effort

| Component             | Complexity | Time Estimate   |
| --------------------- | ---------- | --------------- |
| Donut Chart           | Low        | 4-6 hours       |
| Stacked Bars          | Low        | 2-3 hours       |
| Entity Chart          | Medium     | 8-10 hours      |
| Complex Table         | Medium     | 10-12 hours     |
| Heritage Map          | High       | 16-20 hours     |
| Icon System           | Low        | 2-4 hours       |
| Multi-column Layout   | Low        | 3-4 hours       |
| Integration & Testing | Medium     | 8-10 hours      |
| **Total**             | -          | **50-70 hours** |

---

## Priority Recommendation

**Phase 1 (High Priority):**

1. Donut Chart - Most visually impactful
2. Complex Table - Essential for data
3. Icon System - Needed for Entity Chart

**Phase 2 (Medium Priority):** 4. Entity Chart - Shows structure 5. Stacked Bars - Additional data viz

**Phase 3 (Lower Priority):** 6. Heritage Map - Complex but specialized 7. Multi-column layouts - Can use existing grid

---

## Conclusion

Your estate planning reports are **achievable** with the current POC architecture. The main additions needed are:

1. **New chart types** (donut, stacked bars) - Easy with Recharts
2. **Icon system** - Straightforward with react-icons or SVG
3. **Organizational diagrams** - Medium complexity
4. **Family tree** - Most complex, consider using a library

The React + Puppeteer approach handles all of this well. The key is building each component with PDF rendering in mind (SVG-based, proper page breaks, static rendering).

**Recommended Next Step:** Start with the Donut Chart component to prove out the approach, then build the others incrementally.
