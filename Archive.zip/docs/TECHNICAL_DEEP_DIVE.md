# Project Gutenberg - Technical Deep Dive

A comprehensive guide to the technologies, libraries, and concepts used in this PDF generation engine.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Core Technologies](#core-technologies)
3. [Key Libraries](#key-libraries)
4. [Design Patterns & Concepts](#design-patterns--concepts)
5. [Data Flow](#data-flow)
6. [Further Research Resources](#further-research-resources)

---

## Architecture Overview

### The Big Picture

```
JSON Manifest → Validation → React SSR → HTML → Puppeteer → PDF
     ↓             ↓            ↓          ↓         ↓         ↓
   Input         Zod      Components   String   Chromium   Output
```

**Core Idea:** Treat PDF generation like web development. Build components in React, render to HTML, then "print" using a headless browser.

### Why This Approach?

1. **Separation of Concerns** - Content (JSON) is separate from presentation (React)
2. **Type Safety** - Schemas validate data before rendering
3. **Familiar Tools** - Use web dev skills (React, CSS) instead of PDF-specific libraries
4. **Rich Graphics** - SVG charts render perfectly in PDF
5. **Flexibility** - Easy to add new component types

---

## Core Technologies

### 1. Node.js (Runtime)

**What:** JavaScript runtime built on Chrome's V8 engine  
**Version Used:** 20 LTS  
**Role in POC:** Server runtime for API and PDF generation

**Why Node.js?**

- Native compatibility with Puppeteer (both use Chrome/V8)
- Async/await for handling multiple PDF requests
- Rich ecosystem (Express, React SSR libraries)
- ES Modules support for modern JavaScript

**Key Concept: Event Loop**

```javascript
// Node handles multiple requests without blocking
app.post("/generate-pdf", async (req, res) => {
  const pdf = await pdfService.generatePDF(html); // Non-blocking
  res.send(pdf);
});
```

**Learn More:**

- [Node.js Official Docs](https://nodejs.org/docs/)
- [Understanding the Node.js Event Loop](https://nodejs.org/en/docs/guides/event-loop-timers-and-nexttick/)

---

### 2. TypeScript (Language)

**What:** Typed superset of JavaScript  
**Version Used:** 5.x  
**Role in POC:** Type safety across entire codebase

**Why TypeScript?**

- Catches errors at compile-time (before runtime)
- IntelliSense/autocomplete in IDE
- Self-documenting code via type annotations
- Works seamlessly with React and Zod

**Example from POC:**

```typescript
interface PDFGenerationOptions {
  format?: "A4" | "Letter"; // Only these two strings allowed
  landscape?: boolean;
}

// TypeScript prevents: format: "B5" ← Compile error!
```

**Key Features Used:**

- Interfaces for type definitions
- Generics for reusable types
- Union types for discriminated unions (component types)
- `strict` mode for maximum type checking

**Learn More:**

- [TypeScript Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)
- [TypeScript Deep Dive](https://basarat.gitbook.io/typescript/)

---

### 3. Express (Web Framework)

**What:** Minimal web framework for Node.js  
**Version Used:** 4.x  
**Role in POC:** REST API server

**Why Express?**

- Lightweight and unopinionated
- Middleware architecture (CORS, JSON parsing)
- Route handling for `/generate-pdf` endpoint
- Large ecosystem of plugins

**Middleware Pattern:**

```javascript
app.use(express.json()); // Parse JSON bodies
app.use(cors()); // Enable CORS
app.post("/generate-pdf", handler); // Route handler
```

**Learn More:**

- [Express.js Official Guide](https://expressjs.com/en/guide/routing.html)
- [Understanding Express Middleware](https://expressjs.com/en/guide/using-middleware.html)

---

### 4. Puppeteer (Headless Browser)

**What:** Node library to control Chromium/Chrome via DevTools Protocol  
**Version Used:** 22.x  
**Role in POC:** HTML to PDF conversion

**Why Puppeteer?**

- Full Chrome rendering engine (handles CSS, fonts, SVG perfectly)
- Native PDF generation with paged media support
- Mature API with excellent documentation
- Used by Google (battle-tested)

**How It Works:**

```javascript
const browser = await puppeteer.launch({ headless: true });
const page = await browser.newPage();
await page.setContent(htmlString); // Load HTML
const pdf = await page.pdf({
  // Print to PDF
  format: "A4",
  printBackground: true,
});
```

**Key Concepts:**

- **Headless Mode** - Browser runs without GUI (faster)
- **Browser Context** - Isolated browser session
- **Page** - Individual tab/window
- **DevTools Protocol** - Communication layer with browser

**PDF-Specific Features:**

- Page margins
- Headers/footers with dynamic content
- Page numbers (`<span class="pageNumber"></span>`)
- Background graphics rendering
- CSS Paged Media support

**Learn More:**

- [Puppeteer API Docs](https://pptr.dev/)
- [Chrome DevTools Protocol](https://chromedevtools.github.io/devtools-protocol/)
- [CSS Paged Media Spec](https://www.w3.org/TR/css-page-3/)

---

## Key Libraries

### 5. React (UI Library)

**What:** Component-based UI library  
**Version Used:** 18.x  
**Role in POC:** Component templating system

**Why React?**

- Component reusability (atoms → molecules → organisms)
- JSX syntax for readable templates
- Server-Side Rendering (SSR) via `ReactDOMServer`
- No browser needed (unlike browser-based React)

**Server-Side Rendering (SSR):**

```typescript
import ReactDOMServer from 'react-dom/server';

const htmlString = ReactDOMServer.renderToStaticMarkup(
  <ReportTemplate manifest={data} />
);
// Returns: "<html><body>...</body></html>"
```

**Key Difference: Static vs Client-Side:**

- **Client React:** Runs in browser, interactive, needs hydration
- **Server React (our use):** Renders once to static HTML, no JavaScript in output

**Component Pattern in POC:**

```typescript
// Functional component
export const Currency: React.FC<CurrencyProps> = ({ value }) => {
  const formatted = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(value);

  return <span>{formatted}</span>;
};
```

**Learn More:**

- [React Server Components](https://react.dev/reference/react-dom/server)
- [ReactDOMServer API](https://react.dev/reference/react-dom/server/renderToStaticMarkup)

---

### 6. Recharts (Chart Library)

**What:** React-based charting library built on D3  
**Version Used:** 2.x  
**Role in POC:** Generate bar charts and line charts

**Why Recharts?**

- Declarative API (React-style)
- SVG output (vector graphics, not canvas)
- Responsive containers
- Built on D3 (data visualization standard)

**SVG vs Canvas for PDF:**
| Feature | SVG (Recharts) | Canvas (Chart.js) |
|---------|----------------|-------------------|
| Output | Vector graphics | Raster image |
| Zoom | Stays crisp | Pixelates |
| PDF rendering | Perfect | Quality depends on resolution |
| File size | Smaller | Larger |

**Usage Example:**

```typescript
<BarChart data={chartData}>
  <XAxis dataKey="name" />
  <YAxis />
  <Bar dataKey="revenue" fill="#1E40AF" />
</BarChart>
```

**How It Works in POC:**

1. Recharts generates SVG markup
2. React SSR converts to HTML string
3. Puppeteer renders SVG in Chromium
4. PDF preserves vector graphics

**Learn More:**

- [Recharts Documentation](https://recharts.org/en-US/)
- [SVG vs Canvas](https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial/SVG_and_Canvas)

---

### 7. Zod (Schema Validation)

**What:** TypeScript-first schema validation library  
**Version Used:** 3.x  
**Role in POC:** Validate JSON manifests before rendering

**Why Zod?**

- Type inference (TypeScript types from schemas)
- Runtime validation (catches bad data)
- Excellent error messages
- Composable schemas (build complex from simple)

**Schema Definition:**

```typescript
const ExecutiveSummarySchema = z.object({
  type: z.literal("EXECUTIVE_SUMMARY"),
  data: z.object({
    headline: z.string().max(100),
    sentiment: z.enum(["POSITIVE", "NEUTRAL", "NEGATIVE"]),
    text: z.string().max(500),
  }),
});

// Infer TypeScript type from schema
type ExecutiveSummary = z.infer<typeof ExecutiveSummarySchema>;
```

**Validation Flow:**

```typescript
const result = ReportManifestSchema.safeParse(userInput);

if (!result.success) {
  // result.error.errors contains detailed info
  console.log(result.error.errors);
  // [{ path: ['pages', 0, 'components'], message: 'Required' }]
}
```

**Key Concepts:**

- **Schema** - Definition of valid data structure
- **Parse** - Validate and transform data
- **Inference** - Generate TypeScript types from schemas
- **Discriminated Union** - Different types based on a field (our `type` field)

**Learn More:**

- [Zod Documentation](https://zod.dev/)
- [TypeScript Discriminated Unions](https://www.typescriptlang.org/docs/handbook/2/narrowing.html#discriminated-unions)

---

### 8. Docker (Containerization)

**What:** Platform for containerizing applications  
**Role in POC:** Package app with all dependencies (including Chromium)

**Why Docker?**

- Consistent environment (dev = staging = prod)
- Bundles Chromium with all required fonts/libs
- Eliminates "works on my machine" issues
- Easy deployment to cloud platforms

**Dockerfile Strategy:**

```dockerfile
# Multi-stage build
FROM node:20-slim AS builder
# ... build TypeScript ...

FROM node:20-slim
# Install Chromium + dependencies
RUN apt-get install chromium fonts-liberation ...
# Copy built app
```

**Critical for PDF Generation:**
Puppeteer needs:

- Chromium binary
- Font libraries (fonts-liberation)
- Graphics libraries (libgbm1, libnss3)
- Audio libraries (libasound2)

**Without Docker:** Users must manually install ~15 system packages  
**With Docker:** Everything bundled in one image

**Learn More:**

- [Docker Getting Started](https://docs.docker.com/get-started/)
- [Multi-stage Builds](https://docs.docker.com/build/building/multi-stage/)
- [Puppeteer Docker Guide](https://pptr.dev/guides/docker)

---

## Design Patterns & Concepts

### 9. Atomic Design Pattern

**What:** Methodology for building UI component systems  
**Hierarchy:** Atoms → Molecules → Organisms → Templates → Pages

**How We Use It:**

```
Atoms (Basic elements)
├── Badge.tsx            (colored pill)
├── Currency.tsx         (formatted money)
├── Percentage.tsx       (formatted %)
└── SentimentIcon.tsx    (↑↓→ arrows)

Molecules (Combinations of atoms)
├── ExecutiveSummary.tsx (Icon + Text + Badges)
└── FinancialTable.tsx   (Currency + Table structure)

Organisms (Complex components)
└── (Charts, full sections)

Templates
└── ReportTemplate.tsx   (Full page layout)
```

**Benefits:**

- **Reusability** - Currency atom used in multiple molecules
- **Testability** - Test atoms independently
- **Consistency** - Same atoms = consistent look
- **Maintainability** - Change atom, updates everywhere

**Learn More:**

- [Atomic Design by Brad Frost](https://atomicdesign.bradfrost.com/)
- [Thinking in React](https://react.dev/learn/thinking-in-react)

---

### 10. Server-Side Rendering (SSR)

**What:** Rendering React components to HTML on the server  
**Alternative:** Client-Side Rendering (CSR) - React runs in browser

**Why SSR for PDF?**

- No browser needed on client side
- Faster (no JavaScript download/parse)
- Pure HTML output (no hydration overhead)
- SEO-friendly (bonus for web use)

**Process:**

```
React Component → renderToStaticMarkup() → HTML String → Puppeteer
```

**Key Difference from CSR:**

```typescript
// CSR (Client-Side Rendering)
ReactDOM.render(<App />, document.getElementById('root'));
// Outputs: Interactive React app with event handlers

// SSR (Server-Side Rendering) - our approach
const html = ReactDOMServer.renderToStaticMarkup(<App />);
// Outputs: Static HTML string, no JavaScript
```

**Learn More:**

- [React SSR Guide](https://react.dev/reference/react-dom/server)
- [CSR vs SSR vs SSG](https://www.patterns.dev/posts/rendering-introduction)

---

### 11. CSS Paged Media

**What:** CSS specifications for printed/paginated media  
**Standard:** W3C CSS Paged Media Module Level 3

**Key Features:**

```css
@page {
  size: A4;
  margin: 20mm;
}

/* Avoid breaking inside element */
.chart-container {
  page-break-inside: avoid;
}

/* Force new page */
.page-break {
  page-break-before: always;
}

/* Prevent widows/orphans */
p {
  orphans: 3; /* Min lines at bottom */
  widows: 3; /* Min lines at top */
}
```

**Pseudo-elements in Headers/Footers:**

```html
<!-- Puppeteer injects these -->
<span class="pageNumber"></span>
<!-- Current page -->
<span class="totalPages"></span>
<!-- Total pages -->
```

**Learn More:**

- [CSS Paged Media Spec](https://www.w3.org/TR/css-page-3/)
- [Print CSS Guide](https://www.smashingmagazine.com/2015/01/designing-for-print-with-css/)

---

### 12. Discriminated Unions (TypeScript Pattern)

**What:** Type-safe way to handle multiple related types  
**Used In:** Our component system

**Problem:** Different components have different data structures

```typescript
// Bad approach - no type safety
interface Component {
  type: string;
  data: any; // ← No validation!
}
```

**Solution: Discriminated Union**

```typescript
type Component =
  | { type: 'EXECUTIVE_SUMMARY', data: ExecutiveSummaryData }
  | { type: 'FINANCIAL_TABLE', data: FinancialTableData }
  | { type: 'CHART_BAR_DOUBLE', data: BarChartData };

// TypeScript narrows the type based on 'type' field
function renderComponent(component: Component) {
  switch (component.type) {
    case 'EXECUTIVE_SUMMARY':
      return <ExecutiveSummary data={component.data} />; // ✓ Type-safe
    case 'FINANCIAL_TABLE':
      return <FinancialTable data={component.data} />;   // ✓ Type-safe
  }
}
```

**Combined with Zod:**

```typescript
const ComponentSchema = z.discriminatedUnion("type", [
  ExecutiveSummarySchema,
  FinancialTableSchema,
  BarChartDoubleSchema,
]);

// Validates AND provides types
```

**Learn More:**

- [TypeScript Discriminated Unions](https://www.typescriptlang.org/docs/handbook/2/narrowing.html#discriminated-unions)
- [Zod Discriminated Unions](https://zod.dev/?id=discriminated-unions)

---

### 13. Singleton Pattern (Browser Management)

**What:** Ensure only one instance of a class exists  
**Used In:** Puppeteer browser instance

**Why?**

- Launching browser is expensive (~500ms)
- Multiple instances waste memory
- Reusing browser = faster PDF generation

**Implementation:**

```typescript
class PDFService {
  private browser: Browser | null = null;

  async initialize() {
    if (!this.browser) {
      // ← Singleton check
      this.browser = await puppeteer.launch();
    }
  }
}

// Export singleton instance
export const pdfService = new PDFService();
```

**Trade-offs:**

- **Pro:** Fast subsequent requests
- **Con:** Single point of failure (if browser crashes, all requests fail)
- **Solution:** Could upgrade to browser pool (multiple instances)

**Learn More:**

- [Singleton Pattern](https://refactoring.guru/design-patterns/singleton)
- [Object Pool Pattern](https://en.wikipedia.org/wiki/Object_pool_pattern)

---

### 14. Intl API (Internationalization)

**What:** Built-in JavaScript API for formatting numbers, dates, currencies  
**Used In:** Currency and Percentage atoms

**Number Formatting:**

```typescript
// Currency
new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
}).format(120000);
// → "$120,000.00"

// Percentage
new Intl.NumberFormat("en-US", {
  style: "percent",
  minimumFractionDigits: 1,
}).format(0.083);
// → "8.3%"
```

**Benefits:**

- Locale-aware (handles different regions)
- No external library needed
- Handles edge cases (negative numbers, large numbers)

**Learn More:**

- [Intl.NumberFormat MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat)
- [i18n Best Practices](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl)

---

## Data Flow

### Complete Request Lifecycle

```mermaid
sequenceDiagram
    participant Client
    participant Express
    participant Stitcher
    participant Zod
    participant Renderer
    participant React
    participant Puppeteer
    participant Chromium

    Client->>Express: POST /generate-pdf<br/>(JSON manifest)
    Express->>Stitcher: Process manifest
    Stitcher->>Zod: Validate schema
    alt Invalid schema
        Zod-->>Express: 400 Validation Error
        Express-->>Client: Error response
    end
    Zod-->>Stitcher: Valid manifest
    Stitcher->>Renderer: Generate HTML
    Renderer->>React: Render components
    React-->>Renderer: HTML string
    Renderer-->>Stitcher: Complete HTML
    Stitcher->>Puppeteer: Generate PDF
    Puppeteer->>Chromium: Load HTML
    Chromium->>Chromium: Render page<br/>(CSS, SVG, fonts)
    Chromium->>Chromium: Print to PDF
    Chromium-->>Puppeteer: PDF buffer
    Puppeteer-->>Express: PDF bytes
    Express-->>Client: application/pdf
```

### Detailed Step Breakdown

**1. Request Arrives**

```typescript
app.post('/generate-pdf', async (req, res) => {
  const manifest = req.body;  // JSON manifest
```

**2. Schema Validation**

```typescript
const result = stitcherService.validateManifest(manifest);
if (!result.success) {
  return res.status(400).json({ errors: result.errors });
}
```

**3. React Rendering**

```typescript
const reactElement = React.createElement(ReportTemplate, { manifest });
const htmlContent = ReactDOMServer.renderToStaticMarkup(reactElement);
```

**4. HTML Document Assembly**

```typescript
const fullHTML = `
<!DOCTYPE html>
<html>
  <head>
    <style>${printCSS}</style>
  </head>
  <body>${htmlContent}</body>
</html>
`;
```

**5. Puppeteer Processing**

```typescript
const page = await browser.newPage();
await page.setContent(fullHTML, { waitUntil: "networkidle0" });
await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait for charts
const pdf = await page.pdf({
  format: "A4",
  printBackground: true,
});
```

**6. Response**

```typescript
res.setHeader("Content-Type", "application/pdf");
res.send(pdf); // Binary PDF data
```

---

## Further Research Resources

### Beginner Level

**Node.js & TypeScript**

- [Node.js Official Tutorial](https://nodejs.org/en/docs/guides/getting-started-guide/)
- [TypeScript for Beginners](https://www.typescriptlang.org/docs/handbook/typescript-from-scratch.html)
- [Understanding async/await](https://javascript.info/async-await)

**React Basics**

- [React Official Tutorial](https://react.dev/learn)
- [Thinking in React](https://react.dev/learn/thinking-in-react)
- [Server Components Deep Dive](https://react.dev/reference/react/use-server)

**PDF Generation**

- [Puppeteer Quick Start](https://pptr.dev/guides/what-is-puppeteer)
- [CSS for Print](https://www.smashingmagazine.com/2015/01/designing-for-print-with-css/)

### Intermediate Level

**Architecture Patterns**

- [Atomic Design Methodology](https://atomicdesign.bradfrost.com/table-of-contents/)
- [Design Patterns in TypeScript](https://refactoring.guru/design-patterns/typescript)
- [REST API Best Practices](https://restfulapi.net/)

**Advanced TypeScript**

- [TypeScript Generics](https://www.typescriptlang.org/docs/handbook/2/generics.html)
- [Advanced Types](https://www.typescriptlang.org/docs/handbook/2/types-from-types.html)
- [Zod Advanced Usage](https://zod.dev/?id=advanced)

**Docker & DevOps**

- [Docker Best Practices](https://docs.docker.com/develop/dev-best-practices/)
- [Multi-stage Builds](https://docs.docker.com/build/building/multi-stage/)

### Advanced Level

**Performance Optimization**

- [Node.js Performance Best Practices](https://nodejs.org/en/docs/guides/simple-profiling/)
- [Puppeteer Performance](https://pptr.dev/guides/performance)
- [Memory Management in Node.js](https://nodejs.org/en/docs/guides/simple-profiling/)

**Scaling Strategies**

- [Horizontal Scaling with PM2](https://pm2.keymetrics.io/docs/usage/cluster-mode/)
- [Browser Pool Management](https://github.com/GoogleChrome/puppeteer/issues/3120)
- [Microservices Architecture](https://microservices.io/)

**Testing**

- [Testing React Components](https://react.dev/learn/testing)
- [Puppeteer Testing](https://pptr.dev/guides/testing)
- [Integration Testing with Jest](https://jestjs.io/docs/tutorial-react)

### Books & Courses

**Recommended Reading**

1. **"Designing Data-Intensive Applications"** by Martin Kleppmann  
   _Why:_ Understand system architecture at scale

2. **"Node.js Design Patterns"** by Mario Casciaro  
   _Why:_ Advanced Node.js patterns and best practices

3. **"TypeScript Quickly"** by Yakov Fain & Anton Moiseev  
   _Why:_ Deep dive into TypeScript features

4. **"Fullstack React"** by Anthony Accomazzo  
   _Why:_ Complete React patterns including SSR

**Online Courses**

- [Frontend Masters: TypeScript Fundamentals](https://frontendmasters.com/courses/typescript-v3/)
- [Udemy: Node.js - The Complete Guide](https://www.udemy.com/course/nodejs-the-complete-guide/)
- [Epic React by Kent C. Dodds](https://epicreact.dev/)

### Research Topics for Deep Dives

1. **Headless Browser Architecture**
   - Chrome DevTools Protocol
   - V8 JavaScript Engine
   - Renderer Process vs Browser Process

2. **PDF Standards**
   - PDF/A (archival)
   - PDF/X (printing)
   - Metadata embedding

3. **Chart Rendering Techniques**
   - SVG vs Canvas vs WebGL
   - D3.js deep dive
   - Data visualization principles

4. **Type Systems**
   - Static vs Dynamic typing
   - Structural typing (TypeScript)
   - Dependent types

5. **Containerization**
   - Container orchestration (Kubernetes)
   - Image optimization
   - Security best practices

---

## Glossary

**API (Application Programming Interface)** - Contract between software components  
**Async/Await** - Modern way to handle asynchronous operations in JavaScript  
**Buffer** - Binary data representation in Node.js  
**CSR (Client-Side Rendering)** - Rendering in the browser  
**Docker Image** - Packaged application with all dependencies  
**Headless Browser** - Browser without GUI  
**Hydration** - Attaching event handlers to server-rendered HTML  
**Middleware** - Function that processes requests before they reach route handler  
**Promise** - Object representing eventual completion of async operation  
**Schema** - Structure definition for data validation  
**SSR (Server-Side Rendering)** - Rendering React on the server  
**SVG (Scalable Vector Graphics)** - XML-based vector image format  
**Type Inference** - Automatic type deduction by TypeScript compiler

---

## Summary

This POC demonstrates a modern, type-safe approach to PDF generation by combining:

- **Web technologies** (React, CSS) for familiar development
- **Type safety** (TypeScript, Zod) for reliability
- **Server-side rendering** for performance
- **Headless browser** for accurate rendering
- **Design patterns** for maintainability

The result is a flexible, extensible system that produces professional PDFs while remaining developer-friendly.

---

_Last Updated: January 26, 2026_
