# Project Gutenberg - Quick Reference Guide

A condensed reference for the technologies and concepts used in this project.

---

## Technology Stack at a Glance

| Layer          | Technology     | Purpose            | Key Feature                    |
| -------------- | -------------- | ------------------ | ------------------------------ |
| **Runtime**    | Node.js 20     | Server environment | Event-driven, non-blocking I/O |
| **Language**   | TypeScript 5   | Type safety        | Compile-time error checking    |
| **Framework**  | Express 4      | REST API           | Middleware architecture        |
| **PDF Engine** | Puppeteer 22   | HTML → PDF         | Headless Chrome automation     |
| **UI Library** | React 18       | Components         | Server-side rendering          |
| **Styling**    | CSS + Tailwind | Layout             | CSS Paged Media support        |
| **Charts**     | Recharts 2     | Data viz           | SVG-based (vector graphics)    |
| **Validation** | Zod 3          | Schema check       | Runtime + TypeScript types     |
| **Container**  | Docker         | Packaging          | Bundles Chromium + deps        |

---

## Core Concept: The PDF Pipeline

```
Input (JSON) → Validate (Zod) → Render (React SSR) → Print (Puppeteer) → Output (PDF)
```

**Why this approach?**

- Treat PDF generation like web development
- Use familiar tools (React, CSS)
- Type-safe at every step
- Perfect rendering (Chrome engine)

---

## The Flow in 60 Seconds

1. **Client sends JSON manifest**

   ```json
   {
     "report_title": "Q3 Report",
     "pages": [{ "components": [...] }]
   }
   ```

2. **Zod validates structure**
   - Checks all required fields
   - Validates data types
   - Returns detailed errors if invalid

3. **React renders to HTML**
   - Converts components to HTML string
   - No browser involved (SSR)
   - Injects CSS for print

4. **Puppeteer generates PDF**
   - Launches headless Chrome
   - Loads HTML
   - Prints to PDF with proper page breaks

5. **Client receives PDF**
   - Binary stream
   - Ready to download/display

---

## Key Technologies Explained

### 1. Node.js - Why It's Perfect Here

**Problem:** Need to run JavaScript on server  
**Solution:** Node.js runtime  
**Magic:** V8 engine (same as Chrome) = native Puppeteer compatibility

```javascript
// Handles multiple requests without blocking
async function generatePDF(manifest) {
  const html = await renderHTML(manifest); // Non-blocking
  const pdf = await convertToPDF(html); // Non-blocking
  return pdf;
}
```

### 2. TypeScript - Type Safety Superpowers

**Problem:** JavaScript catches errors only at runtime  
**Solution:** TypeScript adds compile-time checking

```typescript
// This code won't even compile if types are wrong
interface Component {
  type: "CHART" | "TABLE"; // Only these two values allowed
}

// TypeScript error: Type '"GRAPH"' is not assignable to type '"CHART" | "TABLE"'
const c: Component = { type: "GRAPH" }; // ❌ Compile error
```

### 3. Puppeteer - The PDF Workhorse

**Problem:** Need pixel-perfect PDF rendering  
**Solution:** Control real Chrome browser programmatically

**What it does:**

- Launches Chromium in headless mode (no GUI)
- Loads your HTML/CSS
- Renders exactly like Chrome would display it
- Prints to PDF with native quality

**Why not just use a PDF library?**

- PDF libraries (like PDFKit) require manual positioning
- Puppeteer uses browser rendering = perfect CSS support
- SVG, fonts, complex layouts all "just work"

### 4. React SSR - Components Without the Browser

**Typical React (in browser):**

```javascript
ReactDOM.render(<App />, document.getElementById("root"));
// Runs JavaScript in browser, interactive
```

**Our approach (on server):**

```javascript
const html = ReactDOMServer.renderToStaticMarkup(<App />);
// Returns plain HTML string, no JavaScript needed
```

**Benefits:**

- No browser needed on client
- Faster (no JS to download/execute)
- Perfect for static documents like PDFs

### 5. Zod - Runtime + Compile-time Safety

**Problem:** JSON from users is untrustworthy  
**Solution:** Validate at runtime, get TypeScript types for free

```typescript
const ManifestSchema = z.object({
  title: z.string(),
  pages: z.array(PageSchema).min(1),
});

// Validate
const result = ManifestSchema.safeParse(userInput);

// Get TypeScript type automatically
type Manifest = z.infer<typeof ManifestSchema>;
```

**Two-way benefit:**

- Runtime: Catches bad data
- Compile-time: TypeScript knows the shape

### 6. Recharts - Charts That Print Beautifully

**Why Recharts over Chart.js?**

| Feature           | Recharts (SVG)    | Chart.js (Canvas) |
| ----------------- | ----------------- | ----------------- |
| Output            | Vector            | Raster image      |
| PDF quality       | Crisp at any zoom | Can be pixelated  |
| React integration | Native            | Via wrapper       |

```tsx
<BarChart data={data}>
  <Bar dataKey="revenue" fill="#1E40AF" />
</BarChart>
// Renders as <svg>...</svg> → perfect in PDF
```

---

## Design Patterns Used

### Atomic Design

**Hierarchy:**

```
Atoms (smallest)
  ↓
Molecules (combinations)
  ↓
Organisms (complex sections)
  ↓
Templates (full pages)
```

**In our code:**

- `Currency.tsx` (atom) → used in → `FinancialTable.tsx` (molecule)
- Change currency formatting once, updates everywhere

### Singleton Pattern

**Used for:** Puppeteer browser instance

```typescript
class PDFService {
  private static browser: Browser | null = null;

  async initialize() {
    if (!PDFService.browser) {
      // Only create once
      PDFService.browser = await puppeteer.launch();
    }
  }
}
```

**Why:** Launching browser is slow (~500ms), reuse = fast

### Discriminated Unions

**Problem:** Different component types have different data

```typescript
type Component =
  | { type: 'CHART', data: ChartData }
  | { type: 'TABLE', data: TableData };

// TypeScript knows which data based on type field
function render(c: Component) {
  if (c.type === 'CHART') {
    return <Chart data={c.data} />;  // c.data is ChartData
  }
}
```

---

## CSS Paged Media - Print Superpowers

**Regular CSS:** For screen  
**Paged Media CSS:** For print/PDF

```css
/* Define page size */
@page {
  size: A4;
  margin: 20mm;
}

/* Don't break inside this element */
.chart-container {
  page-break-inside: avoid;
}

/* Force new page before this */
.new-section {
  page-break-before: always;
}
```

**Dynamic content in headers/footers:**

```html
<!-- Puppeteer replaces these -->
<span class="pageNumber"></span>
<!-- 1, 2, 3... -->
<span class="totalPages"></span>
<!-- Total count -->
```

---

## Docker - The "It Works on My Machine" Killer

**Problem:** Puppeteer needs Chromium + 15 system libraries  
**Solution:** Package everything in Docker image

```dockerfile
# Install Chromium + all deps
RUN apt-get install chromium fonts-liberation libnss3 ...

# Bundle your app
COPY package*.json ./
RUN npm install
```

**Result:** One image, works anywhere (dev/staging/prod)

---

## Performance Characteristics

### Timing Breakdown

| Step                   | Time       | Notes                      |
| ---------------------- | ---------- | -------------------------- |
| Schema validation      | <1ms       | Zod is fast                |
| React rendering        | 10-50ms    | Depends on complexity      |
| Puppeteer setup        | 500ms      | First request only         |
| HTML loading           | 100ms      | In Puppeteer               |
| Chart rendering        | 500-1000ms | requestAnimationFrame wait |
| PDF generation         | 100-300ms  | Depends on page count      |
| **Total (first)**      | **~2-3s**  | Cold start                 |
| **Total (subsequent)** | **~1-2s**  | Browser reused             |

### Memory Usage

- **Node process:** ~50 MB baseline
- **Puppeteer browser:** ~100-200 MB
- **Per page rendering:** ~20-50 MB (temporary)

---

## Common Patterns in Code

### 1. Async/Await for I/O

```typescript
async function generateReport(manifest: Manifest) {
  const html = await renderService.render(manifest); // Wait for this
  const pdf = await pdfService.generate(html); // Then this
  return pdf;
}
```

### 2. Type Guards

```typescript
function isChart(c: Component): c is ChartComponent {
  return c.type === "CHART";
}

if (isChart(component)) {
  // TypeScript knows component.data is ChartData here
}
```

### 3. React Functional Components

```typescript
export const Currency: React.FC<CurrencyProps> = ({ value, locale = 'en-US' }) => {
  const formatted = new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: 'USD'
  }).format(value);

  return <span>{formatted}</span>;
};
```

### 4. Schema Composition (Zod)

```typescript
// Build complex from simple
const PageSchema = z.object({
  components: z.array(ComponentSchema),
});

const ManifestSchema = z.object({
  pages: z.array(PageSchema),
});
```

---

## Troubleshooting Quick Guide

### Puppeteer won't launch

**Symptom:** `Error: Failed to launch browser`

**Fix:**

```bash
# Install Chromium dependencies
sudo apt-get install chromium fonts-liberation
```

### Charts don't appear in PDF

**Cause:** Recharts uses `requestAnimationFrame`, needs time to render

**Fix:** Add delay before PDF generation

```typescript
await page.setContent(html);
await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait 1s
const pdf = await page.pdf();
```

### Content cut mid-element

**Cause:** Missing page-break CSS rules

**Fix:**

```css
.your-component {
  page-break-inside: avoid;
}
```

### TypeScript errors after npm install

**Cause:** Missing type definitions

**Fix:**

```bash
npm install --save-dev @types/node @types/react
```

---

## Best Practices

### 1. Schema First

Always define Zod schema before building component

```typescript
// 1. Schema
const Schema = z.object({ ... });

// 2. Type
type Data = z.infer<typeof Schema>;

// 3. Component
const Component: React.FC<{ data: Data }> = ...
```

### 2. Error Handling

```typescript
try {
  const pdf = await pdfService.generate(html);
  res.send(pdf);
} catch (error) {
  console.error("PDF generation failed:", error);
  res.status(500).json({ error: "Generation failed" });
}
```

### 3. Browser Cleanup

```typescript
process.on("SIGTERM", async () => {
  await pdfService.close(); // Close browser gracefully
  process.exit(0);
});
```

---

## Extending the System

### Adding a New Component

1. **Define Schema** (`src/schemas/components.schema.ts`)

```typescript
export const NewComponentSchema = z.object({
  type: z.literal('NEW_COMPONENT'),
  data: z.object({ ... })
});
```

2. **Add to Union**

```typescript
export const ComponentSchema = z.discriminatedUnion('type', [
  ...,
  NewComponentSchema
]);
```

3. **Create React Component** (`src/components/molecules/`)

```typescript
export const NewComponent: React.FC<Props> = ({ data }) => {
  return <div>{/* Your markup */}</div>;
};
```

4. **Add to Renderer** (`src/components/layouts/SingleColumn.tsx`)

```typescript
case 'NEW_COMPONENT':
  return <NewComponent data={component.data} />;
```

---

## Resources by Learning Goal

### "I want to understand the basics"

1. Start with [Node.js docs](https://nodejs.org/docs/)
2. Learn [TypeScript fundamentals](https://www.typescriptlang.org/docs/handbook/intro.html)
3. Understand [React SSR](https://react.dev/reference/react-dom/server)

### "I want to build similar systems"

1. Study [Puppeteer examples](https://pptr.dev/category/guides)
2. Learn [CSS Paged Media](https://www.smashingmagazine.com/2015/01/designing-for-print-with-css/)
3. Read [Atomic Design](https://atomicdesign.bradfrost.com/)

### "I want to scale this"

1. Implement browser pooling
2. Add caching layer (Redis)
3. Use message queue (RabbitMQ) for async processing
4. Deploy to Kubernetes for auto-scaling

---

## Key Takeaways

1. **Web Tech for PDFs** - React/CSS are perfectly fine for PDF generation
2. **Type Safety Matters** - TypeScript + Zod catch errors before runtime
3. **SSR is Fast** - No browser on client = quick response
4. **Chrome is Powerful** - Puppeteer leverages full browser rendering
5. **Patterns are Important** - Atomic design, singleton, discriminated unions make code maintainable

---

## Next Steps in Your Learning Journey

### Week 1: Foundations

- [ ] Complete Node.js official tutorial
- [ ] Learn TypeScript basics (types, interfaces, generics)
- [ ] Build a simple Express REST API

### Week 2: React & Components

- [ ] Complete React tutorial
- [ ] Learn SSR concepts
- [ ] Build component library with Atomic Design

### Week 3: PDF Generation

- [ ] Set up Puppeteer locally
- [ ] Generate your first PDF from HTML
- [ ] Learn CSS Paged Media rules

### Week 4: Integration

- [ ] Combine React SSR + Puppeteer
- [ ] Add Zod validation
- [ ] Dockerize your application

### Advanced Topics (Month 2+)

- [ ] Browser pooling and connection management
- [ ] Horizontal scaling strategies
- [ ] Performance optimization
- [ ] Monitoring and observability
- [ ] Security hardening

---

_For detailed explanations, see [`TECHNICAL_DEEP_DIVE.md`](TECHNICAL_DEEP_DIVE.md)_
