# Project Gutenberg - Design Document

## Executive Summary

Project Gutenberg is an AI-powered PDF report generation engine designed for wealth management and estate planning applications. It provides two complementary PDF generation strategies:

1. **Puppeteer-based rendering** - HTML/CSS to PDF conversion using headless Chrome
2. **@react-pdf/renderer** - Pure React-based PDF generation with native PDF primitives

The system is architected as a REST API service that accepts structured data and produces professionally formatted PDF documents with complex visualizations including charts, flowcharts, family trees, and data tables.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Technology Stack](#technology-stack)
3. [System Components](#system-components)
4. [Data Models](#data-models)
5. [PDF Components Library](#pdf-components-library)
6. [API Reference](#api-reference)
7. [Design System](#design-system)
8. [Rendering Strategies](#rendering-strategies)
9. [File Structure](#file-structure)
10. [Deployment](#deployment)
11. [Future Enhancements](#future-enhancements)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Client Applications                          │
│                    (Web Apps, Mobile, Integrations)                  │
└───────────────────────────────┬─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                          Express API Server                          │
│                          (src/index.ts)                              │
│  ┌─────────────────┐  ┌──────────────────┐  ┌───────────────────┐  │
│  │   PDF Routes    │  │  Stitcher Svc    │  │  Validation (Zod) │  │
│  │   /api/v1/*     │  │  Manifest→HTML   │  │  Schema Checks    │  │
│  └────────┬────────┘  └────────┬─────────┘  └───────────────────┘  │
└───────────┼────────────────────┼────────────────────────────────────┘
            │                    │
            ▼                    ▼
┌───────────────────────┐  ┌───────────────────────────────────────┐
│   Puppeteer Service   │  │        @react-pdf/renderer            │
│   (HTML → PDF)        │  │        (React → PDF)                  │
│   ┌───────────────┐   │  │   ┌──────────────────────────────┐   │
│   │ Headless      │   │  │   │  EstateReportDocument        │   │
│   │ Chrome        │   │  │   │  ├── DonutChart              │   │
│   │               │   │  │   │  ├── TrustDetailCard         │   │
│   │ HTML/CSS/JS   │   │  │   │  ├── EntityStructureChart    │   │
│   │ Rendering     │   │  │   │  ├── AssetTable              │   │
│   └───────────────┘   │  │   │  ├── EstateFlowDiagram       │   │
└───────────┬───────────┘  │   │  ├── HeritageMap             │   │
            │              │   │  └── TrustFlowchart          │   │
            │              │   └──────────────────────────────┘   │
            │              └───────────────────┬───────────────────┘
            │                                  │
            ▼                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                          PDF Output Buffer                           │
│                    (Binary PDF returned to client)                   │
└─────────────────────────────────────────────────────────────────────┘
```

### Key Design Principles

1. **Dual Rendering Strategy**: Support both HTML-to-PDF (Puppeteer) and native PDF (react-pdf) approaches
2. **Component-Based Architecture**: Reusable React components for consistent PDF layouts
3. **Data-Driven Design**: All content is driven by structured JSON data
4. **Type Safety**: Full TypeScript implementation with Zod schema validation
5. **Design System Consistency**: Centralized theme with colors, fonts, and spacing tokens

---

## Technology Stack

### Core Dependencies

| Package               | Version | Purpose                                     |
| --------------------- | ------- | ------------------------------------------- |
| `@react-pdf/renderer` | ^4.3.2  | Native PDF generation from React components |
| `puppeteer`           | ^22.0.0 | Headless Chrome for HTML→PDF conversion     |
| `express`             | ^4.18.2 | REST API server framework                   |
| `react`               | ^18.2.0 | UI component framework                      |
| `zod`                 | ^3.22.4 | Runtime schema validation                   |
| `typescript`          | ^5.3.3  | Type-safe JavaScript                        |
| `tsx`                 | ^4.7.0  | TypeScript execution                        |

### Development Tools

| Tool        | Purpose                       |
| ----------- | ----------------------------- |
| `tsx watch` | Hot-reload development server |
| Docker      | Containerized deployment      |
| TypeScript  | Static type checking          |

---

## System Components

### 1. Entry Point (`src/index.ts`)

The application entry point initializes services and starts the Express server:

```typescript
// Initialization sequence:
// 1. Load environment variables
// 2. Initialize Puppeteer browser instance
// 3. Create Express app with routes
// 4. Start HTTP server on PORT (default: 3000)
```

### 2. API Layer (`src/api/`)

#### Express Application Factory (`src/api/index.ts`)

- CORS middleware enabled
- JSON body parsing (10MB limit)
- Request logging
- Error handling middleware
- Route mounting at `/api/v1`

#### PDF Routes (`src/api/routes/pdf.routes.ts`)

| Endpoint                         | Method | Description                            |
| -------------------------------- | ------ | -------------------------------------- |
| `/api/v1/generate-pdf`           | POST   | Generate PDF from manifest (Puppeteer) |
| `/api/v1/generate-estate-report` | POST   | Generate estate report (react-pdf)     |
| `/api/v1/estate-report-sample`   | GET    | Generate sample estate report          |
| `/api/v1/health`                 | GET    | Health check endpoint                  |

### 3. Service Layer (`src/services/`)

#### PDF Service (`src/services/pdf.service.ts`)

Manages Puppeteer browser lifecycle and HTML→PDF conversion:

```typescript
interface PDFGenerationOptions {
  format?: "A4" | "Letter";
  landscape?: boolean;
  displayHeaderFooter?: boolean;
  headerTemplate?: string;
  footerTemplate?: string;
}
```

**Key Features:**

- Singleton browser instance for performance
- Configurable page margins and headers/footers
- Network idle detection for dynamic content
- Graceful shutdown handling

#### Stitcher Service (`src/services/stitcher.service.ts`)

Validates manifests and generates HTML from component definitions:

- Zod schema validation
- Component-to-HTML rendering
- Error aggregation

### 4. React-PDF Renderer (`src/pdf/`)

#### PDF Renderer Service (`src/pdf/pdf-renderer.service.ts`)

Main entry point for @react-pdf/renderer based generation:

```typescript
async function generatePdfWithReactPdf(
  data: EstateReportProps,
): Promise<Buffer>;
```

Includes comprehensive sample data for testing all components.

#### Theme System (`src/pdf/theme.ts`)

Centralized design tokens:

```typescript
// Color palette
pdfColors = {
  primary: { 50-700 shades },  // Teal
  secondary: { 50-700 shades }, // Blue
  accent: { teal, blue, purple, red, orange, pink, green },
  neutral: { 50-900 shades }
}

// Typography
pdfFonts = {
  size: { xs: 9, sm: 10, base: 11, md: 12, lg: 14, xl: 16, 2xl: 20, 3xl: 24, 4xl: 32 },
  weight: { normal, medium, semibold, bold }
}

// Spacing scale
pdfSpacing = { 0, 1, 2, 3, 4, 5, 6, 8, 10, 12 } // multiplied by 4px
```

---

## Data Models

### Estate Report Props (`EstateReportProps`)

The main data interface for generating estate planning reports:

```typescript
interface EstateReportProps {
  // Metadata
  clientName: string;
  reportTitle: string;
  reportDate?: string;
  brandName?: string;

  // Page content (each creates a separate PDF page)
  overview?: OverviewData;
  trustDetails?: TrustDetailsData;
  entityStructure?: EntityStructureData;
  assetTable?: AssetTableData;
  estateFlow?: EstateFlowData;
  heritageMap?: HeritageMapData;
  trustFlowchart?: TrustFlowchartData;
}
```

### Trust Flowchart Data Model

```typescript
interface TrustFlowchartData {
  title?: string;
  nodes: FlowNode[];
  edges: FlowEdge[];
  stages: FlowStage[];
  notes?: FlowNote[];
}

interface FlowNode {
  id: string;
  type: "trust" | "gift" | "person" | "entity";
  label: string;
  icon: "building" | "gift" | "document" | "person";
  color: string;
  stageId: string;
}

interface FlowEdge {
  id: string;
  from: string;
  to: string;
  label?: string; // e.g., "50%"
  description?: string;
  style?: "solid" | "dashed";
}

interface FlowStage {
  id: string;
  label: string; // e.g., "Death of First Spouse"
  order: number;
  dividerStyle?: "solid" | "dashed";
}
```

---

## PDF Components Library

### Page Structure Components

#### EstateReportDocument (`src/pdf/components/EstateReportDocument.tsx`)

Main document wrapper that orchestrates all pages:

```typescript
<Document>
  <Page>Overview with DonutChart</Page>
  <Page>Trust Details</Page>
  <Page>Entity Structure</Page>
  <Page>Asset Table</Page>
  <Page>Estate Flow</Page>
  <Page>Heritage Map</Page>
  <Page>Trust Flowchart</Page>
</Document>
```

### Visualization Components

#### 1. DonutChart (`src/pdf/components/DonutChart.tsx`)

Circular pie chart with hollow center for displaying portfolio allocations.

**Features:**

- SVG-based arc rendering using polar coordinates
- Configurable segment colors
- Center label with total value
- Legend with percentages
- Currency formatting

**Algorithm:**

```
describeArc(cx, cy, outerRadius, innerRadius, startAngle, endAngle)
  → Generates SVG path commands for arc segments
```

#### 2. TrustDetailCard (`src/pdf/components/TrustDetailCard.tsx`)

Property-value grid for displaying trust details with colored badges.

**Layout:**

```
┌─────────────────────────────────────────┐
│ [B] Credit Shelter Trust                │
│     Additional Details                  │
├─────────────────────────────────────────┤
│ Funding Directive Type  │ Fractional... │
│ Income Distributions    │ Fully Disc... │
│ Principal Distributions │ Income and... │
└─────────────────────────────────────────┘
```

#### 3. EntityStructureChart (`src/pdf/components/EntityStructureChart.tsx`)

Displays ownership percentages between trusts/entities.

**Features:**

- Entity type icons (trust, business, individual)
- Percentage progress bars
- Horizontal connector lines

#### 4. AssetTable (`src/pdf/components/AssetTable.tsx`)

Financial data table with grouping and subtotals.

**Features:**

- Column alignment (left, center, right)
- Data formatting (currency, percentage, text)
- Row grouping with subtotals
- Alternating row colors
- Group headers

#### 5. EstateFlowDiagram (`src/pdf/components/EstateFlowDiagram.tsx`)

Sankey-style flow diagram showing asset distribution.

**Layout:**

```
┌────────────────────────────────────────┐
│     Estates    →    →    Beneficiaries │
│  ┌──────────┐          ┌──────────┐   │
│  │ John's   │──────────│ Daniel   │   │
│  │ Estate   │    ╲     │ Doe      │   │
│  │ $176.7M  │     ╲    └──────────┘   │
│  └──────────┘      ╲   ┌──────────┐   │
│  ┌──────────┐       ╲──│ Andrew   │   │
│  │ Jane's   │──────────│ Doe      │   │
│  │ Estate   │          └──────────┘   │
│  └──────────┘                         │
└────────────────────────────────────────┘
```

#### 6. HeritageMap (`src/pdf/components/HeritageMap.tsx`)

Multi-generational family tree visualization.

**Features:**

- Generation-based row layout
- Avatar circles with initials
- SVG connection lines between family members
- Spouse coupling lines
- Parent-child relationship lines

**Layout:**

```
Parents:      [JD]────[JD]
                 │
Children:   [DD]  [AD]  [SD]
               │     │     │
Grandchildren: [EJ][MD] [AD] [SS]
```

#### 7. TrustFlowchart (`src/pdf/components/TrustFlowchart.tsx`)

Complex estate distribution flowchart with stages.

**Key Features:**

- Multi-stage layout with dividers
- T-junction branching patterns
- Horizontal branching to Specific Gifts nodes
- Arrow heads on specific connections
- Percentage labels on distribution paths
- Note boxes for legal disclaimers

**Coordinate System (A4 515×680 usable area):**

```typescript
const X = {
  center: 257, // Main vertical trunk
  survivorTrust: 110, // Left column
  bypassTrust: 257, // Center column
  maritalTrust: 390, // Right column
  specificGifts: 450, // Far right (Specific Gifts)
  janeTrust: 190, // Bottom left
  johnTrust: 320, // Bottom right
};

const Y = {
  mainTrust: 55, // Top node
  divider1: 130, // "Death of First Spouse"
  branchPoint1: 150, // Horizontal branch start
  specificGifts1: 210, // First Specific Gifts
  tJunction: 270, // T-junction horizontal line
  row3Trusts: 330, // Middle trust row
  divider2: 430, // "Death of Surviving Spouse"
  specificGifts2: 555, // Second Specific Gifts
  row4Trusts: 620, // Final trust row
};
```

**Visual Layout:**

```
          ┌─────────────────────┐
          │ Doe-Smith Revocable │
          │       Trust         │
          └─────────┬───────────┘
                    │
- - - - Death of First Spouse - - - -
                    │
                    ├──────────────→ [Specific Gifts]
                    │
        ┌───────────┼───────────┐
        │           │           │
   ┌────┴────┐ ┌────┴────┐ ┌────┴────┐
   │Survivor's│ │ Bypass  │ │ Marital │
   │  Trust   │ │  Trust  │ │  Trust  │
   └─────────┘ └────┬────┘ └────┬────┘
                    │           │
- - - Death of Surviving Spouse - - -
                    │           │
                    └─────┬─────┼────→ [Specific Gifts]
                          │     │
                    ┌─────┴─────┐
                  [50%]       [50%]
                    │           │
             ┌──────┴──┐  ┌─────┴───┐
             │Jane Doe │  │John Doe │
             │  Trust  │  │  Trust  │
             └─────────┘  └─────────┘
```

---

## API Reference

### Generate Estate Report

```http
POST /api/v1/generate-estate-report
Content-Type: application/json

{
  "clientName": "John Doe & Jane Doe",
  "reportTitle": "Estimated Estate Overview",
  "reportDate": "Estate Report: March 2025",
  "brandName": "wealth.com",
  "overview": { ... },
  "trustDetails": { ... },
  "entityStructure": { ... },
  "assetTable": { ... },
  "estateFlow": { ... },
  "heritageMap": { ... },
  "trustFlowchart": { ... }
}
```

**Response:**

- Content-Type: `application/pdf`
- Headers: `X-Render-Time-Ms`, `X-Renderer: react-pdf`

### Sample Report

```http
GET /api/v1/estate-report-sample
```

Returns a pre-configured sample PDF using built-in demo data.

### Health Check

```http
GET /api/v1/health
```

```json
{
  "success": true,
  "status": "healthy",
  "timestamp": "2025-01-28T19:00:00.000Z"
}
```

---

## Design System

### Color Palette

| Name             | Hex       | Usage                                    |
| ---------------- | --------- | ---------------------------------------- |
| Primary (Teal)   | `#14b8a6` | Main trust elements, positive indicators |
| Secondary (Blue) | `#3b82f6` | Bypass trusts, secondary elements        |
| Purple           | `#7c3aed` | Irrevocable trusts                       |
| Orange           | `#f97316` | Specific gifts, warnings                 |
| Red              | `#f87171` | Descendant trusts, alerts                |
| Green            | `#059669` | Survivor's trust, success states         |

### Typography Scale

| Name | Size | Weight   | Usage                  |
| ---- | ---- | -------- | ---------------------- |
| xs   | 9pt  | normal   | Footnotes, disclaimers |
| sm   | 10pt | normal   | Captions, labels       |
| base | 11pt | normal   | Body text              |
| md   | 12pt | medium   | Emphasized body        |
| lg   | 14pt | semibold | Section titles         |
| xl   | 16pt | bold     | Card titles            |
| 2xl  | 20pt | bold     | Page subtitles         |
| 3xl  | 24pt | bold     | Page titles            |
| 4xl  | 32pt | bold     | Large numbers          |

### Spacing System

Based on 4px grid: `0, 4, 8, 12, 16, 20, 24, 32, 40, 48`

### Page Layout

- **Page Size**: A4 (595 × 842 points)
- **Padding**: 40pt on all sides
- **Footer Height**: 50pt reserved
- **Usable Content Area**: 515 × 680pt

---

## Rendering Strategies

### Strategy 1: Puppeteer (HTML → PDF)

**When to Use:**

- Complex CSS layouts (flexbox, grid)
- Web fonts
- Interactive elements that need to be flattened
- Existing HTML templates

**Pros:**

- Full CSS support
- Familiar web development patterns
- Can render any HTML/CSS

**Cons:**

- Requires headless browser (Chrome)
- Higher memory usage
- Slower generation times
- Text not selectable in some cases

### Strategy 2: @react-pdf/renderer (React → PDF)

**When to Use:**

- Native PDF features needed
- Optimal file size
- Pixel-perfect positioning
- Performance critical

**Pros:**

- Pure PDF generation (no browser)
- Smaller file sizes
- Better text handling
- Faster generation
- Works in serverless environments

**Cons:**

- Limited CSS support (subset of flexbox)
- Custom SVG rendering required
- Learning curve for PDF primitives

### Performance Comparison

| Metric             | Puppeteer | react-pdf  |
| ------------------ | --------- | ---------- |
| Startup Time       | ~2-3s     | ~100ms     |
| Generation Time    | ~1-2s     | ~200-400ms |
| Memory Usage       | ~150MB    | ~30MB      |
| File Size (8-page) | ~150KB    | ~30KB      |

---

## File Structure

```
project-gutenberg/
├── src/
│   ├── index.ts                    # Application entry point
│   ├── api/
│   │   ├── index.ts                # Express app factory
│   │   └── routes/
│   │       └── pdf.routes.ts       # PDF generation endpoints
│   ├── services/
│   │   ├── pdf.service.ts          # Puppeteer PDF service
│   │   ├── renderer.service.ts     # HTML rendering
│   │   └── stitcher.service.ts     # Manifest validation
│   ├── pdf/
│   │   ├── pdf-renderer.service.ts # react-pdf service
│   │   ├── theme.ts                # Design system tokens
│   │   └── components/
│   │       ├── EstateReportDocument.tsx
│   │       ├── DonutChart.tsx
│   │       ├── TrustDetailCard.tsx
│   │       ├── EntityStructureChart.tsx
│   │       ├── AssetTable.tsx
│   │       ├── EstateFlowDiagram.tsx
│   │       ├── HeritageMap.tsx
│   │       └── TrustFlowchart.tsx
│   ├── schemas/
│   │   ├── components.schema.ts    # Component data schemas
│   │   └── manifest.schema.ts      # Report manifest schema
│   ├── components/                 # HTML/Recharts components
│   │   ├── atoms/
│   │   ├── charts/
│   │   ├── layouts/
│   │   ├── molecules/
│   │   └── templates/
│   └── styles/
│       ├── print.css
│       └── theme.ts
├── docs/
│   ├── DESIGN_DOCUMENT.md          # This document
│   ├── REACT_PDF_IMPLEMENTATION.md
│   ├── COMPLEX_UI_IMPLEMENTATION.md
│   └── ...
├── sample-data/
│   ├── estate-planning-demo.json
│   └── novacorp-q3.json
├── package.json
├── tsconfig.json
├── Dockerfile
└── docker-compose.yml
```

---

## Deployment

### Docker Deployment

```dockerfile
FROM node:20-slim

# Install Chromium dependencies for Puppeteer
RUN apt-get update && apt-get install -y \
    chromium \
    --no-install-recommends

WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

ENV PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium
EXPOSE 3000
CMD ["npm", "start"]
```

### Environment Variables

| Variable                    | Default | Description                 |
| --------------------------- | ------- | --------------------------- |
| `PORT`                      | 3000    | HTTP server port            |
| `PUPPETEER_EXECUTABLE_PATH` | (auto)  | Chrome/Chromium binary path |

### Docker Compose

```yaml
version: "3.8"
services:
  pdf-engine:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
```

---

## Future Enhancements

### Planned Features

1. **Template Registry** - Store and retrieve report templates by ID
2. **Async Generation** - Queue-based generation for large reports
3. **Caching Layer** - Cache frequently generated reports
4. **Multi-language Support** - i18n for report content
5. **Custom Fonts** - Support for brand-specific typography
6. **Watermarking** - Draft/confidential watermarks
7. **Digital Signatures** - PDF/A compliance and signing

### Component Roadmap

1. **Timeline Component** - Chronological estate events
2. **Comparison Tables** - Side-by-side scenario analysis
3. **Tax Calculator Charts** - Estate tax projections
4. **Geographic Maps** - Property location visualization
5. **Document Checklist** - Estate planning document status

### API Enhancements

1. **Batch Generation** - Multiple reports in single request
2. **Webhook Notifications** - Completion callbacks
3. **Progress Streaming** - Real-time generation status
4. **Version Management** - Report revision tracking

---

## Contributing

### Code Style

- TypeScript strict mode enabled
- ESLint + Prettier formatting
- Component naming: PascalCase
- File naming: kebab-case for services, PascalCase for components

### Testing

```bash
# Run development server
npm run dev

# Generate sample PDF
curl http://localhost:3000/api/v1/estate-report-sample -o sample.pdf

# Build for production
npm run build
```

### Documentation

All components should include:

- JSDoc comments for props interfaces
- Usage examples in implementation
- Visual diagrams where applicable

---

## License

MIT License - See LICENSE file for details.

---

_Last Updated: January 2025_
_Version: 0.1.0_
