/**
 * Design System Theme
 * Centralized design tokens for consistent UI across all components
 */

export const theme = {
  // Card Container Styles
  card: {
    background: "#ffffff",
    border: "1px solid #e5e7eb",
    borderRadius: "8px",
    padding: "24px",
    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
    marginBottom: "24px",
  },

  // Typography
  typography: {
    h1: {
      fontSize: "28px",
      fontWeight: "700",
      color: "#111827",
      lineHeight: "1.2",
    },
    h2: {
      fontSize: "24px",
      fontWeight: "700",
      color: "#111827",
      lineHeight: "1.3",
    },
    h3: {
      fontSize: "20px",
      fontWeight: "700",
      color: "#111827",
      lineHeight: "1.4",
      marginBottom: "24px",
    },
    h4: {
      fontSize: "16px",
      fontWeight: "600",
      color: "#111827",
      lineHeight: "1.5",
    },
    body: {
      fontSize: "14px",
      fontWeight: "400",
      color: "#374151",
      lineHeight: "1.6",
    },
    bodyLarge: {
      fontSize: "15px",
      fontWeight: "400",
      color: "#374151",
      lineHeight: "1.6",
    },
    small: {
      fontSize: "13px",
      fontWeight: "400",
      color: "#6b7280",
      lineHeight: "1.5",
    },
    caption: {
      fontSize: "12px",
      fontWeight: "500",
      color: "#6b7280",
      lineHeight: "1.4",
    },
  },

  // Color Palette
  colors: {
    // Primary (Teal/Green)
    primary: {
      50: "#f0fdfa",
      100: "#ccfbf1",
      500: "#14b8a6",
      600: "#0d9488",
      700: "#0f766e",
    },
    // Secondary (Blue)
    secondary: {
      50: "#eff6ff",
      100: "#dbeafe",
      500: "#3b82f6",
      600: "#2563eb",
      700: "#1d4ed8",
    },
    // Neutral/Gray
    neutral: {
      50: "#f9fafb",
      100: "#f3f4f6",
      200: "#e5e7eb",
      300: "#d1d5db",
      400: "#9ca3af",
      500: "#6b7280",
      600: "#4b5563",
      700: "#374151",
      800: "#1f2937",
      900: "#111827",
    },
    // Semantic Colors
    success: "#10b981",
    warning: "#f59e0b",
    error: "#ef4444",
    info: "#3b82f6",
  },

  // Spacing
  spacing: {
    xs: "4px",
    sm: "8px",
    md: "12px",
    lg: "16px",
    xl: "20px",
    "2xl": "24px",
    "3xl": "32px",
    "4xl": "48px",
  },

  // Border Radius
  borderRadius: {
    sm: "4px",
    md: "6px",
    lg: "8px",
    xl: "10px",
    "2xl": "12px",
    full: "9999px",
  },

  // Shadows
  shadows: {
    sm: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
    md: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
    lg: "0 2px 4px 0 rgba(0, 0, 0, 0.1)",
    xl: "0 4px 6px 0 rgba(0, 0, 0, 0.1)",
  },

  // Chart Colors
  chart: {
    colors: [
      "#0d9488", // Teal
      "#14b8a6", // Light Teal
      "#1d4ed8", // Blue
      "#3b82f6", // Light Blue
      "#7c3aed", // Purple
      "#d97706", // Orange
      "#10b981", // Green
      "#ef4444", // Red
    ],
  },
};

// Helper function to create consistent card container style
export const getCardStyle = () => theme.card;

// Helper function to create consistent title style
export const getTitleStyle = () => theme.typography.h3;

// Helper function to create icon container style
export const getIconContainerStyle = (size: number = 80) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  padding: "12px",
  background: theme.colors.primary[50],
  borderRadius: theme.borderRadius.full,
  width: `${size}px`,
  height: `${size}px`,
  margin: "0 auto",
  border: `1px solid ${theme.colors.primary[100]}`,
});
