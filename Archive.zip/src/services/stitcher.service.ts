import {
  ReportManifest,
  ReportManifestSchema,
} from "../schemas/manifest.schema.js";
import { RendererService } from "./renderer.service.js";
import { ZodError } from "zod";

export interface ValidationResult {
  success: boolean;
  data?: ReportManifest;
  errors?: {
    path: string;
    message: string;
  }[];
}

export class StitcherService {
  private renderer: RendererService;

  constructor() {
    this.renderer = new RendererService();
  }

  /**
   * Validates a report manifest against the schema
   */
  validateManifest(manifest: unknown): ValidationResult {
    try {
      const validated = ReportManifestSchema.parse(manifest);
      return {
        success: true,
        data: validated,
      };
    } catch (error) {
      if (error instanceof ZodError) {
        return {
          success: false,
          errors: error.errors.map((err) => ({
            path: err.path.join("."),
            message: err.message,
          })),
        };
      }
      return {
        success: false,
        errors: [
          {
            path: "unknown",
            message: "Unknown validation error",
          },
        ],
      };
    }
  }

  /**
   * Stitches components together and generates HTML
   */
  generateHTML(manifest: ReportManifest): string {
    return this.renderer.renderToHTML(manifest);
  }

  /**
   * Validates and generates HTML in one step
   */
  processManifest(manifest: unknown): {
    success: boolean;
    html?: string;
    errors?: any;
  } {
    const validation = this.validateManifest(manifest);

    if (!validation.success) {
      return {
        success: false,
        errors: validation.errors,
      };
    }

    const html = this.generateHTML(validation.data!);

    return {
      success: true,
      html,
    };
  }
}

export const stitcherService = new StitcherService();
