import puppeteer, { Browser, Page, PDFOptions } from "puppeteer";

export interface PDFGenerationOptions {
  format?: "A4" | "Letter";
  landscape?: boolean;
  displayHeaderFooter?: boolean;
  headerTemplate?: string;
  footerTemplate?: string;
}

export class PDFService {
  private browser: Browser | null = null;

  /**
   * Initialize the browser instance
   */
  async initialize(): Promise<void> {
    if (!this.browser) {
      this.browser = await puppeteer.launch({
        headless: true,
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
          "--disable-dev-shm-usage",
          "--disable-gpu",
        ],
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
      });
      console.log("Puppeteer browser initialized");
    }
  }

  /**
   * Generate PDF from HTML string
   */
  async generatePDF(
    html: string,
    options?: PDFGenerationOptions,
  ): Promise<Buffer> {
    await this.initialize();

    if (!this.browser) {
      throw new Error("Browser not initialized");
    }

    const page: Page = await this.browser.newPage();

    try {
      // Set content and wait for network idle
      await page.setContent(html, {
        waitUntil: "networkidle0",
      });

      // Wait a bit for charts to render (Recharts uses requestAnimationFrame)
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const pdfOptions: PDFOptions = {
        format: options?.format || "A4",
        landscape: options?.landscape || false,
        printBackground: true,
        margin: {
          top: "20mm",
          right: "15mm",
          bottom: "20mm",
          left: "15mm",
        },
        displayHeaderFooter: options?.displayHeaderFooter ?? true,
        headerTemplate:
          options?.headerTemplate ||
          '<div style="font-size:10px; width:100%; text-align:center; color:#666;">Confidential - Board Only</div>',
        footerTemplate:
          options?.footerTemplate ||
          '<div style="font-size:10px; width:100%; text-align:center; color:#666;">Page <span class="pageNumber"></span> of <span class="totalPages"></span></div>',
      };

      const pdf = await page.pdf(pdfOptions);

      return pdf;
    } finally {
      await page.close();
    }
  }

  /**
   * Close the browser instance
   */
  async close(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      console.log("Puppeteer browser closed");
    }
  }
}

// Singleton instance
export const pdfService = new PDFService();

// Graceful shutdown
process.on("SIGINT", async () => {
  await pdfService.close();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  await pdfService.close();
  process.exit(0);
});
