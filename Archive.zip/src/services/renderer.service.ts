import React from "react";
import ReactDOMServer from "react-dom/server";
import { ReportTemplate } from "../components/templates/ReportTemplate.js";
import type { ReportManifest } from "../schemas/manifest.schema.js";
import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export class RendererService {
  private printCSS: string;

  constructor() {
    // Load print CSS
    const cssPath = join(__dirname, "../styles/print.css");
    this.printCSS = readFileSync(cssPath, "utf-8");
  }

  /**
   * Renders a report manifest to HTML string
   */
  renderToHTML(manifest: ReportManifest): string {
    const reactElement = React.createElement(ReportTemplate, { manifest });
    const htmlContent = ReactDOMServer.renderToStaticMarkup(reactElement);

    // Wrap in complete HTML document with styles
    return this.wrapInHTMLDocument(htmlContent);
  }

  /**
   * Wraps the rendered content in a complete HTML document
   */
  private wrapInHTMLDocument(content: string): string {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    ${this.printCSS}
    
    /* Additional inline styles for better PDF rendering */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      padding: 0;
      margin: 0;
    }
    
    /* Grid utilities */
    .grid {
      display: grid;
    }
    
    .grid-cols-2 {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    
    .gap-6 {
      gap: 1.5rem;
    }
    
    .gap-4 {
      gap: 1rem;
    }
    
    .gap-2 {
      gap: 0.5rem;
    }
    
    /* Flex utilities */
    .flex {
      display: flex;
    }
    
    .flex-1 {
      flex: 1 1 0%;
    }
    
    .items-start {
      align-items: flex-start;
    }
    
    .items-center {
      align-items: center;
    }
    
    .justify-center {
      justify-content: center;
    }
    
    .justify-between {
      justify-content: space-between;
    }
    
    /* Spacing utilities */
    .space-y-2 > * + * {
      margin-top: 0.5rem;
    }
    
    .space-y-4 > * + * {
      margin-top: 1rem;
    }
    
    /* Layout utilities */
    .w-full {
      width: 100%;
    }
    
    .w-10 {
      width: 2.5rem;
    }
    
    .h-10 {
      height: 2.5rem;
    }
    
    .inline-flex {
      display: inline-flex;
    }
    
    /* Background colors */
    .bg-green-100 {
      background-color: #d1fae5;
    }
    
    .bg-yellow-100 {
      background-color: #fef3c7;
    }
    
    .bg-red-100 {
      background-color: #fee2e2;
    }
    
    .bg-blue-100 {
      background-color: #dbeafe;
    }
    
    .bg-gray-50 {
      background-color: #f9fafb;
    }
    
    .bg-gray-100 {
      background-color: #f3f4f6;
    }
    
    .bg-blue-50 {
      background-color: #eff6ff;
    }
    
    /* Text colors */
    .text-green-600 {
      color: #059669;
    }
    
    .text-green-800 {
      color: #065f46;
    }
    
    .text-yellow-600 {
      color: #d97706;
    }
    
    .text-yellow-800 {
      color: #92400e;
    }
    
    .text-red-600 {
      color: #dc2626;
    }
    
    .text-red-800 {
      color: #991b1b;
    }
    
    .text-blue-600 {
      color: #2563eb;
    }
    
    .text-blue-800 {
      color: #1e40af;
    }
    
    /* Border utilities */
    .border-green-200 {
      border-color: #a7f3d0;
    }
    
    .border-yellow-200 {
      border-color: #fde68a;
    }
    
    .border-red-200 {
      border-color: #fecaca;
    }
    
    .border-blue-200 {
      border-color: #bfdbfe;
    }
    
    .border-blue-300 {
      border-color: #93c5fd;
    }
    
    .border-b-2 {
      border-bottom-width: 2px;
    }
    
    .border-t-2 {
      border-top-width: 2px;
    }
    
    /* Table utilities */
    .border-collapse {
      border-collapse: collapse;
    }
    
    .list-none {
      list-style: none;
    }
    
    .uppercase {
      text-transform: uppercase;
    }
    
    .px-3 {
      padding-left: 0.75rem;
      padding-right: 0.75rem;
    }
    
    .px-4 {
      padding-left: 1rem;
      padding-right: 1rem;
    }
    
    .py-1 {
      padding-top: 0.25rem;
      padding-bottom: 0.25rem;
    }
    
    .py-3 {
      padding-top: 0.75rem;
      padding-bottom: 0.75rem;
    }
    
    .pb-4 {
      padding-bottom: 1rem;
    }
    
    .mb-2 {
      margin-bottom: 0.5rem;
    }
    
    .mb-3 {
      margin-bottom: 0.75rem;
    }
    
    .mb-8 {
      margin-bottom: 2rem;
    }
    
    .mt-2 {
      margin-top: 0.5rem;
    }
    
    .mt-4 {
      margin-top: 1rem;
    }
    
    .rounded-full {
      border-radius: 9999px;
    }
    
    .font-semibold {
      font-weight: 600;
    }
    
    .font-medium {
      font-weight: 500;
    }
  </style>
</head>
<body>
  ${content}
</body>
</html>
    `.trim();
  }
}
