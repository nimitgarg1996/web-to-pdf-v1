import { z } from "zod";

// Sentiment enum for visual indicators
export const SentimentSchema = z.enum(["POSITIVE", "NEUTRAL", "NEGATIVE"]);
export type Sentiment = z.infer<typeof SentimentSchema>;

// Executive Summary Component
export const ExecutiveSummarySchema = z.object({
  type: z.literal("EXECUTIVE_SUMMARY"),
  data: z.object({
    headline: z.string().max(100),
    sentiment: SentimentSchema,
    text: z.string().max(500),
    highlights: z.array(z.string()).optional(),
  }),
});

export type ExecutiveSummary = z.infer<typeof ExecutiveSummarySchema>;

// Financial Table Component
export const FinancialTableSchema = z.object({
  type: z.literal("FINANCIAL_TABLE"),
  data: z.object({
    title: z.string(),
    columns: z.array(
      z.object({
        key: z.string(),
        label: z.string(),
        format: z
          .enum(["text", "currency", "percentage", "number"])
          .default("text"),
      }),
    ),
    rows: z.array(z.record(z.union([z.string(), z.number()]))),
    showTotal: z.boolean().default(false),
    totalLabel: z.string().default("Total"),
  }),
});

export type FinancialTable = z.infer<typeof FinancialTableSchema>;

// Bar Chart Component (Double Series)
export const BarChartDoubleSchema = z.object({
  type: z.literal("CHART_BAR_DOUBLE"),
  data: z.object({
    title: z.string(),
    labels: z.array(z.string()),
    series_A: z.object({
      name: z.string(),
      data: z.array(z.number()),
      color: z.string().optional(),
    }),
    series_B: z.object({
      name: z.string(),
      data: z.array(z.number()),
      color: z.string().optional(),
    }),
  }),
});

export type BarChartDouble = z.infer<typeof BarChartDoubleSchema>;

// Line Chart Component
export const TrendLineChartSchema = z.object({
  type: z.literal("CHART_LINE_TREND"),
  data: z.object({
    title: z.string(),
    labels: z.array(z.string()),
    series: z.array(
      z.object({
        name: z.string(),
        data: z.array(z.number()),
        color: z.string().optional(),
      }),
    ),
  }),
});

export type TrendLineChart = z.infer<typeof TrendLineChartSchema>;

// Donut/Pie Chart Component
export const DonutChartSchema = z.object({
  type: z.literal("CHART_DONUT"),
  data: z.object({
    title: z.string(),
    centerLabel: z.string().optional(),
    centerValue: z.number().optional(),
    segments: z.array(
      z.object({
        name: z.string(),
        value: z.number(),
        color: z.string(),
        percentage: z.number().optional(),
      }),
    ),
    legend: z.boolean().default(true),
  }),
});

export type DonutChart = z.infer<typeof DonutChartSchema>;

// Stacked Bar Chart Component
export const StackedBarChartSchema = z.object({
  type: z.literal("CHART_STACKED_BAR"),
  data: z.object({
    title: z.string(),
    labels: z.array(z.string()),
    series: z.array(
      z.object({
        name: z.string(),
        data: z.array(z.number()),
        color: z.string().optional(),
      }),
    ),
    layout: z.enum(["horizontal", "vertical"]).default("horizontal"),
  }),
});

export type StackedBarChart = z.infer<typeof StackedBarChartSchema>;

// Entity Structure Chart Component
export const EntityChartSchema = z.object({
  type: z.literal("ENTITY_CHART"),
  data: z.object({
    title: z.string(),
    entities: z.array(
      z.object({
        name: z.string(),
        subtitle: z.string().optional(),
        ownership: z.number().min(0).max(100),
        icon: z
          .enum(["briefcase", "folder", "building", "user"])
          .default("briefcase"),
      }),
    ),
  }),
});

export type EntityChart = z.infer<typeof EntityChartSchema>;

// Heritage Map (Family Tree) Component
export const HeritageMapSchema = z.object({
  type: z.literal("HERITAGE_MAP"),
  data: z.object({
    title: z.string(),
    members: z.array(
      z.object({
        id: z.string(),
        name: z.string(),
        initials: z.string().min(1).max(3),
        parentId: z.string().optional(),
        generation: z.number().min(0),
      }),
    ),
  }),
});

export type HeritageMap = z.infer<typeof HeritageMapSchema>;

// Complex Table with Grouping Component
export const ComplexTableSchema = z.object({
  type: z.literal("COMPLEX_TABLE"),
  data: z.object({
    title: z.string(),
    columns: z.array(
      z.object({
        key: z.string(),
        label: z.string(),
        format: z
          .enum(["text", "currency", "percentage", "number"])
          .default("text"),
        align: z.enum(["left", "center", "right"]).default("left"),
        width: z.string().optional(),
      }),
    ),
    groups: z.array(
      z.object({
        groupName: z.string(),
        rows: z.array(z.record(z.union([z.string(), z.number()]))),
        showSubtotal: z.boolean().default(false),
      }),
    ),
  }),
});

export type ComplexTable = z.infer<typeof ComplexTableSchema>;

// Union of all component types
export const ComponentSchema = z.discriminatedUnion("type", [
  ExecutiveSummarySchema,
  FinancialTableSchema,
  BarChartDoubleSchema,
  TrendLineChartSchema,
  DonutChartSchema,
  StackedBarChartSchema,
  EntityChartSchema,
  HeritageMapSchema,
  ComplexTableSchema,
]);

export type Component = z.infer<typeof ComponentSchema>;
