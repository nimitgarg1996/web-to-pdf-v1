import { z } from "zod";
import { ComponentSchema } from "./components.schema.js";

export const LayoutSchema = z.enum(["single_column", "two_column"]);
export type Layout = z.infer<typeof LayoutSchema>;

export const PageSchema = z.object({
  layout: LayoutSchema,
  components: z.array(ComponentSchema),
});

export type Page = z.infer<typeof PageSchema>;

export const ReportManifestSchema = z.object({
  report_title: z.string(),
  subtitle: z.string().optional(),
  generated_at: z.string().datetime().optional(),
  branding: z
    .object({
      company_name: z.string(),
      logo_url: z.string().optional(),
      primary_color: z.string().default("#1E40AF"),
      secondary_color: z.string().default("#64748B"),
    })
    .optional(),
  pages: z.array(PageSchema).min(1),
});

export type ReportManifest = z.infer<typeof ReportManifestSchema>;
