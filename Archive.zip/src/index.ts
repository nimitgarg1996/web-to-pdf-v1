import dotenv from "dotenv";
import { createApp } from "./api/index.js";
import { pdfService } from "./services/pdf.service.js";

// Load environment variables
dotenv.config();

const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    // Initialize PDF service (browser instance)
    console.log("Initializing Puppeteer browser...");
    await pdfService.initialize();
    console.log("✓ Puppeteer browser ready");

    // Create Express app
    const app = createApp();

    // Start server
    app.listen(PORT, () => {
      console.log(`\n🚀 Project Gutenberg API Server`);
      console.log(`   Server running on http://localhost:${PORT}`);
      console.log(`   Health check: http://localhost:${PORT}/api/v1/health`);
      console.log(
        `   Generate PDF: POST http://localhost:${PORT}/api/v1/generate-pdf\n`,
      );
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();
