import { Router, Request, Response } from "express";
import { stitcherService } from "../../services/stitcher.service.js";
import { pdfService } from "../../services/pdf.service.js";
import {
  generatePdfWithReactPdf,
  sampleEstateReportData,
} from "../../pdf/pdf-renderer.service.js";
import { EstateReportProps } from "../../pdf/components/EstateReportDocument.js";

const router = Router();

/**
 * POST /api/v1/generate-pdf
 * Generate a PDF from a report manifest
 */
router.post("/generate-pdf", async (req: Request, res: Response) => {
  const startTime = Date.now();

  try {
    // Validate and process manifest
    const result = stitcherService.processManifest(req.body);

    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: "Invalid manifest",
        details: result.errors,
      });
    }

    // Generate PDF
    const pdfBuffer = await pdfService.generatePDF(result.html!);

    const renderTime = Date.now() - startTime;

    // Set response headers
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", 'attachment; filename="report.pdf"');
    res.setHeader("X-Render-Time-Ms", renderTime.toString());

    // Send PDF
    return res.send(pdfBuffer);
  } catch (error) {
    console.error("PDF generation error:", error);
    return res.status(500).json({
      success: false,
      error: "PDF generation failed",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

/**
 * POST /api/v1/generate-estate-report
 * Generate Estate Planning PDF using @react-pdf/renderer
 */
router.post("/generate-estate-report", async (req: Request, res: Response) => {
  const startTime = Date.now();

  try {
    // Use provided data or fall back to sample data
    const reportData: EstateReportProps =
      req.body && Object.keys(req.body).length > 0
        ? req.body
        : sampleEstateReportData;

    console.log("Generating estate report PDF with @react-pdf/renderer...");

    // Generate PDF using @react-pdf/renderer
    const pdfBuffer = await generatePdfWithReactPdf(reportData);

    const renderTime = Date.now() - startTime;
    console.log(`Estate report PDF generated in ${renderTime}ms`);

    // Set response headers
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="estate-report.pdf"',
    );
    res.setHeader("X-Render-Time-Ms", renderTime.toString());
    res.setHeader("X-Renderer", "react-pdf");

    // Send PDF
    return res.send(pdfBuffer);
  } catch (error) {
    console.error("Estate report PDF generation error:", error);
    return res.status(500).json({
      success: false,
      error: "Estate report PDF generation failed",
      message: error instanceof Error ? error.message : "Unknown error",
      stack: error instanceof Error ? error.stack : undefined,
    });
  }
});

/**
 * GET /api/v1/estate-report-sample
 * Generate sample estate report PDF for testing
 */
router.get("/estate-report-sample", async (_req: Request, res: Response) => {
  const startTime = Date.now();

  try {
    console.log("Generating sample estate report PDF...");

    // Generate PDF using sample data
    const pdfBuffer = await generatePdfWithReactPdf(sampleEstateReportData);

    const renderTime = Date.now() - startTime;
    console.log(`Sample estate report PDF generated in ${renderTime}ms`);

    // Set response headers
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="estate-report-sample.pdf"',
    );
    res.setHeader("X-Render-Time-Ms", renderTime.toString());
    res.setHeader("X-Renderer", "react-pdf");

    // Send PDF
    return res.send(pdfBuffer);
  } catch (error) {
    console.error("Sample estate report PDF generation error:", error);
    return res.status(500).json({
      success: false,
      error: "Sample estate report PDF generation failed",
      message: error instanceof Error ? error.message : "Unknown error",
      stack: error instanceof Error ? error.stack : undefined,
    });
  }
});

/**
 * GET /api/v1/health
 * Health check endpoint
 */
router.get("/health", async (_req: Request, res: Response) => {
  try {
    await pdfService.initialize();
    return res.json({
      success: true,
      status: "healthy",
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return res.status(503).json({
      success: false,
      status: "unhealthy",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;
