import express, { Express, Request, Response, NextFunction } from "express";
import cors from "cors";
import pdfRoutes from "./routes/pdf.routes.js";

export function createApp(): Express {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ extended: true }));

  // Request logging middleware
  app.use((req: Request, _res: Response, next: NextFunction) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
  });

  // Routes
  app.use("/api/v1", pdfRoutes);

  // Root endpoint
  app.get("/", (_req: Request, res: Response) => {
    res.json({
      name: "Project Gutenberg - AI Report Engine",
      version: "0.1.0",
      endpoints: {
        health: "GET /api/v1/health",
        generatePDF: "POST /api/v1/generate-pdf",
      },
    });
  });

  // Error handling middleware
  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    console.error("Unhandled error:", err);
    res.status(500).json({
      success: false,
      error: "Internal server error",
      message: err.message,
    });
  });

  return app;
}
