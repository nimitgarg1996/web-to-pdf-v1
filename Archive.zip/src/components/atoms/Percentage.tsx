import React from "react";

interface PercentageProps {
  value: number;
  decimals?: number;
}

export const Percentage: React.FC<PercentageProps> = ({
  value,
  decimals = 1,
}) => {
  const formatted = value.toFixed(decimals);
  const isNegative = value < 0;

  return (
    <span className={isNegative ? "text-red-600 font-semibold" : ""}>
      {formatted}%
    </span>
  );
};
