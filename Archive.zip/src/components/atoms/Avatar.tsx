import React from "react";

interface AvatarProps {
  initials: string;
  name: string;
  size?: number;
  bgColor?: string;
}

export const Avatar: React.FC<AvatarProps> = ({
  initials,
  name,
  size = 64,
  bgColor = "#0d9488",
}) => {
  const fontSize = size * 0.35; // Scale font size with avatar size

  return (
    <div className="avatar-container flex flex-col items-center">
      <div
        className="avatar-circle rounded-full flex items-center justify-center text-white font-bold"
        style={{
          width: `${size}px`,
          height: `${size}px`,
          backgroundColor: bgColor,
          fontSize: `${fontSize}px`,
        }}
      >
        {initials}
      </div>
      <p className="avatar-name text-center mt-2 text-sm text-gray-700 font-medium">
        {name}
      </p>
    </div>
  );
};
