import React from "react";
import type { Sentiment } from "../../schemas/components.schema.js";

interface SentimentIconProps {
  sentiment: Sentiment;
}

export const SentimentIcon: React.FC<SentimentIconProps> = ({ sentiment }) => {
  const icons = {
    POSITIVE: {
      symbol: "↑",
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    NEUTRAL: {
      symbol: "→",
      color: "text-gray-600",
      bgColor: "bg-gray-100",
    },
    NEGATIVE: {
      symbol: "↓",
      color: "text-red-600",
      bgColor: "bg-red-100",
    },
  };

  const config = icons[sentiment];

  return (
    <span
      className={`inline-flex items-center justify-center w-10 h-10 rounded-full ${config.bgColor} ${config.color} font-bold text-2xl`}
    >
      {config.symbol}
    </span>
  );
};
