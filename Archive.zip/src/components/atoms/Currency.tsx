import React from "react";

interface CurrencyProps {
  value: number;
  locale?: string;
  currency?: string;
}

export const Currency: React.FC<CurrencyProps> = ({
  value,
  locale = "en-US",
  currency = "USD",
}) => {
  const formatted = new Intl.NumberFormat(locale, {
    style: "currency",
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);

  const isNegative = value < 0;

  return (
    <span className={isNegative ? "text-red-600 font-semibold" : ""}>
      {isNegative ? `(${formatted.replace("-", "")})` : formatted}
    </span>
  );
};
