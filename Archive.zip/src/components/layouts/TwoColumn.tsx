import React from "react";
import type { Component } from "../../schemas/components.schema.js";
import { ExecutiveSummary } from "../molecules/ExecutiveSummary.js";
import { FinancialTable } from "../molecules/FinancialTable.js";
import { BarChartDouble } from "../charts/BarChartDouble.js";
import { TrendLineChart } from "../charts/TrendLineChart.js";
import { DonutChart } from "../charts/DonutChart.js";
import { StackedBarChart } from "../charts/StackedBarChart.js";
import { EntityChart } from "../molecules/EntityChart.js";
import { HeritageMap } from "../molecules/HeritageMap.js";
import { ComplexTable } from "../molecules/ComplexTable.js";

interface TwoColumnProps {
  components: Component[];
}

export const TwoColumn: React.FC<TwoColumnProps> = ({ components }) => {
  const renderComponent = (component: Component, index: number) => {
    switch (component.type) {
      case "EXECUTIVE_SUMMARY":
        return <ExecutiveSummary key={index} data={component.data} />;
      case "FINANCIAL_TABLE":
        return <FinancialTable key={index} data={component.data} />;
      case "CHART_BAR_DOUBLE":
        return <BarChartDouble key={index} data={component.data} />;
      case "CHART_LINE_TREND":
        return <TrendLineChart key={index} data={component.data} />;
      case "CHART_DONUT":
        return <DonutChart key={index} data={component.data} />;
      case "CHART_STACKED_BAR":
        return <StackedBarChart key={index} data={component.data} />;
      case "ENTITY_CHART":
        return <EntityChart key={index} data={component.data} />;
      case "HERITAGE_MAP":
        return <HeritageMap key={index} data={component.data} />;
      case "COMPLEX_TABLE":
        return <ComplexTable key={index} data={component.data} />;
      default:
        return null;
    }
  };

  // Split components into two columns
  const midpoint = Math.ceil(components.length / 2);
  const leftColumn = components.slice(0, midpoint);
  const rightColumn = components.slice(midpoint);

  return (
    <div className="two-column-layout grid grid-cols-2 gap-6">
      <div className="left-column">
        {leftColumn.map((component, index) =>
          renderComponent(component, index),
        )}
      </div>
      <div className="right-column">
        {rightColumn.map((component, index) =>
          renderComponent(component, index + midpoint),
        )}
      </div>
    </div>
  );
};
