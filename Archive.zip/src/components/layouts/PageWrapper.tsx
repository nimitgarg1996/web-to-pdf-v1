import React from "react";
import type { Page } from "../../schemas/manifest.schema.js";
import { SingleColumn } from "./SingleColumn.js";
import { TwoColumn } from "./TwoColumn.js";

interface PageWrapperProps {
  page: Page;
  pageNumber?: number;
}

export const PageWrapper: React.FC<PageWrapperProps> = ({
  page,
  pageNumber,
}) => {
  return (
    <div className="page-wrapper">
      {pageNumber && pageNumber > 1 && <div className="page-break"></div>}
      {page.layout === "single_column" ? (
        <SingleColumn components={page.components} />
      ) : (
        <TwoColumn components={page.components} />
      )}
    </div>
  );
};
