import React from "react";
import { IconSVG } from "../atoms/IconSVG.js";
import type { EntityChart as EntityChartType } from "../../schemas/components.schema.js";

interface EntityChartProps {
  data: EntityChartType["data"];
}

export const EntityChart: React.FC<EntityChartProps> = ({ data }) => {
  const { title, entities } = data;

  return (
    <div
      style={{
        background: "white",
        border: "1px solid #e5e7eb",
        borderRadius: "8px",
        padding: "24px",
        boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
        marginBottom: "24px",
      }}
    >
      <h3
        style={{
          fontSize: "20px",
          fontWeight: "700",
          color: "#111827",
          marginBottom: "24px",
        }}
      >
        {title}
      </h3>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: "24px",
        }}
      >
        {entities.map((entity, index) => (
          <div
            key={index}
            style={{
              flex: "1",
              textAlign: "center",
              padding: "20px",
              border: "2px solid #e5e7eb",
              borderRadius: "10px",
              background: "#ffffff",
              boxShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
            }}
          >
            {/* Icon */}
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginBottom: "16px",
                padding: "12px",
                background: "#f0fdfa",
                borderRadius: "50%",
                width: "80px",
                height: "80px",
                margin: "0 auto 16px",
              }}
            >
              <IconSVG type={entity.icon} size={48} color="#0d9488" />
            </div>

            {/* Name */}
            <h4
              style={{
                fontWeight: "700",
                color: "#111827",
                marginBottom: "6px",
                fontSize: "15px",
                lineHeight: "1.4",
              }}
            >
              {entity.name}
            </h4>

            {/* Subtitle */}
            {entity.subtitle && (
              <p
                style={{
                  fontSize: "13px",
                  color: "#6b7280",
                  marginBottom: "20px",
                }}
              >
                {entity.subtitle}
              </p>
            )}

            {/* Progress bar */}
            <div style={{ width: "100%" }}>
              <div
                style={{
                  height: "10px",
                  background: "#e5e7eb",
                  borderRadius: "5px",
                  overflow: "hidden",
                  marginBottom: "8px",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    background:
                      "linear-gradient(90deg, #14b8a6 0%, #0d9488 100%)",
                    width: `${entity.ownership}%`,
                    transition: "width 0.3s ease",
                  }}
                />
              </div>
              <p
                style={{
                  fontSize: "14px",
                  fontWeight: "700",
                  color: "#0d9488",
                }}
              >
                {entity.ownership}%
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
