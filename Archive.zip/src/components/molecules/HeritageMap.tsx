import React from "react";
import { Avatar } from "../atoms/Avatar.js";
import type { HeritageMap as HeritageMapType } from "../../schemas/components.schema.js";
import { getCardStyle, getTitleStyle, theme } from "../../styles/theme.js";

interface HeritageMapProps {
  data: HeritageMapType["data"];
}

export const HeritageMap: React.FC<HeritageMapProps> = ({ data }) => {
  const { title, members } = data;

  // Group members by generation
  const generations: Record<number, typeof members> = {};
  members.forEach((member) => {
    if (!generations[member.generation]) {
      generations[member.generation] = [];
    }
    generations[member.generation].push(member);
  });

  // Sort generations
  const sortedGenerations = Object.keys(generations)
    .map(Number)
    .sort()
    .map((gen) => ({ generation: gen, members: generations[gen] }));

  const colors = [
    theme.colors.primary[600], // Teal
    theme.colors.secondary[600], // Blue
    "#7C3AED", // Purple
    "#DC2626", // Red
    "#D97706", // Orange
  ];

  return (
    <div style={getCardStyle()}>
      <h3 style={getTitleStyle()}>{title}</h3>

      <div style={{ padding: "20px 0" }}>
        {sortedGenerations.map(
          ({ generation, members: genMembers }, genIndex) => (
            <div
              key={generation}
              style={{
                marginBottom:
                  genIndex < sortedGenerations.length - 1 ? "48px" : "0",
              }}
            >
              {/* Generation Label */}
              <div
                style={{
                  fontSize: "14px",
                  fontWeight: "600",
                  color: theme.colors.neutral[500],
                  textAlign: "center",
                  marginBottom: "24px",
                  textTransform: "uppercase",
                  letterSpacing: "0.5px",
                }}
              >
                Generation {generation + 1}
              </div>

              {/* Members Grid */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "flex-start",
                  gap: "40px",
                  flexWrap: "wrap",
                  padding: "0 20px",
                }}
              >
                {genMembers.map((member, memberIndex) => (
                  <div
                    key={member.id}
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      maxWidth: "120px",
                    }}
                  >
                    {/* Avatar */}
                    <div style={{ marginBottom: "12px" }}>
                      <Avatar
                        initials={member.initials}
                        name={member.name}
                        size={80}
                        bgColor={colors[memberIndex % colors.length]}
                      />
                    </div>

                    {/* Name */}
                    <div
                      style={{
                        fontSize: "14px",
                        fontWeight: "600",
                        color: theme.colors.neutral[900],
                        textAlign: "center",
                        lineHeight: "1.4",
                      }}
                    >
                      {member.name}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ),
        )}
      </div>
    </div>
  );
};
