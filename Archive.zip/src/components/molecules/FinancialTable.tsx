import React from "react";
import { Currency } from "../atoms/Currency.js";
import { Percentage } from "../atoms/Percentage.js";
import type { FinancialTable as FinancialTableType } from "../../schemas/components.schema.js";

interface FinancialTableProps {
  data: FinancialTableType["data"];
}

export const FinancialTable: React.FC<FinancialTableProps> = ({ data }) => {
  const { title, columns, rows, showTotal, totalLabel } = data;

  const formatValue = (
    value: string | number,
    format: "text" | "currency" | "percentage" | "number",
  ) => {
    if (format === "currency" && typeof value === "number") {
      return <Currency value={value} />;
    } else if (format === "percentage" && typeof value === "number") {
      return <Percentage value={value} />;
    } else if (format === "number" && typeof value === "number") {
      return value.toLocaleString("en-US");
    }
    return value;
  };

  const calculateTotal = (key: string, format: string) => {
    if (format === "text") return totalLabel;
    const sum = rows.reduce((acc, row) => {
      const val = row[key];
      return typeof val === "number" ? acc + val : acc;
    }, 0);
    return formatValue(sum, format as any);
  };

  return (
    <div className="financial-table mb-6">
      <h3 className="text-xl font-bold text-gray-900 mb-4">{title}</h3>
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-100 border-b-2 border-gray-300">
            {columns.map((col, index) => (
              <th
                key={index}
                className="px-4 py-3 text-left text-sm font-bold text-gray-700 uppercase"
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr
              key={rowIndex}
              className={rowIndex % 2 === 0 ? "bg-white" : "bg-gray-50"}
            >
              {columns.map((col, colIndex) => (
                <td
                  key={colIndex}
                  className="px-4 py-3 text-sm text-gray-900 border-b border-gray-200"
                >
                  {formatValue(row[col.key], col.format)}
                </td>
              ))}
            </tr>
          ))}
          {showTotal && (
            <tr className="bg-blue-50 border-t-2 border-blue-300 font-bold">
              {columns.map((col, index) => (
                <td
                  key={index}
                  className="px-4 py-3 text-sm text-gray-900 font-bold"
                >
                  {calculateTotal(col.key, col.format)}
                </td>
              ))}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
