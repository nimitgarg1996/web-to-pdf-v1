import React from "react";
import { SentimentIcon } from "../atoms/SentimentIcon.js";
import { Badge } from "../atoms/Badge.js";
import type { ExecutiveSummary as ExecutiveSummaryType } from "../../schemas/components.schema.js";

interface ExecutiveSummaryProps {
  data: ExecutiveSummaryType["data"];
}

export const ExecutiveSummary: React.FC<ExecutiveSummaryProps> = ({ data }) => {
  const { headline, sentiment, text, highlights } = data;

  return (
    <div className="executive-summary bg-white p-6 rounded-lg shadow-lg border border-gray-200 mb-6">
      <div className="flex items-start gap-4">
        <SentimentIcon sentiment={sentiment} />
        <div className="flex-1">
          <h2 className="text-2xl font-bold text-gray-900 mb-3">{headline}</h2>
          <p className="text-gray-700 mb-4">{text}</p>
          {highlights && highlights.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-gray-600 uppercase">
                Key Highlights
              </h3>
              <ul className="list-none space-y-2">
                {highlights.map((highlight, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <span className="text-blue-600">•</span>
                    <span className="text-gray-700">{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
