import React from "react";
import { Currency } from "../atoms/Currency.js";
import { Percentage } from "../atoms/Percentage.js";
import type { ComplexTable as ComplexTableType } from "../../schemas/components.schema.js";

interface ComplexTableProps {
  data: ComplexTableType["data"];
}

export const ComplexTable: React.FC<ComplexTableProps> = ({ data }) => {
  const { title, columns, groups } = data;

  const formatValue = (
    value: string | number,
    format: "text" | "currency" | "percentage" | "number",
  ) => {
    if (format === "currency" && typeof value === "number") {
      return <Currency value={value} />;
    } else if (format === "percentage" && typeof value === "number") {
      return <Percentage value={value} />;
    } else if (format === "number" && typeof value === "number") {
      return value.toLocaleString("en-US");
    }
    return value;
  };

  const calculateSubtotal = (
    rows: Array<Record<string, any>>,
    key: string,
    format: string,
  ) => {
    if (format === "text") return "";

    const sum = rows.reduce((acc, row) => {
      const val = row[key];
      return typeof val === "number" ? acc + val : acc;
    }, 0);

    return formatValue(sum, format as any);
  };

  return (
    <div className="complex-table mb-6">
      <h3 className="text-xl font-bold text-gray-900 mb-4">{title}</h3>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100 border-b-2 border-gray-300">
              {columns.map((col, index) => (
                <th
                  key={index}
                  className="px-4 py-3 text-sm font-bold text-gray-700 uppercase"
                  style={{
                    textAlign: col.align,
                    width: col.width,
                  }}
                >
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {groups.map((group, groupIndex) => (
              <React.Fragment key={groupIndex}>
                {/* Group header row */}
                <tr className="bg-blue-50 border-t-2 border-blue-200">
                  <td
                    colSpan={columns.length}
                    className="px-4 py-2 font-bold text-gray-900 text-sm"
                  >
                    {group.groupName}
                  </td>
                </tr>

                {/* Group data rows */}
                {group.rows.map((row, rowIndex) => (
                  <tr
                    key={rowIndex}
                    className={
                      rowIndex % 2 === 0
                        ? "bg-white hover:bg-gray-50"
                        : "bg-gray-50 hover:bg-gray-100"
                    }
                  >
                    {columns.map((col, colIndex) => (
                      <td
                        key={colIndex}
                        className="px-4 py-3 text-sm text-gray-900 border-b border-gray-200"
                        style={{ textAlign: col.align }}
                      >
                        {formatValue(row[col.key], col.format)}
                      </td>
                    ))}
                  </tr>
                ))}

                {/* Subtotal row */}
                {group.showSubtotal && (
                  <tr className="bg-blue-100 border-t-2 border-blue-300 font-bold">
                    <td className="px-4 py-3 text-sm text-gray-900 font-bold">
                      {group.groupName} Subtotal
                    </td>
                    {columns.slice(1).map((col, index) => (
                      <td
                        key={index}
                        className="px-4 py-3 text-sm text-gray-900 font-bold"
                        style={{ textAlign: col.align }}
                      >
                        {calculateSubtotal(group.rows, col.key, col.format)}
                      </td>
                    ))}
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
