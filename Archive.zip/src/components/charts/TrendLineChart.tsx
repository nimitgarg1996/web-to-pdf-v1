import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import type { TrendLineChart as TrendLineChartType } from "../../schemas/components.schema.js";

interface TrendLineChartProps {
  data: TrendLineChartType["data"];
}

export const TrendLineChart: React.FC<TrendLineChartProps> = ({ data }) => {
  const { title, labels, series } = data;

  // Transform data for Recharts format
  const chartData = labels.map((label, index) => {
    const point: any = { name: label };
    series.forEach((s) => {
      point[s.name] = s.data[index];
    });
    return point;
  });

  const colors = [
    "#1E40AF",
    "#DC2626",
    "#059669",
    "#D97706",
    "#7C3AED",
    "#DB2777",
  ];

  return (
    <div className="chart-container mb-6">
      <h3 className="text-xl font-bold text-gray-900 mb-4">{title}</h3>
      <div style={{ width: "100%", height: 400 }}>
        <ResponsiveContainer>
          <LineChart
            data={chartData}
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" stroke="#374151" />
            <YAxis stroke="#374151" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "0.375rem",
              }}
            />
            <Legend />
            {series.map((s, index) => (
              <Line
                key={s.name}
                type="monotone"
                dataKey={s.name}
                stroke={s.color || colors[index % colors.length]}
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
