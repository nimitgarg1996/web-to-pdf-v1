import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import type { StackedBarChart as StackedBarChartType } from "../../schemas/components.schema.js";

interface StackedBarChartProps {
  data: StackedBarChartType["data"];
}

export const StackedBarChart: React.FC<StackedBarChartProps> = ({ data }) => {
  const { title, labels, series, layout } = data;

  // Transform data for Recharts
  const chartData = labels.map((label, index) => {
    const point: any = { name: label };
    series.forEach((s) => {
      point[s.name] = s.data[index] || 0;
    });
    return point;
  });

  const colors = [
    "#1E40AF",
    "#0d9488",
    "#5eead4",
    "#dc2626",
    "#D97706",
    "#7C3AED",
  ];

  return (
    <div
      className="chart-container stacked-bar-chart mb-6"
      style={{
        background: "white",
        border: "1px solid #e5e7eb",
        borderRadius: "8px",
        padding: "24px",
        boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
      }}
    >
      <h3
        className="text-xl font-bold text-gray-900 mb-6"
        style={{
          fontSize: "20px",
          fontWeight: "700",
          color: "#111827",
          marginBottom: "24px",
        }}
      >
        {title}
      </h3>
      <div style={{ width: "100%", height: 400 }}>
        <BarChart
          width={750}
          height={400}
          data={chartData}
          layout={layout === "vertical" ? "vertical" : "horizontal"}
          margin={{ top: 20, right: 30, left: 80, bottom: 40 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          {layout === "vertical" ? (
            <>
              <XAxis
                type="number"
                stroke="#6b7280"
                style={{ fontSize: "12px" }}
                tickFormatter={(value) => value.toLocaleString()}
              />
              <YAxis
                type="category"
                dataKey="name"
                stroke="#6b7280"
                style={{ fontSize: "12px" }}
              />
            </>
          ) : (
            <>
              <XAxis
                type="category"
                dataKey="name"
                stroke="#6b7280"
                style={{ fontSize: "12px" }}
                angle={-15}
                textAnchor="end"
                height={60}
              />
              <YAxis
                type="number"
                stroke="#6b7280"
                style={{ fontSize: "12px" }}
                tickFormatter={(value) => value.toLocaleString()}
              />
            </>
          )}
          <Tooltip
            contentStyle={{
              backgroundColor: "#fff",
              border: "1px solid #e5e7eb",
              borderRadius: "0.375rem",
              padding: "12px",
              boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
            }}
            formatter={(value: number) => `$${value.toLocaleString()}`}
          />
          <Legend
            wrapperStyle={{
              paddingTop: "16px",
              fontSize: "13px",
            }}
            iconType="circle"
            iconSize={10}
          />
          {series.map((s, index) => (
            <Bar
              key={s.name}
              dataKey={s.name}
              stackId="a"
              fill={s.color || colors[index % colors.length]}
              radius={index === series.length - 1 ? [4, 4, 0, 0] : undefined}
            />
          ))}
        </BarChart>
      </div>
    </div>
  );
};
