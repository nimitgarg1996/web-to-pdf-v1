import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import type { BarChartDouble as BarChartDoubleType } from "../../schemas/components.schema.js";

interface BarChartDoubleProps {
  data: BarChartDoubleType["data"];
}

export const BarChartDouble: React.FC<BarChartDoubleProps> = ({ data }) => {
  const { title, labels, series_A, series_B } = data;

  // Transform data for Recharts format
  const chartData = labels.map((label, index) => ({
    name: label,
    [series_A.name]: series_A.data[index],
    [series_B.name]: series_B.data[index],
  }));

  return (
    <div className="chart-container mb-6">
      <h3 className="text-xl font-bold text-gray-900 mb-4">{title}</h3>
      <div style={{ width: "100%", height: 400 }}>
        <ResponsiveContainer>
          <BarChart
            data={chartData}
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" stroke="#374151" />
            <YAxis stroke="#374151" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "0.375rem",
              }}
            />
            <Legend />
            <Bar
              dataKey={series_A.name}
              fill={series_A.color || "#1E40AF"}
              radius={[4, 4, 0, 0]}
            />
            <Bar
              dataKey={series_B.name}
              fill={series_B.color || "#64748B"}
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
