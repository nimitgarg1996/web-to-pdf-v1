import React from "react";
import { PieChart, Pie, Cell, Legend } from "recharts";
import type { DonutChart as DonutChartType } from "../../schemas/components.schema.js";
import { getCardStyle, getTitleStyle } from "../../styles/theme.js";

interface DonutChartProps {
  data: DonutChartType["data"];
}

export const DonutChart: React.FC<DonutChartProps> = ({ data }) => {
  const { title, centerLabel, centerValue, segments, legend } = data;

  // Calculate total if centerValue not provided
  const total =
    centerValue || segments.reduce((sum, seg) => sum + seg.value, 0);

  // Transform data for Recharts
  const chartData = segments.map((seg) => ({
    name: seg.name,
    value: seg.value,
    color: seg.color,
    percentage: seg.percentage || (seg.value / total) * 100,
  }));

  return (
    <div
      className="chart-container donut-chart mb-6"
      style={{
        background: "white",
        border: "1px solid #e5e7eb",
        borderRadius: "8px",
        padding: "24px",
        boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
      }}
    >
      <h3
        className="text-xl font-bold text-gray-900 mb-6"
        style={{
          fontSize: "20px",
          fontWeight: "700",
          color: "#111827",
          marginBottom: "24px",
        }}
      >
        {title}
      </h3>
      <div style={{ width: "100%", height: 400, position: "relative" }}>
        <PieChart width={750} height={400}>
          <Pie
            data={chartData}
            cx={220}
            cy={200}
            innerRadius={85}
            outerRadius={145}
            paddingAngle={3}
            dataKey="value"
            stroke="#fff"
            strokeWidth={3}
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          {legend && (
            <Legend
              verticalAlign="middle"
              align="right"
              layout="vertical"
              wrapperStyle={{
                right: 20,
                top: "50%",
                transform: "translateY(-50%)",
                fontSize: "14px",
                lineHeight: "24px",
              }}
              formatter={(value, entry: any) => {
                const item = chartData.find((d) => d.name === value);
                return `${value}: $${item?.value.toLocaleString()} (${item?.percentage.toFixed(2)}%)`;
              }}
              iconType="circle"
              iconSize={10}
            />
          )}
        </PieChart>

        {/* Center label */}
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "220px",
            transform: "translate(-50%, -50%)",
            textAlign: "center",
            pointerEvents: "none",
          }}
        >
          {centerLabel && (
            <div
              style={{
                fontSize: "13px",
                color: "#6b7280",
                marginBottom: "8px",
                fontWeight: "500",
                letterSpacing: "0.5px",
              }}
            >
              {centerLabel}
            </div>
          )}
          <div
            style={{
              fontSize: "32px",
              fontWeight: "700",
              color: "#111827",
              lineHeight: "1.2",
            }}
          >
            ${total.toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
};
