import React from "react";
import type { ReportManifest } from "../../schemas/manifest.schema.js";
import { PageWrapper } from "../layouts/PageWrapper.js";

interface ReportTemplateProps {
  manifest: ReportManifest;
}

export const ReportTemplate: React.FC<ReportTemplateProps> = ({ manifest }) => {
  const { report_title, subtitle, generated_at, branding, pages } = manifest;

  const primaryColor = branding?.primary_color || "#1E40AF";
  const secondaryColor = branding?.secondary_color || "#64748B";
  const companyName = branding?.company_name || "";

  return (
    <html lang="en">
      <head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>{report_title}</title>
        <style>{`
          :root {
            --primary-color: ${primaryColor};
            --secondary-color: ${secondaryColor};
          }
        `}</style>
      </head>
      <body>
        {/* Report Header */}
        <div className="report-header mb-8 pb-4 border-b-2 border-gray-300">
          <h1 className="text-3xl font-bold text-gray-900">{report_title}</h1>
          {subtitle && <p className="text-lg text-gray-600 mt-2">{subtitle}</p>}
          <div className="flex justify-between items-center mt-4 text-sm text-gray-500">
            <span>{companyName}</span>
            <span>
              {generated_at
                ? new Date(generated_at).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })
                : new Date().toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
            </span>
          </div>
        </div>

        {/* Report Pages */}
        <div className="report-content">
          {pages.map((page, index) => (
            <PageWrapper key={index} page={page} pageNumber={index + 1} />
          ))}
        </div>
      </body>
    </html>
  );
};
