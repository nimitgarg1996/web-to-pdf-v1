import React from "react";
import { View, Text, Svg, Path, G, StyleSheet } from "@react-pdf/renderer";
import { pdfColors, pdfFonts, commonStyles, chartColors } from "../theme.js";

interface DonutSegment {
  name: string;
  value: number;
  color?: string;
  percentage?: number;
}

interface DonutChartProps {
  title?: string;
  centerLabel?: string;
  centerValue?: number;
  segments: DonutSegment[];
  showLegend?: boolean;
  size?: number;
}

const styles = StyleSheet.create({
  container: {
    ...commonStyles.card,
  },
  chartContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  svgContainer: {
    position: "relative",
    width: 200,
    height: 200,
  },
  centerLabelContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
  },
  centerLabel: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[500],
    textAlign: "center",
    marginBottom: 4,
  },
  centerValue: {
    fontSize: pdfFonts.size["3xl"],
    fontWeight: "bold",
    color: pdfColors.neutral[900],
    textAlign: "center",
  },
  legend: {
    flex: 1,
    marginLeft: 40,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 10,
  },
  legendText: {
    fontSize: pdfFonts.size.base,
    color: pdfColors.neutral[700],
  },
  legendValue: {
    fontSize: pdfFonts.size.base,
    fontWeight: "semibold",
    color: pdfColors.neutral[900],
    marginLeft: 4,
  },
  legendPercentage: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[500],
    marginLeft: 4,
  },
});

/**
 * Calculate SVG arc path for a donut segment
 */
function describeArc(
  cx: number,
  cy: number,
  outerRadius: number,
  innerRadius: number,
  startAngle: number,
  endAngle: number,
): string {
  const startOuter = polarToCartesian(cx, cy, outerRadius, endAngle);
  const endOuter = polarToCartesian(cx, cy, outerRadius, startAngle);
  const startInner = polarToCartesian(cx, cy, innerRadius, endAngle);
  const endInner = polarToCartesian(cx, cy, innerRadius, startAngle);

  const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

  return [
    "M",
    startOuter.x,
    startOuter.y,
    "A",
    outerRadius,
    outerRadius,
    0,
    largeArcFlag,
    0,
    endOuter.x,
    endOuter.y,
    "L",
    endInner.x,
    endInner.y,
    "A",
    innerRadius,
    innerRadius,
    0,
    largeArcFlag,
    1,
    startInner.x,
    startInner.y,
    "Z",
  ].join(" ");
}

function polarToCartesian(
  cx: number,
  cy: number,
  radius: number,
  angleInDegrees: number,
) {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180;
  return {
    x: cx + radius * Math.cos(angleInRadians),
    y: cy + radius * Math.sin(angleInRadians),
  };
}

export const DonutChart: React.FC<DonutChartProps> = ({
  title,
  centerLabel,
  centerValue,
  segments,
  showLegend = true,
  size = 200,
}) => {
  // Calculate total
  const total =
    centerValue || segments.reduce((sum, seg) => sum + seg.value, 0);

  // Calculate percentages if not provided
  const segmentsWithPercentage = segments.map((seg, index) => ({
    ...seg,
    percentage: seg.percentage ?? (seg.value / total) * 100,
    color: seg.color || chartColors[index % chartColors.length],
  }));

  // Calculate arc paths
  const cx = size / 2;
  const cy = size / 2;
  const outerRadius = size / 2 - 10;
  const innerRadius = outerRadius * 0.6;

  let currentAngle = 0;
  const arcs = segmentsWithPercentage.map((seg) => {
    const segmentAngle = (seg.percentage / 100) * 360;
    const startAngle = currentAngle;
    const endAngle = currentAngle + segmentAngle;
    currentAngle = endAngle;

    return {
      ...seg,
      path: describeArc(cx, cy, outerRadius, innerRadius, startAngle, endAngle),
    };
  });

  // Format currency
  const formatCurrency = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    }
    return `$${value.toLocaleString()}`;
  };

  return (
    <View style={styles.container}>
      {title && <Text style={commonStyles.cardTitle}>{title}</Text>}

      <View style={styles.chartContainer}>
        {/* SVG Donut Chart */}
        <View style={styles.svgContainer}>
          <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
            <G>
              {arcs.map((arc, index) => (
                <Path key={index} d={arc.path} fill={arc.color} />
              ))}
            </G>
          </Svg>

          {/* Center Label */}
          <View style={styles.centerLabelContainer}>
            {centerLabel && (
              <Text style={styles.centerLabel}>{centerLabel}</Text>
            )}
            <Text style={styles.centerValue}>{formatCurrency(total)}</Text>
          </View>
        </View>

        {/* Legend */}
        {showLegend && (
          <View style={styles.legend}>
            {segmentsWithPercentage.map((seg, index) => (
              <View key={index} style={styles.legendItem}>
                <View
                  style={[styles.legendDot, { backgroundColor: seg.color }]}
                />
                <View>
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <Text style={styles.legendText}>{seg.name}</Text>
                    <Text style={styles.legendPercentage}>
                      ({seg.percentage.toFixed(1)}%)
                    </Text>
                  </View>
                  <Text style={styles.legendValue}>
                    {formatCurrency(seg.value)}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}
      </View>
    </View>
  );
};
