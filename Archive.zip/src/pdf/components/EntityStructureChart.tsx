import React from "react";
import {
  View,
  Text,
  Svg,
  Path,
  Line,
  Circle,
  StyleSheet,
} from "@react-pdf/renderer";
import { pdfColors, pdfFonts, commonStyles, chartColors } from "../theme.js";

interface Entity {
  name: string;
  subtitle?: string;
  type: "trust" | "estate" | "business" | "individual";
  percentage?: number;
  color?: string;
}

interface EntityStructureChartProps {
  title?: string;
  entities: Entity[];
  showConnections?: boolean;
  legendItems?: Array<{ label: string; color: string }>;
}

const styles = StyleSheet.create({
  container: {
    ...commonStyles.card,
  },
  legend: {
    flexDirection: "row",
    marginBottom: 20,
    gap: 20,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 6,
  },
  legendText: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[600],
  },
  entitiesContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "flex-start",
    paddingTop: 20,
  },
  entityCard: {
    alignItems: "center",
    width: 120,
  },
  iconContainer: {
    width: 60,
    height: 60,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  entityName: {
    fontSize: pdfFonts.size.sm,
    fontWeight: "bold",
    color: pdfColors.neutral[900],
    textAlign: "center",
    marginBottom: 4,
  },
  entitySubtitle: {
    fontSize: pdfFonts.size.xs,
    color: pdfColors.neutral[500],
    textAlign: "center",
    marginBottom: 8,
  },
  progressContainer: {
    width: "100%",
    height: 8,
    backgroundColor: pdfColors.neutral[200],
    borderRadius: 4,
    marginTop: 8,
    overflow: "hidden",
  },
  progressBar: {
    height: "100%",
    borderRadius: 4,
  },
  percentageText: {
    fontSize: pdfFonts.size.sm,
    fontWeight: "semibold",
    color: pdfColors.neutral[700],
    textAlign: "center",
    marginTop: 4,
  },
});

/**
 * SVG Icons for different entity types
 */
const EntityIcon: React.FC<{ type: Entity["type"]; color: string }> = ({
  type,
  color,
}) => {
  const iconSize = 30;

  const icons: Record<Entity["type"], React.ReactNode> = {
    trust: (
      <Svg width={iconSize} height={iconSize} viewBox="0 0 24 24">
        <Path
          d="M14 6V4h-4v2h4zM4 8v11h16V8H4zm16-2c1.11 0 2 .89 2 2v11c0 1.11-.89 2-2 2H4c-1.11 0-2-.89-2-2l.01-11c0-1.11.88-2 1.99-2h4V4c0-1.11.89-2 2-2h4c1.11 0 2 .89 2 2v2h4z"
          fill={color}
        />
      </Svg>
    ),
    estate: (
      <Svg width={iconSize} height={iconSize} viewBox="0 0 24 24">
        <Path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" fill={color} />
      </Svg>
    ),
    business: (
      <Svg width={iconSize} height={iconSize} viewBox="0 0 24 24">
        <Path
          d="M12 7V3H2v18h20V7H12zM6 19H4v-2h2v2zm0-4H4v-2h2v2zm0-4H4V9h2v2zm0-4H4V5h2v2zm4 12H8v-2h2v2zm0-4H8v-2h2v2zm0-4H8V9h2v2zm0-4H8V5h2v2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8v10zm-2-8h-2v2h2v-2zm0 4h-2v2h2v-2z"
          fill={color}
        />
      </Svg>
    ),
    individual: (
      <Svg width={iconSize} height={iconSize} viewBox="0 0 24 24">
        <Path
          d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
          fill={color}
        />
      </Svg>
    ),
  };

  return icons[type];
};

export const EntityStructureChart: React.FC<EntityStructureChartProps> = ({
  title,
  entities,
  showConnections = true,
  legendItems,
}) => {
  const defaultLegend = [
    { label: "Taxable Estate", color: pdfColors.accent.teal },
    { label: "Non-Taxable Estate", color: pdfColors.accent.blue },
    { label: "GST Exempt", color: pdfColors.accent.purple },
    { label: "Non-GST Exempt", color: pdfColors.accent.orange },
  ];

  const legend = legendItems || defaultLegend;

  return (
    <View style={styles.container}>
      {title && <Text style={commonStyles.cardTitle}>{title}</Text>}

      {/* Legend */}
      <View style={styles.legend}>
        {legend.map((item, index) => (
          <View key={index} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: item.color }]} />
            <Text style={styles.legendText}>{item.label}</Text>
          </View>
        ))}
      </View>

      {/* Connection lines (SVG) */}
      {showConnections && entities.length > 1 && (
        <View style={{ height: 40, position: "relative" }}>
          <Svg width="100%" height={40} viewBox="0 0 500 40">
            <Line
              x1={50}
              y1={20}
              x2={450}
              y2={20}
              stroke={pdfColors.neutral[300]}
              strokeWidth={2}
            />
            {entities.map((_, index) => {
              const x = 50 + (index * 400) / (entities.length - 1 || 1);
              return (
                <Circle
                  key={index}
                  cx={x}
                  cy={20}
                  r={4}
                  fill={pdfColors.neutral[300]}
                />
              );
            })}
          </Svg>
        </View>
      )}

      {/* Entities */}
      <View style={styles.entitiesContainer}>
        {entities.map((entity, index) => {
          const color = entity.color || chartColors[index % chartColors.length];
          return (
            <View key={index} style={styles.entityCard}>
              {/* Icon */}
              <View
                style={[
                  styles.iconContainer,
                  { backgroundColor: `${color}20` },
                ]}
              >
                <EntityIcon type={entity.type} color={color} />
              </View>

              {/* Name */}
              <Text style={styles.entityName}>{entity.name}</Text>

              {/* Subtitle */}
              {entity.subtitle && (
                <Text style={styles.entitySubtitle}>{entity.subtitle}</Text>
              )}

              {/* Progress bar */}
              {entity.percentage !== undefined && (
                <>
                  <View style={styles.progressContainer}>
                    <View
                      style={[
                        styles.progressBar,
                        {
                          width: `${entity.percentage}%`,
                          backgroundColor: color,
                        },
                      ]}
                    />
                  </View>
                  <Text style={styles.percentageText}>
                    {entity.percentage}%
                  </Text>
                </>
              )}
            </View>
          );
        })}
      </View>
    </View>
  );
};
