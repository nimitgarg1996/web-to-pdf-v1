import React from "react";
import { View, Text, StyleSheet } from "@react-pdf/renderer";
import { pdfColors, pdfFonts, commonStyles } from "../theme.js";

interface TrustProperty {
  label: string;
  value: string;
}

interface TrustDetailCardProps {
  badge?: {
    label: string;
    color: "blue" | "green" | "teal" | "purple";
  };
  trustName: string;
  subtitle?: string;
  properties: TrustProperty[];
}

const badgeColors = {
  blue: { bg: pdfColors.secondary[100], text: pdfColors.secondary[700] },
  green: { bg: "#d1fae5", text: "#047857" },
  teal: { bg: pdfColors.primary[100], text: pdfColors.primary[700] },
  purple: { bg: "#ede9fe", text: "#6d28d9" },
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: pdfColors.white,
    borderWidth: 1,
    borderColor: pdfColors.neutral[200],
    borderRadius: 8,
    padding: 16,
    width: "48%",
    marginBottom: 16,
  },
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  badge: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 4,
    marginRight: 10,
  },
  badgeText: {
    fontSize: pdfFonts.size.xs,
    fontWeight: "bold",
  },
  trustName: {
    fontSize: pdfFonts.size.lg,
    fontWeight: "bold",
    color: pdfColors.neutral[900],
    flex: 1,
  },
  subtitle: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[500],
    marginTop: 2,
  },
  propertiesContainer: {
    marginTop: 8,
  },
  propertyRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: pdfColors.neutral[100],
  },
  propertyLabel: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[600],
    flex: 1,
  },
  propertyValue: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[900],
    fontWeight: "medium",
    flex: 1,
    textAlign: "right",
  },
});

export const TrustDetailCard: React.FC<TrustDetailCardProps> = ({
  badge,
  trustName,
  subtitle,
  properties,
}) => {
  const badgeStyle = badge ? badgeColors[badge.color] : null;

  return (
    <View style={styles.card}>
      {/* Header with badge */}
      <View style={styles.header}>
        {badge && badgeStyle && (
          <View style={[styles.badge, { backgroundColor: badgeStyle.bg }]}>
            <Text style={[styles.badgeText, { color: badgeStyle.text }]}>
              {badge.label}
            </Text>
          </View>
        )}
        <View style={{ flex: 1 }}>
          <Text style={styles.trustName}>{trustName}</Text>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
        </View>
      </View>

      {/* Properties table */}
      <View style={styles.propertiesContainer}>
        {properties.map((prop, index) => (
          <View key={index} style={styles.propertyRow}>
            <Text style={styles.propertyLabel}>{prop.label}</Text>
            <Text style={styles.propertyValue}>{prop.value}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

/**
 * Container for multiple trust cards
 */
interface TrustCardsContainerProps {
  title?: string;
  subtitle?: string;
  cards: TrustDetailCardProps[];
}

export const TrustCardsContainer: React.FC<TrustCardsContainerProps> = ({
  title,
  subtitle,
  cards,
}) => {
  return (
    <View style={commonStyles.card}>
      {title && (
        <View style={{ marginBottom: 8 }}>
          <Text
            style={{
              fontSize: pdfFonts.size.sm,
              color: pdfColors.neutral[500],
            }}
          >
            {subtitle}
          </Text>
          <Text style={commonStyles.cardTitle}>{title}</Text>
        </View>
      )}
      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          justifyContent: "space-between",
        }}
      >
        {cards.map((card, index) => (
          <TrustDetailCard key={index} {...card} />
        ))}
      </View>
    </View>
  );
};
