import React from "react";
import { View, Text, StyleSheet } from "@react-pdf/renderer";
import { pdfColors, pdfFonts, commonStyles } from "../theme.js";

interface Column {
  key: string;
  label: string;
  width?: string | number;
  align?: "left" | "center" | "right";
  format?: "text" | "currency" | "percentage" | "number";
}

interface ColumnGroup {
  label: string;
  columns: Column[];
}

interface RowGroup {
  groupName: string;
  rows: Array<Record<string, string | number>>;
  showSubtotal?: boolean;
}

interface AssetTableProps {
  title?: string;
  subtitle?: string;
  columnGroups?: ColumnGroup[];
  columns?: Column[];
  groups: RowGroup[];
  totalLabel?: string;
}

const styles = StyleSheet.create({
  container: {
    ...commonStyles.card,
  },
  headerRow: {
    flexDirection: "row",
    backgroundColor: pdfColors.neutral[100],
    borderBottomWidth: 1,
    borderBottomColor: pdfColors.neutral[300],
  },
  headerGroupRow: {
    flexDirection: "row",
    backgroundColor: pdfColors.neutral[50],
    borderBottomWidth: 1,
    borderBottomColor: pdfColors.neutral[200],
  },
  headerCell: {
    padding: 8,
    fontSize: pdfFonts.size.xs,
    fontWeight: "bold",
    color: pdfColors.neutral[600],
    textTransform: "uppercase",
  },
  headerGroupCell: {
    padding: 6,
    fontSize: pdfFonts.size.xs,
    fontWeight: "semibold",
    color: pdfColors.neutral[500],
    textAlign: "center",
    borderLeftWidth: 1,
    borderLeftColor: pdfColors.neutral[200],
  },
  groupHeaderRow: {
    flexDirection: "row",
    backgroundColor: pdfColors.primary[50],
    borderTopWidth: 1,
    borderTopColor: pdfColors.primary[200],
    paddingVertical: 6,
    paddingHorizontal: 8,
  },
  groupHeaderText: {
    fontSize: pdfFonts.size.sm,
    fontWeight: "bold",
    color: pdfColors.neutral[800],
  },
  dataRow: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: pdfColors.neutral[100],
  },
  dataRowAlternate: {
    backgroundColor: pdfColors.neutral[50],
  },
  dataCell: {
    padding: 8,
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[900],
  },
  subtotalRow: {
    flexDirection: "row",
    backgroundColor: pdfColors.primary[100],
    borderTopWidth: 1,
    borderTopColor: pdfColors.primary[300],
  },
  subtotalCell: {
    padding: 8,
    fontSize: pdfFonts.size.sm,
    fontWeight: "bold",
    color: pdfColors.neutral[900],
  },
  totalRow: {
    flexDirection: "row",
    backgroundColor: pdfColors.neutral[800],
  },
  totalCell: {
    padding: 10,
    fontSize: pdfFonts.size.base,
    fontWeight: "bold",
    color: pdfColors.white,
  },
});

/**
 * Format value based on type
 */
const formatValue = (
  value: string | number,
  format?: Column["format"],
): string => {
  if (typeof value === "string") return value;

  switch (format) {
    case "currency":
      return `$${value.toLocaleString("en-US", { minimumFractionDigits: 0 })}`;
    case "percentage":
      return `${value.toFixed(1)}%`;
    case "number":
      return value.toLocaleString("en-US");
    default:
      return String(value);
  }
};

/**
 * Calculate subtotal for a group
 */
const calculateSubtotal = (
  rows: Array<Record<string, string | number>>,
  key: string,
): number => {
  return rows.reduce((sum, row) => {
    const val = row[key];
    return typeof val === "number" ? sum + val : sum;
  }, 0);
};

export const AssetTable: React.FC<AssetTableProps> = ({
  title,
  subtitle,
  columnGroups,
  columns,
  groups,
  totalLabel,
}) => {
  // Flatten columns if using column groups
  const flatColumns: Column[] = columnGroups
    ? columnGroups.flatMap((group) => group.columns)
    : columns || [];

  return (
    <View style={styles.container}>
      {/* Title */}
      {(title || subtitle) && (
        <View style={{ marginBottom: 16 }}>
          {subtitle && (
            <Text
              style={{
                fontSize: pdfFonts.size.sm,
                color: pdfColors.neutral[500],
              }}
            >
              {subtitle}
            </Text>
          )}
          {title && <Text style={commonStyles.cardTitle}>{title}</Text>}
        </View>
      )}

      {/* Column Group Headers (if using groups) */}
      {columnGroups && (
        <View style={styles.headerGroupRow}>
          {columnGroups.map((group, index) => (
            <View
              key={index}
              style={[
                styles.headerGroupCell,
                {
                  flex: group.columns.length,
                  borderLeftWidth: index === 0 ? 0 : 1,
                },
              ]}
            >
              <Text>{group.label}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Column Headers */}
      <View style={styles.headerRow}>
        {flatColumns.map((col, index) => (
          <View
            key={index}
            style={[
              styles.headerCell,
              {
                flex: col.width ? undefined : 1,
                width: col.width,
                textAlign: col.align || "left",
              },
            ]}
          >
            <Text>{col.label}</Text>
          </View>
        ))}
      </View>

      {/* Data Groups */}
      {groups.map((group, groupIndex) => (
        <View key={groupIndex}>
          {/* Group Header */}
          <View style={styles.groupHeaderRow}>
            <Text style={styles.groupHeaderText}>{group.groupName}</Text>
          </View>

          {/* Group Rows */}
          {group.rows.map((row, rowIndex) => (
            <View
              key={rowIndex}
              style={[
                styles.dataRow,
                rowIndex % 2 === 1 ? styles.dataRowAlternate : {},
              ]}
            >
              {flatColumns.map((col, colIndex) => (
                <View
                  key={colIndex}
                  style={[
                    styles.dataCell,
                    {
                      flex: col.width ? undefined : 1,
                      width: col.width,
                      textAlign: col.align || "left",
                    },
                  ]}
                >
                  <Text>{formatValue(row[col.key], col.format)}</Text>
                </View>
              ))}
            </View>
          ))}

          {/* Subtotal */}
          {group.showSubtotal && (
            <View style={styles.subtotalRow}>
              {flatColumns.map((col, colIndex) => (
                <View
                  key={colIndex}
                  style={[
                    styles.subtotalCell,
                    {
                      flex: col.width ? undefined : 1,
                      width: col.width,
                      textAlign: col.align || "left",
                    },
                  ]}
                >
                  <Text>
                    {colIndex === 0
                      ? `${group.groupName} Subtotal`
                      : formatValue(
                          calculateSubtotal(group.rows, col.key),
                          col.format,
                        )}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </View>
      ))}

      {/* Grand Total */}
      {totalLabel && (
        <View style={styles.totalRow}>
          {flatColumns.map((col, colIndex) => {
            const allRows = groups.flatMap((g) => g.rows);
            return (
              <View
                key={colIndex}
                style={[
                  styles.totalCell,
                  {
                    flex: col.width ? undefined : 1,
                    width: col.width,
                    textAlign: col.align || "left",
                  },
                ]}
              >
                <Text>
                  {colIndex === 0
                    ? totalLabel
                    : formatValue(
                        calculateSubtotal(allRows, col.key),
                        col.format,
                      )}
                </Text>
              </View>
            );
          })}
        </View>
      )}
    </View>
  );
};
