import React from "react";
import { View, Text, Svg, Path, Rect, StyleSheet } from "@react-pdf/renderer";
import { pdfColors, pdfFonts, commonStyles, chartColors } from "../theme.js";

interface FlowNode {
  id: string;
  label: string;
  value: number;
  color?: string;
  subLabel?: string;
}

interface FlowConnection {
  from: string;
  to: string;
  value: number;
}

interface EstateFlowDiagramProps {
  title?: string;
  subtitle?: string;
  totalValue?: number;
  leftColumn: {
    title: string;
    nodes: FlowNode[];
  };
  middleColumn?: {
    title: string;
    nodes: FlowNode[];
  };
  rightColumn: {
    title: string;
    nodes: FlowNode[];
  };
}

const styles = StyleSheet.create({
  container: {
    ...commonStyles.card,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 24,
  },
  totalValue: {
    fontSize: pdfFonts.size["2xl"],
    fontWeight: "bold",
    color: pdfColors.neutral[900],
  },
  totalLabel: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[500],
  },
  columnsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  column: {
    flex: 1,
    alignItems: "center",
  },
  columnTitle: {
    fontSize: pdfFonts.size.sm,
    fontWeight: "semibold",
    color: pdfColors.neutral[500],
    textTransform: "uppercase",
    marginBottom: 16,
    textAlign: "center",
  },
  nodeCard: {
    width: "90%",
    padding: 12,
    borderRadius: 6,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: pdfColors.neutral[200],
  },
  nodeLabel: {
    fontSize: pdfFonts.size.sm,
    fontWeight: "semibold",
    color: pdfColors.white,
    marginBottom: 4,
  },
  nodeValue: {
    fontSize: pdfFonts.size.lg,
    fontWeight: "bold",
    color: pdfColors.white,
  },
  nodeSubLabel: {
    fontSize: pdfFonts.size.xs,
    color: "rgba(255,255,255,0.8)",
    marginTop: 2,
  },
  lightNode: {
    backgroundColor: pdfColors.neutral[50],
    borderColor: pdfColors.neutral[200],
  },
  lightNodeLabel: {
    color: pdfColors.neutral[900],
  },
  lightNodeValue: {
    color: pdfColors.neutral[700],
  },
  connectionsContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: -1,
  },
});

/**
 * Format currency value
 */
const formatCurrency = (value: number): string => {
  if (value >= 1000000000) {
    return `$${(value / 1000000000).toFixed(1)}B`;
  }
  if (value >= 1000000) {
    return `$${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `$${(value / 1000).toFixed(0)}K`;
  }
  return `$${value.toLocaleString()}`;
};

/**
 * Single flow node component
 */
const FlowNodeCard: React.FC<{
  node: FlowNode;
  variant?: "primary" | "light";
  index: number;
}> = ({ node, variant = "primary", index }) => {
  const color = node.color || chartColors[index % chartColors.length];
  const isPrimary = variant === "primary";

  return (
    <View
      style={[
        styles.nodeCard,
        isPrimary ? { backgroundColor: color } : styles.lightNode,
      ]}
    >
      <Text style={[styles.nodeLabel, !isPrimary ? styles.lightNodeLabel : {}]}>
        {node.label}
      </Text>
      <Text style={[styles.nodeValue, !isPrimary ? styles.lightNodeValue : {}]}>
        {formatCurrency(node.value)}
      </Text>
      {node.subLabel && (
        <Text
          style={[
            styles.nodeSubLabel,
            !isPrimary ? { color: pdfColors.neutral[500] } : {},
          ]}
        >
          {node.subLabel}
        </Text>
      )}
    </View>
  );
};

export const EstateFlowDiagram: React.FC<EstateFlowDiagramProps> = ({
  title,
  subtitle,
  totalValue,
  leftColumn,
  middleColumn,
  rightColumn,
}) => {
  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          {subtitle && <Text style={styles.totalLabel}>{subtitle}</Text>}
          {title && <Text style={commonStyles.cardTitle}>{title}</Text>}
        </View>
        {totalValue && (
          <View style={{ alignItems: "flex-end" }}>
            <Text style={styles.totalLabel}>Estimated Total Portfolio:</Text>
            <Text style={styles.totalValue}>{formatCurrency(totalValue)}</Text>
          </View>
        )}
      </View>

      {/* Columns */}
      <View style={styles.columnsContainer}>
        {/* Left Column */}
        <View style={styles.column}>
          <Text style={styles.columnTitle}>{leftColumn.title}</Text>
          {leftColumn.nodes.map((node, index) => (
            <FlowNodeCard key={node.id} node={node} index={index} />
          ))}
        </View>

        {/* Middle Column (if exists) */}
        {middleColumn && (
          <View style={styles.column}>
            <Text style={styles.columnTitle}>{middleColumn.title}</Text>
            {middleColumn.nodes.map((node, index) => (
              <FlowNodeCard
                key={node.id}
                node={node}
                variant="light"
                index={index}
              />
            ))}
          </View>
        )}

        {/* Right Column */}
        <View style={styles.column}>
          <Text style={styles.columnTitle}>{rightColumn.title}</Text>
          {rightColumn.nodes.map((node, index) => (
            <FlowNodeCard key={node.id} node={node} index={index} />
          ))}
        </View>
      </View>
    </View>
  );
};

/**
 * Simplified estate summary card
 */
export const EstateSummaryCard: React.FC<{
  title: string;
  totalValue: number;
  items: Array<{
    label: string;
    value: number;
    percentage?: number;
    color?: string;
  }>;
}> = ({ title, totalValue, items }) => {
  return (
    <View style={commonStyles.card}>
      <Text style={commonStyles.cardTitle}>{title}</Text>

      {/* Total */}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 16,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: pdfColors.neutral[200],
        }}
      >
        <Text
          style={{ fontSize: pdfFonts.size.lg, color: pdfColors.neutral[600] }}
        >
          Total Estate Value
        </Text>
        <Text
          style={{
            fontSize: pdfFonts.size["2xl"],
            fontWeight: "bold",
            color: pdfColors.neutral[900],
          }}
        >
          {formatCurrency(totalValue)}
        </Text>
      </View>

      {/* Items */}
      {items.map((item, index) => {
        const color = item.color || chartColors[index % chartColors.length];
        return (
          <View
            key={index}
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <View
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: 5,
                  backgroundColor: color,
                  marginRight: 10,
                }}
              />
              <Text
                style={{
                  fontSize: pdfFonts.size.base,
                  color: pdfColors.neutral[700],
                }}
              >
                {item.label}
              </Text>
            </View>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Text
                style={{
                  fontSize: pdfFonts.size.base,
                  fontWeight: "semibold",
                  color: pdfColors.neutral[900],
                  marginRight: 8,
                }}
              >
                {formatCurrency(item.value)}
              </Text>
              {item.percentage !== undefined && (
                <Text
                  style={{
                    fontSize: pdfFonts.size.sm,
                    color: pdfColors.neutral[500],
                  }}
                >
                  ({item.percentage.toFixed(1)}%)
                </Text>
              )}
            </View>
          </View>
        );
      })}
    </View>
  );
};
