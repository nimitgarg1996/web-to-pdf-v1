import React from "react";
import {
  View,
  Text,
  Svg,
  Path,
  Circle,
  Rect,
  G,
  Line,
  StyleSheet,
} from "@react-pdf/renderer";
import { pdfColors, pdfFonts, commonStyles } from "../theme.js";

// ============================================================================
// DATA MODEL INTERFACES
// ============================================================================

export type NodeType = "trust" | "gift" | "person" | "entity";
export type IconType = "building" | "gift" | "document" | "person";
export type EdgeStyle = "solid" | "dashed";
export type NotePosition = "left" | "right" | "bottom";

export interface FlowNode {
  id: string;
  type: NodeType;
  label: string;
  icon: IconType;
  color: string;
  stageId: string;
  column?: number;
  x?: number; // Explicit x position (0-100%)
  y?: number; // Explicit y position
}

export interface FlowEdge {
  id: string;
  from: string;
  to: string;
  label?: string;
  description?: string;
  descriptionPosition?: "left" | "right" | "center";
  style?: EdgeStyle;
}

export interface FlowStage {
  id: string;
  label: string;
  order: number;
  y?: number; // Explicit y position
  dividerStyle?: EdgeStyle;
}

export interface FlowNote {
  id: string;
  text: string;
  position: NotePosition;
  x?: number;
  y?: number;
  linkedToNode?: string;
}

export interface TrustFlowchartData {
  title?: string;
  nodes: FlowNode[];
  edges: FlowEdge[];
  stages: FlowStage[];
  notes?: FlowNote[];
}

export interface TrustFlowchartProps {
  data: TrustFlowchartData;
  width?: number;
  height?: number;
  showTitle?: boolean;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const CHART_WIDTH = 515;
const CHART_HEIGHT = 680;
const NODE_SIZE = 50;
const NODE_ICON_SIZE = 22;
const ROUNDED_RECT_RADIUS = 8;

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  container: {
    backgroundColor: pdfColors.white,
    padding: 20,
  },
  title: {
    fontSize: pdfFonts.size.lg,
    fontWeight: "bold",
    color: pdfColors.neutral[900],
    marginBottom: 20,
    textAlign: "center",
  },
  chartContainer: {
    position: "relative",
    width: CHART_WIDTH,
    height: CHART_HEIGHT,
  },
});

// ============================================================================
// ICON COMPONENTS
// ============================================================================

interface IconProps {
  color: string;
  size?: number;
}

const BuildingIcon: React.FC<IconProps> = ({
  color,
  size = NODE_ICON_SIZE,
}) => (
  <Svg width={size} height={size} viewBox="0 0 24 24">
    <Path
      d="M3 21h18v-2H3v2zm0-4h18v-2H3v2zm0-4h18v-2H3v2zm0-4h18V7H3v2zm0-6v2h18V3H3z"
      fill={color}
    />
  </Svg>
);

const GiftIcon: React.FC<IconProps> = ({ color, size = NODE_ICON_SIZE }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24">
    <Path
      d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"
      fill={color}
    />
  </Svg>
);

const DocumentIcon: React.FC<IconProps> = ({
  color,
  size = NODE_ICON_SIZE,
}) => (
  <Svg width={size} height={size} viewBox="0 0 24 24">
    <Path
      d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"
      fill={color}
    />
  </Svg>
);

// ============================================================================
// NODE COMPONENT
// ============================================================================

interface NodeComponentProps {
  x: number;
  y: number;
  icon: IconType;
  color: string;
  label: string;
  labelPosition?: "bottom" | "right";
}

const NodeComponent: React.FC<NodeComponentProps> = ({
  x,
  y,
  icon,
  color,
  label,
  labelPosition = "bottom",
}) => {
  const bgColor = `${color}15`; // 15% opacity
  const iconX = x - NODE_SIZE / 2;
  const iconY = y - NODE_SIZE / 2;

  return (
    <G>
      {/* Rounded rectangle background */}
      <Rect
        x={iconX}
        y={iconY}
        width={NODE_SIZE}
        height={NODE_SIZE}
        rx={ROUNDED_RECT_RADIUS}
        ry={ROUNDED_RECT_RADIUS}
        fill={bgColor}
        stroke={color}
        strokeWidth={1.5}
      />
      {/* Icon centered in rectangle */}
      <G
        transform={`translate(${x - NODE_ICON_SIZE / 2}, ${y - NODE_ICON_SIZE / 2})`}
      >
        {icon === "building" && <BuildingIcon color={color} />}
        {icon === "gift" && <GiftIcon color={color} />}
        {icon === "document" && <DocumentIcon color={color} />}
      </G>
    </G>
  );
};

// ============================================================================
// EDGE DRAWING HELPERS
// ============================================================================

function drawVerticalLine(x: number, y1: number, y2: number): string {
  return `M ${x} ${y1} L ${x} ${y2}`;
}

function drawHorizontalLine(x1: number, x2: number, y: number): string {
  return `M ${x1} ${y} L ${x2} ${y}`;
}

function drawElbowPath(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  direction: "down-right" | "down-left" | "right-down" | "left-down",
): string {
  const midY = (y1 + y2) / 2;
  switch (direction) {
    case "down-right":
    case "down-left":
      return `M ${x1} ${y1} L ${x1} ${midY} L ${x2} ${midY} L ${x2} ${y2}`;
    case "right-down":
      return `M ${x1} ${y1} L ${x2} ${y1} L ${x2} ${y2}`;
    case "left-down":
      return `M ${x1} ${y1} L ${x2} ${y1} L ${x2} ${y2}`;
    default:
      return `M ${x1} ${y1} L ${x2} ${y2}`;
  }
}

function drawBranchingPath(
  startX: number,
  startY: number,
  branchY: number,
  endPoints: Array<{ x: number; y: number }>,
): string[] {
  const paths: string[] = [];

  // Vertical line from start to branch point
  paths.push(`M ${startX} ${startY} L ${startX} ${branchY}`);

  // Horizontal line connecting all branches
  if (endPoints.length > 1) {
    const minX = Math.min(...endPoints.map((p) => p.x));
    const maxX = Math.max(...endPoints.map((p) => p.x));
    paths.push(`M ${minX} ${branchY} L ${maxX} ${branchY}`);
  }

  // Vertical lines to each endpoint
  endPoints.forEach((point) => {
    paths.push(`M ${point.x} ${branchY} L ${point.x} ${point.y}`);
  });

  return paths;
}

// ============================================================================
// MAIN COMPONENT - EXACT A4 LAYOUT
// ============================================================================

export const TrustFlowchart: React.FC<TrustFlowchartProps> = ({
  data,
  width = CHART_WIDTH,
  height = CHART_HEIGHT,
  showTitle = true,
}) => {
  // ============================================================================
  // A4 COORDINATE SYSTEM (515 x 680 usable area)
  // Based on detailed reference image analysis
  // ============================================================================

  // X-AXIS POSITIONS (columns)
  const X = {
    center: 257, // Main vertical trunk
    survivorTrust: 110, // Leftmost trust
    bypassTrust: 257, // Center trust (same as trunk)
    maritalTrust: 390, // Right trust
    specificGifts: 450, // Specific Gifts (far right)
    janeTrust: 190, // Jane Doe Trust
    johnTrust: 320, // John Doe Trust
  };

  // Y-AXIS POSITIONS (rows)
  const Y = {
    mainTrust: 55, // Main trust node center
    divider1: 130, // "Death of First Spouse" line
    branchPoint1: 150, // Where horizontal branch to SG#1 starts
    specificGifts1: 210, // Specific Gifts #1 center
    tJunction: 270, // T-junction horizontal line
    row3Trusts: 330, // Survivor's, Bypass, Marital trust centers
    divider2: 430, // "Death of Surviving Spouse" line
    branchPoint2: 520, // Where horizontal branch to SG#2 connects
    specificGifts2: 555, // Specific Gifts #2 center
    tJunction2: 570, // T-junction for Jane/John
    row4Trusts: 620, // Jane/John trust centers
  };

  // Node half-size for edge calculations
  const HALF = NODE_SIZE / 2;

  return (
    <View style={styles.container}>
      {showTitle && data.title && (
        <Text style={styles.title}>{data.title}</Text>
      )}

      <View style={[styles.chartContainer, { width, height }]}>
        <Svg width={width} height={height}>
          {/* ================================================================
              LAYER 1: CONNECTION LINES (drawn first, behind nodes)
              ================================================================ */}

          {/* --- MAIN TRUNK: Vertical line from Main Trust to T-junction --- */}
          <Path
            d={`M ${X.center} ${Y.mainTrust + HALF} L ${X.center} ${Y.tJunction}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- BRANCH TO SPECIFIC GIFTS #1 (horizontal right, then down) --- */}
          <Path
            d={`M ${X.center} ${Y.branchPoint1} L ${X.specificGifts} ${Y.branchPoint1} L ${X.specificGifts} ${Y.specificGifts1 - HALF}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />
          {/* Arrow head pointing INTO Specific Gifts #1 */}
          <Path
            d={`M ${X.specificGifts - 5} ${Y.specificGifts1 - HALF - 8} L ${X.specificGifts} ${Y.specificGifts1 - HALF} L ${X.specificGifts + 5} ${Y.specificGifts1 - HALF - 8}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- T-JUNCTION: Horizontal line connecting 3 trusts --- */}
          <Path
            d={`M ${X.survivorTrust} ${Y.tJunction} L ${X.maritalTrust} ${Y.tJunction}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- VERTICAL DROPS from T-junction to Row 3 trusts --- */}
          {/* To Survivor's Trust */}
          <Path
            d={`M ${X.survivorTrust} ${Y.tJunction} L ${X.survivorTrust} ${Y.row3Trusts - HALF}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />
          {/* To Bypass Trust */}
          <Path
            d={`M ${X.bypassTrust} ${Y.tJunction} L ${X.bypassTrust} ${Y.row3Trusts - HALF}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />
          {/* To Marital Trust */}
          <Path
            d={`M ${X.maritalTrust} ${Y.tJunction} L ${X.maritalTrust} ${Y.row3Trusts - HALF}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- CONNECTIONS FROM ROW 3 TO ROW 4 --- */}

          {/* From Bypass Trust down to branch point */}
          <Path
            d={`M ${X.bypassTrust} ${Y.row3Trusts + HALF} L ${X.bypassTrust} ${Y.branchPoint2}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* From Marital Trust down to branch point */}
          <Path
            d={`M ${X.maritalTrust} ${Y.row3Trusts + HALF} L ${X.maritalTrust} ${Y.branchPoint2}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- BRANCH TO SPECIFIC GIFTS #2 (horizontal right from marital, then down) --- */}
          <Path
            d={`M ${X.maritalTrust} ${Y.branchPoint2} L ${X.specificGifts} ${Y.branchPoint2} L ${X.specificGifts} ${Y.specificGifts2 - HALF}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />
          {/* Arrow head pointing INTO Specific Gifts #2 */}
          <Path
            d={`M ${X.specificGifts - 5} ${Y.specificGifts2 - HALF - 8} L ${X.specificGifts} ${Y.specificGifts2 - HALF} L ${X.specificGifts + 5} ${Y.specificGifts2 - HALF - 8}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- T-JUNCTION #2: Horizontal line connecting Jane/John --- */}
          <Path
            d={`M ${X.janeTrust} ${Y.tJunction2} L ${X.johnTrust} ${Y.tJunction2}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- VERTICAL CONNECTIONS from Row 3 to T-junction #2 --- */}
          {/* Bypass to T-junction #2 */}
          <Path
            d={`M ${X.bypassTrust} ${Y.branchPoint2} L ${X.bypassTrust} ${Y.tJunction2}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />
          {/* Marital to T-junction #2 - merges into horizontal */}
          <Path
            d={`M ${X.maritalTrust} ${Y.branchPoint2} L ${X.maritalTrust} ${Y.tJunction2 - 20} L ${X.johnTrust} ${Y.tJunction2 - 20} L ${X.johnTrust} ${Y.tJunction2}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* --- VERTICAL DROPS to Jane/John trusts --- */}
          <Path
            d={`M ${X.janeTrust} ${Y.tJunction2} L ${X.janeTrust} ${Y.row4Trusts - HALF}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />
          <Path
            d={`M ${X.johnTrust} ${Y.tJunction2} L ${X.johnTrust} ${Y.row4Trusts - HALF}`}
            stroke={pdfColors.neutral[400]}
            strokeWidth={1.5}
            fill="none"
          />

          {/* ================================================================
              LAYER 2: DIVIDER LINES
              ================================================================ */}

          {/* Divider 1: Death of First Spouse */}
          <Line
            x1={20}
            y1={Y.divider1}
            x2={width - 20}
            y2={Y.divider1}
            stroke={pdfColors.neutral[300]}
            strokeWidth={1}
            strokeDasharray="4,4"
          />
          {/* Label background */}
          <Rect
            x={X.center - 70}
            y={Y.divider1 - 10}
            width={140}
            height={20}
            fill={pdfColors.white}
          />
          {/* Label text */}
          <Text
            x={X.center}
            y={Y.divider1 + 3}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[600],
            }}
          >
            Death of First Spouse
          </Text>

          {/* Divider 2: Death of Surviving Spouse */}
          <Line
            x1={20}
            y1={Y.divider2}
            x2={width - 20}
            y2={Y.divider2}
            stroke={pdfColors.neutral[300]}
            strokeWidth={1}
            strokeDasharray="4,4"
          />
          {/* Label background */}
          <Rect
            x={X.center - 80}
            y={Y.divider2 - 10}
            width={160}
            height={20}
            fill={pdfColors.white}
          />
          {/* Label text */}
          <Text
            x={X.center}
            y={Y.divider2 + 3}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[600],
            }}
          >
            Death of Surviving Spouse
          </Text>

          {/* ================================================================
              LAYER 3: 50% LABELS (on connecting lines)
              ================================================================ */}

          {/* 50% label on Jane's line */}
          <Rect
            x={X.janeTrust - 18}
            y={Y.tJunction2 + 10}
            width={36}
            height={16}
            rx={8}
            ry={8}
            fill={pdfColors.white}
            stroke={pdfColors.neutral[300]}
            strokeWidth={1}
          />
          <Text
            x={X.janeTrust}
            y={Y.tJunction2 + 21}
            style={{
              fontSize: 8,
              textAnchor: "middle",
              fill: pdfColors.neutral[600],
            }}
          >
            50%
          </Text>

          {/* 50% label on John's line */}
          <Rect
            x={X.johnTrust - 18}
            y={Y.tJunction2 + 10}
            width={36}
            height={16}
            rx={8}
            ry={8}
            fill={pdfColors.white}
            stroke={pdfColors.neutral[300]}
            strokeWidth={1}
          />
          <Text
            x={X.johnTrust}
            y={Y.tJunction2 + 21}
            style={{
              fontSize: 8,
              textAnchor: "middle",
              fill: pdfColors.neutral[600],
            }}
          >
            50%
          </Text>

          {/* ================================================================
              LAYER 4: DESCRIPTION LABELS
              ================================================================ */}

          {/* Left branch description - Surviving Spouse's Property */}
          <Text
            x={X.survivorTrust}
            y={Y.tJunction - 35}
            style={{
              fontSize: 7,
              textAnchor: "middle",
              fill: pdfColors.neutral[500],
            }}
          >
            Surviving Spouse's Separate
          </Text>
          <Text
            x={X.survivorTrust}
            y={Y.tJunction - 25}
            style={{
              fontSize: 7,
              textAnchor: "middle",
              fill: pdfColors.neutral[500],
            }}
          >
            Property and Share of
          </Text>
          <Text
            x={X.survivorTrust}
            y={Y.tJunction - 15}
            style={{
              fontSize: 7,
              textAnchor: "middle",
              fill: pdfColors.neutral[500],
            }}
          >
            Marital Property
          </Text>

          {/* Right branch description - Deceased Spouse's Property */}
          <Text
            x={(X.bypassTrust + X.maritalTrust) / 2}
            y={Y.tJunction - 25}
            style={{
              fontSize: 7,
              textAnchor: "middle",
              fill: pdfColors.neutral[500],
            }}
          >
            Deceased Spouse's Separate Property
          </Text>
          <Text
            x={(X.bypassTrust + X.maritalTrust) / 2}
            y={Y.tJunction - 15}
            style={{
              fontSize: 7,
              textAnchor: "middle",
              fill: pdfColors.neutral[500],
            }}
          >
            and Share of Marital Property
          </Text>

          {/* ================================================================
              LAYER 5: NODE COMPONENTS (drawn on top)
              ================================================================ */}

          {/* Main Trust */}
          <NodeComponent
            x={X.center}
            y={Y.mainTrust}
            icon="building"
            color="#14b8a6"
            label="Doe-Smith Revocable Trust"
          />
          <Text
            x={X.center}
            y={Y.mainTrust + 35}
            style={{
              fontSize: 10,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
            }}
          >
            Doe-Smith Revocable Trust
          </Text>

          {/* Specific Gifts #1 */}
          <NodeComponent
            x={X.specificGifts}
            y={Y.specificGifts1}
            icon="gift"
            color="#f97316"
            label="Specific Gifts"
          />
          <Text
            x={X.specificGifts}
            y={Y.specificGifts1 + 35}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
              fontWeight: "bold",
            }}
          >
            Specific Gifts
          </Text>

          {/* Survivor's Trust */}
          <NodeComponent
            x={X.survivorTrust}
            y={Y.row3Trusts}
            icon="document"
            color="#a855f7"
            label="Survivor's Trust"
          />
          <Text
            x={X.survivorTrust}
            y={Y.row3Trusts + 35}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
            }}
          >
            Survivor's Trust
          </Text>

          {/* Bypass Trust */}
          <NodeComponent
            x={X.bypassTrust}
            y={Y.row3Trusts}
            icon="document"
            color="#3b82f6"
            label="Bypass Trust"
          />
          <Text
            x={X.bypassTrust}
            y={Y.row3Trusts + 35}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
            }}
          >
            Bypass Trust
          </Text>

          {/* Marital Trust */}
          <NodeComponent
            x={X.maritalTrust}
            y={Y.row3Trusts}
            icon="document"
            color="#14b8a6"
            label="Marital Trust"
          />
          <Text
            x={X.maritalTrust}
            y={Y.row3Trusts + 35}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
            }}
          >
            Marital Trust
          </Text>

          {/* Specific Gifts #2 */}
          <NodeComponent
            x={X.specificGifts}
            y={Y.specificGifts2}
            icon="gift"
            color="#f97316"
            label="Specific Gifts"
          />
          <Text
            x={X.specificGifts}
            y={Y.specificGifts2 + 35}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
              fontWeight: "bold",
            }}
          >
            Specific Gifts
          </Text>

          {/* Jane Doe Trust */}
          <NodeComponent
            x={X.janeTrust}
            y={Y.row4Trusts}
            icon="document"
            color="#f87171"
            label="Jane Doe Trust"
          />
          <Text
            x={X.janeTrust}
            y={Y.row4Trusts + 35}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
            }}
          >
            Jane Doe Trust
          </Text>

          {/* John Doe Trust */}
          <NodeComponent
            x={X.johnTrust}
            y={Y.row4Trusts}
            icon="document"
            color="#f87171"
            label="John Doe Trust"
          />
          <Text
            x={X.johnTrust}
            y={Y.row4Trusts + 35}
            style={{
              fontSize: 9,
              textAnchor: "middle",
              fill: pdfColors.neutral[800],
            }}
          >
            John Doe Trust
          </Text>
        </Svg>

        {/* ================================================================
            LEFT NOTE BOX (positioned absolutely)
            ================================================================ */}
        <View
          style={{
            position: "absolute",
            left: 10,
            top: Y.specificGifts2 - 20,
            width: 120,
            padding: 8,
            backgroundColor: pdfColors.neutral[50],
            borderLeftWidth: 3,
            borderLeftColor: pdfColors.neutral[400],
          }}
        >
          <Text
            style={{
              fontSize: 7,
              color: pdfColors.neutral[600],
              lineHeight: 1.4,
            }}
          >
            If a child of the Grantors has not yet attained 21 years of age,
            trust assets will be held in a pot trust for the benefit of the
            Grantors' descendants until such time as the youngest living child
            of the Grantors attains age 21.
          </Text>
        </View>
      </View>
    </View>
  );
};

// ============================================================================
// SAMPLE DATA (matching the reference image)
// ============================================================================

export const sampleTrustFlowchartData: TrustFlowchartData = {
  title: "Doe-Smith Revocable Trust Distribution",

  stages: [
    { id: "initial", label: "", order: 0 },
    {
      id: "first-death",
      label: "Death of First Spouse",
      order: 1,
      dividerStyle: "dashed",
    },
    {
      id: "second-death",
      label: "Death of Surviving Spouse",
      order: 2,
      dividerStyle: "dashed",
    },
  ],

  nodes: [
    // Stage 0: Initial
    {
      id: "main-trust",
      type: "trust",
      label: "Doe-Smith Revocable Trust",
      icon: "building",
      color: "#14b8a6",
      stageId: "initial",
    },

    // Stage 1: After First Spouse Death
    {
      id: "specific-gifts-1",
      type: "gift",
      label: "Specific Gifts",
      icon: "gift",
      color: "#f97316",
      stageId: "first-death",
    },
    {
      id: "survivors-trust",
      type: "trust",
      label: "Survivor's Trust",
      icon: "document",
      color: "#a855f7",
      stageId: "first-death",
    },
    {
      id: "bypass-trust",
      type: "trust",
      label: "Bypass Trust",
      icon: "document",
      color: "#3b82f6",
      stageId: "first-death",
    },
    {
      id: "marital-trust",
      type: "trust",
      label: "Marital Trust",
      icon: "document",
      color: "#14b8a6",
      stageId: "first-death",
    },

    // Stage 2: After Surviving Spouse Death
    {
      id: "specific-gifts-2",
      type: "gift",
      label: "Specific Gifts",
      icon: "gift",
      color: "#f97316",
      stageId: "second-death",
    },
    {
      id: "jane-trust",
      type: "trust",
      label: "Jane Doe Trust",
      icon: "document",
      color: "#f87171",
      stageId: "second-death",
    },
    {
      id: "john-trust",
      type: "trust",
      label: "John Doe Trust",
      icon: "document",
      color: "#f87171",
      stageId: "second-death",
    },
  ],

  edges: [
    // From main trust
    {
      id: "e1",
      from: "main-trust",
      to: "specific-gifts-1",
    },
    {
      id: "e2",
      from: "main-trust",
      to: "survivors-trust",
      description:
        "Surviving Spouse's Separate Property and Share of Marital Property",
      descriptionPosition: "left",
    },
    {
      id: "e3",
      from: "main-trust",
      to: "bypass-trust",
      description:
        "Deceased Spouse's Separate Property and Share of Marital Property",
      descriptionPosition: "right",
    },
    {
      id: "e4",
      from: "main-trust",
      to: "marital-trust",
    },

    // To final trusts
    {
      id: "e5",
      from: "bypass-trust",
      to: "specific-gifts-2",
    },
    {
      id: "e6",
      from: "bypass-trust",
      to: "jane-trust",
      label: "50%",
    },
    {
      id: "e7",
      from: "bypass-trust",
      to: "john-trust",
      label: "50%",
    },
    {
      id: "e8",
      from: "marital-trust",
      to: "jane-trust",
    },
    {
      id: "e9",
      from: "marital-trust",
      to: "john-trust",
    },
  ],

  notes: [
    {
      id: "note-1",
      text: "If a child of the Grantors has not yet attained 21 years of age, trust assets will be held in a pot trust for the benefit of the Grantors' descendants until such time as the youngest living child of the Grantors attains age 21.",
      position: "left",
      linkedToNode: "jane-trust",
    },
  ],
};

export default TrustFlowchart;
