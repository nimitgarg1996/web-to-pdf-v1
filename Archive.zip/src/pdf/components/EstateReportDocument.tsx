import React from "react";
import {
  Document,
  Page,
  View,
  Text,
  StyleSheet,
  Image,
} from "@react-pdf/renderer";
import { pdfColors, pdfFonts, pdfSpacing } from "../theme.js";
import { DonutChart } from "./DonutChart.js";
import { TrustCardsContainer } from "./TrustDetailCard.js";
import { EntityStructureChart } from "./EntityStructureChart.js";
import { AssetTable } from "./AssetTable.js";
import { HeritageMap } from "./HeritageMap.js";
import { EstateFlowDiagram, EstateSummaryCard } from "./EstateFlowDiagram.js";
import { TrustFlowchart, TrustFlowchartData } from "./TrustFlowchart.js";

const styles = StyleSheet.create({
  page: {
    padding: 40,
    paddingBottom: 80,
    fontFamily: "Helvetica",
    fontSize: pdfFonts.size.base,
    color: pdfColors.neutral[900],
    backgroundColor: pdfColors.white,
  },
  header: {
    marginBottom: pdfSpacing[6],
  },
  headerSubtitle: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[500],
    marginBottom: 4,
  },
  headerTitle: {
    fontSize: pdfFonts.size["3xl"],
    fontWeight: "bold",
    color: pdfColors.neutral[900],
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 40,
    right: 40,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: pdfColors.neutral[200],
    paddingTop: 12,
  },
  footerBrand: {
    flexDirection: "row",
    alignItems: "center",
  },
  footerLogo: {
    fontSize: pdfFonts.size.lg,
    fontWeight: "bold",
    color: pdfColors.primary[600],
  },
  footerDisclaimer: {
    fontSize: pdfFonts.size.xs,
    color: pdfColors.neutral[500],
    maxWidth: 300,
    textAlign: "center",
  },
  footerMeta: {
    fontSize: pdfFonts.size.xs,
    color: pdfColors.neutral[500],
    textAlign: "right",
  },
  pageNumber: {
    fontSize: pdfFonts.size.xs,
    color: pdfColors.neutral[500],
  },
});

/**
 * Page header component
 */
const PageHeader: React.FC<{
  subtitle?: string;
  title: string;
}> = ({ subtitle, title }) => (
  <View style={styles.header}>
    {subtitle && <Text style={styles.headerSubtitle}>{subtitle}</Text>}
    <Text style={styles.headerTitle}>{title}</Text>
  </View>
);

/**
 * Page footer component
 */
const PageFooter: React.FC<{
  brandName?: string;
  disclaimer?: string;
  reportDate?: string;
}> = ({
  brandName = "wealth.com",
  disclaimer = "This information is being provided for illustrative purposes. Please refer to your original sourcing documents for the most accurate information.",
  reportDate,
}) => (
  <View style={styles.footer} fixed>
    <View style={styles.footerBrand}>
      <Text style={styles.footerLogo}>{brandName}</Text>
    </View>
    <Text style={styles.footerDisclaimer}>{disclaimer}</Text>
    <View>
      {reportDate && <Text style={styles.footerMeta}>{reportDate}</Text>}
      <Text
        style={styles.pageNumber}
        render={({ pageNumber, totalPages }) =>
          `Page ${pageNumber} of ${totalPages}`
        }
      />
    </View>
  </View>
);

/**
 * Estate Report Document Props
 */
interface EstateReportProps {
  // Metadata
  clientName: string;
  reportTitle: string;
  reportDate?: string;
  brandName?: string;

  // Page 1: Overview
  overview?: {
    donutChart: {
      title: string;
      centerLabel: string;
      centerValue: number;
      segments: Array<{
        name: string;
        value: number;
        color?: string;
        percentage?: number;
      }>;
    };
  };

  // Page 2: Trust Details
  trustDetails?: {
    pageTitle: string;
    cards: Array<{
      badge?: { label: string; color: "blue" | "green" | "teal" | "purple" };
      trustName: string;
      subtitle?: string;
      properties: Array<{ label: string; value: string }>;
    }>;
  };

  // Page 3: Entity Structure
  entityStructure?: {
    title: string;
    entities: Array<{
      name: string;
      subtitle?: string;
      type: "trust" | "estate" | "business" | "individual";
      percentage?: number;
      color?: string;
    }>;
  };

  // Page 4: Asset Table
  assetTable?: {
    title: string;
    subtitle?: string;
    columns: Array<{
      key: string;
      label: string;
      width?: string | number;
      align?: "left" | "center" | "right";
      format?: "text" | "currency" | "percentage" | "number";
    }>;
    groups: Array<{
      groupName: string;
      rows: Array<Record<string, string | number>>;
      showSubtotal?: boolean;
    }>;
  };

  // Page 5: Estate Flow
  estateFlow?: {
    title: string;
    totalValue: number;
    leftColumn: {
      title: string;
      nodes: Array<{
        id: string;
        label: string;
        value: number;
        color?: string;
      }>;
    };
    rightColumn: {
      title: string;
      nodes: Array<{
        id: string;
        label: string;
        value: number;
        color?: string;
      }>;
    };
  };

  // Page 6: Heritage Map
  heritageMap?: {
    title: string;
    members: Array<{
      id: string;
      name: string;
      initials: string;
      role?: string;
      generation: number;
      parentId?: string;
      color?: string;
    }>;
  };

  // Page 7: Trust Flowchart
  trustFlowchart?: TrustFlowchartData;
}

/**
 * Main Estate Report Document
 */
export const EstateReportDocument: React.FC<EstateReportProps> = ({
  clientName,
  reportTitle,
  reportDate = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }),
  brandName = "wealth.com",
  overview,
  trustDetails,
  entityStructure,
  assetTable,
  estateFlow,
  heritageMap,
  trustFlowchart,
}) => {
  return (
    <Document>
      {/* Page 1: Overview with Donut Chart */}
      {overview && (
        <Page size="A4" style={styles.page}>
          <PageHeader subtitle={clientName} title={reportTitle} />
          <DonutChart
            title={overview.donutChart.title}
            centerLabel={overview.donutChart.centerLabel}
            centerValue={overview.donutChart.centerValue}
            segments={overview.donutChart.segments}
            showLegend={true}
          />
          <PageFooter brandName={brandName} reportDate={reportDate} />
        </Page>
      )}

      {/* Page 2: Trust Details */}
      {trustDetails && (
        <Page size="A4" style={styles.page}>
          <PageHeader subtitle={clientName} title={trustDetails.pageTitle} />
          <TrustCardsContainer cards={trustDetails.cards} />
          <PageFooter brandName={brandName} reportDate={reportDate} />
        </Page>
      )}

      {/* Page 3: Entity Structure */}
      {entityStructure && (
        <Page size="A4" style={styles.page}>
          <EntityStructureChart
            title={entityStructure.title}
            entities={entityStructure.entities}
          />
          <PageFooter brandName={brandName} reportDate={reportDate} />
        </Page>
      )}

      {/* Page 4: Asset Table */}
      {assetTable && (
        <Page size="A4" style={styles.page}>
          <AssetTable
            title={assetTable.title}
            subtitle={assetTable.subtitle}
            columns={assetTable.columns}
            groups={assetTable.groups}
          />
          <PageFooter brandName={brandName} reportDate={reportDate} />
        </Page>
      )}

      {/* Page 5: Estate Flow */}
      {estateFlow && (
        <Page size="A4" style={styles.page}>
          <EstateFlowDiagram
            title={estateFlow.title}
            totalValue={estateFlow.totalValue}
            leftColumn={estateFlow.leftColumn}
            rightColumn={estateFlow.rightColumn}
          />
          <PageFooter brandName={brandName} reportDate={reportDate} />
        </Page>
      )}

      {/* Page 6: Heritage Map */}
      {heritageMap && (
        <Page size="A4" style={styles.page}>
          <PageHeader subtitle={clientName} title="Heritage Map" />
          <HeritageMap
            title={heritageMap.title}
            members={heritageMap.members}
          />
          <PageFooter brandName={brandName} reportDate={reportDate} />
        </Page>
      )}

      {/* Page 7: Trust Flowchart */}
      {trustFlowchart && (
        <Page size="A4" style={styles.page}>
          <PageHeader subtitle={clientName} title="Trust Distribution" />
          <TrustFlowchart data={trustFlowchart} />
          <PageFooter brandName={brandName} reportDate={reportDate} />
        </Page>
      )}
    </Document>
  );
};

export type { EstateReportProps };
