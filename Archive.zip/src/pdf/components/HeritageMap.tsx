import React from "react";
import {
  View,
  Text,
  Svg,
  Circle,
  Line,
  Path,
  StyleSheet,
} from "@react-pdf/renderer";
import { pdfColors, pdfFonts, commonStyles, avatarColors } from "../theme.js";

interface FamilyMember {
  id: string;
  name: string;
  initials: string;
  role?: string;
  generation: number;
  parentId?: string;
  color?: string;
}

interface HeritageMapProps {
  title?: string;
  subtitle?: string;
  members: FamilyMember[];
  showConnections?: boolean;
}

const CARD_WIDTH = 80;
const CARD_GAP = 40;
const AVATAR_SIZE = 56;
const GENERATION_HEIGHT = 140;
const CHART_WIDTH = 520;
const HEADER_HEIGHT = 60;

const styles = StyleSheet.create({
  container: {
    ...commonStyles.card,
  },
  header: {
    marginBottom: 24,
  },
  subtitle: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[500],
    marginBottom: 4,
  },
  chartContainer: {
    position: "relative",
    width: CHART_WIDTH,
    marginHorizontal: "auto",
  },
  svgContainer: {
    position: "absolute",
    top: 0,
    left: 0,
  },
  generationsContainer: {
    position: "relative",
    zIndex: 1,
  },
  generationRow: {
    marginBottom: 24,
  },
  generationLabel: {
    fontSize: pdfFonts.size.xs,
    fontWeight: "semibold",
    color: pdfColors.neutral[500],
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 16,
  },
  membersRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "flex-start",
    gap: CARD_GAP,
    flexWrap: "wrap",
  },
  memberCard: {
    alignItems: "center",
    width: CARD_WIDTH,
  },
  avatarContainer: {
    width: AVATAR_SIZE,
    height: AVATAR_SIZE,
    borderRadius: AVATAR_SIZE / 2,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  avatarInitials: {
    fontSize: pdfFonts.size.lg,
    fontWeight: "bold",
    color: pdfColors.white,
  },
  memberName: {
    fontSize: pdfFonts.size.sm,
    fontWeight: "semibold",
    color: pdfColors.neutral[900],
    textAlign: "center",
    marginBottom: 2,
  },
  memberRole: {
    fontSize: pdfFonts.size.xs,
    color: pdfColors.neutral[500],
    textAlign: "center",
  },
});

/**
 * Avatar component with initials
 */
const Avatar: React.FC<{
  initials: string;
  color: string;
  size?: number;
}> = ({ initials, color, size = AVATAR_SIZE }) => {
  return (
    <View
      style={[
        styles.avatarContainer,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: color,
        },
      ]}
    >
      <Text style={[styles.avatarInitials, { fontSize: size * 0.32 }]}>
        {initials}
      </Text>
    </View>
  );
};

/**
 * Calculate member positions for drawing connection lines
 */
function calculateMemberPositions(
  sortedGenerations: Array<{ generation: number; members: FamilyMember[] }>,
): Map<string, { x: number; y: number }> {
  const positions = new Map<string, { x: number; y: number }>();

  sortedGenerations.forEach(({ generation, members }, genIndex) => {
    const rowWidth =
      members.length * CARD_WIDTH + (members.length - 1) * CARD_GAP;
    const startX = (CHART_WIDTH - rowWidth) / 2 + CARD_WIDTH / 2;
    const y = HEADER_HEIGHT + genIndex * GENERATION_HEIGHT + AVATAR_SIZE / 2;

    members.forEach((member, memberIndex) => {
      const x = startX + memberIndex * (CARD_WIDTH + CARD_GAP);
      positions.set(member.id, { x, y });
    });
  });

  return positions;
}

/**
 * Generate connection lines between parents and children
 */
function generateConnectionLines(
  members: FamilyMember[],
  positions: Map<string, { x: number; y: number }>,
): Array<{ x1: number; y1: number; x2: number; y2: number; color: string }> {
  const lines: Array<{
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    color: string;
  }> = [];

  members.forEach((member) => {
    if (member.parentId) {
      const parentPos = positions.get(member.parentId);
      const childPos = positions.get(member.id);

      if (parentPos && childPos) {
        // Vertical line from parent bottom
        const midY = (parentPos.y + childPos.y) / 2;

        // Line from parent bottom to midpoint
        lines.push({
          x1: parentPos.x,
          y1: parentPos.y + AVATAR_SIZE / 2,
          x2: parentPos.x,
          y2: midY,
          color: pdfColors.neutral[300],
        });

        // Horizontal line at midpoint
        lines.push({
          x1: parentPos.x,
          y1: midY,
          x2: childPos.x,
          y2: midY,
          color: pdfColors.neutral[300],
        });

        // Line from midpoint to child top
        lines.push({
          x1: childPos.x,
          y1: midY,
          x2: childPos.x,
          y2: childPos.y - AVATAR_SIZE / 2,
          color: pdfColors.neutral[300],
        });
      }
    }
  });

  return lines;
}

/**
 * Draw coupling line between spouse pairs (generation 0)
 */
function generateSpouseLines(
  sortedGenerations: Array<{ generation: number; members: FamilyMember[] }>,
  positions: Map<string, { x: number; y: number }>,
): Array<{ x1: number; y1: number; x2: number; y2: number; color: string }> {
  const lines: Array<{
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    color: string;
  }> = [];

  // Find generation 0 (parents/spouses)
  const gen0 = sortedGenerations.find((g) => g.generation === 0);
  if (gen0 && gen0.members.length >= 2) {
    const spouse1Pos = positions.get(gen0.members[0].id);
    const spouse2Pos = positions.get(gen0.members[1].id);

    if (spouse1Pos && spouse2Pos) {
      // Horizontal line connecting spouses
      lines.push({
        x1: spouse1Pos.x + AVATAR_SIZE / 2,
        y1: spouse1Pos.y,
        x2: spouse2Pos.x - AVATAR_SIZE / 2,
        y2: spouse2Pos.y,
        color: pdfColors.primary[500],
      });
    }
  }

  return lines;
}

export const HeritageMap: React.FC<HeritageMapProps> = ({
  title,
  subtitle,
  members,
  showConnections = true,
}) => {
  // Group members by generation
  const generations: Record<number, FamilyMember[]> = {};
  members.forEach((member) => {
    if (!generations[member.generation]) {
      generations[member.generation] = [];
    }
    generations[member.generation].push(member);
  });

  // Sort and format generations
  const sortedGenerations = Object.keys(generations)
    .map(Number)
    .sort()
    .map((gen) => ({
      generation: gen,
      members: generations[gen],
    }));

  // Generation labels
  const generationLabels = [
    "Parents",
    "Children",
    "Grandchildren",
    "Great-Grandchildren",
  ];

  // Calculate positions for connection lines
  const positions = calculateMemberPositions(sortedGenerations);
  const connectionLines = showConnections
    ? generateConnectionLines(members, positions)
    : [];
  const spouseLines = showConnections
    ? generateSpouseLines(sortedGenerations, positions)
    : [];
  const allLines = [...spouseLines, ...connectionLines];

  // Calculate total height for SVG
  const totalHeight =
    HEADER_HEIGHT + sortedGenerations.length * GENERATION_HEIGHT;

  return (
    <View style={styles.container}>
      {/* Header */}
      {(title || subtitle) && (
        <View style={styles.header}>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
          {title && <Text style={commonStyles.cardTitle}>{title}</Text>}
        </View>
      )}

      {/* Chart with connections */}
      <View style={[styles.chartContainer, { height: totalHeight }]}>
        {/* SVG Connection Lines */}
        {showConnections && allLines.length > 0 && (
          <Svg
            style={styles.svgContainer}
            width={CHART_WIDTH}
            height={totalHeight}
          >
            {allLines.map((line, index) => (
              <Line
                key={index}
                x1={line.x1}
                y1={line.y1}
                x2={line.x2}
                y2={line.y2}
                stroke={line.color}
                strokeWidth={2}
              />
            ))}
            {/* Draw dots at connection points */}
            {connectionLines.length > 0 &&
              sortedGenerations.slice(0, -1).map(({ members: genMembers }) =>
                genMembers.map((member) => {
                  const pos = positions.get(member.id);
                  if (!pos) return null;
                  // Find if this member has children
                  const hasChildren = members.some(
                    (m) => m.parentId === member.id,
                  );
                  if (!hasChildren) return null;
                  return (
                    <Circle
                      key={`dot-${member.id}`}
                      cx={pos.x}
                      cy={pos.y + AVATAR_SIZE / 2 + 5}
                      r={3}
                      fill={pdfColors.neutral[400]}
                    />
                  );
                }),
              )}
          </Svg>
        )}

        {/* Generations Content */}
        <View style={styles.generationsContainer}>
          {sortedGenerations.map(
            ({ generation, members: genMembers }, genIndex) => (
              <View
                key={generation}
                style={[
                  styles.generationRow,
                  { height: GENERATION_HEIGHT - 24 },
                ]}
              >
                {/* Generation Label */}
                <Text style={styles.generationLabel}>
                  {generationLabels[generation] ||
                    `Generation ${generation + 1}`}
                </Text>

                {/* Members */}
                <View style={styles.membersRow}>
                  {genMembers.map((member, memberIndex) => {
                    const color =
                      member.color ||
                      avatarColors[memberIndex % avatarColors.length];
                    return (
                      <View key={member.id} style={styles.memberCard}>
                        <Avatar initials={member.initials} color={color} />
                        <Text style={styles.memberName}>{member.name}</Text>
                        {member.role && (
                          <Text style={styles.memberRole}>{member.role}</Text>
                        )}
                      </View>
                    );
                  })}
                </View>
              </View>
            ),
          )}
        </View>
      </View>
    </View>
  );
};

/**
 * Simplified heritage map with just avatars in a row
 */
export const HeritageMapSimple: React.FC<{
  title?: string;
  members: Array<{ name: string; initials: string; color?: string }>;
}> = ({ title, members }) => {
  return (
    <View style={commonStyles.card}>
      {title && <Text style={commonStyles.cardTitle}>{title}</Text>}
      <View
        style={{
          flexDirection: "row",
          justifyContent: "center",
          gap: 24,
          flexWrap: "wrap",
        }}
      >
        {members.map((member, index) => {
          const color =
            member.color || avatarColors[index % avatarColors.length];
          return (
            <View key={index} style={{ alignItems: "center" }}>
              <Avatar initials={member.initials} color={color} size={48} />
              <Text
                style={{
                  fontSize: pdfFonts.size.xs,
                  color: pdfColors.neutral[700],
                  marginTop: 6,
                  textAlign: "center",
                }}
              >
                {member.name}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
};
