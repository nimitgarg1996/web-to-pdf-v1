import React from "react";
import { renderToBuffer } from "@react-pdf/renderer";
import {
  EstateReportDocument,
  EstateReportProps,
} from "./components/EstateReportDocument.js";
import { sampleTrustFlowchartData } from "./components/TrustFlowchart.js";

/**
 * Generate PDF using @react-pdf/renderer
 */
export async function generatePdfWithReactPdf(
  data: EstateReportProps,
): Promise<Buffer> {
  // Create the document element and cast to ReactElement for renderToBuffer
  const document = React.createElement(
    EstateReportDocument,
    data,
  ) as React.ReactElement;
  const buffer = await renderToBuffer(document);
  return Buffer.from(buffer);
}

/**
 * Sample data for testing
 */
export const sampleEstateReportData: EstateReportProps = {
  clientName: "John Doe & Jane Doe",
  reportTitle: "Estimated Estate Overview",
  reportDate: "Estate Report: March 2025",
  brandName: "wealth.com",

  overview: {
    donutChart: {
      title: "Estimated Total Portfolio",
      centerLabel: "Total Estate Value",
      centerValue: 398304420,
      segments: [
        {
          name: "Inside Estate",
          value: 334531600,
          color: "#0d9488",
          percentage: 83.99,
        },
        {
          name: "Outside Estate",
          value: 63772820,
          color: "#5eead4",
          percentage: 16.01,
        },
      ],
    },
  },

  trustDetails: {
    pageTitle: "The Doe Family Trust Additional Details",
    cards: [
      {
        badge: { label: "B", color: "blue" },
        trustName: "Credit Shelter Trust",
        subtitle: "Additional Details",
        properties: [
          { label: "Funding Directive Type", value: "Fractional Share" },
          {
            label: "Income Distributions",
            value: "Fully Discretionary Distributions",
          },
          {
            label: "Principal Distributions",
            value:
              "Income and principal to surviving spouse for health, education, maintenance and support",
          },
          {
            label: "Distribution Type",
            value: "Power of Appointment: Limited",
          },
          { label: "Appointment Becomes Effective", value: "Testamentary" },
        ],
      },
      {
        badge: { label: "G", color: "green" },
        trustName: "Survivor's Trust",
        subtitle: "Additional Details",
        properties: [
          { label: "Funding Directive Type", value: "Fractional Share" },
          {
            label: "Income Distributions",
            value: "All income to surviving spouse, or Issue",
          },
          {
            label: "Principal Distributions",
            value:
              "Income and principal to surviving spouse for health, education, maintenance and support",
          },
          {
            label: "Trust Termination Event",
            value: "Death of Surviving Spouse (Jane Doe)",
          },
        ],
      },
      {
        badge: { label: "B", color: "blue" },
        trustName: "Daniel Doe Separate Trust",
        subtitle: "Additional Details",
        properties: [
          {
            label: "Income Distributions",
            value: "Fully Discretionary Distributions",
          },
          {
            label: "Principal Distributions",
            value:
              "Trustee may distribute income and principal to the beneficiary for health, education, maintenance, and support",
          },
          {
            label: "Distribution Type",
            value: "Power of Appointment: Limited",
          },
        ],
      },
      {
        badge: { label: "B", color: "teal" },
        trustName: "Andrew Doe Separate Trust",
        subtitle: "Additional Details",
        properties: [
          {
            label: "Income Distributions",
            value: "Fully Discretionary Distributions",
          },
          {
            label: "Principal Distributions",
            value: "Trustee may distribute income and principal",
          },
          {
            label: "Distribution Type",
            value: "Power of Appointment: Limited",
          },
        ],
      },
    ],
  },

  entityStructure: {
    title: "Entity Structure Chart",
    entities: [
      {
        name: "The Daniel Doe Irrevocable Trust",
        subtitle: "dtd 4/1/2018",
        type: "trust",
        percentage: 45,
        color: "#0d9488",
      },
      {
        name: "The Andrew Doe Irrevocable Trust",
        subtitle: "dtd 4/1/2018",
        type: "trust",
        percentage: 55,
        color: "#1e40af",
      },
      {
        name: "Doe 2018 Irrevocable Trust",
        subtitle: "dtd 8/15/2018",
        type: "trust",
        percentage: 60,
        color: "#7c3aed",
      },
      {
        name: "Doe Family Trust",
        subtitle: "dtd 12/1/2015",
        type: "business",
        percentage: 88,
        color: "#d97706",
      },
    ],
  },

  assetTable: {
    title: "Asset Ownership Overview",
    subtitle: "John Doe & Jane Doe",
    columns: [
      { key: "category", label: "Category", align: "left", format: "text" },
      { key: "johnDoe", label: "John Doe", align: "right", format: "currency" },
      { key: "janeDoe", label: "Jane Doe", align: "right", format: "currency" },
      { key: "total", label: "Total", align: "right", format: "currency" },
    ],
    groups: [
      {
        groupName: "Real Estate",
        rows: [
          {
            category: "Primary Residence",
            johnDoe: 2500000,
            janeDoe: 2500000,
            total: 5000000,
          },
          {
            category: "Investment Properties",
            johnDoe: 1200000,
            janeDoe: 800000,
            total: 2000000,
          },
        ],
        showSubtotal: true,
      },
      {
        groupName: "Investment Accounts",
        rows: [
          {
            category: "Brokerage",
            johnDoe: 5000000,
            janeDoe: 4500000,
            total: 9500000,
          },
          {
            category: "Retirement",
            johnDoe: 3000000,
            janeDoe: 2800000,
            total: 5800000,
          },
        ],
        showSubtotal: true,
      },
      {
        groupName: "Other Assets",
        rows: [
          {
            category: "Cash & Equivalents",
            johnDoe: 500000,
            janeDoe: 400000,
            total: 900000,
          },
          {
            category: "Life Insurance",
            johnDoe: 2000000,
            janeDoe: 1500000,
            total: 3500000,
          },
        ],
        showSubtotal: true,
      },
    ],
  },

  estateFlow: {
    title: "Estate Flow Chart",
    totalValue: 398304420,
    leftColumn: {
      title: "Estates",
      nodes: [
        {
          id: "john",
          label: "John's Estate",
          value: 176742100,
          color: "#0d9488",
        },
        {
          id: "jane",
          label: "Jane's Estate",
          value: 159621400,
          color: "#1e40af",
        },
      ],
    },
    rightColumn: {
      title: "Beneficiaries",
      nodes: [
        {
          id: "daniel",
          label: "Daniel Doe",
          value: 125000000,
          color: "#0d9488",
        },
        {
          id: "andrew",
          label: "Andrew Doe",
          value: 129424880,
          color: "#1e40af",
        },
        {
          id: "charity",
          label: "Family Charities",
          value: 6530000,
          color: "#7c3aed",
        },
      ],
    },
  },

  heritageMap: {
    title: "Heritage Map",
    members: [
      {
        id: "john",
        name: "John Doe",
        initials: "JD",
        generation: 0,
        color: "#0d9488",
      },
      {
        id: "jane",
        name: "Jane Doe",
        initials: "JD",
        generation: 0,
        color: "#1e40af",
      },
      {
        id: "daniel",
        name: "Daniel Doe",
        initials: "DD",
        generation: 1,
        parentId: "john",
        color: "#7c3aed",
      },
      {
        id: "andrew",
        name: "Andrew Doe",
        initials: "AD",
        generation: 1,
        parentId: "john",
        color: "#dc2626",
      },
      {
        id: "sarah",
        name: "Sarah Doe",
        initials: "SD",
        generation: 1,
        parentId: "jane",
        color: "#d97706",
      },
      {
        id: "emily",
        name: "Emily Johnson",
        initials: "EJ",
        generation: 2,
        parentId: "daniel",
        color: "#0d9488",
      },
      {
        id: "michael",
        name: "Michael Doe",
        initials: "MD",
        generation: 2,
        parentId: "daniel",
        color: "#1e40af",
      },
      {
        id: "alex",
        name: "Alex Doe",
        initials: "AD",
        generation: 2,
        parentId: "andrew",
        color: "#7c3aed",
      },
      {
        id: "sophia",
        name: "Sophia Smith",
        initials: "SS",
        generation: 2,
        parentId: "sarah",
        color: "#dc2626",
      },
    ],
  },

  // Trust Flowchart
  trustFlowchart: sampleTrustFlowchartData,
};
