import { StyleSheet } from "@react-pdf/renderer";

/**
 * PDF Design System Theme
 * Based on the estate planning reference UI
 */
export const pdfColors = {
  // Primary (Teal)
  primary: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
  },
  // Secondary (Blue)
  secondary: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
  },
  // Accent colors for charts
  accent: {
    teal: "#0d9488",
    lightTeal: "#5eead4",
    blue: "#1e40af",
    purple: "#7c3aed",
    red: "#dc2626",
    orange: "#d97706",
    pink: "#db2777",
    green: "#059669",
  },
  // Neutrals
  neutral: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
  },
  white: "#ffffff",
  black: "#000000",
};

export const pdfFonts = {
  // Font sizes
  size: {
    xs: 9,
    sm: 10,
    base: 11,
    md: 12,
    lg: 14,
    xl: 16,
    "2xl": 20,
    "3xl": 24,
    "4xl": 32,
  },
  // Font weights (note: @react-pdf uses string values)
  weight: {
    normal: "normal" as const,
    medium: "medium" as const,
    semibold: "semibold" as const,
    bold: "bold" as const,
  },
};

export const pdfSpacing = {
  0: 0,
  1: 4,
  2: 8,
  3: 12,
  4: 16,
  5: 20,
  6: 24,
  8: 32,
  10: 40,
  12: 48,
};

/**
 * Common styles for PDF components
 */
export const commonStyles = StyleSheet.create({
  // Page styles
  page: {
    padding: 40,
    fontFamily: "Helvetica",
    fontSize: pdfFonts.size.base,
    color: pdfColors.neutral[900],
    backgroundColor: pdfColors.white,
  },

  // Card container
  card: {
    backgroundColor: pdfColors.white,
    borderWidth: 1,
    borderColor: pdfColors.neutral[200],
    borderRadius: 8,
    padding: 20,
    marginBottom: 20,
  },

  // Card title
  cardTitle: {
    fontSize: pdfFonts.size["2xl"],
    fontWeight: pdfFonts.weight.bold,
    color: pdfColors.neutral[900],
    marginBottom: 16,
  },

  // Section title (smaller)
  sectionTitle: {
    fontSize: pdfFonts.size.lg,
    fontWeight: pdfFonts.weight.semibold,
    color: pdfColors.neutral[800],
    marginBottom: 12,
  },

  // Body text
  bodyText: {
    fontSize: pdfFonts.size.base,
    color: pdfColors.neutral[700],
    lineHeight: 1.5,
  },

  // Small/caption text
  caption: {
    fontSize: pdfFonts.size.sm,
    color: pdfColors.neutral[500],
  },

  // Row layout
  row: {
    flexDirection: "row",
    alignItems: "center",
  },

  // Space between
  spaceBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  // Centered
  centered: {
    alignItems: "center",
    justifyContent: "center",
  },

  // Badge
  badge: {
    paddingVertical: 2,
    paddingHorizontal: 8,
    borderRadius: 4,
    fontSize: pdfFonts.size.xs,
    fontWeight: pdfFonts.weight.medium,
  },

  // Table styles
  tableHeader: {
    backgroundColor: pdfColors.neutral[100],
    borderBottomWidth: 2,
    borderBottomColor: pdfColors.neutral[300],
  },

  tableHeaderCell: {
    padding: 8,
    fontSize: pdfFonts.size.sm,
    fontWeight: pdfFonts.weight.bold,
    color: pdfColors.neutral[700],
    textTransform: "uppercase",
  },

  tableRow: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: pdfColors.neutral[200],
  },

  tableRowAlternate: {
    backgroundColor: pdfColors.neutral[50],
  },

  tableCell: {
    padding: 8,
    fontSize: pdfFonts.size.base,
    color: pdfColors.neutral[900],
  },

  // Footer
  footer: {
    position: "absolute",
    bottom: 30,
    left: 40,
    right: 40,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: pdfColors.neutral[200],
    paddingTop: 12,
  },

  footerText: {
    fontSize: pdfFonts.size.xs,
    color: pdfColors.neutral[500],
  },
});

/**
 * Chart color palette (in order for consistent usage)
 */
export const chartColors = [
  pdfColors.accent.teal,
  pdfColors.accent.lightTeal,
  pdfColors.accent.blue,
  pdfColors.accent.purple,
  pdfColors.accent.orange,
  pdfColors.accent.red,
  pdfColors.accent.green,
  pdfColors.accent.pink,
];

/**
 * Avatar colors for heritage map
 */
export const avatarColors = [
  pdfColors.accent.teal,
  pdfColors.accent.blue,
  pdfColors.accent.purple,
  pdfColors.accent.red,
  pdfColors.accent.orange,
  pdfColors.accent.green,
];
