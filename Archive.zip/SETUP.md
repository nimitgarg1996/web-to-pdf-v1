# Project Gutenberg - Setup Guide

## Prerequisites

- Node.js 20.x or higher
- npm 9.x or higher
- Docker (optional, for containerized deployment)

---

## Installation Steps

### 1. Install Dependencies

```bash
npm install
```

This will install all required packages:

- Express (API server)
- Puppeteer (PDF generation)
- React & React-DOM (component rendering)
- Recharts (charts)
- Zod (schema validation)
- TypeScript and type definitions

**Expected output:**

```
added 234 packages, and audited 235 packages in 12s
```

### 2. Create Environment File

```bash
cp .env.example .env
```

Default configuration works out of the box for local development.

### 3. Build TypeScript

```bash
npm run build
```

This compiles TypeScript to JavaScript in the `dist/` folder.

### 4. Start the Server

**Development Mode (with hot reload):**

```bash
npm run dev
```

**Production Mode:**

```bash
npm start
```

---

## Verification

### 1. Check Health Endpoint

```bash
curl http://localhost:3000/api/v1/health
```

Expected response:

```json
{
  "success": true,
  "status": "healthy",
  "timestamp": "2024-01-25T12:00:00.000Z"
}
```

### 2. Generate Test PDF

```bash
# Make test script executable
chmod +x scripts/test-pdf.sh

# Run test
./scripts/test-pdf.sh
```

Or manually:

```bash
curl -X POST http://localhost:3000/api/v1/generate-pdf \
  -H "Content-Type: application/json" \
  -d @sample-data/minimal-test.json \
  --output test-report.pdf
```

### 3. View Generated PDF

```bash
# macOS
open test-report.pdf

# Linux
xdg-open test-report.pdf

# Windows
start test-report.pdf
```

---

## Docker Setup

### Build Image

```bash
docker-compose build
```

### Run Container

```bash
docker-compose up
```

### Run in Background

```bash
docker-compose up -d
```

### View Logs

```bash
docker-compose logs -f
```

### Stop Container

```bash
docker-compose down
```

---

## Troubleshooting

### Issue: `Cannot find module 'zod'` or similar TypeScript errors

**Solution:** Run `npm install` to install dependencies. TypeScript errors are expected until packages are installed.

### Issue: Puppeteer fails to launch

**Symptoms:**

```
Error: Failed to launch the browser process
```

**Solution (Linux/WSL):**

```bash
sudo apt-get update
sudo apt-get install -y \
  chromium \
  fonts-liberation \
  libnss3 \
  libatk-bridge2.0-0
```

**Solution (macOS):**
Puppeteer downloads Chromium automatically. If issues persist:

```bash
npm rebuild puppeteer
```

### Issue: PDF generation times out

**Symptoms:**

```
Error: Navigation timeout of 30000 ms exceeded
```

**Solution:** Charts need time to render. The timeout is set in `pdf.service.ts`:

```typescript
await page.waitForTimeout(1000); // Increase if needed
```

### Issue: Charts don't appear in PDF

**Cause:** Recharts uses `requestAnimationFrame` which needs time to execute in headless Chrome.

**Solution:** Already handled with `waitForTimeout(1000)` in pdf.service.ts. If charts still don't render, increase timeout to 2000ms.

### Issue: Content is cut mid-element across pages

**Solution:** Ensure the component has `page-break-inside: avoid` in print.css. Already applied to:

- `.executive-summary`
- `.financial-table`
- `.chart-container`

---

## Development Workflow

### 1. Make Changes to Components

Edit files in `src/components/`

### 2. Rebuild TypeScript

```bash
npm run build
```

Or use watch mode:

```bash
npm run dev
```

### 3. Test Changes

```bash
./scripts/test-pdf.sh
```

### 4. View Logs

Server logs show:

- Request timestamps
- Puppeteer initialization status
- Render times
- Errors

---

## Testing Different Scenarios

### Minimal Report (1 component)

```bash
curl -X POST http://localhost:3000/api/v1/generate-pdf \
  -H "Content-Type: application/json" \
  -d @sample-data/minimal-test.json \
  --output minimal.pdf
```

### Full Novacorp Demo (4 components, 2 pages)

```bash
curl -X POST http://localhost:3000/api/v1/generate-pdf \
  -H "Content-Type: application/json" \
  -d @sample-data/novacorp-q3.json \
  --output novacorp.pdf
```

### Invalid Manifest (Test Validation)

```bash
curl -X POST http://localhost:3000/api/v1/generate-pdf \
  -H "Content-Type: application/json" \
  -d '{"invalid": "manifest"}' \
  -v
```

Expected: `400 Bad Request` with validation errors

---

## Performance Benchmarks

Typical render times on MacBook Pro M1:

- Minimal report (1 component): ~500ms
- Novacorp report (4 components, charts): ~1200ms
- 10-page report: ~3000ms

First request is slower (~2s) due to browser initialization. Subsequent requests reuse the browser instance.

---

## Next Steps

1. ✅ Run `npm install`
2. ✅ Test with minimal sample
3. ✅ Test with Novacorp sample
4. 📝 Review requirements questionnaire
5. 🎨 Customize components as needed
6. 🤖 Add AI orchestration (Phase 3)

---

## File Structure Summary

```
.
├── src/                           # Source code
│   ├── components/                # React components
│   ├── schemas/                   # Zod validation schemas
│   ├── services/                  # Business logic
│   └── api/                       # Express routes
├── sample-data/                   # Test manifests
├── scripts/                       # Utility scripts
├── plans/                         # Documentation
└── output/                        # Generated PDFs (created at runtime)
```

---

**Questions?** See [requirements-questionnaire.md](plans/requirements-questionnaire.md) for detailed configuration options.
