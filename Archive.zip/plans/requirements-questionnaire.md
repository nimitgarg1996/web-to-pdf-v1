# Project Gutenberg - Requirements Questionnaire

## Questions to Resolve Before Implementation

---

## 🔧 Infrastructure & Deployment

### 1. Server Configuration

- **Question:** What port should the API server run on?
- **Options:** 3000 (Node default), 8080 (common), custom?
- **Impact:** Affects Dockerfile EXPOSE and environment configs

### 2. Environment Configuration

- **Question:** What values should be environment-configurable vs hardcoded?
- **Considerations:**
  - Port number
  - Puppeteer executable path
  - PDF output directory (if saving to disk)
  - Log level
  - API keys (for future AI integration)
- **Decision Needed:** Use `.env` files? Config service?

### 3. Browser Instance Management

- **Question:** How should Puppeteer browser instances be managed?
- **Options:**
  - **Singleton:** One browser for all requests (fast, but risky if it crashes)
  - **Pool:** Fixed pool of N browsers (balanced approach)
  - **Per-Request:** New browser each time (slow but isolated)
- **Recommendation Needed:** Expected concurrent users?

---

## 📄 PDF Generation Specifics

### 4. PDF Output Strategy

- **Question:** How should generated PDFs be delivered?
- **Options:**
  - Return as binary stream (download immediately)
  - Return as base64 string (for embedding in JSON response)
  - Save to disk and return file URL
  - Save to cloud storage (S3) and return signed URL
- **Decision Needed:** What fits your deployment model?

### 5. Page Orientation

- **Question:** Should PDFs support landscape mode for wide tables?
- **Options:**
  - Portrait only (simpler)
  - Support both (add `orientation` field to manifest)
  - Auto-detect based on content (complex)
- **Impact:** Affects layout component design

### 6. PDF Metadata

- **Question:** What metadata should be embedded in PDFs?
- **Fields to consider:**
  - Title (from `report_title`)
  - Author (company name or "Project Gutenberg")
  - Subject
  - Keywords
  - Creation date
  - Producer
- **Decision Needed:** Required for compliance/auditing?

### 7. File Size & Page Limits

- **Question:** Should there be constraints on PDF output?
- **Considerations:**
  - Maximum page count (e.g., 50 pages)
  - Maximum file size (e.g., 10MB)
  - Maximum chart data points
- **Decision Needed:** Resource limits to prevent abuse?

---

## 🎨 Visual Design & Branding

### 8. Font Strategy

- **Question:** What fonts should be used?
- **Options:**
  - System fonts only (Arial, Times New Roman)
  - Google Fonts (Inter, Roboto) - requires download
  - Custom corporate fonts - requires font files
- **Decision Needed:** Provide font files or use web fonts?

### 9. Color Palette & Theming

- **Question:** Should color schemes be:
  - Fixed in components (hardcoded brand colors)
  - Configurable per manifest (as designed with `branding.primary_color`)
  - Support dark mode variants
- **Current Plan:** Manifest-based, confirm this is correct?

### 10. Chart Dimensions

- **Question:** What are the standard dimensions for charts?
- **Considerations:**
  - Fixed pixel dimensions (e.g., 800x400)
  - Responsive to page width (e.g., 100% width, 400px height)
  - Different sizes for different chart types
- **Decision Needed:** Chart sizing strategy?

### 11. Corporate Logo Handling

- **Question:** How should logos be handled?
- **Options:**
  - URL provided in manifest (fetch remotely)
  - Pre-upload to assets folder (reference by ID)
  - Base64 embedded in manifest
- **Decision Needed:** Logo management strategy?

---

## 💰 Financial Data Formatting

### 12. Currency & Locale

- **Question:** What currency formatting is required?
- **Considerations:**
  - Single currency (USD assumed)?
  - Multi-currency support needed?
  - Locale for number formatting (en-US: 1,000.00 vs de-DE: 1.000,00)
- **Decision Needed:** Locale and currency configuration?

### 13. Numeric Precision

- **Question:** How should financial numbers be displayed?
- **Options:**
  - Always 2 decimals for currency ($1,234.00)
  - Automatic precision (remove .00 for whole numbers)
  - Configurable per component
- **Decision Needed:** Precision rules?

### 14. Negative Numbers

- **Question:** How should negative values be displayed?
- **Options:**
  - Parentheses: (1,234.56)
  - Minus sign: -1,234.56
  - Red color + minus sign
- **Decision Needed:** Accounting standard to follow?

---

## 🔒 API & Security

### 15. API Authentication

- **Question:** Should the `/generate-pdf` endpoint be protected?
- **Options:**
  - Public (no auth) - for POC
  - API key in headers
  - JWT token
  - OAuth 2.0
- **Decision Needed:** Security requirements?

### 16. Rate Limiting

- **Question:** Should API requests be rate-limited?
- **Considerations:**
  - PDF generation is CPU-intensive
  - Prevent abuse/DoS
  - Limit per IP or per API key
- **Decision Needed:** Rate limiting strategy?

### 17. Request Size Limits

- **Question:** Maximum JSON manifest size?
- **Considerations:**
  - Large manifests = many components = heavy PDFs
  - Express default is 100kb
- **Decision Needed:** Body parser limit?

---

## 🧪 Testing & Development

### 18. Testing Framework

- **Question:** Should we include automated tests?
- **Options:**
  - No tests (rapid POC)
  - Unit tests (Jest/Vitest for components)
  - Integration tests (test full PDF generation pipeline)
  - Visual regression tests (compare PDF outputs)
- **Decision Needed:** Testing strategy for POC?

### 19. Development Workflow

- **Question:** How will you run the project during development?
- **Options:**
  - Local Node.js (hot reload with nodemon/tsx)
  - Docker only (slower iteration)
  - Hybrid (Node locally, Docker for testing)
- **Decision Needed:** Preferred dev environment?

### 20. Sample Data

- **Question:** Should we create multiple sample manifests for testing?
- **Suggestions:**
  - Minimal report (1 page, 1 component)
  - Novacorp Q3 (2 pages, mixed components)
  - Stress test (10+ pages, many charts)
  - Edge cases (empty data, very long text)
- **Decision Needed:** How many sample files to create?

---

## 🎯 Error Handling & Edge Cases

### 21. PDF Generation Failures

- **Question:** How should the system handle Puppeteer failures?
- **Scenarios:**
  - Chromium crashes
  - Timeout (rendering takes too long)
  - Out of memory
- **Decision Needed:** Retry logic? Fallback response?

### 22. Invalid Component Data

- **Question:** What happens when Zod validation fails?
- **Options:**
  - Return 400 error with detailed Zod error messages
  - Attempt to render with defaults/fallbacks
  - Log error and skip the invalid component
- **Decision Needed:** Strict or lenient validation?

### 23. Chart Data Edge Cases

- **Question:** How to handle problematic chart data?
- **Scenarios:**
  - All values are zero
  - Negative values in datasets
  - Mismatched array lengths (labels vs data)
  - Very large numbers (formatting)
- **Decision Needed:** Validation rules and fallback rendering?

---

## 📊 Performance & Scalability

### 24. Concurrency Model

- **Question:** How many PDF generations can run simultaneously?
- **Considerations:**
  - Each Puppeteer page uses ~50-100MB RAM
  - CPU-intensive rendering
  - Docker resource limits
- **Decision Needed:** Max concurrent requests? Queue system?

### 25. Caching Strategy

- **Question:** Should identical manifests return cached PDFs?
- **Options:**
  - No caching (always regenerate)
  - Hash-based cache (manifest hash → PDF)
  - Time-based cache (expire after N minutes)
- **Decision Needed:** Caching requirements?

### 26. Monitoring & Metrics

- **Question:** What metrics should be tracked?
- **Suggestions:**
  - PDF generation time
  - Success/failure rates
  - Memory usage
  - Queue depth
- **Decision Needed:** Observability requirements for POC?

---

## 🎨 Component-Specific Questions

### 27. Executive Summary Design

- **Question:** Should sentiment indicators be:
  - Icons only (↑ ↓ →)
  - Color-coded backgrounds (green/red/yellow)
  - Both icons and colors
- **Decision Needed:** Visual design preference?

### 28. Financial Table Features

- **Question:** Should tables support:
  - Sortable columns (N/A for static PDF)
  - Conditional formatting (highlight negative values in red)
  - Subtotals and grouping
  - Colspan/rowspan for complex layouts
- **Decision Needed:** Table feature scope?

### 29. Chart Customization

- **Question:** How configurable should charts be?
- **Options:**
  - Minimal (use defaults)
  - Moderate (colors, axis labels)
  - Advanced (grid lines, legends, annotations, tooltips)
- **Decision Needed:** Chart configuration depth?

### 30. Layout Flexibility

- **Question:** Should layouts support:
  - Only predefined layouts (single, two-column)
  - Custom column ratios (e.g., 70/30 split)
  - Three-column layouts
  - Nested grids
- **Decision Needed:** Layout system complexity?

---

## 🚀 Demo & Presentation

### 31. Demo Data Source

- **Question:** For the "Novacorp" demo, should we:
  - Use the hardcoded JSON manifest from the plan
  - Create a simple UI to input data
  - Read from a CSV/Excel file
  - Generate random mock data
- **Decision Needed:** Demo input method?

### 32. Demo Output

- **Question:** How should the demo be presented?
- **Options:**
  - CLI tool (run command, get PDF)
  - REST API + Postman collection
  - Simple web UI (form → PDF download)
  - Jupyter notebook style
- **Decision Needed:** Demo interface preference?

---

## Priority Clarifications Needed

Based on the above questions, here are the **CRITICAL** ones that will block implementation:

| Priority  | Question                | Why It Blocks Progress                               |
| --------- | ----------------------- | ---------------------------------------------------- |
| 🔴 HIGH   | #4: PDF Output Strategy | Affects API response design and Docker volume mounts |
| 🔴 HIGH   | #8: Font Strategy       | Need font files before building components           |
| 🔴 HIGH   | #12: Currency & Locale  | Affects FinancialTable component implementation      |
| 🟡 MEDIUM | #3: Browser Management  | Affects pdf.service.ts architecture                  |
| 🟡 MEDIUM | #18: Testing Framework  | Affects package.json dependencies                    |
| 🟡 MEDIUM | #19: Dev Workflow       | Affects how we structure npm scripts                 |
| 🟢 LOW    | All others              | Can use sensible defaults and adjust later           |

---

## Recommended Approach

I suggest we resolve the **HIGH priority** questions first, then proceed with sensible defaults for MEDIUM/LOW items that can be adjusted as we build.

Please provide answers to questions #4, #8, and #12 so I can finalize the implementation plan.
