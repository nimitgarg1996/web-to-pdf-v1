# Project Gutenberg - AI Report Engine

## Phase 1-2 Architecture Plan

---

## Executive Summary

This document outlines the architecture for building the **Rendering Core** (Phase 1) and **Template Registry** (Phase 2) of Project Gutenberg - an AI-powered financial report generation engine.

**Primary Goal:** Establish a rock-solid HTML-to-PDF pipeline with reusable, type-safe components before integrating AI in Phase 3.

---

## Tech Stack

| Layer             | Technology   | Version | Purpose            |
| ----------------- | ------------ | ------- | ------------------ |
| Runtime           | Node.js      | 20 LTS  | Server runtime     |
| Language          | TypeScript   | 5.x     | Type safety        |
| Web Framework     | Express      | 4.x     | REST API           |
| PDF Engine        | Puppeteer    | 22.x    | Headless Chrome    |
| Template Engine   | React        | 18.x    | SSR components     |
| Styling           | Tailwind CSS | 3.x     | Utility-first CSS  |
| Charts            | Recharts     | 2.x     | SVG-based charts   |
| Schema Validation | Zod          | 3.x     | Runtime validation |
| Container         | Docker       | -       | Deployment         |

---

## System Architecture

```mermaid
flowchart TB
    subgraph Client
        A[API Request with JSON Manifest]
    end

    subgraph Backend [Node.js Backend]
        B[Express API Server]
        C[Manifest Validator - Zod]
        D[Stitcher Service]
        E[React SSR Engine]
        F[Puppeteer PDF Generator]
    end

    subgraph Components [Template Registry]
        G[Executive Summary]
        H[Financial Table]
        I[Bar Chart]
        J[Line Chart]
        K[Layout Grid]
    end

    subgraph Output
        L[PDF Buffer / File]
    end

    A --> B
    B --> C
    C --> D
    D --> E
    E --> G & H & I & J & K
    G & H & I & J & K --> E
    E --> F
    F --> L
    L --> A
```

---

## Project Structure

```
project-gutenberg/
├── src/
│   ├── api/
│   │   ├── routes/
│   │   │   └── pdf.routes.ts          # POST /generate-pdf
│   │   └── index.ts                    # Express app setup
│   │
│   ├── components/                     # React components for PDF
│   │   ├── atoms/                      # Smallest units
│   │   │   ├── Badge.tsx
│   │   │   ├── SentimentIcon.tsx
│   │   │   └── Currency.tsx
│   │   │
│   │   ├── molecules/                  # Composed atoms
│   │   │   ├── ExecutiveSummary.tsx
│   │   │   ├── FinancialTable.tsx
│   │   │   └── ChartContainer.tsx
│   │   │
│   │   ├── charts/                     # Recharts wrappers
│   │   │   ├── BarChartDouble.tsx
│   │   │   └── TrendLineChart.tsx
│   │   │
│   │   ├── layouts/                    # Page layouts
│   │   │   ├── SingleColumn.tsx
│   │   │   ├── TwoColumnGrid.tsx
│   │   │   └── PageWrapper.tsx
│   │   │
│   │   └── templates/                  # Full page templates
│   │       └── ReportTemplate.tsx
│   │
│   ├── schemas/                        # Zod schemas
│   │   ├── manifest.schema.ts          # Full report manifest
│   │   └── components.schema.ts        # Individual component schemas
│   │
│   ├── services/
│   │   ├── pdf.service.ts              # Puppeteer logic
│   │   ├── stitcher.service.ts         # Component assembly
│   │   └── renderer.service.ts         # React SSR
│   │
│   ├── styles/
│   │   ├── globals.css                 # Tailwind base
│   │   └── print.css                   # CSS Paged Media rules
│   │
│   ├── assets/
│   │   ├── fonts/                      # Local fonts
│   │   └── images/                     # Logos, icons
│   │
│   └── index.ts                        # Entry point
│
├── Dockerfile
├── docker-compose.yml
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── README.md
```

---

## Phase 1: Rendering Core

### 1.1 Puppeteer Configuration

```typescript
// src/services/pdf.service.ts
interface PDFOptions {
  format: "A4" | "Letter";
  printBackground: boolean;
  margin: {
    top: string;
    right: string;
    bottom: string;
    left: string;
  };
  displayHeaderFooter: boolean;
  headerTemplate: string;
  footerTemplate: string;
}

const defaultPDFOptions: PDFOptions = {
  format: "A4",
  printBackground: true,
  margin: {
    top: "20mm",
    right: "15mm",
    bottom: "20mm",
    left: "15mm",
  },
  displayHeaderFooter: true,
  headerTemplate:
    '<div style="font-size:10px; width:100%; text-align:center;">Confidential - Board Only</div>',
  footerTemplate:
    '<div style="font-size:10px; width:100%; text-align:center;">Page <span class="pageNumber"></span> of <span class="totalPages"></span></div>',
};
```

### 1.2 CSS Paged Media Strategy

```css
/* src/styles/print.css */

/* Base page setup */
@page {
  size: A4;
  margin: 20mm 15mm;
}

/* Prevent orphans and widows */
p,
li {
  orphans: 3;
  widows: 3;
}

/* Keep headings with their content */
h1,
h2,
h3,
h4,
h5,
h6 {
  page-break-after: avoid;
  break-after: avoid;
}

/* Keep tables together when possible */
table {
  page-break-inside: avoid;
  break-inside: avoid;
}

/* Charts should never be split */
.chart-container {
  page-break-inside: avoid;
  break-inside: avoid;
}

/* Force page breaks where needed */
.page-break {
  page-break-before: always;
  break-before: page;
}

/* Executive summary cards stay together */
.executive-summary {
  page-break-inside: avoid;
  break-inside: avoid;
}
```

### 1.3 Dockerfile Strategy

```dockerfile
# Dockerfile
FROM node:20-slim

# Install Chromium dependencies
RUN apt-get update && apt-get install -y \
    chromium \
    fonts-liberation \
    fonts-noto-color-emoji \
    libgbm1 \
    libnss3 \
    libatk-bridge2.0-0 \
    libgtk-3-0 \
    libasound2 \
    --no-install-recommends \
    && rm -rf /var/lib/apt/lists/*

# Tell Puppeteer to use installed Chromium
ENV PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true
ENV PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000
CMD ["node", "dist/index.js"]
```

### 1.4 API Endpoint Design

```typescript
// POST /api/v1/generate-pdf
interface GeneratePDFRequest {
  manifest: ReportManifest;
  options?: {
    format?: "A4" | "Letter";
    quality?: "draft" | "final";
  };
}

interface GeneratePDFResponse {
  success: boolean;
  pdf?: Buffer; // Base64 encoded or binary stream
  metadata?: {
    pageCount: number;
    generatedAt: string;
    renderTimeMs: number;
  };
  error?: string;
}
```

---

## Phase 2: Template Registry

### 2.1 Component Type Definitions

```typescript
// src/schemas/components.schema.ts
import { z } from "zod";

// Sentiment enum for visual indicators
export const SentimentSchema = z.enum(["POSITIVE", "NEUTRAL", "NEGATIVE"]);

// Executive Summary Component
export const ExecutiveSummarySchema = z.object({
  type: z.literal("EXECUTIVE_SUMMARY"),
  data: z.object({
    headline: z.string().max(100),
    sentiment: SentimentSchema,
    text: z.string().max(500),
    highlights: z.array(z.string()).optional(),
  }),
});

// Financial Table Component
export const FinancialTableSchema = z.object({
  type: z.literal("FINANCIAL_TABLE"),
  data: z.object({
    title: z.string(),
    columns: z.array(
      z.object({
        key: z.string(),
        label: z.string(),
        format: z
          .enum(["text", "currency", "percentage", "number"])
          .default("text"),
      }),
    ),
    rows: z.array(z.record(z.union([z.string(), z.number()]))),
    showTotal: z.boolean().default(false),
    totalLabel: z.string().default("Total"),
  }),
});

// Bar Chart Component (Double Series)
export const BarChartDoubleSchema = z.object({
  type: z.literal("CHART_BAR_DOUBLE"),
  data: z.object({
    title: z.string(),
    labels: z.array(z.string()),
    series_A: z.object({
      name: z.string(),
      data: z.array(z.number()),
      color: z.string().optional(),
    }),
    series_B: z.object({
      name: z.string(),
      data: z.array(z.number()),
      color: z.string().optional(),
    }),
  }),
});

// Line Chart Component
export const TrendLineChartSchema = z.object({
  type: z.literal("CHART_LINE_TREND"),
  data: z.object({
    title: z.string(),
    labels: z.array(z.string()),
    series: z.array(
      z.object({
        name: z.string(),
        data: z.array(z.number()),
        color: z.string().optional(),
      }),
    ),
  }),
});

// Union of all component types
export const ComponentSchema = z.discriminatedUnion("type", [
  ExecutiveSummarySchema,
  FinancialTableSchema,
  BarChartDoubleSchema,
  TrendLineChartSchema,
]);
```

### 2.2 Report Manifest Schema

```typescript
// src/schemas/manifest.schema.ts
import { z } from "zod";
import { ComponentSchema } from "./components.schema";

export const LayoutSchema = z.enum(["single_column", "two_column"]);

export const PageSchema = z.object({
  layout: LayoutSchema,
  components: z.array(ComponentSchema),
});

export const ReportManifestSchema = z.object({
  report_title: z.string(),
  subtitle: z.string().optional(),
  generated_at: z.string().datetime().optional(),
  branding: z
    .object({
      company_name: z.string(),
      logo_url: z.string().optional(),
      primary_color: z.string().default("#1E40AF"),
      secondary_color: z.string().default("#64748B"),
    })
    .optional(),
  pages: z.array(PageSchema).min(1),
});

export type ReportManifest = z.infer<typeof ReportManifestSchema>;
```

### 2.3 Component Visual Design

```mermaid
flowchart LR
    subgraph Atoms
        A1[Badge]
        A2[SentimentIcon]
        A3[Currency]
        A4[Percentage]
    end

    subgraph Molecules
        M1[Executive Summary Card]
        M2[Financial Table]
        M3[Chart Container]
    end

    subgraph Organisms
        O1[Page Section]
        O2[Report Header]
        O3[Report Footer]
    end

    subgraph Templates
        T1[Single Column Page]
        T2[Two Column Page]
    end

    A1 & A2 --> M1
    A3 & A4 --> M2
    M1 & M2 & M3 --> O1
    O1 & O2 & O3 --> T1 & T2
```

### 2.4 Stitcher Service Flow

```mermaid
sequenceDiagram
    participant API as Express API
    participant Val as Zod Validator
    participant Stitch as Stitcher Service
    participant React as React SSR
    participant Pup as Puppeteer

    API->>Val: Validate manifest
    Val-->>API: Validation result

    alt Invalid manifest
        API-->>API: Return 400 error
    end

    API->>Stitch: Process manifest

    loop For each page
        Stitch->>React: Render page components
        React-->>Stitch: HTML string
    end

    Stitch->>Stitch: Wrap in document shell
    Stitch-->>API: Complete HTML

    API->>Pup: Generate PDF from HTML
    Pup-->>API: PDF buffer
    API-->>API: Return PDF response
```

---

## Sample JSON Manifest (Demo)

This is the expected input format for the "Novacorp Q3 Financials" demo:

```json
{
  "report_title": "Novacorp Q3 Financials",
  "subtitle": "July - September 2024",
  "branding": {
    "company_name": "Novacorp",
    "primary_color": "#1E40AF",
    "secondary_color": "#64748B"
  },
  "pages": [
    {
      "layout": "single_column",
      "components": [
        {
          "type": "EXECUTIVE_SUMMARY",
          "data": {
            "headline": "Strong Q3 Finish Driven by Enterprise Wins",
            "sentiment": "POSITIVE",
            "text": "Despite a seasonal dip in August, Q3 revenue grew by 50% month-over-month in September, anchored by the strategic MegaBank acquisition.",
            "highlights": [
              "MegaBank deal closed - $500K ARR",
              "Engineering team expanded by 3 FTEs",
              "Net profit margin: 15%"
            ]
          }
        },
        {
          "type": "CHART_BAR_DOUBLE",
          "data": {
            "title": "Revenue vs Expenses Q3",
            "labels": ["July", "August", "September"],
            "series_A": {
              "name": "Revenue",
              "data": [120000, 135000, 180000],
              "color": "#1E40AF"
            },
            "series_B": {
              "name": "Expenses",
              "data": [110000, 115000, 120000],
              "color": "#64748B"
            }
          }
        }
      ]
    },
    {
      "layout": "single_column",
      "components": [
        {
          "type": "FINANCIAL_TABLE",
          "data": {
            "title": "Monthly Breakdown",
            "columns": [
              { "key": "month", "label": "Month", "format": "text" },
              { "key": "revenue", "label": "Revenue", "format": "currency" },
              { "key": "expenses", "label": "Expenses", "format": "currency" },
              { "key": "profit", "label": "Net Profit", "format": "currency" },
              { "key": "margin", "label": "Margin", "format": "percentage" }
            ],
            "rows": [
              {
                "month": "July",
                "revenue": 120000,
                "expenses": 110000,
                "profit": 10000,
                "margin": 8.3
              },
              {
                "month": "August",
                "revenue": 135000,
                "expenses": 115000,
                "profit": 20000,
                "margin": 14.8
              },
              {
                "month": "September",
                "revenue": 180000,
                "expenses": 120000,
                "profit": 60000,
                "margin": 33.3
              }
            ],
            "showTotal": true,
            "totalLabel": "Q3 Total"
          }
        }
      ]
    }
  ]
}
```

---

## Key Technical Decisions

### 1. SVG Charts over Canvas

- **Decision:** Use Recharts (SVG-based) instead of Chart.js (Canvas-based)
- **Reason:** SVG renders as vectors in PDF, ensuring crisp graphics at any zoom level

### 2. Server-Side React Rendering

- **Decision:** Use `ReactDOMServer.renderToString()` instead of a browser-based approach
- **Reason:** Faster rendering, no need for React hydration, cleaner HTML output

### 3. Puppeteer Page Reuse

- **Decision:** Use a browser pool with page recycling
- **Reason:** Creating a new browser instance per request is slow (~500ms). Reusing pages drops this to ~50ms

### 4. Local Asset Loading

- **Decision:** Bundle fonts and logos locally, serve via data URIs or local file paths
- **Reason:** Avoids network timeouts, ensures consistent rendering in offline/containerized environments

### 5. Zod for Schema Validation

- **Decision:** Use Zod instead of JSON Schema or Joi
- **Reason:** TypeScript-first, infers types automatically, excellent error messages for AI debugging in Phase 3

---

## Success Criteria for Phase 1-2

### Phase 1 Complete When:

- [ ] `POST /generate-pdf` returns a valid PDF from static HTML
- [ ] Docker container runs without Chromium errors
- [ ] Multi-page content renders without being cut mid-element
- [ ] Headers and footers appear correctly on each page

### Phase 2 Complete When:

- [ ] All 4 core components render correctly (Summary, Table, Bar Chart, Line Chart)
- [ ] JSON manifest is validated before rendering (invalid input returns 400)
- [ ] Sample "Novacorp" manifest generates a professional-looking 2-page PDF
- [ ] Components can be arranged in both single-column and two-column layouts

---

## Next Steps After This Plan

1. **Review this plan** - Does the architecture align with your expectations?
2. **Switch to Code mode** - Begin implementation starting with Phase 1.1
3. **Iterate** - Test each phase thoroughly before moving to the next

---

_Plan created: January 25, 2026_
_Project Gutenberg - Phase 1-2 Architecture_
