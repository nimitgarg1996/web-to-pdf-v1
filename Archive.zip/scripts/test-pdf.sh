#!/bin/bash

# Test script for generating PDF from sample data

echo "🧪 Testing Project Gutenberg PDF Generation"
echo ""

# Check if server is running
echo "1. Checking if server is running..."
if curl -s http://localhost:3000/api/v1/health > /dev/null; then
    echo "   ✓ Server is running"
else
    echo "   ✗ Server is not running. Please start it with: npm run dev"
    exit 1
fi

echo ""
echo "2. Generating PDF from Novacorp Q3 sample data..."

# Generate PDF
curl -X POST http://localhost:3000/api/v1/generate-pdf \
  -H "Content-Type: application/json" \
  -d @sample-data/novacorp-q3.json \
  --output novacorp-q3-report.pdf \
  -w "\n   Render time: %{time_total}s\n" \
  -s

if [ -f novacorp-q3-report.pdf ]; then
    SIZE=$(du -h novacorp-q3-report.pdf | cut -f1)
    echo "   ✓ PDF generated successfully"
    echo "   File: novacorp-q3-report.pdf"
    echo "   Size: $SIZE"
    echo ""
    echo "3. Opening PDF..."
    
    # Open PDF based on OS
    if [[ "$OSTYPE" == "darwin"* ]]; then
        open novacorp-q3-report.pdf
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        xdg-open novacorp-q3-report.pdf
    else
        echo "   Please open novacorp-q3-report.pdf manually"
    fi
else
    echo "   ✗ PDF generation failed"
    exit 1
fi

echo ""
echo "✅ Test complete!"
