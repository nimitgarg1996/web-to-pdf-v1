# Project Gutenberg - AI Report Engine POC

A proof-of-concept for generating professional PDF reports from structured JSON manifests using React components and Puppeteer.

## 🚀 Quick Start

### Option 1: Local Development (Recommended for POC)

1. **Install Dependencies**

   ```bash
   npm install
   ```

2. **Start Development Server**

   ```bash
   npm run dev
   ```

3. **Test the API**

   ```bash
   # Health check
   curl http://localhost:3000/api/v1/health

   # Generate sample PDF
   curl -X POST http://localhost:3000/api/v1/generate-pdf \
     -H "Content-Type: application/json" \
     -d @sample-data/novacorp-q3.json \
     --output novacorp-q3-report.pdf
   ```

### Option 2: Docker

1. **Build and Run**

   ```bash
   docker-compose up --build
   ```

2. **Test**
   ```bash
   curl -X POST http://localhost:3000/api/v1/generate-pdf \
     -H "Content-Type: application/json" \
     -d @sample-data/novacorp-q3.json \
     --output report.pdf
   ```

---

## 📋 API Endpoints

### `GET /api/v1/health`

Check if the service is running and Puppeteer is initialized.

**Response:**

```json
{
  "success": true,
  "status": "healthy",
  "timestamp": "2024-01-25T12:00:00.000Z"
}
```

### `POST /api/v1/generate-pdf`

Generate a PDF from a report manifest.

**Request Body:**

```json
{
  "report_title": "Q3 Financial Report",
  "pages": [
    {
      "layout": "single_column",
      "components": [
        {
          "type": "EXECUTIVE_SUMMARY",
          "data": {
            "headline": "Strong Performance",
            "sentiment": "POSITIVE",
            "text": "Revenue increased by 50%"
          }
        }
      ]
    }
  ]
}
```

**Response:**

- Content-Type: `application/pdf`
- Binary PDF data

**Custom Headers:**

- `X-Render-Time-Ms`: Time taken to generate PDF in milliseconds

---

## 🎨 Available Components

### 1. Executive Summary

**Type:** `EXECUTIVE_SUMMARY`

Shows a headline with sentiment indicator (↑↓→), body text, and optional highlights.

```json
{
  "type": "EXECUTIVE_SUMMARY",
  "data": {
    "headline": "Strong Q3 Performance",
    "sentiment": "POSITIVE",
    "text": "Detailed explanation...",
    "highlights": ["Point 1", "Point 2"]
  }
}
```

### 2. Financial Table

**Type:** `FINANCIAL_TABLE`

Displays tabular data with formatting for currency, percentages, and numbers.

```json
{
  "type": "FINANCIAL_TABLE",
  "data": {
    "title": "Monthly Breakdown",
    "columns": [
      { "key": "month", "label": "Month", "format": "text" },
      { "key": "revenue", "label": "Revenue", "format": "currency" }
    ],
    "rows": [{ "month": "Jan", "revenue": 100000 }],
    "showTotal": true,
    "totalLabel": "Total"
  }
}
```

### 3. Bar Chart (Double Series)

**Type:** `CHART_BAR_DOUBLE`

Displays two data series as side-by-side bars.

```json
{
  "type": "CHART_BAR_DOUBLE",
  "data": {
    "title": "Revenue vs Expenses",
    "labels": ["Jan", "Feb", "Mar"],
    "series_A": {
      "name": "Revenue",
      "data": [100, 120, 150],
      "color": "#1E40AF"
    },
    "series_B": {
      "name": "Expenses",
      "data": [80, 90, 95],
      "color": "#64748B"
    }
  }
}
```

### 4. Line Chart (Trend)

**Type:** `CHART_LINE_TREND`

Displays one or more data series as line graphs.

```json
{
  "type": "CHART_LINE_TREND",
  "data": {
    "title": "Growth Trend",
    "labels": ["Q1", "Q2", "Q3"],
    "series": [
      {
        "name": "Revenue Growth",
        "data": [10, 25, 40],
        "color": "#059669"
      }
    ]
  }
}
```

---

## 📐 Layouts

- **`single_column`**: Full-width layout
- **`two_column`**: Split components across two columns

---

## 🧪 Demo Script

A quick demo to test all features:

```bash
# 1. Start the server
npm run dev

# 2. In another terminal, generate the Novacorp sample report
curl -X POST http://localhost:3000/api/v1/generate-pdf \
  -H "Content-Type: application/json" \
  -d @sample-data/novacorp-q3.json \
  --output novacorp-report.pdf

# 3. Open the PDF
open novacorp-report.pdf  # macOS
# or
xdg-open novacorp-report.pdf  # Linux
```

---

## 🏗️ Project Structure

```
project-gutenberg/
├── src/
│   ├── api/
│   │   ├── routes/
│   │   │   └── pdf.routes.ts       # API route handlers
│   │   └── index.ts                # Express app setup
│   ├── components/
│   │   ├── atoms/                  # Basic UI elements
│   │   │   ├── Badge.tsx
│   │   │   ├── Currency.tsx
│   │   │   ├── Percentage.tsx
│   │   │   └── SentimentIcon.tsx
│   │   ├── molecules/              # Composed components
│   │   │   ├── ExecutiveSummary.tsx
│   │   │   └── FinancialTable.tsx
│   │   ├── charts/                 # Chart components
│   │   │   ├── BarChartDouble.tsx
│   │   │   └── TrendLineChart.tsx
│   │   ├── layouts/                # Page layouts
│   │   │   ├── SingleColumn.tsx
│   │   │   ├── TwoColumn.tsx
│   │   │   └── PageWrapper.tsx
│   │   └── templates/
│   │       └── ReportTemplate.tsx  # Main template
│   ├── schemas/
│   │   ├── components.schema.ts    # Zod schemas for components
│   │   └── manifest.schema.ts      # Zod schema for full manifest
│   ├── services/
│   │   ├── pdf.service.ts          # Puppeteer PDF generation
│   │   ├── renderer.service.ts     # React SSR
│   │   └── stitcher.service.ts     # Component assembly
│   ├── styles/
│   │   └── print.css               # CSS Paged Media rules
│   └── index.ts                    # Server entry point
├── sample-data/
│   └── novacorp-q3.json            # Demo manifest
├── plans/                          # Architecture documentation
├── Dockerfile
├── docker-compose.yml
└── package.json
```

---

## 🔧 Configuration

Create a `.env` file (copy from `.env.example`):

```bash
PORT=3000
NODE_ENV=development
PUPPETEER_HEADLESS=true
```

---

## 🐳 Docker Notes

The Dockerfile installs Chromium with all required dependencies. Key points:

- Uses multi-stage build to minimize image size
- Chromium installed at `/usr/bin/chromium`
- Includes all necessary fonts and libraries
- Health check runs every 30 seconds

---

## 📊 Current Status

### ✅ Phase 1: Rendering Core

- [x] TypeScript + Node.js setup
- [x] Puppeteer configuration
- [x] Docker with Chromium
- [x] PDF generation endpoint
- [x] CSS Paged Media styles
- [x] Multi-page support

### ✅ Phase 2: Template Registry

- [x] Zod schemas for all components
- [x] Executive Summary component
- [x] Financial Table component
- [x] Bar Chart (double series)
- [x] Line Chart (trend)
- [x] Layout system (single/two column)
- [x] Stitcher service

### ⏳ Phase 3: AI Orchestrator

- [ ] AI provider integration (TBD)
- [ ] Prompt engineering
- [ ] Data analysis logic

---

## 🎯 Next Steps

1. **Install dependencies** and test the Novacorp demo
2. **Review** the [requirements questionnaire](plans/requirements-questionnaire.md)
3. **Customize** components based on your feedback
4. **Integrate AI** in Phase 3 once rendering is validated

---

## 📝 Notes

- TypeScript errors in IDE are expected until `npm install` is run
- Charts render as SVG for crisp PDF output
- Headers/footers show "Confidential - Board Only" and page numbers
- Currency formatting defaults to USD with en-US locale
- Negative values show in red with parentheses

---

## 🆘 Troubleshooting

### Puppeteer fails to launch

```bash
# Install Chromium dependencies manually
sudo apt-get install -y chromium fonts-liberation
```

### Charts not rendering

- Ensure `waitForTimeout(1000)` in pdf.service.ts (gives Recharts time to render SVG)

### PDF cuts content mid-element

- Check that CSS `page-break-inside: avoid` is applied to the component
- Verify print.css is loaded in renderer.service.ts

---

**Built with:** Node.js 20 • TypeScript 5 • React 18 • Puppeteer 22 • Recharts 2 • Zod 3
