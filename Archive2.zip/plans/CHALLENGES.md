# Challenges & Solutions: Server-Side PDF Report Generator

> A comprehensive guide to challenges you'll face when building an autonomous PDF generation pipeline, with battle-tested solutions.

---

## Table of Contents

1. [Data Structure & Validation](#1-data-structure--validation)
2. [Performance & Memory Issues](#2-performance--memory-issues)
3. [Styling & Layout Issues](#3-styling--layout-issues)
4. [Dynamic Content & Templating](#4-dynamic-content--templating)
5. [Error Handling & Debugging](#5-error-handling--debugging)
6. [Testing & Quality Assurance](#6-testing--quality-assurance)
7. [Deployment & Infrastructure](#7-deployment--infrastructure)
8. [Data Security & Compliance](#8-data-security--compliance)
9. [Implementation Phases](#9-implementation-phases)

---

## 1. Data Structure & Validation

### Challenges

| Challenge                 | Impact                                                | Severity |
| ------------------------- | ----------------------------------------------------- | -------- |
| Dynamic schema variations | Different clients need different report structures    | High     |
| Nested/complex data       | Deeply nested objects, arrays within arrays           | Medium   |
| Data type inconsistencies | Numbers as strings, null vs undefined, missing fields | High     |
| Large datasets            | Reports with thousands of rows causing memory issues  | Critical |
| Date/time formatting      | Different locales and timezone handling               | Medium   |

### Solutions

#### Schema Validation with Joi/Zod

```typescript
// src/api/validators/reportSchema.ts
import Joi from "joi";

const clientSchema = Joi.object({
  id: Joi.string().required(),
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  phone: Joi.string().optional(),
  address: Joi.object({
    street: Joi.string().optional(),
    city: Joi.string().optional(),
    country: Joi.string().optional(),
  }).optional(),
});

const tableDataSchema = Joi.object({
  columns: Joi.array()
    .items(
      Joi.object({
        key: Joi.string().required(),
        header: Joi.string().required(),
        width: Joi.alternatives().try(Joi.string(), Joi.number()).required(),
        align: Joi.string().valid("left", "center", "right").default("left"),
      }),
    )
    .min(1)
    .required(),
  rows: Joi.array().items(Joi.object()).min(0).required(),
});

export const reportSchema = Joi.object({
  company: Joi.object({
    name: Joi.string().required(),
    logo: Joi.string().uri().optional(),
  }).required(),
  client: clientSchema.required(),
  reportTitle: Joi.string().required(),
  generatedDate: Joi.date()
    .iso()
    .default(() => new Date()),
  tables: Joi.array().items(tableDataSchema).optional(),
  diagrams: Joi.array().items(Joi.object()).optional(),
  metadata: Joi.object().unknown(true).optional(),
});

export function validateReportData(data: unknown): ReportData {
  const { error, value } = reportSchema.validate(data, {
    abortEarly: false,
    stripUnknown: true,
  });

  if (error) {
    const details = error.details.map((d) => ({
      path: d.path.join("."),
      message: d.message,
    }));
    throw new ValidationError("Invalid report data", details);
  }

  return value as ReportData;
}
```

#### Data Normalization

```typescript
// src/transformers/content/DataNormalizer.ts

interface NormalizationOptions {
  dateFormat?: string;
  numberLocale?: string;
  defaultCurrency?: string;
  timezone?: string;
}

export class DataNormalizer {
  private options: NormalizationOptions;

  constructor(options: NormalizationOptions = {}) {
    this.options = {
      dateFormat: "YYYY-MM-DD",
      numberLocale: "en-US",
      defaultCurrency: "USD",
      timezone: "UTC",
      ...options,
    };
  }

  normalize(data: RawReportData): NormalizedReportData {
    return {
      ...data,
      generatedDate: this.normalizeDate(data.generatedDate),
      client: this.normalizeClient(data.client),
      tables: data.tables?.map((t) => this.normalizeTable(t)),
      metrics: data.metrics?.map((m) => this.normalizeMetric(m)),
    };
  }

  private normalizeDate(date: unknown): string {
    if (!date) return new Date().toISOString();
    if (date instanceof Date) return date.toISOString();
    if (typeof date === "string") return new Date(date).toISOString();
    if (typeof date === "number") return new Date(date).toISOString();
    return new Date().toISOString();
  }

  private normalizeClient(client: RawClient): NormalizedClient {
    return {
      id: String(client.id),
      name: String(client.name).trim(),
      email: String(client.email).toLowerCase().trim(),
      phone: client.phone ? this.normalizePhone(client.phone) : undefined,
    };
  }

  private normalizePhone(phone: string): string {
    // Remove all non-numeric characters
    return phone.replace(/\D/g, "");
  }

  private normalizeTable(table: RawTable): NormalizedTable {
    return {
      ...table,
      rows: table.rows.map((row) => this.normalizeRow(row, table.columns)),
    };
  }

  private normalizeRow(
    row: Record<string, unknown>,
    columns: Column[],
  ): NormalizedRow {
    const normalized: NormalizedRow = {};

    for (const col of columns) {
      const value = row[col.key];
      normalized[col.key] = this.normalizeValue(value, col.type);
    }

    return normalized;
  }

  private normalizeValue(value: unknown, type?: string): string | number {
    if (value === null || value === undefined) return "";

    switch (type) {
      case "currency":
        return this.formatCurrency(value);
      case "date":
        return this.formatDate(value);
      case "number":
        return this.formatNumber(value);
      case "percentage":
        return this.formatPercentage(value);
      default:
        return String(value);
    }
  }

  private formatCurrency(value: unknown): string {
    const num = typeof value === "number" ? value : parseFloat(String(value));
    if (isNaN(num)) return "$0.00";

    return new Intl.NumberFormat(this.options.numberLocale, {
      style: "currency",
      currency: this.options.defaultCurrency,
    }).format(num);
  }

  private formatDate(value: unknown): string {
    const date = new Date(value as string | number);
    if (isNaN(date.getTime())) return "";

    return new Intl.DateTimeFormat(this.options.numberLocale, {
      year: "numeric",
      month: "short",
      day: "numeric",
      timeZone: this.options.timezone,
    }).format(date);
  }

  private formatNumber(value: unknown): string {
    const num = typeof value === "number" ? value : parseFloat(String(value));
    if (isNaN(num)) return "0";

    return new Intl.NumberFormat(this.options.numberLocale).format(num);
  }

  private formatPercentage(value: unknown): string {
    const num = typeof value === "number" ? value : parseFloat(String(value));
    if (isNaN(num)) return "0%";

    return new Intl.NumberFormat(this.options.numberLocale, {
      style: "percent",
      minimumFractionDigits: 1,
      maximumFractionDigits: 2,
    }).format(num / 100);
  }
}
```

#### Large Dataset Pagination

```typescript
// src/utils/pagination.ts

export interface PaginationResult<T> {
  pages: T[][];
  totalPages: number;
  totalItems: number;
}

export function paginateData<T>(
  data: T[],
  itemsPerPage: number = 25,
): PaginationResult<T> {
  const pages: T[][] = [];

  for (let i = 0; i < data.length; i += itemsPerPage) {
    pages.push(data.slice(i, i + itemsPerPage));
  }

  return {
    pages,
    totalPages: pages.length,
    totalItems: data.length,
  };
}

// Smart pagination that accounts for header space on first page
export function smartPaginate<T>(
  data: T[],
  options: {
    firstPageItems: number; // Fewer items on first page due to headers
    subsequentPageItems: number;
    minItemsOnLastPage?: number; // Avoid orphans
  },
): PaginationResult<T> {
  const {
    firstPageItems,
    subsequentPageItems,
    minItemsOnLastPage = 3,
  } = options;
  const pages: T[][] = [];

  if (data.length === 0) {
    return { pages: [[]], totalPages: 1, totalItems: 0 };
  }

  // First page
  const firstPage = data.slice(0, firstPageItems);
  pages.push(firstPage);

  // Subsequent pages
  let remaining = data.slice(firstPageItems);
  while (remaining.length > 0) {
    // Check for orphan condition
    if (remaining.length <= minItemsOnLastPage && pages.length > 0) {
      // Move some items from previous page to avoid orphans
      const lastPage = pages[pages.length - 1];
      const itemsToMove = Math.min(
        minItemsOnLastPage - remaining.length,
        lastPage.length - minItemsOnLastPage,
      );

      if (itemsToMove > 0) {
        const movedItems = lastPage.splice(-itemsToMove);
        remaining = [...movedItems, ...remaining];
      }
    }

    pages.push(remaining.slice(0, subsequentPageItems));
    remaining = remaining.slice(subsequentPageItems);
  }

  return {
    pages,
    totalPages: pages.length,
    totalItems: data.length,
  };
}
```

---

## 2. Performance & Memory Issues

### Challenges

| Challenge                  | Impact                                           | Severity |
| -------------------------- | ------------------------------------------------ | -------- |
| Large PDFs (100+ pages)    | Excessive memory consumption                     | Critical |
| Concurrent generation      | Multiple users requesting reports simultaneously | High     |
| Image processing           | High-resolution images bloating file size        | Medium   |
| Font loading               | Custom fonts increasing bundle size              | Low      |
| Server resource exhaustion | Memory leaks during batch processing             | Critical |

### Solutions

#### Stream-Based Rendering

```typescript
// src/core/renderer/StreamRenderer.ts
import { renderToStream } from "@react-pdf/renderer";
import { Readable, PassThrough } from "stream";
import fs from "fs";

export class StreamRenderer {
  async renderToFile(
    document: React.ReactElement,
    outputPath: string,
  ): Promise<void> {
    const stream = await renderToStream(document);
    const writeStream = fs.createWriteStream(outputPath);

    return new Promise((resolve, reject) => {
      stream.pipe(writeStream);
      writeStream.on("finish", resolve);
      writeStream.on("error", reject);
      stream.on("error", reject);
    });
  }

  async renderToPassThrough(
    document: React.ReactElement,
  ): Promise<PassThrough> {
    const stream = await renderToStream(document);
    const passThrough = new PassThrough();
    stream.pipe(passThrough);
    return passThrough;
  }

  async pipeToResponse(
    document: React.ReactElement,
    res: Response,
    filename: string,
  ): Promise<void> {
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);

    const stream = await renderToStream(document);
    stream.pipe(res);

    return new Promise((resolve, reject) => {
      stream.on("end", resolve);
      stream.on("error", reject);
    });
  }
}
```

#### Job Queue System

```typescript
// src/core/queue/ReportQueue.ts
import Bull, { Queue, Job } from "bull";
import { logger } from "../../utils/logger";

interface ReportJob {
  id: string;
  data: ReportData;
  outputPath: string;
  priority?: number;
}

interface QueueMetrics {
  waiting: number;
  active: number;
  completed: number;
  failed: number;
}

export class ReportQueue {
  private queue: Queue<ReportJob>;
  private processor: (job: Job<ReportJob>) => Promise<void>;

  constructor(
    redisUrl: string,
    processor: (job: Job<ReportJob>) => Promise<void>,
  ) {
    this.queue = new Bull("report-generation", redisUrl, {
      limiter: {
        max: 5, // Max 5 concurrent jobs
        duration: 1000, // Per second
      },
      defaultJobOptions: {
        attempts: 3,
        backoff: {
          type: "exponential",
          delay: 1000,
        },
        removeOnComplete: 100, // Keep last 100 completed
        removeOnFail: 50, // Keep last 50 failed
      },
    });

    this.processor = processor;
    this.setupEventHandlers();
    this.queue.process(5, this.processor); // 5 concurrent workers
  }

  private setupEventHandlers(): void {
    this.queue.on("completed", (job, result) => {
      logger.info(`Job ${job.id} completed`, { jobId: job.id });
    });

    this.queue.on("failed", (job, error) => {
      logger.error(`Job ${job.id} failed`, {
        jobId: job.id,
        error: error.message,
        attempts: job.attemptsMade,
      });
    });

    this.queue.on("stalled", (job) => {
      logger.warn(`Job ${job.id} stalled`, { jobId: job.id });
    });
  }

  async addJob(job: ReportJob): Promise<Job<ReportJob>> {
    return this.queue.add(job, {
      priority: job.priority || 0,
      jobId: job.id,
    });
  }

  async getJobStatus(jobId: string): Promise<JobStatus> {
    const job = await this.queue.getJob(jobId);
    if (!job) return { status: "not_found" };

    const state = await job.getState();
    const progress = job.progress();

    return {
      status: state,
      progress,
      data: state === "completed" ? job.returnvalue : undefined,
      error: state === "failed" ? job.failedReason : undefined,
    };
  }

  async getMetrics(): Promise<QueueMetrics> {
    const [waiting, active, completed, failed] = await Promise.all([
      this.queue.getWaitingCount(),
      this.queue.getActiveCount(),
      this.queue.getCompletedCount(),
      this.queue.getFailedCount(),
    ]);

    return { waiting, active, completed, failed };
  }

  async pause(): Promise<void> {
    await this.queue.pause();
  }

  async resume(): Promise<void> {
    await this.queue.resume();
  }

  async close(): Promise<void> {
    await this.queue.close();
  }
}
```

#### Image Optimization

```typescript
// src/utils/imageOptimizer.ts
import sharp from "sharp";
import fetch from "node-fetch";

interface OptimizationOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  format?: "jpeg" | "png" | "webp";
}

export class ImageOptimizer {
  private cache: Map<string, string> = new Map();

  async optimizeFromUrl(
    url: string,
    options: OptimizationOptions = {},
  ): Promise<string> {
    const cacheKey = `${url}-${JSON.stringify(options)}`;

    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey)!;
    }

    try {
      const response = await fetch(url, { timeout: 10000 });
      if (!response.ok) throw new Error(`Failed to fetch image: ${url}`);

      const buffer = Buffer.from(await response.arrayBuffer());
      const optimized = await this.optimize(buffer, options);

      const dataUri = this.toDataUri(optimized, options.format || "jpeg");
      this.cache.set(cacheKey, dataUri);

      return dataUri;
    } catch (error) {
      logger.warn(`Image optimization failed for ${url}`, { error });
      return url; // Return original URL as fallback
    }
  }

  async optimize(
    buffer: Buffer,
    options: OptimizationOptions = {},
  ): Promise<Buffer> {
    const {
      maxWidth = 800,
      maxHeight = 600,
      quality = 80,
      format = "jpeg",
    } = options;

    let pipeline = sharp(buffer);

    // Resize if necessary
    const metadata = await pipeline.metadata();
    if (metadata.width && metadata.height) {
      if (metadata.width > maxWidth || metadata.height > maxHeight) {
        pipeline = pipeline.resize(maxWidth, maxHeight, {
          fit: "inside",
          withoutEnlargement: true,
        });
      }
    }

    // Convert format and compress
    switch (format) {
      case "jpeg":
        pipeline = pipeline.jpeg({ quality, progressive: true });
        break;
      case "png":
        pipeline = pipeline.png({ compressionLevel: 9 });
        break;
      case "webp":
        pipeline = pipeline.webp({ quality });
        break;
    }

    return pipeline.toBuffer();
  }

  private toDataUri(buffer: Buffer, format: string): string {
    const mimeType =
      format === "png"
        ? "image/png"
        : format === "webp"
          ? "image/webp"
          : "image/jpeg";
    return `data:${mimeType};base64,${buffer.toString("base64")}`;
  }

  clearCache(): void {
    this.cache.clear();
  }
}

// Singleton instance
export const imageOptimizer = new ImageOptimizer();
```

#### Memory Monitoring

```typescript
// src/utils/memoryMonitor.ts

interface MemoryStats {
  heapUsed: number;
  heapTotal: number;
  external: number;
  rss: number;
  heapUsedMB: number;
  heapTotalMB: number;
}

export class MemoryMonitor {
  private threshold: number;
  private checkInterval: NodeJS.Timeout | null = null;

  constructor(thresholdMB: number = 512) {
    this.threshold = thresholdMB * 1024 * 1024;
  }

  getStats(): MemoryStats {
    const usage = process.memoryUsage();
    return {
      ...usage,
      heapUsedMB: Math.round(usage.heapUsed / 1024 / 1024),
      heapTotalMB: Math.round(usage.heapTotal / 1024 / 1024),
    };
  }

  isAboveThreshold(): boolean {
    return this.getStats().heapUsed > this.threshold;
  }

  startMonitoring(intervalMs: number = 5000): void {
    this.checkInterval = setInterval(() => {
      const stats = this.getStats();

      if (stats.heapUsed > this.threshold) {
        logger.warn("Memory threshold exceeded", {
          heapUsedMB: stats.heapUsedMB,
          thresholdMB: this.threshold / 1024 / 1024,
        });

        // Force garbage collection if available
        if (global.gc) {
          global.gc();
          logger.info("Forced garbage collection");
        }
      }

      // Log periodic stats
      logger.debug("Memory stats", stats);
    }, intervalMs);
  }

  stopMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }
}

// Usage wrapper for heavy operations
export async function withMemoryGuard<T>(
  operation: () => Promise<T>,
  maxHeapMB: number = 512,
): Promise<T> {
  const monitor = new MemoryMonitor(maxHeapMB);

  if (monitor.isAboveThreshold()) {
    // Wait for GC before proceeding
    if (global.gc) global.gc();
    await new Promise((resolve) => setTimeout(resolve, 100));

    if (monitor.isAboveThreshold()) {
      throw new Error("Memory threshold exceeded, cannot proceed");
    }
  }

  return operation();
}
```

---

## 3. Styling & Layout Issues

### Challenges

| Challenge           | Impact                                       | Severity |
| ------------------- | -------------------------------------------- | -------- |
| Limited CSS support | React-PDF doesn't support all CSS properties | High     |
| Text overflow       | Long text breaking layout                    | Medium   |
| Table column widths | Auto-sizing tables properly                  | Medium   |
| Vertical alignment  | Center aligning content can be tricky        | Low      |
| Page breaks         | Content splitting awkwardly across pages     | High     |

### Solutions

#### Flexbox-Based Layouts

```tsx
// src/styles/layout.ts
import { StyleSheet } from "@react-pdf/renderer";

export const flexStyles = StyleSheet.create({
  // Row layouts
  row: {
    flexDirection: "row",
  },
  rowCenter: {
    flexDirection: "row",
    alignItems: "center",
  },
  rowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  rowAround: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  rowEnd: {
    flexDirection: "row",
    justifyContent: "flex-end",
  },

  // Column layouts
  column: {
    flexDirection: "column",
  },
  columnCenter: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },

  // Flex items
  flex1: { flex: 1 },
  flex2: { flex: 2 },
  flex3: { flex: 3 },
  flexGrow: { flexGrow: 1 },
  flexShrink: { flexShrink: 1 },

  // Wrapping
  wrap: { flexWrap: "wrap" },
  noWrap: { flexWrap: "nowrap" },
});
```

#### Text Handling

```tsx
// src/components/common/TruncatedText.tsx
import React from "react";
import { Text, View, StyleSheet } from "@react-pdf/renderer";

interface TruncatedTextProps {
  children: string;
  maxLines?: number;
  style?: any;
}

const styles = StyleSheet.create({
  container: {
    overflow: "hidden",
  },
  text: {
    fontSize: 10,
  },
});

// Note: React-PDF doesn't have text-overflow: ellipsis
// We need to calculate and truncate manually
export const TruncatedText: React.FC<TruncatedTextProps> = ({
  children,
  maxLines = 1,
  style,
}) => {
  // Approximate characters that fit (adjust based on font size)
  const charsPerLine = 50;
  const maxChars = charsPerLine * maxLines;

  let displayText = children;
  if (children.length > maxChars) {
    displayText = children.substring(0, maxChars - 3) + "...";
  }

  return (
    <View style={styles.container}>
      <Text style={[styles.text, style]}>{displayText}</Text>
    </View>
  );
};

// Word-wrapped text with hyphenation
export const WrappedText: React.FC<{
  children: string;
  style?: any;
}> = ({ children, style }) => (
  <Text
    style={[{ fontSize: 10 }, style]}
    hyphenationCallback={(word) => {
      // Simple syllable-based hyphenation
      // Use a proper hyphenation library for production
      if (word.length > 12) {
        const mid = Math.floor(word.length / 2);
        return [word.slice(0, mid), word.slice(mid)];
      }
      return [word];
    }}
  >
    {children}
  </Text>
);
```

#### Table Column Management

```tsx
// src/components/tables/ResponsiveTable.tsx
import React from "react";
import { View, Text, StyleSheet } from "@react-pdf/renderer";

interface Column {
  key: string;
  header: string;
  width: string | number;
  minWidth?: number;
  maxWidth?: number;
  align?: "left" | "center" | "right";
  wrap?: boolean;
}

interface ResponsiveTableProps {
  columns: Column[];
  data: Record<string, any>[];
  pageWidth: number;
}

export const ResponsiveTable: React.FC<ResponsiveTableProps> = ({
  columns,
  data,
  pageWidth,
}) => {
  // Calculate actual column widths
  const calculatedColumns = calculateColumnWidths(columns, pageWidth);

  return (
    <View>
      {/* Header */}
      <View style={styles.headerRow}>
        {calculatedColumns.map((col) => (
          <View key={col.key} style={[styles.cell, { width: col.actualWidth }]}>
            <Text
              style={[styles.headerText, { textAlign: col.align || "left" }]}
            >
              {col.header}
            </Text>
          </View>
        ))}
      </View>

      {/* Rows */}
      {data.map((row, rowIndex) => (
        <View key={rowIndex} style={styles.row} wrap={false}>
          {calculatedColumns.map((col) => (
            <View
              key={col.key}
              style={[styles.cell, { width: col.actualWidth }]}
            >
              <Text
                style={[styles.cellText, { textAlign: col.align || "left" }]}
              >
                {formatCellValue(row[col.key], col)}
              </Text>
            </View>
          ))}
        </View>
      ))}
    </View>
  );
};

function calculateColumnWidths(
  columns: Column[],
  pageWidth: number,
): (Column & { actualWidth: number })[] {
  const totalPadding = 40; // Left and right page margins
  const availableWidth = pageWidth - totalPadding;

  return columns.map((col) => {
    let actualWidth: number;

    if (typeof col.width === "string" && col.width.endsWith("%")) {
      const percentage = parseFloat(col.width) / 100;
      actualWidth = availableWidth * percentage;
    } else if (typeof col.width === "number") {
      actualWidth = col.width;
    } else {
      actualWidth = availableWidth / columns.length;
    }

    // Apply min/max constraints
    if (col.minWidth && actualWidth < col.minWidth) {
      actualWidth = col.minWidth;
    }
    if (col.maxWidth && actualWidth > col.maxWidth) {
      actualWidth = col.maxWidth;
    }

    return { ...col, actualWidth };
  });
}

const styles = StyleSheet.create({
  headerRow: {
    flexDirection: "row",
    backgroundColor: "#f3f4f6",
    borderBottomWidth: 1,
    borderBottomColor: "#d1d5db",
  },
  row: {
    flexDirection: "row",
    borderBottomWidth: 0.5,
    borderBottomColor: "#e5e7eb",
  },
  cell: {
    padding: 6,
  },
  headerText: {
    fontSize: 10,
    fontWeight: "bold",
    color: "#374151",
  },
  cellText: {
    fontSize: 9,
    color: "#4b5563",
  },
});
```

#### Page Break Control

```tsx
// src/components/layout/PageBreakControl.tsx
import React from "react";
import { View } from "@react-pdf/renderer";

interface KeepTogetherProps {
  children: React.ReactNode;
  minPresenceAhead?: number;
}

// Keep content together on same page
export const KeepTogether: React.FC<KeepTogetherProps> = ({
  children,
  minPresenceAhead = 50,
}) => (
  <View wrap={false} minPresenceAhead={minPresenceAhead}>
    {children}
  </View>
);

// Force page break before content
export const PageBreakBefore: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => <View break>{children}</View>;

// Orphan-protected paragraph
export const SafeParagraph: React.FC<{
  children: string;
  orphans?: number;
  widows?: number;
}> = ({ children, orphans = 3, widows = 3 }) => (
  <Text orphans={orphans} widows={widows}>
    {children}
  </Text>
);

// Section that avoids breaking unless necessary
export const Section: React.FC<{
  children: React.ReactNode;
  title?: string;
  keepWithNext?: boolean;
}> = ({ children, title, keepWithNext = true }) => (
  <View minPresenceAhead={keepWithNext ? 100 : 0}>
    {title && (
      <Text style={{ fontSize: 14, fontWeight: "bold", marginBottom: 8 }}>
        {title}
      </Text>
    )}
    {children}
  </View>
);
```

---

## 4. Dynamic Content & Templating

### Challenges

| Challenge             | Impact                                            | Severity |
| --------------------- | ------------------------------------------------- | -------- |
| Multiple report types | Different layouts for sales, financial, marketing | High     |
| Conditional sections  | Show/hide based on data availability              | Medium   |
| Template versioning   | Managing different report versions                | Medium   |
| White-labeling        | Different branding per organization               | High     |
| Localization          | Multi-language support                            | Medium   |

### Solutions

#### Template Registry

```typescript
// src/templates/TemplateRegistry.ts
import React from 'react';

interface TemplateDefinition {
  id: string;
  name: string;
  version: string;
  component: React.ComponentType<any>;
  schema: any;  // Validation schema
  defaultOptions: Record<string, any>;
}

class TemplateRegistry {
  private templates: Map<string, TemplateDefinition> = new Map();

  register(template: TemplateDefinition): void {
    const key = `${template.id}@${template.version}`;
    this.templates.set(key, template);

    // Also register as latest
    this.templates.set(template.id, template);
  }

  get(id: string, version?: string): TemplateDefinition | undefined {
    const key = version ? `${id}@${version}` : id;
    return this.templates.get(key);
  }

  list(): TemplateDefinition[] {
    // Return unique templates (not versioned duplicates)
    const seen = new Set<string>();
    const result: TemplateDefinition[] = [];

    for (const template of this.templates.values()) {
      if (!seen.has(template.id)) {
        seen.add(template.id);
        result.push(template);
      }
    }

    return result;
  }

  render(
    templateId: string,
    data: any,
    options?: { version?: string; overrides?: Record<string, any> }
  ): React.ReactElement {
    const template = this.get(templateId, options?.version);

    if (!template) {
      throw new Error(`Template not found: ${templateId}`);
    }

    const Component = template.component;
    const mergedOptions = {
      ...template.defaultOptions,
      ...options?.overrides
    };

    return <Component data={data} options={mergedOptions} />;
  }
}

export const templateRegistry = new TemplateRegistry();

// Register templates
import { StandardReport } from './StandardReport';
import { InvoiceReport } from './InvoiceReport';
import { DiagramReport } from './DiagramReport';

templateRegistry.register({
  id: 'standard',
  name: 'Standard Report',
  version: '2.0',
  component: StandardReport,
  schema: standardReportSchema,
  defaultOptions: {
    pageSize: 'A4',
    orientation: 'portrait'
  }
});

templateRegistry.register({
  id: 'invoice',
  name: 'Invoice',
  version: '1.0',
  component: InvoiceReport,
  schema: invoiceSchema,
  defaultOptions: {
    pageSize: 'A4',
    showTaxDetails: true
  }
});
```

#### Conditional Sections

```tsx
// src/components/layout/ConditionalSection.tsx
import React from "react";
import { View } from "@react-pdf/renderer";

interface ConditionalSectionProps {
  show: boolean;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export const ConditionalSection: React.FC<ConditionalSectionProps> = ({
  show,
  children,
  fallback = null,
}) => {
  if (!show) return fallback ? <>{fallback}</> : null;
  return <>{children}</>;
};

// Configuration-driven section renderer
interface SectionConfig {
  type: string;
  required: boolean;
  condition?: (data: any) => boolean;
  component: React.ComponentType<any>;
}

interface DynamicSectionsProps {
  config: SectionConfig[];
  data: any;
}

export const DynamicSections: React.FC<DynamicSectionsProps> = ({
  config,
  data,
}) => (
  <>
    {config.map((section, index) => {
      const shouldShow =
        section.required ||
        (section.condition ? section.condition(data) : true);

      if (!shouldShow) return null;

      const Component = section.component;
      return <Component key={index} data={data} />;
    })}
  </>
);

// Usage example
const reportConfig: SectionConfig[] = [
  { type: "header", required: true, component: HeaderSection },
  {
    type: "executive-summary",
    required: false,
    condition: (data) => data.includeSummary,
    component: ExecutiveSummary,
  },
  {
    type: "metrics",
    required: false,
    condition: (data) => data.metrics?.length > 0,
    component: MetricsSection,
  },
  { type: "tables", required: true, component: TablesSection },
  {
    type: "diagrams",
    required: false,
    condition: (data) => data.diagrams?.length > 0,
    component: DiagramsSection,
  },
  { type: "footer", required: true, component: FooterSection },
];
```

#### Branding System

```typescript
// src/styles/branding.ts
import { StyleSheet, Font } from "@react-pdf/renderer";

interface BrandConfig {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    text: string;
    background: string;
    border: string;
  };
  logo: string;
  fonts: {
    primary: string;
    secondary?: string;
  };
  customStyles?: Record<string, any>;
}

const brandConfigs: Record<string, BrandConfig> = {
  default: {
    id: "default",
    name: "Default",
    colors: {
      primary: "#2563eb",
      secondary: "#64748b",
      accent: "#8b5cf6",
      text: "#1e293b",
      background: "#ffffff",
      border: "#e2e8f0",
    },
    logo: "/assets/default-logo.png",
    fonts: {
      primary: "Inter",
    },
  },
  acme: {
    id: "acme",
    name: "ACME Corp",
    colors: {
      primary: "#dc2626",
      secondary: "#78716c",
      accent: "#f59e0b",
      text: "#292524",
      background: "#fafaf9",
      border: "#d6d3d1",
    },
    logo: "/assets/acme-logo.png",
    fonts: {
      primary: "Roboto",
      secondary: "Georgia",
    },
  },
};

export function getBrandConfig(brandId: string): BrandConfig {
  return brandConfigs[brandId] || brandConfigs.default;
}

export function createBrandedStyles(brand: BrandConfig) {
  return StyleSheet.create({
    page: {
      backgroundColor: brand.colors.background,
      fontFamily: brand.fonts.primary,
      color: brand.colors.text,
    },
    header: {
      backgroundColor: brand.colors.primary,
      color: "#ffffff",
      padding: 20,
    },
    primaryText: {
      color: brand.colors.primary,
    },
    secondaryText: {
      color: brand.colors.secondary,
    },
    border: {
      borderColor: brand.colors.border,
      borderWidth: 1,
    },
    accent: {
      backgroundColor: brand.colors.accent,
    },
  });
}

// Brand context for components
export const BrandContext = React.createContext<BrandConfig>(
  brandConfigs.default,
);

export const useBrand = () => React.useContext(BrandContext);
```

#### Internationalization

```typescript
// src/i18n/translations.ts

interface TranslationSet {
  reportTitle: string;
  generatedOn: string;
  page: string;
  of: string;
  total: string;
  subtotal: string;
  tax: string;
  grandTotal: string;
  // ... more keys
}

const translations: Record<string, TranslationSet> = {
  en: {
    reportTitle: "Report",
    generatedOn: "Generated on",
    page: "Page",
    of: "of",
    total: "Total",
    subtotal: "Subtotal",
    tax: "Tax",
    grandTotal: "Grand Total",
  },
  es: {
    reportTitle: "Informe",
    generatedOn: "Generado el",
    page: "Página",
    of: "de",
    total: "Total",
    subtotal: "Subtotal",
    tax: "Impuesto",
    grandTotal: "Total General",
  },
  fr: {
    reportTitle: "Rapport",
    generatedOn: "Généré le",
    page: "Page",
    of: "sur",
    total: "Total",
    subtotal: "Sous-total",
    tax: "Taxe",
    grandTotal: "Total Général",
  },
  de: {
    reportTitle: "Bericht",
    generatedOn: "Erstellt am",
    page: "Seite",
    of: "von",
    total: "Gesamt",
    subtotal: "Zwischensumme",
    tax: "Steuer",
    grandTotal: "Gesamtsumme",
  },
};

export function getTranslations(locale: string): TranslationSet {
  return translations[locale] || translations.en;
}

export function t(key: keyof TranslationSet, locale: string = "en"): string {
  const set = getTranslations(locale);
  return set[key] || key;
}

// Date/number formatting per locale
export function formatDate(date: Date | string, locale: string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat(locale, {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(d);
}

export function formatCurrency(
  amount: number,
  locale: string,
  currency: string = "USD",
): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
  }).format(amount);
}
```

---

## 5. Error Handling & Debugging

### Challenges

| Challenge              | Impact                                | Severity |
| ---------------------- | ------------------------------------- | -------- |
| Silent failures        | PDF generates but content is wrong    | High     |
| Cryptic error messages | React-PDF errors can be unclear       | Medium   |
| No visual debugging    | Can't inspect like browser DevTools   | High     |
| Font loading failures  | Missing fonts causing fallback issues | Medium   |
| Image loading timeouts | External images failing to load       | Medium   |

### Solutions

#### Custom Error Classes

```typescript
// src/core/errors/CustomErrors.ts

export class ReportGenerationError extends Error {
  public readonly code: string;
  public readonly context: Record<string, any>;
  public readonly timestamp: string;
  public readonly recoverable: boolean;

  constructor(
    message: string,
    code: string,
    context: Record<string, any> = {},
    recoverable: boolean = false,
  ) {
    super(message);
    this.name = "ReportGenerationError";
    this.code = code;
    this.context = context;
    this.timestamp = new Date().toISOString();
    this.recoverable = recoverable;

    Error.captureStackTrace(this, ReportGenerationError);
  }

  toJSON() {
    return {
      name: this.name,
      message: this.message,
      code: this.code,
      context: this.context,
      timestamp: this.timestamp,
      stack: this.stack,
    };
  }
}

export class ValidationError extends ReportGenerationError {
  public readonly details: Array<{ path: string; message: string }>;

  constructor(
    message: string,
    details: Array<{ path: string; message: string }>,
  ) {
    super(message, "VALIDATION_ERROR", { details }, true);
    this.name = "ValidationError";
    this.details = details;
  }
}

export class RenderError extends ReportGenerationError {
  constructor(message: string, context: Record<string, any> = {}) {
    super(message, "RENDER_ERROR", context, false);
    this.name = "RenderError";
  }
}

export class ResourceError extends ReportGenerationError {
  public readonly resourceType: "font" | "image" | "data";
  public readonly resourceUrl: string;

  constructor(
    resourceType: "font" | "image" | "data",
    resourceUrl: string,
    originalError?: Error,
  ) {
    super(
      `Failed to load ${resourceType}: ${resourceUrl}`,
      "RESOURCE_ERROR",
      { resourceType, resourceUrl, originalError: originalError?.message },
      true,
    );
    this.name = "ResourceError";
    this.resourceType = resourceType;
    this.resourceUrl = resourceUrl;
  }
}

export class TimeoutError extends ReportGenerationError {
  constructor(operation: string, timeoutMs: number) {
    super(
      `Operation timed out: ${operation} (${timeoutMs}ms)`,
      "TIMEOUT_ERROR",
      { operation, timeoutMs },
      true,
    );
    this.name = "TimeoutError";
  }
}
```

#### Comprehensive Error Handler

```typescript
// src/utils/errorHandler.ts
import { logger } from "./logger";
import {
  ReportGenerationError,
  ValidationError,
  RenderError,
  ResourceError,
} from "../core/errors/CustomErrors";

interface ErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
    requestId?: string;
  };
}

export function handleError(error: Error, requestId?: string): ErrorResponse {
  // Log the error
  logger.error("Report generation error", {
    requestId,
    error: error.message,
    stack: error.stack,
    ...(error instanceof ReportGenerationError ? error.context : {}),
  });

  // Format response based on error type
  if (error instanceof ValidationError) {
    return {
      success: false,
      error: {
        code: error.code,
        message: "Invalid request data",
        details: error.details,
        requestId,
      },
    };
  }

  if (error instanceof ResourceError) {
    return {
      success: false,
      error: {
        code: error.code,
        message: `Failed to load ${error.resourceType}`,
        details: { url: error.resourceUrl },
        requestId,
      },
    };
  }

  if (error instanceof RenderError) {
    return {
      success: false,
      error: {
        code: error.code,
        message: "PDF rendering failed",
        requestId,
      },
    };
  }

  // Generic error
  return {
    success: false,
    error: {
      code: "INTERNAL_ERROR",
      message: "An unexpected error occurred",
      requestId,
    },
  };
}

// Wrapper for async operations with error handling
export async function safeExecute<T>(
  operation: () => Promise<T>,
  context: { operation: string; requestId?: string },
): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    logger.error(`Operation failed: ${context.operation}`, {
      requestId: context.requestId,
      error: error instanceof Error ? error.message : String(error),
    });
    throw error;
  }
}
```

#### Resource Validation

```typescript
// src/utils/resourceValidator.ts
import fetch from "node-fetch";
import { ResourceError, TimeoutError } from "../core/errors/CustomErrors";

interface ResourceCheckResult {
  valid: boolean;
  url: string;
  error?: string;
}

export async function validateResources(
  data: ReportData,
): Promise<ResourceCheckResult[]> {
  const resources: Array<{ url: string; type: "image" | "font" }> = [];

  // Collect all resource URLs
  if (data.company?.logo) {
    resources.push({ url: data.company.logo, type: "image" });
  }

  if (data.images) {
    data.images.forEach((img) => {
      resources.push({ url: img.url, type: "image" });
    });
  }

  // Check all resources in parallel
  const results = await Promise.all(
    resources.map((r) => checkResource(r.url, r.type)),
  );

  return results;
}

async function checkResource(
  url: string,
  type: "image" | "font",
  timeoutMs: number = 5000,
): Promise<ResourceCheckResult> {
  // Skip data URIs
  if (url.startsWith("data:")) {
    return { valid: true, url };
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    const response = await fetch(url, {
      method: "HEAD",
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      return {
        valid: false,
        url,
        error: `HTTP ${response.status}: ${response.statusText}`,
      };
    }

    // Verify content type for images
    if (type === "image") {
      const contentType = response.headers.get("content-type");
      if (!contentType?.startsWith("image/")) {
        return {
          valid: false,
          url,
          error: `Invalid content type: ${contentType}`,
        };
      }
    }

    return { valid: true, url };
  } catch (error) {
    return {
      valid: false,
      url,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Validate with fallback
export async function loadResourceWithFallback(
  url: string,
  fallbackUrl: string,
  type: "image" | "font",
): Promise<string> {
  const result = await checkResource(url, type);

  if (result.valid) {
    return url;
  }

  logger.warn(`Resource failed, using fallback`, {
    originalUrl: url,
    fallbackUrl,
    error: result.error,
  });

  return fallbackUrl;
}
```

#### Debug Mode

```typescript
// src/config/debug.ts

export const DEBUG_CONFIG = {
  enabled: process.env.NODE_ENV === 'development',
  logLevel: process.env.LOG_LEVEL || 'info',
  showBorders: process.env.PDF_DEBUG_BORDERS === 'true',
  dumpData: process.env.PDF_DUMP_DATA === 'true',
  saveIntermediates: process.env.PDF_SAVE_INTERMEDIATES === 'true'
};

// Debug wrapper for components
export function withDebug<P extends object>(
  Component: React.ComponentType<P>,
  name: string
): React.ComponentType<P> {
  if (!DEBUG_CONFIG.enabled) {
    return Component;
  }

  return (props: P) => {
    if (DEBUG_CONFIG.dumpData) {
      console.log(`[DEBUG] ${name} props:`, JSON.stringify(props, null, 2));
    }

    return (
      <View style={DEBUG_CONFIG.showBorders ? debugBorder : {}}>
        <Component {...props} />
      </View>
    );
  };
}

const debugBorder = {
  borderWidth: 1,
  borderColor: 'red',
  borderStyle: 'dashed'
};
```

---

## 6. Testing & Quality Assurance

### Solutions

#### Unit Tests

```typescript
// tests/unit/transformers/DataNormalizer.test.ts
import { describe, it, expect } from "vitest";
import { DataNormalizer } from "../../../src/transformers/content/DataNormalizer";

describe("DataNormalizer", () => {
  const normalizer = new DataNormalizer({
    numberLocale: "en-US",
    defaultCurrency: "USD",
    timezone: "UTC",
  });

  describe("normalize", () => {
    it("should normalize client data correctly", () => {
      const rawData = {
        client: {
          id: 123,
          name: "  Test Client  ",
          email: "TEST@EXAMPLE.COM",
        },
        company: { name: "Test Co" },
      };

      const result = normalizer.normalize(rawData);

      expect(result.client.id).toBe("123");
      expect(result.client.name).toBe("Test Client");
      expect(result.client.email).toBe("test@example.com");
    });

    it("should handle missing optional fields", () => {
      const minimalData = {
        client: { id: "1", name: "Client", email: "a@b.com" },
        company: { name: "Co" },
      };

      expect(() => normalizer.normalize(minimalData)).not.toThrow();
    });

    it("should format currency values", () => {
      const data = {
        client: { id: "1", name: "Test", email: "a@b.com" },
        company: { name: "Co" },
        tables: [
          {
            columns: [{ key: "amount", type: "currency" }],
            rows: [{ amount: 1234.56 }],
          },
        ],
      };

      const result = normalizer.normalize(data);
      expect(result.tables[0].rows[0].amount).toBe("$1,234.56");
    });
  });
});
```

#### Integration Tests

```typescript
// tests/integration/ReportGeneration.test.ts
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { ReportOrchestrator } from "../../src/core/orchestrator/ReportOrchestrator";
import fs from "fs";
import path from "path";

describe("Report Generation Integration", () => {
  const orchestrator = new ReportOrchestrator();
  const outputDir = path.join(__dirname, "../output");

  beforeAll(() => {
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
  });

  afterAll(() => {
    // Cleanup test files
    fs.readdirSync(outputDir).forEach((file) => {
      fs.unlinkSync(path.join(outputDir, file));
    });
  });

  it("should generate valid PDF file", async () => {
    const outputPath = path.join(outputDir, "test-report.pdf");

    await orchestrator.generateReport({
      template: "standard",
      data: getSampleReportData(),
      output: { format: "file", path: outputPath },
    });

    expect(fs.existsSync(outputPath)).toBe(true);

    const stats = fs.statSync(outputPath);
    expect(stats.size).toBeGreaterThan(1000);
  });

  it("should generate PDF buffer", async () => {
    const result = await orchestrator.generateReport({
      template: "standard",
      data: getSampleReportData(),
      output: { format: "buffer" },
    });

    expect(result.buffer).toBeInstanceOf(Buffer);
    expect(result.buffer.length).toBeGreaterThan(1000);

    // Verify PDF header
    const header = result.buffer.slice(0, 5).toString();
    expect(header).toBe("%PDF-");
  });

  it("should handle large tables without memory issues", async () => {
    const largeData = getSampleReportData();
    largeData.tables = [
      {
        columns: [
          { key: "id", header: "ID", width: "20%" },
          { key: "name", header: "Name", width: "40%" },
          { key: "value", header: "Value", width: "40%" },
        ],
        rows: Array.from({ length: 1000 }, (_, i) => ({
          id: String(i + 1),
          name: `Item ${i + 1}`,
          value: (Math.random() * 1000).toFixed(2),
        })),
      },
    ];

    const startMemory = process.memoryUsage().heapUsed;

    await orchestrator.generateReport({
      template: "standard",
      data: largeData,
      output: { format: "buffer" },
    });

    const endMemory = process.memoryUsage().heapUsed;
    const memoryIncrease = (endMemory - startMemory) / 1024 / 1024;

    // Should not increase memory by more than 100MB
    expect(memoryIncrease).toBeLessThan(100);
  }, 30000); // 30 second timeout
});

function getSampleReportData() {
  return {
    company: {
      name: "Test Company",
      logo: "data:image/png;base64,...", // Use data URI for testing
    },
    client: {
      id: "TEST-001",
      name: "Test Client",
      email: "client@test.com",
    },
    reportTitle: "Test Report",
    generatedDate: new Date().toISOString(),
    tables: [
      {
        columns: [
          { key: "item", header: "Item", width: "50%" },
          { key: "amount", header: "Amount", width: "50%", align: "right" },
        ],
        rows: [
          { item: "Item 1", amount: "$100.00" },
          { item: "Item 2", amount: "$200.00" },
        ],
      },
    ],
  };
}
```

#### Performance Benchmarks

```typescript
// tests/performance/benchmark.ts
import { performance } from "perf_hooks";
import { ReportOrchestrator } from "../../src/core/orchestrator/ReportOrchestrator";

interface BenchmarkResult {
  rows: number;
  duration: number;
  memoryBefore: number;
  memoryAfter: number;
  memoryDelta: number;
  pdfSize: number;
}

async function runBenchmark(): Promise<void> {
  const orchestrator = new ReportOrchestrator();
  const sizes = [10, 50, 100, 500, 1000, 5000];
  const results: BenchmarkResult[] = [];

  for (const rows of sizes) {
    // Force GC before test
    if (global.gc) global.gc();

    const memoryBefore = process.memoryUsage().heapUsed;
    const start = performance.now();

    const data = generateTestData(rows);
    const result = await orchestrator.generateReport({
      template: "standard",
      data,
      output: { format: "buffer" },
    });

    const duration = performance.now() - start;
    const memoryAfter = process.memoryUsage().heapUsed;

    results.push({
      rows,
      duration: Math.round(duration),
      memoryBefore: Math.round(memoryBefore / 1024 / 1024),
      memoryAfter: Math.round(memoryAfter / 1024 / 1024),
      memoryDelta: Math.round((memoryAfter - memoryBefore) / 1024 / 1024),
      pdfSize: Math.round(result.buffer.length / 1024),
    });

    console.log(`Completed: ${rows} rows in ${Math.round(duration)}ms`);
  }

  console.log("\n=== Benchmark Results ===\n");
  console.table(results);

  // Analyze scaling
  console.log("\n=== Performance Analysis ===\n");
  for (let i = 1; i < results.length; i++) {
    const prev = results[i - 1];
    const curr = results[i];
    const rowsRatio = curr.rows / prev.rows;
    const timeRatio = curr.duration / prev.duration;

    console.log(
      `${prev.rows} -> ${curr.rows} rows: ` +
        `${rowsRatio.toFixed(1)}x data, ${timeRatio.toFixed(1)}x time`,
    );
  }
}

function generateTestData(rows: number) {
  return {
    company: { name: "Benchmark Corp" },
    client: { id: "BENCH", name: "Benchmark", email: "bench@test.com" },
    reportTitle: "Performance Benchmark",
    tables: [
      {
        columns: [
          { key: "id", header: "ID", width: "10%" },
          { key: "name", header: "Name", width: "30%" },
          { key: "description", header: "Description", width: "40%" },
          { key: "amount", header: "Amount", width: "20%", align: "right" },
        ],
        rows: Array.from({ length: rows }, (_, i) => ({
          id: String(i + 1).padStart(5, "0"),
          name: `Item ${i + 1}`,
          description: `This is a description for item number ${i + 1} with some additional text`,
          amount: `$${(Math.random() * 10000).toFixed(2)}`,
        })),
      },
    ],
  };
}

runBenchmark().catch(console.error);
```

---

## 7. Deployment & Infrastructure

### Solutions

#### Dockerfile

```dockerfile
# Dockerfile
FROM node:18-alpine AS builder

# Install build dependencies
RUN apk add --no-cache \
    python3 \
    make \
    g++ \
    cairo-dev \
    pango-dev \
    jpeg-dev \
    giflib-dev \
    pixman-dev

WORKDIR /app

# Install dependencies
COPY package*.json ./
RUN npm ci

# Build
COPY . .
RUN npm run build

# Production image
FROM node:18-alpine AS production

# Install runtime dependencies for canvas/fonts
RUN apk add --no-cache \
    cairo \
    pango \
    jpeg \
    giflib \
    pixman \
    fontconfig \
    ttf-dejavu \
    && fc-cache -f

# Create non-root user
RUN addgroup -g 1001 -S nodejs && \
    adduser -S nodejs -u 1001

WORKDIR /app

# Copy built application
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./

# Copy fonts
COPY --chown=nodejs:nodejs fonts/ /usr/share/fonts/custom/
RUN fc-cache -f

# Create directories
RUN mkdir -p /app/temp /app/logs && \
    chown -R nodejs:nodejs /app

USER nodejs

ENV NODE_ENV=production
ENV PORT=3000

EXPOSE 3000

HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD wget --no-verbose --tries=1 --spider http://localhost:3000/api/health || exit 1

CMD ["node", "dist/index.js"]
```

#### Docker Compose

```yaml
# docker-compose.yml
version: "3.8"

services:
  report-generator:
    build:
      context: .
      dockerfile: Dockerfile
```
