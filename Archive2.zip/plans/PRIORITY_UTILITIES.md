# Priority Utilities Design

> Detailed design for the 5 essential utilities identified for the PDF generation pipeline.

---

## Overview

| Utility                  | Priority | Complexity | Integration Point    |
| ------------------------ | -------- | ---------- | -------------------- |
| **Table of Contents**    | High     | Medium     | Document composition |
| **Bookmarks / Outline**  | High     | Medium     | Post-processing      |
| **Print-Ready Output**   | Medium   | Low        | Page configuration   |
| **Template Preview**     | Medium   | Medium     | API endpoint         |
| **Developer Experience** | High     | Low        | Tooling layer        |

---

## 1. Table of Contents (TOC) Generation

### Purpose

Automatically generate a navigable table of contents from document headings with page numbers and clickable links.

### Architecture

```
Document Render (Pass 1)
        │
        ▼
┌─────────────────────┐
│  Heading Collector  │ ──► Collect all headings with IDs
└─────────────────────┘
        │
        ▼
┌─────────────────────┐
│  Page Number Calc   │ ──► Calculate page numbers per heading
└─────────────────────┘
        │
        ▼
┌─────────────────────┐
│    TOC Generator    │ ──► Generate TOC component
└─────────────────────┘
        │
        ▼
Document Render (Pass 2) ──► Insert TOC, render final PDF
```

### Implementation

```typescript
// src/components/documents/TOC/types.ts

export interface TOCEntry {
  id: string;
  title: string;
  level: 1 | 2 | 3 | 4;
  pageNumber?: number;
  children?: TOCEntry[];
}

export interface TOCOptions {
  title?: string;
  maxDepth?: number; // Max heading level to include
  showPageNumbers?: boolean;
  dotLeader?: boolean; // Show dots between title and page
  indentSize?: number; // Indentation per level
  styles?: {
    container?: Style;
    title?: Style;
    entry?: Style;
    pageNumber?: Style;
    dotLeader?: Style;
  };
}
```

```typescript
// src/components/documents/TOC/TOCContext.tsx

import React, { createContext, useContext, useRef } from 'react';

interface TOCContextValue {
  entries: TOCEntry[];
  registerHeading: (entry: Omit<TOCEntry, 'pageNumber'>) => void;
  setPageNumber: (id: string, pageNumber: number) => void;
}

const TOCContext = createContext<TOCContextValue | null>(null);

export const TOCProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const entriesRef = useRef<TOCEntry[]>([]);

  const registerHeading = (entry: Omit<TOCEntry, 'pageNumber'>) => {
    // Avoid duplicates
    if (!entriesRef.current.find(e => e.id === entry.id)) {
      entriesRef.current.push({ ...entry, pageNumber: undefined });
    }
  };

  const setPageNumber = (id: string, pageNumber: number) => {
    const entry = entriesRef.current.find(e => e.id === id);
    if (entry) {
      entry.pageNumber = pageNumber;
    }
  };

  return (
    <TOCContext.Provider value={{
      entries: entriesRef.current,
      registerHeading,
      setPageNumber
    }}>
      {children}
    </TOCContext.Provider>
  );
};

export const useTOC = () => {
  const context = useContext(TOCContext);
  if (!context) throw new Error('useTOC must be used within TOCProvider');
  return context;
};
```

```typescript
// src/components/documents/TOC/TrackedHeading.tsx

import React from 'react';
import { Text, View } from '@react-pdf/renderer';
import { useTOC } from './TOCContext';

interface TrackedHeadingProps {
  level: 1 | 2 | 3 | 4;
  id: string;
  children: string;
  style?: Style;
}

export const TrackedHeading: React.FC<TrackedHeadingProps> = ({
  level,
  id,
  children,
  style
}) => {
  const { registerHeading } = useTOC();

  // Register on mount
  React.useEffect(() => {
    registerHeading({ id, title: children, level });
  }, [id, children, level]);

  const headingStyles = {
    1: { fontSize: 24, fontWeight: 'bold', marginTop: 20, marginBottom: 12 },
    2: { fontSize: 18, fontWeight: 'bold', marginTop: 16, marginBottom: 8 },
    3: { fontSize: 14, fontWeight: 'bold', marginTop: 12, marginBottom: 6 },
    4: { fontSize: 12, fontWeight: 'bold', marginTop: 8, marginBottom: 4 },
  };

  return (
    <View id={id} bookmark={children}>
      <Text style={[headingStyles[level], style]}>{children}</Text>
    </View>
  );
};

// Convenience exports
export const H1 = (props: Omit<TrackedHeadingProps, 'level'>) =>
  <TrackedHeading level={1} {...props} />;
export const H2 = (props: Omit<TrackedHeadingProps, 'level'>) =>
  <TrackedHeading level={2} {...props} />;
export const H3 = (props: Omit<TrackedHeadingProps, 'level'>) =>
  <TrackedHeading level={3} {...props} />;
export const H4 = (props: Omit<TrackedHeadingProps, 'level'>) =>
  <TrackedHeading level={4} {...props} />;
```

```typescript
// src/components/documents/TOC/TableOfContents.tsx

import React from 'react';
import { View, Text, Link, StyleSheet } from '@react-pdf/renderer';
import { TOCEntry, TOCOptions } from './types';

const defaultStyles = StyleSheet.create({
  container: {
    marginBottom: 30,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  entryRow: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  entryText: {
    fontSize: 11,
    flex: 1,
  },
  dotLeader: {
    flex: 1,
    borderBottomWidth: 1,
    borderBottomStyle: 'dotted',
    borderBottomColor: '#cccccc',
    marginHorizontal: 4,
    marginBottom: 3,
  },
  pageNumber: {
    fontSize: 11,
    minWidth: 20,
    textAlign: 'right',
  },
});

export const TableOfContents: React.FC<{
  entries: TOCEntry[];
  options?: TOCOptions;
}> = ({ entries, options = {} }) => {
  const {
    title = 'Table of Contents',
    maxDepth = 3,
    showPageNumbers = true,
    dotLeader = true,
    indentSize = 15,
    styles: customStyles = {},
  } = options;

  const filteredEntries = entries.filter(e => e.level <= maxDepth);

  return (
    <View style={[defaultStyles.container, customStyles.container]} wrap={false}>
      {title && (
        <Text style={[defaultStyles.title, customStyles.title]}>{title}</Text>
      )}

      {filteredEntries.map((entry) => (
        <View
          key={entry.id}
          style={[
            defaultStyles.entryRow,
            { marginLeft: (entry.level - 1) * indentSize }
          ]}
        >
          <Link src={`#${entry.id}`} style={{ textDecoration: 'none', flex: 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
              <Text style={[defaultStyles.entryText, customStyles.entry]}>
                {entry.title}
              </Text>

              {dotLeader && showPageNumbers && (
                <View style={[defaultStyles.dotLeader, customStyles.dotLeader]} />
              )}

              {showPageNumbers && entry.pageNumber && (
                <Text style={[defaultStyles.pageNumber, customStyles.pageNumber]}>
                  {entry.pageNumber}
                </Text>
              )}
            </View>
          </Link>
        </View>
      ))}
    </View>
  );
};
```

### Usage Example

```tsx
// In your document
import { TOCProvider, TableOfContents, H1, H2, H3 } from "./TOC";

const MyDocument = ({ data }) => (
  <Document>
    <TOCProvider>
      {/* TOC Page */}
      <Page size="A4">
        <TableOfContents
          entries={tocEntries}
          options={{
            title: "Contents",
            maxDepth: 2,
            dotLeader: true,
          }}
        />
      </Page>

      {/* Content Pages */}
      <Page size="A4">
        <H1 id="intro">Introduction</H1>
        <Text>Content...</Text>

        <H2 id="overview">Overview</H2>
        <Text>More content...</Text>

        <H3 id="details">Details</H3>
        <Text>Even more content...</Text>
      </Page>
    </TOCProvider>
  </Document>
);
```

---

## 2. Bookmarks / Document Outline

### Purpose

Create PDF bookmarks (outline) that appear in the sidebar of PDF readers for quick navigation.

### Architecture

React-PDF has built-in bookmark support via the `bookmark` prop. We need a utility layer to manage hierarchical bookmarks.

```
Document Structure
        │
        ▼
┌─────────────────────┐
│  Bookmark Registry  │ ──► Collect bookmarks hierarchically
└─────────────────────┘
        │
        ▼
┌─────────────────────┐
│   Outline Builder   │ ──► Build nested outline structure
└─────────────────────┘
        │
        ▼
PDF Generation ──► Bookmarks embedded in PDF
```

### Implementation

```typescript
// src/utils/bookmarks/BookmarkManager.ts

export interface Bookmark {
  title: string;
  id: string;
  level: number;
  expanded?: boolean;
  children?: Bookmark[];
}

export class BookmarkManager {
  private bookmarks: Bookmark[] = [];
  private stack: Bookmark[] = [];

  add(title: string, id: string, level: number): void {
    const bookmark: Bookmark = { title, id, level, children: [] };

    if (level === 1) {
      // Top level
      this.bookmarks.push(bookmark);
      this.stack = [bookmark];
    } else {
      // Find parent
      while (
        this.stack.length > 0 &&
        this.stack[this.stack.length - 1].level >= level
      ) {
        this.stack.pop();
      }

      if (this.stack.length > 0) {
        const parent = this.stack[this.stack.length - 1];
        parent.children = parent.children || [];
        parent.children.push(bookmark);
      } else {
        this.bookmarks.push(bookmark);
      }

      this.stack.push(bookmark);
    }
  }

  getOutline(): Bookmark[] {
    return this.bookmarks;
  }

  clear(): void {
    this.bookmarks = [];
    this.stack = [];
  }
}

// Singleton instance
export const bookmarkManager = new BookmarkManager();
```

```typescript
// src/components/common/BookmarkedSection.tsx

import React from 'react';
import { View, Text } from '@react-pdf/renderer';

interface BookmarkedSectionProps {
  title: string;
  id?: string;
  level?: number;
  fit?: boolean;
  expanded?: boolean;
  children: React.ReactNode;
}

export const BookmarkedSection: React.FC<BookmarkedSectionProps> = ({
  title,
  id,
  level = 1,
  fit = false,
  expanded = true,
  children
}) => {
  // Create bookmark object for react-pdf
  const bookmarkProps = {
    title,
    fit,
    expanded,
  };

  return (
    <View id={id} bookmark={bookmarkProps}>
      {children}
    </View>
  );
};

// Convenience components for nested bookmarks
export const Chapter: React.FC<Omit<BookmarkedSectionProps, 'level'>> = (props) => (
  <BookmarkedSection level={1} {...props} />
);

export const Section: React.FC<Omit<BookmarkedSectionProps, 'level'>> = (props) => (
  <BookmarkedSection level={2} {...props} />
);

export const Subsection: React.FC<Omit<BookmarkedSectionProps, 'level'>> = (props) => (
  <BookmarkedSection level={3} {...props} />
);
```

### Usage Example

```tsx
import { Chapter, Section, Subsection } from "./BookmarkedSection";

const Report = () => (
  <Document>
    <Page>
      <Chapter title="Executive Summary" id="exec-summary">
        <Text>Summary content...</Text>
      </Chapter>

      <Chapter title="Analysis" id="analysis">
        <Section title="Market Overview" id="market">
          <Text>Market content...</Text>

          <Subsection title="Regional Breakdown" id="regional">
            <Text>Regional data...</Text>
          </Subsection>
        </Section>

        <Section title="Competitive Analysis" id="competitive">
          <Text>Competitive content...</Text>
        </Section>
      </Chapter>
    </Page>
  </Document>
);
```

---

## 3. Print-Ready Output

### Purpose

Generate PDFs suitable for professional printing with proper bleed, crop marks, and color specifications.

### Configuration

```typescript
// src/config/print.ts

export interface PrintConfig {
  // Bleed settings
  bleed: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };

  // Crop marks
  cropMarks: {
    enabled: boolean;
    length: number; // Length of crop mark lines
    offset: number; // Distance from page edge
    strokeWidth: number;
  };

  // Registration marks
  registrationMarks: boolean;

  // Color bars
  colorBars: boolean;

  // Resolution
  dpi: 72 | 150 | 300;

  // Color profile
  colorProfile: "RGB" | "CMYK";
}

export const defaultPrintConfig: PrintConfig = {
  bleed: { top: 3, right: 3, bottom: 3, left: 3 }, // in mm
  cropMarks: {
    enabled: true,
    length: 10,
    offset: 3,
    strokeWidth: 0.25,
  },
  registrationMarks: false,
  colorBars: false,
  dpi: 300,
  colorProfile: "RGB", // CMYK requires post-processing
};
```

### Implementation

```typescript
// src/components/layout/PrintReadyPage.tsx

import React from 'react';
import { Page, View, Svg, Line, Circle, StyleSheet } from '@react-pdf/renderer';
import { PrintConfig, defaultPrintConfig } from '../../config/print';

const mmToPt = (mm: number) => mm * 2.834645669;

interface PrintReadyPageProps {
  size?: 'A4' | 'LETTER' | { width: number; height: number };
  orientation?: 'portrait' | 'landscape';
  config?: Partial<PrintConfig>;
  children: React.ReactNode;
}

export const PrintReadyPage: React.FC<PrintReadyPageProps> = ({
  size = 'A4',
  orientation = 'portrait',
  config: configOverrides = {},
  children
}) => {
  const config = { ...defaultPrintConfig, ...configOverrides };

  // Calculate page dimensions
  let baseWidth: number, baseHeight: number;
  if (typeof size === 'string') {
    const sizes = {
      'A4': { width: 595, height: 842 },
      'LETTER': { width: 612, height: 792 },
    };
    baseWidth = sizes[size].width;
    baseHeight = sizes[size].height;
  } else {
    baseWidth = size.width;
    baseHeight = size.height;
  }

  if (orientation === 'landscape') {
    [baseWidth, baseHeight] = [baseHeight, baseWidth];
  }

  // Add bleed
  const bleed = {
    top: mmToPt(config.bleed.top),
    right: mmToPt(config.bleed.right),
    bottom: mmToPt(config.bleed.bottom),
    left: mmToPt(config.bleed.left),
  };

  const totalWidth = baseWidth + bleed.left + bleed.right;
  const totalHeight = baseHeight + bleed.top + bleed.bottom;

  return (
    <Page
      size={{ width: totalWidth, height: totalHeight }}
      style={styles.page}
    >
      {/* Crop Marks */}
      {config.cropMarks.enabled && (
        <CropMarks
          width={totalWidth}
          height={totalHeight}
          bleed={bleed}
          config={config.cropMarks}
        />
      )}

      {/* Registration Marks */}
      {config.registrationMarks && (
        <RegistrationMarks
          width={totalWidth}
          height={totalHeight}
          bleed={bleed}
        />
      )}

      {/* Content Area (within bleed) */}
      <View
        style={{
          position: 'absolute',
          top: bleed.top,
          left: bleed.left,
          width: baseWidth,
          height: baseHeight,
        }}
      >
        {children}
      </View>
    </Page>
  );
};

// Crop Marks Component
const CropMarks: React.FC<{
  width: number;
  height: number;
  bleed: { top: number; right: number; bottom: number; left: number };
  config: PrintConfig['cropMarks'];
}> = ({ width, height, bleed, config }) => {
  const markLength = mmToPt(config.length);
  const offset = mmToPt(config.offset);

  return (
    <Svg style={{ position: 'absolute', top: 0, left: 0, width, height }}>
      {/* Top-Left Corner */}
      <Line
        x1={bleed.left - offset - markLength}
        y1={bleed.top}
        x2={bleed.left - offset}
        y2={bleed.top}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />
      <Line
        x1={bleed.left}
        y1={bleed.top - offset - markLength}
        x2={bleed.left}
        y2={bleed.top - offset}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />

      {/* Top-Right Corner */}
      <Line
        x1={width - bleed.right + offset}
        y1={bleed.top}
        x2={width - bleed.right + offset + markLength}
        y2={bleed.top}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />
      <Line
        x1={width - bleed.right}
        y1={bleed.top - offset - markLength}
        x2={width - bleed.right}
        y2={bleed.top - offset}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />

      {/* Bottom-Left Corner */}
      <Line
        x1={bleed.left - offset - markLength}
        y1={height - bleed.bottom}
        x2={bleed.left - offset}
        y2={height - bleed.bottom}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />
      <Line
        x1={bleed.left}
        y1={height - bleed.bottom + offset}
        x2={bleed.left}
        y2={height - bleed.bottom + offset + markLength}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />

      {/* Bottom-Right Corner */}
      <Line
        x1={width - bleed.right + offset}
        y1={height - bleed.bottom}
        x2={width - bleed.right + offset + markLength}
        y2={height - bleed.bottom}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />
      <Line
        x1={width - bleed.right}
        y1={height - bleed.bottom + offset}
        x2={width - bleed.right}
        y2={height - bleed.bottom + offset + markLength}
        stroke="black"
        strokeWidth={config.strokeWidth}
      />
    </Svg>
  );
};

// Registration Marks Component
const RegistrationMarks: React.FC<{
  width: number;
  height: number;
  bleed: { top: number; right: number; bottom: number; left: number };
}> = ({ width, height, bleed }) => {
  const markSize = 10;
  const positions = [
    { x: width / 2, y: bleed.top / 2 },           // Top center
    { x: width / 2, y: height - bleed.bottom / 2 }, // Bottom center
    { x: bleed.left / 2, y: height / 2 },         // Left center
    { x: width - bleed.right / 2, y: height / 2 }, // Right center
  ];

  return (
    <Svg style={{ position: 'absolute', top: 0, left: 0, width, height }}>
      {positions.map((pos, i) => (
        <React.Fragment key={i}>
          {/* Cross */}
          <Line
            x1={pos.x - markSize / 2}
            y1={pos.y}
            x2={pos.x + markSize / 2}
            y2={pos.y}
            stroke="black"
            strokeWidth={0.25}
          />
          <Line
            x1={pos.x}
            y1={pos.y - markSize / 2}
            x2={pos.x}
            y2={pos.y + markSize / 2}
            stroke="black"
            strokeWidth={0.25}
          />
          {/* Circle */}
          <Circle
            cx={pos.x}
            cy={pos.y}
            r={markSize / 3}
            stroke="black"
            strokeWidth={0.25}
            fill="none"
          />
        </React.Fragment>
      ))}
    </Svg>
  );
};

const styles = StyleSheet.create({
  page: {
    backgroundColor: 'white',
  },
});
```

### Usage Example

```tsx
import { PrintReadyPage } from "./PrintReadyPage";

const PrintDocument = () => (
  <Document>
    <PrintReadyPage
      size="A4"
      config={{
        bleed: { top: 5, right: 5, bottom: 5, left: 5 },
        cropMarks: { enabled: true, length: 12 },
        registrationMarks: true,
      }}
    >
      {/* Your content here - design to extend into bleed area */}
      <View
        style={{ backgroundColor: "#f0f0f0", width: "100%", height: "100%" }}
      >
        <Text>Print-ready content</Text>
      </View>
    </PrintReadyPage>
  </Document>
);
```

---

## 4. Template Preview & Thumbnails

### Purpose

Generate quick previews and thumbnails without full PDF generation for template selection UI.

### Architecture

```
Template + Sample Data
        │
        ▼
┌─────────────────────┐
│  Preview Generator  │ ──► Generate first page only
└─────────────────────┘
        │
        ▼
┌─────────────────────┐
│   PDF to Image      │ ──► Convert to PNG/JPEG
└─────────────────────┘
        │
        ▼
┌─────────────────────┐
│   Image Resizer     │ ──► Create thumbnail
└─────────────────────┘
        │
        ▼
Thumbnail Image (base64 or URL)
```

### Implementation

```typescript
// src/utils/preview/PreviewGenerator.ts

import { renderToBuffer } from "@react-pdf/renderer";
import { fromBuffer } from "pdf2pic";
import sharp from "sharp";

export interface PreviewOptions {
  width?: number;
  height?: number;
  quality?: number;
  format?: "png" | "jpeg" | "webp";
  page?: number; // Which page to preview (default: 1)
  density?: number; // DPI for PDF to image conversion
}

export interface PreviewResult {
  thumbnail: Buffer;
  mimeType: string;
  width: number;
  height: number;
  base64?: string;
}

export class PreviewGenerator {
  private defaultOptions: PreviewOptions = {
    width: 300,
    height: 400,
    quality: 80,
    format: "png",
    page: 1,
    density: 150,
  };

  async generateThumbnail(
    document: React.ReactElement,
    options: PreviewOptions = {},
  ): Promise<PreviewResult> {
    const opts = { ...this.defaultOptions, ...options };

    // Step 1: Render PDF to buffer
    const pdfBuffer = await renderToBuffer(document);

    // Step 2: Convert PDF page to image
    const converter = fromBuffer(pdfBuffer, {
      density: opts.density,
      format: opts.format,
      width: opts.width! * 2, // 2x for quality
      height: opts.height! * 2,
    });

    const pageImage = await converter(opts.page!, { responseType: "buffer" });

    // Step 3: Resize and optimize
    let pipeline = sharp(pageImage.buffer);

    pipeline = pipeline.resize(opts.width, opts.height, {
      fit: "cover",
      position: "top",
    });

    // Apply format-specific optimization
    switch (opts.format) {
      case "jpeg":
        pipeline = pipeline.jpeg({ quality: opts.quality });
        break;
      case "webp":
        pipeline = pipeline.webp({ quality: opts.quality });
        break;
      case "png":
      default:
        pipeline = pipeline.png({ compressionLevel: 9 });
    }

    const thumbnail = await pipeline.toBuffer();
    const metadata = await sharp(thumbnail).metadata();

    return {
      thumbnail,
      mimeType: `image/${opts.format}`,
      width: metadata.width!,
      height: metadata.height!,
      base64: thumbnail.toString("base64"),
    };
  }

  async generateMultiPagePreview(
    document: React.ReactElement,
    options: PreviewOptions & { maxPages?: number } = {},
  ): Promise<PreviewResult[]> {
    const { maxPages = 5, ...previewOptions } = options;
    const results: PreviewResult[] = [];

    for (let page = 1; page <= maxPages; page++) {
      try {
        const preview = await this.generateThumbnail(document, {
          ...previewOptions,
          page,
        });
        results.push(preview);
      } catch (error) {
        // Reached end of document
        break;
      }
    }

    return results;
  }
}

export const previewGenerator = new PreviewGenerator();
```

```typescript
// src/api/routes/preview.ts

import { Router } from "express";
import { previewGenerator } from "../../utils/preview/PreviewGenerator";
import { templateRegistry } from "../../templates/TemplateRegistry";

export function createPreviewRouter(): Router {
  const router = Router();

  // Get template thumbnail
  router.get("/templates/:templateId/preview", async (req, res, next) => {
    try {
      const { templateId } = req.params;
      const { width, height, format } = req.query;

      const template = templateRegistry.get(templateId);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }

      // Use sample data for preview
      const sampleData =
        template.sampleData || generateSampleData(template.schema);
      const document = template.component({ data: sampleData });

      const preview = await previewGenerator.generateThumbnail(document, {
        width: parseInt(width as string) || 300,
        height: parseInt(height as string) || 400,
        format: (format as "png" | "jpeg" | "webp") || "png",
      });

      res.setHeader("Content-Type", preview.mimeType);
      res.setHeader("Cache-Control", "public, max-age=3600");
      res.send(preview.thumbnail);
    } catch (error) {
      next(error);
    }
  });

  // Get preview with custom data
  router.post("/preview", async (req, res, next) => {
    try {
      const { templateId, data, options } = req.body;

      const template = templateRegistry.get(templateId);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }

      const document = template.component({ data });
      const preview = await previewGenerator.generateThumbnail(
        document,
        options,
      );

      res.json({
        thumbnail: `data:${preview.mimeType};base64,${preview.base64}`,
        width: preview.width,
        height: preview.height,
      });
    } catch (error) {
      next(error);
    }
  });

  return router;
}
```

### Caching Layer

```typescript
// src/utils/preview/PreviewCache.ts

import NodeCache from "node-cache";
import crypto from "crypto";

export class PreviewCache {
  private cache: NodeCache;

  constructor(ttlSeconds: number = 3600) {
    this.cache = new NodeCache({
      stdTTL: ttlSeconds,
      checkperiod: ttlSeconds * 0.2,
      useClones: false,
    });
  }

  generateKey(templateId: string, data: any, options: any): string {
    const hash = crypto
      .createHash("md5")
      .update(JSON.stringify({ templateId, data, options }))
      .digest("hex");
    return `preview:${hash}`;
  }

  get(key: string): Buffer | undefined {
    return this.cache.get(key);
  }

  set(key: string, value: Buffer): void {
    this.cache.set(key, value);
  }

  async getOrGenerate(
    key: string,
    generator: () => Promise<Buffer>,
  ): Promise<Buffer> {
    const cached = this.get(key);
    if (cached) return cached;

    const generated = await generator();
    this.set(key, generated);
    return generated;
  }
}
```

---

## 5. Developer Experience Utilities

### Purpose

Improve development workflow with debugging tools, hot reload, and component documentation.

### 5.1 Debug Mode

```typescript
// src/utils/debug/DebugProvider.tsx

import React, { createContext, useContext } from 'react';
import { View, Text, StyleSheet } from '@react-pdf/renderer';

interface DebugConfig {
  showBorders: boolean;
  showSpacing: boolean;
  showGrid: boolean;
  labelComponents: boolean;
  logRenderTime: boolean;
}

const defaultDebugConfig: DebugConfig = {
  showBorders: process.env.PDF_DEBUG === 'true',
  showSpacing: false,
  showGrid: false,
  labelComponents: false,
  logRenderTime: true,
};

const DebugContext = createContext<DebugConfig>(defaultDebugConfig);

export const DebugProvider: React.FC<{
  config?: Partial<DebugConfig>;
  children: React.ReactNode;
}> = ({ config, children }) => (
  <DebugContext.Provider value={{ ...defaultDebugConfig, ...config }}>
    {children}
  </DebugContext.Provider>
);

export const useDebug = () => useContext(DebugContext);

// Debug wrapper component
export const DebugView: React.FC<{
  name?: string;
  children: React.ReactNode;
  style?: any;
}> = ({ name, children, style }) => {
  const debug = useDebug();

  if (!debug.showBorders) {
    return <View style={style}>{children}</View>;
  }

  return (
    <View style={[style, debugStyles.border]}>
      {debug.labelComponents && name && (
        <Text style={debugStyles.label}>{name}</Text>
      )}
      {children}
    </View>
  );
};

const debugStyles = StyleSheet.create({
  border: {
    borderWidth: 1,
    borderColor: 'red',
    borderStyle: 'dashed',
  },
  label: {
    position: 'absolute',
    top: -10,
    left: 2,
    fontSize: 6,
    color: 'red',
    backgroundColor: 'white',
    padding: 1,
  },
});
```

### 5.2 Component Catalog / Storybook-like System

```typescript
// src/dev/ComponentCatalog.tsx

interface ComponentExample {
  id: string;
  name: string;
  description: string;
  component: React.ComponentType<any>;
  props: Record<string, any>;
  variants?: Array<{
    name: string;
    props: Record<string, any>;
  }>;
}

const componentCatalog: ComponentExample[] = [
  {
    id: 'heading',
    name: 'Heading',
    description: 'Text headings from H1 to H4',
    component: Heading,
    props: { level: 1, children: 'Sample Heading' },
    variants: [
      { name: 'H1', props: { level: 1, children: 'Heading Level 1' } },
      { name: 'H2', props: { level: 2, children: 'Heading Level 2' } },
      { name: 'H3', props: { level: 3, children: 'Heading Level 3' } },
      { name: 'H4', props: { level: 4, children: 'Heading Level 4' } },
    ],
  },
  {
    id: 'table',
    name: 'Table',
    description: 'Data table with header repetition',
    component: Table,
    props: {
      columns: [
        { key: 'name', header: 'Name', width: '50%' },
        { key: 'value', header: 'Value', width: '50%' },
      ],
      data: [
        { name: 'Item 1', value: '$100' },
        { name: 'Item 2', value: '$200' },
      ],
    },
  },
  // ... more components
];

// Generate catalog PDF
const CatalogDocument = () => (
  <Document>
    {componentCatalog.map((item) => (
      <Page key={item.id} size="A4" style={{ padding: 40 }}>
        <Text style={{ fontSize: 24, marginBottom: 10 }}>{item.name}</Text>
        <Text style={{ fontSize: 10, color: '#666', marginBottom: 20 }}>
          {item.description}
        </Text>

        {/* Default example */}
        <View style={{ marginBottom: 20, padding: 10, border: '1pt solid #ddd' }}>
          <Text style={{ fontSize: 8, color: '#999', marginBottom: 5 }}>Default</Text>
          <item.component {...item.props} />
        </View>

        {/* Variants */}
        {item.variants?.map((variant, i) => (
          <View key={i} style={{ marginBottom: 20, padding: 10, border: '1pt solid #ddd' }}>
            <Text style={{ fontSize: 8, color: '#999', marginBottom: 5 }}>{variant.name}</Text>
            <item.component {...variant.props} />
          </View>
        ))}
      </Page>
    ))}
  </Document>
);
```

### 5.3 Hot Reload for Development

```typescript
// src/dev/hotReload.ts

import chokidar from "chokidar";
import { EventEmitter } from "events";

export class PDFHotReload extends EventEmitter {
  private watcher: chokidar.FSWatcher | null = null;

  start(watchPaths: string[]): void {
    this.watcher = chokidar.watch(watchPaths, {
      ignored: /node_modules/,
      persistent: true,
    });

    this.watcher.on("change", (path) => {
      console.log(`[Hot Reload] File changed: ${path}`);
      this.emit("change", path);
    });

    console.log("[Hot Reload] Watching for changes...");
  }

  stop(): void {
    this.watcher?.close();
  }
}

// Usage in dev server
const hotReload = new PDFHotReload();
hotReload.start(["src/components/**/*.tsx", "src/templates/**/*.tsx"]);

hotReload.on("change", async (path) => {
  // Clear require cache
  delete require.cache[require.resolve(path)];

  // Regenerate preview
  await regeneratePreview();

  // Notify connected clients (WebSocket)
  wsServer.broadcast({ type: "reload" });
});
```

### 5.4 Visual Diff Testing

```typescript
// src/dev/visualDiff.ts

import { renderToBuffer } from "@react-pdf/renderer";
import { fromBuffer } from "pdf2pic";
import pixelmatch from "pixelmatch";
import { PNG } from "pngjs";
import fs from "fs";
import path from "path";

export interface DiffResult {
  match: boolean;
  diffPercentage: number;
  diffPixels: number;
  totalPixels: number;
  diffImage?: Buffer;
}

export async function compareDocuments(
  baseline: React.ReactElement,
  current: React.ReactElement,
  options: { threshold?: number; outputDir?: string } = {},
): Promise<DiffResult[]> {
  const { threshold = 0.1, outputDir = "./test-output" } = options;

  // Render both documents
  const [baselinePdf, currentPdf] = await Promise.all([
    renderToBuffer(baseline),
    renderToBuffer(current),
  ]);

  // Convert to images
  const converter1 = fromBuffer(baselinePdf, { density: 150, format: "png" });
  const converter2 = fromBuffer(currentPdf, { density: 150, format: "png" });

  const results: DiffResult[] = [];
  let pageNum = 1;

  while (true) {
    try {
      const [img1, img2] = await Promise.all([
        converter1(pageNum, { responseType: "buffer" }),
        converter2(pageNum, { responseType: "buffer" }),
      ]);

      const png1 = PNG.sync.read(img1.buffer);
      const png2 = PNG.sync.read(img2.buffer);

      const { width, height } = png1;
      const diff = new PNG({ width, height });

      const diffPixels = pixelmatch(
        png1.data,
        png2.data,
        diff.data,
        width,
        height,
        { threshold },
      );

      const totalPixels = width * height;
      const diffPercentage = (diffPixels / totalPixels) * 100;

      // Save diff image if there are differences
      let diffImage: Buffer | undefined;
      if (diffPixels > 0) {
        diffImage = PNG.sync.write(diff);

        if (outputDir) {
          fs.mkdirSync(outputDir, { recursive: true });
          fs.writeFileSync(
            path.join(outputDir, `diff-page-${pageNum}.png`),
            diffImage,
          );
        }
      }

      results.push({
        match: diffPixels === 0,
        diffPercentage,
        diffPixels,
        totalPixels,
        diffImage,
      });

      pageNum++;
    } catch (error) {
      // No more pages
      break;
    }
  }

  return results;
}

// Jest/Vitest matcher
export function toMatchPDF(
  received: React.ReactElement,
  expected: React.ReactElement,
) {
  return {
    async pass() {
      const results = await compareDocuments(expected, received);
      return results.every((r) => r.match);
    },
    message() {
      return "PDF documents do not match visually";
    },
  };
}
```

---

## Updated Project Structure

```
src/
├── components/
│   ├── documents/
│   │   ├── TOC/
│   │   │   ├── TOCContext.tsx
│   │   │   ├── TrackedHeading.tsx
│   │   │   ├── TableOfContents.tsx
│   │   │   └── types.ts
│   │   └── ...
│   ├── layout/
│   │   ├── PrintReadyPage.tsx
│   │   ├── BookmarkedSection.tsx
│   │   └── ...
│   └── ...
│
├── utils/
│   ├── bookmarks/
│   │   └── BookmarkManager.ts
│   ├── preview/
│   │   ├── PreviewGenerator.ts
│   │   └── PreviewCache.ts
│   └── debug/
│       ├── DebugProvider.tsx
│       └── visualDiff.ts
│
├── config/
│   ├── print.ts
│   └── ...
│
├── api/
│   └── routes/
│       ├── preview.ts
│       └── ...
│
└── dev/
    ├── ComponentCatalog.tsx
    └── hotReload.ts
```

---

## Summary

These 5 utilities transform the PDF generator from a basic rendering tool to a **professional document production system**:

| Utility                | Value Added                      |
| ---------------------- | -------------------------------- |
| **TOC Generation**     | Professional document navigation |
| **Bookmarks**          | Reader-friendly PDF navigation   |
| **Print-Ready**        | Commercial print production      |
| **Preview/Thumbnails** | Better UX for template selection |
| **Dev Tools**          | Faster development iteration     |

All implementations are designed to integrate seamlessly with the existing architecture.
