# Missing Utilities & Features Analysis

> A critical review of gaps in the current architecture from a production utility perspective.

---

## Summary of Missing Components

After reviewing the architecture as an expert, here are the **critical gaps** that should be addressed for a production-ready utility:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    MISSING UTILITIES OVERVIEW                        │
├─────────────────────────────────────────────────────────────────────┤
│  🔴 Critical   │ PDF Security, Accessibility, Batch Processing      │
│  🟡 Important  │ TOC, Bookmarks, QR Codes, Print-Ready Output       │
│  🟢 Nice-to-Have│ Mail Merge, Scheduling, Analytics                 │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔴 CRITICAL GAPS

### 1. PDF Security & Compliance

**Missing Features:**
| Feature | Business Need | Implementation |
|---------|---------------|----------------|
| **Password Protection** | Confidential reports | `pdf-lib` post-processing |
| **Digital Signatures** | Legal documents, contracts | `node-signpdf` integration |
| **PDF/A Compliance** | Archival requirements | Specific font embedding, metadata |
| **Watermarks** | Draft/Confidential marking | Overlay during render |
| **Permission Controls** | Prevent print/copy | PDF encryption flags |

**Proposed Solution:**

```typescript
// src/utils/pdfSecurity.ts
import { PDFDocument } from "pdf-lib";

interface SecurityOptions {
  userPassword?: string; // Password to open
  ownerPassword?: string; // Password for permissions
  permissions?: {
    printing?: "none" | "lowResolution" | "highResolution";
    copying?: boolean;
    modifying?: boolean;
    annotating?: boolean;
  };
}

async function securePDF(
  pdfBuffer: Buffer,
  options: SecurityOptions,
): Promise<Buffer> {
  const pdfDoc = await PDFDocument.load(pdfBuffer);

  // Apply encryption
  if (options.userPassword || options.ownerPassword) {
    pdfDoc.encrypt({
      userPassword: options.userPassword,
      ownerPassword: options.ownerPassword,
      permissions: {
        printing: options.permissions?.printing || "highResolution",
        copying: options.permissions?.copying ?? true,
        modifying: options.permissions?.modifying ?? false,
      },
    });
  }

  return Buffer.from(await pdfDoc.save());
}
```

---

### 2. Accessibility (PDF/UA)

**Missing Features:**
| Feature | Compliance Need | Implementation |
|---------|-----------------|----------------|
| **Tagged PDF** | Screen reader support | Structure tree |
| **Alt Text** | Image descriptions | Metadata on images |
| **Reading Order** | Logical flow | Tag ordering |
| **Language Tag** | Multi-language | Document metadata |
| **Heading Structure** | Navigation | Proper tag hierarchy |

**Why Critical:** Legal requirements (ADA, WCAG), government contracts, enterprise clients.

**Proposed Solution:**

```typescript
// src/components/AccessibleImage.tsx
interface AccessibleImageProps {
  src: string;
  alt: string;  // Required for accessibility
  role?: 'figure' | 'decorative';
}

const AccessibleImage: React.FC<AccessibleImageProps> = ({
  src,
  alt,
  role = 'figure'
}) => (
  <View accessibilityRole={role}>
    <Image src={src} />
    {/* Alt text stored in PDF structure */}
    <Text style={{ display: 'none' }}>{alt}</Text>
  </View>
);
```

---

### 3. Batch Processing & Mail Merge

**Missing Features:**
| Feature | Use Case | Implementation |
|---------|----------|----------------|
| **Bulk Generation** | 1000s of invoices | Queue + parallel workers |
| **Mail Merge** | Personalized letters | Template + data array |
| **PDF Merging** | Combined reports | `pdf-lib` merge |
| **Zip Output** | Batch download | `archiver` package |

**Proposed Architecture:**

```typescript
// src/core/batch/BatchProcessor.ts

interface BatchJob {
  template: string;
  dataSet: any[]; // Array of report data
  outputFormat: "individual" | "merged" | "zip";
  namingPattern: string; // e.g., 'invoice-{id}-{date}.pdf'
}

interface BatchResult {
  jobId: string;
  total: number;
  completed: number;
  failed: number;
  outputs: Array<{
    index: number;
    filename: string;
    url?: string;
    error?: string;
  }>;
}

class BatchProcessor {
  async processBatch(job: BatchJob): Promise<BatchResult> {
    const results: BatchResult = {
      jobId: generateId(),
      total: job.dataSet.length,
      completed: 0,
      failed: 0,
      outputs: [],
    };

    // Process in parallel with concurrency limit
    await pMap(
      job.dataSet,
      async (data, index) => {
        try {
          const pdf = await this.generateSingle(job.template, data);
          const filename = this.resolveFilename(job.namingPattern, data, index);

          results.outputs.push({
            index,
            filename,
            url: await this.store(pdf, filename),
          });
          results.completed++;
        } catch (error) {
          results.outputs.push({ index, filename: "", error: error.message });
          results.failed++;
        }
      },
      { concurrency: 5 },
    );

    // Post-process based on output format
    if (job.outputFormat === "merged") {
      return this.mergeResults(results);
    }
    if (job.outputFormat === "zip") {
      return this.zipResults(results);
    }

    return results;
  }
}
```

---

## 🟡 IMPORTANT GAPS

### 4. Table of Contents (TOC) Generation

**Missing:** Automatic TOC based on headings with clickable links.

**Proposed Solution:**

```typescript
// src/components/documents/TOCGenerator.tsx

interface TOCEntry {
  id: string;
  title: string;
  level: number;     // 1 = H1, 2 = H2, etc.
  pageNumber: number;
}

// During render, collect headings
const tocEntries: TOCEntry[] = [];

const TrackedHeading: React.FC<{
  level: number;
  children: string;
  id: string;
}> = ({ level, children, id }) => {
  // Register for TOC
  useEffect(() => {
    tocEntries.push({
      id,
      title: children,
      level,
      pageNumber: 0  // Filled in during render pass
    });
  }, []);

  return (
    <View id={id}>
      <Text style={headingStyles[level]}>{children}</Text>
    </View>
  );
};

// TOC Component
const TableOfContents: React.FC<{ entries: TOCEntry[] }> = ({ entries }) => (
  <View>
    <Text style={styles.tocTitle}>Table of Contents</Text>
    {entries.map(entry => (
      <View key={entry.id} style={[styles.tocEntry, { marginLeft: entry.level * 15 }]}>
        <Link src={`#${entry.id}`}>
          <Text>{entry.title}</Text>
        </Link>
        <Text style={styles.pageNumber}>{entry.pageNumber}</Text>
      </View>
    ))}
  </View>
);
```

---

### 5. Bookmarks / Document Outline

**Missing:** PDF bookmarks for navigation in PDF readers.

**Current Limitation:** React-PDF has limited bookmark support.

**Workaround:**

```typescript
// Post-process with pdf-lib to add bookmarks
import { PDFDocument, PDFName, PDFDict, PDFArray } from "pdf-lib";

async function addBookmarks(
  pdfBuffer: Buffer,
  bookmarks: Array<{ title: string; page: number; level: number }>,
): Promise<Buffer> {
  const pdfDoc = await PDFDocument.load(pdfBuffer);

  // Create outline dictionary
  const outlineDict = pdfDoc.context.obj({
    Type: "Outlines",
    Count: bookmarks.length,
  });

  // Add bookmarks...
  // (Complex implementation involving PDF internal structure)

  return Buffer.from(await pdfDoc.save());
}
```

---

### 6. Barcode & QR Code Generation

**Missing:** Native barcode/QR code support.

**Proposed Solution:**

```typescript
// src/components/common/QRCode.tsx
import QRCodeLib from 'qrcode';

interface QRCodeProps {
  value: string;
  size?: number;
  errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
}

const QRCode: React.FC<QRCodeProps> = async ({
  value,
  size = 100,
  errorCorrectionLevel = 'M'
}) => {
  // Generate QR as SVG path
  const qrData = await QRCodeLib.create(value, { errorCorrectionLevel });
  const modules = qrData.modules;

  const cellSize = size / modules.size;

  return (
    <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {modules.data.map((cell, index) => {
        if (!cell) return null;
        const x = (index % modules.size) * cellSize;
        const y = Math.floor(index / modules.size) * cellSize;
        return (
          <Rect
            key={index}
            x={x}
            y={y}
            width={cellSize}
            height={cellSize}
            fill="black"
          />
        );
      })}
    </Svg>
  );
};

// Barcode component (Code128, EAN, etc.)
// src/components/common/Barcode.tsx
import bwipjs from 'bwip-js';

interface BarcodeProps {
  value: string;
  format: 'code128' | 'ean13' | 'qrcode' | 'datamatrix';
  width?: number;
  height?: number;
  showText?: boolean;
}

const Barcode: React.FC<BarcodeProps> = async ({
  value,
  format,
  width = 200,
  height = 50,
  showText = true
}) => {
  const svg = await bwipjs.toSVG({
    bcid: format,
    text: value,
    scale: 3,
    includetext: showText,
  });

  // Convert SVG to React-PDF compatible format
  return <SvgFromString svg={svg} width={width} height={height} />;
};
```

---

### 7. Print-Ready Output

**Missing:** Professional print preparation.

**Features Needed:**
| Feature | Purpose |
|---------|---------|
| **Bleed Area** | 3mm extra for trimming |
| **Crop Marks** | Cutting guides |
| **Color Profile** | CMYK for print |
| **High DPI** | 300 DPI for quality |
| **Font Embedding** | Full font files |

**Proposed Solution:**

```typescript
// src/utils/printReady.ts

interface PrintOptions {
  bleed: number;           // in mm
  cropMarks: boolean;
  colorProfile: 'RGB' | 'CMYK';
  dpi: number;
}

const PrintReadyPage: React.FC<{
  children: React.ReactNode;
  options: PrintOptions;
}> = ({ children, options }) => {
  const bleedPt = mmToPt(options.bleed);

  return (
    <Page
      size={{
        width: 595 + (bleedPt * 2),  // A4 + bleed
        height: 842 + (bleedPt * 2)
      }}
      style={{ padding: bleedPt }}
    >
      {/* Crop marks */}
      {options.cropMarks && <CropMarks bleed={bleedPt} />}

      {/* Content area */}
      <View style={{ width: 595, height: 842 }}>
        {children}
      </View>
    </Page>
  );
};

const CropMarks: React.FC<{ bleed: number }> = ({ bleed }) => (
  <Svg style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
    {/* Top-left */}
    <Line x1={0} y1={bleed} x2={bleed - 5} y2={bleed} stroke="black" strokeWidth={0.5} />
    <Line x1={bleed} y1={0} x2={bleed} y2={bleed - 5} stroke="black" strokeWidth={0.5} />
    {/* ... other corners */}
  </Svg>
);
```

---

### 8. Document Versioning & Audit Trail

**Missing:** Track document versions and changes.

**Proposed Solution:**

```typescript
// src/utils/documentMetadata.ts

interface DocumentMetadata {
  version: string;
  createdAt: string;
  createdBy: string;
  templateVersion: string;
  dataHash: string;       // Hash of input data for integrity
  revisionHistory?: Array<{
    version: string;
    timestamp: string;
    author: string;
    changes: string;
  }>;
}

function embedMetadata(
  document: React.ReactElement,
  metadata: DocumentMetadata
): React.ReactElement {
  return (
    <Document
      title={metadata.title}
      author={metadata.createdBy}
      subject={`Version ${metadata.version}`}
      keywords={`version:${metadata.version},hash:${metadata.dataHash}`}
      creator="Report Builder v1.0"
      producer="@react-pdf/renderer"
    >
      {document.props.children}
    </Document>
  );
}
```

---

## 🟢 NICE-TO-HAVE GAPS

### 9. Scheduled Report Generation

**Use Case:** Daily/weekly/monthly automated reports.

```typescript
// src/core/scheduler/ReportScheduler.ts
import cron from "node-cron";

interface ScheduledReport {
  id: string;
  schedule: string; // Cron expression
  template: string;
  dataSource: () => Promise<any>;
  recipients: string[]; // Email addresses
  enabled: boolean;
}

class ReportScheduler {
  private jobs: Map<string, cron.ScheduledTask> = new Map();

  schedule(report: ScheduledReport): void {
    const task = cron.schedule(report.schedule, async () => {
      const data = await report.dataSource();
      const pdf = await generateReport(report.template, data);
      await sendEmail(report.recipients, pdf);
    });

    this.jobs.set(report.id, task);
  }

  cancel(reportId: string): void {
    this.jobs.get(reportId)?.stop();
    this.jobs.delete(reportId);
  }
}
```

---

### 10. Analytics & Usage Tracking

**Missing:** Insights into report generation patterns.

```typescript
// src/utils/analytics.ts

interface ReportMetrics {
  templateId: string;
  generationTime: number;
  pageCount: number;
  fileSize: number;
  dataSize: number;
  userId?: string;
  timestamp: string;
}

class AnalyticsCollector {
  async track(metrics: ReportMetrics): Promise<void> {
    // Store metrics for analysis
    await this.store.insert("report_metrics", metrics);

    // Emit for real-time dashboards
    this.emitter.emit("report.generated", metrics);
  }

  async getStats(period: "day" | "week" | "month"): Promise<{
    totalReports: number;
    avgGenerationTime: number;
    popularTemplates: Array<{ template: string; count: number }>;
    errorRate: number;
  }> {
    // Query aggregated stats
  }
}
```

---

### 11. Template Preview & Thumbnails

**Missing:** Quick preview without full generation.

```typescript
// src/utils/preview.ts
import puppeteer from "puppeteer";

async function generateThumbnail(
  template: string,
  sampleData: any,
  options: { width: number; height: number },
): Promise<Buffer> {
  // Generate first page only
  const pdfBuffer = await generateReport(template, sampleData, {
    pageLimit: 1,
  });

  // Convert to image using puppeteer
  const browser = await puppeteer.launch();
  const page = await browser.newPage();

  // Load PDF and screenshot
  await page.goto(
    `data:application/pdf;base64,${pdfBuffer.toString("base64")}`,
  );
  const thumbnail = await page.screenshot({
    type: "png",
    clip: { x: 0, y: 0, ...options },
  });

  await browser.close();
  return thumbnail;
}
```

---

### 12. Developer Experience Utilities

**Missing Tools:**

| Tool                  | Purpose                               |
| --------------------- | ------------------------------------- |
| **Component Catalog** | Visual documentation of components    |
| **Debug Mode**        | Layout borders, spacing visualization |
| **Hot Reload**        | Fast iteration during development     |
| **Visual Diff**       | Compare PDF outputs                   |

```typescript
// src/utils/debug.ts

// Debug wrapper that adds visible borders
const DebugView: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  if (process.env.PDF_DEBUG !== 'true') {
    return <>{children}</>;
  }

  return (
    <View debug style={{ borderColor: 'red', borderWidth: 1 }}>
      {children}
    </View>
  );
};

// Visual diff testing
async function compareReports(
  baseline: Buffer,
  current: Buffer
): Promise<{
  match: boolean;
  diffPercentage: number;
  diffImage?: Buffer;
}> {
  // Convert PDFs to images
  const baselineImages = await pdfToImages(baseline);
  const currentImages = await pdfToImages(current);

  // Compare using pixelmatch
  let totalDiff = 0;
  for (let i = 0; i < baselineImages.length; i++) {
    const diff = pixelmatch(
      baselineImages[i],
      currentImages[i],
      null,
      width,
      height
    );
    totalDiff += diff;
  }

  return {
    match: totalDiff === 0,
    diffPercentage: (totalDiff / (width * height * baselineImages.length)) * 100
  };
}
```

---

## Updated Project Structure

```
src/
├── ...existing structure...
│
├── security/
│   ├── encryption.ts        # Password protection
│   ├── signatures.ts        # Digital signatures
│   └── permissions.ts       # PDF permissions
│
├── accessibility/
│   ├── tags.ts              # PDF tagging
│   ├── altText.ts           # Image descriptions
│   └── validation.ts        # A11y validation
│
├── batch/
│   ├── BatchProcessor.ts    # Bulk generation
│   ├── MailMerge.ts         # Personalization
│   └── Merger.ts            # PDF combining
│
├── postprocess/
│   ├── bookmarks.ts         # Add outline
│   ├── metadata.ts          # Embed metadata
│   ├── optimize.ts          # Compress/linearize
│   └── print.ts             # Print-ready prep
│
├── components/
│   ├── ...existing...
│   ├── QRCode.tsx           # QR code generator
│   ├── Barcode.tsx          # Barcode generator
│   └── TOC.tsx              # Table of contents
│
├── scheduler/
│   ├── ReportScheduler.ts   # Cron-based scheduling
│   └── EmailDelivery.ts     # Report delivery
│
└── analytics/
    ├── collector.ts         # Metrics collection
    └── dashboard.ts         # Stats API
```

---

## Priority Implementation Order

### Phase 1 (Critical - Add to existing roadmap)

1. ✅ Password Protection
2. ✅ QR Code / Barcode generation
3. ✅ Batch Processing foundation
4. ✅ Basic accessibility tags

### Phase 2 (Important - After core complete)

5. Table of Contents
6. Bookmarks
7. Print-ready output
8. Document versioning

### Phase 3 (Enhancement)

9. Scheduled reports
10. Analytics dashboard
11. Template thumbnails
12. Developer tools

---

## Recommended Additional Dependencies

```json
{
  "dependencies": {
    "pdf-lib": "^1.17.1", // PDF manipulation
    "qrcode": "^1.5.3", // QR code generation
    "bwip-js": "^4.0.0", // Barcode generation
    "node-signpdf": "^3.0.0", // Digital signatures
    "archiver": "^6.0.0", // ZIP creation
    "node-cron": "^3.0.2", // Scheduling
    "pixelmatch": "^5.3.0" // Visual diff testing
  }
}
```

---

## Summary

The original architecture is **solid for core PDF generation**. These additions make it a **complete enterprise utility**:

| Category                   | Status      | Priority     |
| -------------------------- | ----------- | ------------ |
| Core Generation            | ✅ Complete | -            |
| Security                   | ❌ Missing  | Critical     |
| Accessibility              | ❌ Missing  | Critical     |
| Batch Processing           | ❌ Missing  | Critical     |
| Navigation (TOC/Bookmarks) | ❌ Missing  | Important    |
| Barcodes/QR                | ❌ Missing  | Important    |
| Print Production           | ❌ Missing  | Important    |
| Scheduling                 | ❌ Missing  | Nice-to-have |
| Analytics                  | ❌ Missing  | Nice-to-have |

**Recommendation:** Add Security, Accessibility, and Batch Processing to Phase 1, as these are often **required** for enterprise adoption.
