# Report Factory Pattern Architecture

> A hierarchical composition pattern for building PDF reports from blueprints to primitives.

---

## The Pattern Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────┐
│                            BLUEPRINT                                     │
│         Abstract structure definition (JSON Schema / Config)            │
│                                │                                         │
│                                ▼                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                            TEMPLATE                                      │
│           Concrete document layout implementing blueprint                │
│                                │                                         │
│                                ▼                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                         UI COMPONENTS                                    │
│              Reusable building blocks (Table, Card, Chart)              │
│                                │                                         │
│                                ▼                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                           PRIMITIVES                                     │
│               Icons, Images, Fonts, Colors, Spacing                     │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Layer 1: Primitives (Foundation)

The atomic building blocks that cannot be broken down further.

### Structure

```
primitives/
├── colors/
│   ├── palette.ts       # Color definitions
│   └── semantic.ts      # Semantic color mappings
├── typography/
│   ├── fonts.ts         # Font family definitions
│   ├── sizes.ts         # Font size scale
│   └── weights.ts       # Font weight mappings
├── spacing/
│   └── scale.ts         # Spacing scale (4, 8, 12, 16, 24, 32...)
├── icons/
│   ├── registry.ts      # Icon registry
│   └── svgs/            # SVG icon files
├── images/
│   ├── logos/           # Brand logos
│   └── placeholders/    # Placeholder images
└── index.ts             # Exports all primitives
```

### Implementation

```typescript
// src/primitives/colors/palette.ts

export const palette = {
  // Brand colors
  brand: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
  },

  // Neutral colors
  neutral: {
    0: "#ffffff",
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
  },

  // Semantic colors
  success: { light: "#dcfce7", main: "#22c55e", dark: "#15803d" },
  warning: { light: "#fef3c7", main: "#f59e0b", dark: "#b45309" },
  error: { light: "#fee2e2", main: "#ef4444", dark: "#b91c1c" },
  info: { light: "#dbeafe", main: "#3b82f6", dark: "#1d4ed8" },
} as const;

export type PaletteColor = keyof typeof palette;
```

```typescript
// src/primitives/typography/fonts.ts

import { Font } from "@react-pdf/renderer";

export interface FontFamily {
  name: string;
  weights: {
    normal?: string;
    medium?: string;
    semibold?: string;
    bold?: string;
  };
  styles?: {
    italic?: string;
    boldItalic?: string;
  };
}

export const fontFamilies: Record<string, FontFamily> = {
  primary: {
    name: "Inter",
    weights: {
      normal: "/fonts/Inter-Regular.ttf",
      medium: "/fonts/Inter-Medium.ttf",
      semibold: "/fonts/Inter-SemiBold.ttf",
      bold: "/fonts/Inter-Bold.ttf",
    },
  },
  secondary: {
    name: "Georgia",
    weights: {
      normal: "Georgia",
      bold: "Georgia-Bold",
    },
  },
  mono: {
    name: "JetBrains Mono",
    weights: {
      normal: "/fonts/JetBrainsMono-Regular.ttf",
      bold: "/fonts/JetBrainsMono-Bold.ttf",
    },
  },
};

// Register all fonts
export function registerFonts(): void {
  Object.values(fontFamilies).forEach((family) => {
    const fonts = Object.entries(family.weights).map(([weight, src]) => ({
      src,
      fontWeight: weight as any,
    }));

    Font.register({ family: family.name, fonts });
  });
}
```

```typescript
// src/primitives/icons/registry.ts

export interface IconDefinition {
  viewBox: string;
  path: string;
}

export const icons: Record<string, IconDefinition> = {
  check: {
    viewBox: "0 0 24 24",
    path: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z",
  },
  warning: {
    viewBox: "0 0 24 24",
    path: "M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z",
  },
  info: {
    viewBox: "0 0 24 24",
    path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z",
  },
  arrow_right: {
    viewBox: "0 0 24 24",
    path: "M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z",
  },
  // ... more icons
};

export type IconName = keyof typeof icons;
```

---

## Layer 2: UI Components (Building Blocks)

Reusable components built from primitives.

### Structure

```
components/
├── primitives/           # Primitive wrappers
│   ├── Icon.tsx
│   ├── Text.tsx
│   └── Box.tsx
├── typography/
│   ├── Heading.tsx
│   ├── Paragraph.tsx
│   ├── Label.tsx
│   └── Caption.tsx
├── layout/
│   ├── Stack.tsx         # Vertical stack
│   ├── Row.tsx           # Horizontal row
│   ├── Grid.tsx          # Grid layout
│   ├── Divider.tsx
│   └── Spacer.tsx
├── data/
│   ├── Table/
│   ├── List.tsx
│   ├── KeyValue.tsx
│   └── MetricCard.tsx
├── feedback/
│   ├── Badge.tsx
│   ├── StatusIndicator.tsx
│   └── ProgressBar.tsx
├── media/
│   ├── Image.tsx
│   ├── Logo.tsx
│   └── QRCode.tsx
├── containers/
│   ├── Card.tsx
│   ├── Section.tsx
│   └── Callout.tsx
└── index.ts
```

### Component Factory

```typescript
// src/components/ComponentFactory.ts

import React from "react";

// Component registry
const componentRegistry: Map<string, React.ComponentType<any>> = new Map();

// Register a component
export function registerComponent(
  name: string,
  component: React.ComponentType<any>,
): void {
  componentRegistry.set(name, component);
}

// Get a component by name
export function getComponent(
  name: string,
): React.ComponentType<any> | undefined {
  return componentRegistry.get(name);
}

// Create component instance from config
export function createComponent(
  type: string,
  props: Record<string, any>,
  children?: React.ReactNode,
): React.ReactElement | null {
  const Component = componentRegistry.get(type);

  if (!Component) {
    console.warn(`Component not found: ${type}`);
    return null;
  }

  return React.createElement(Component, props, children);
}

// Register all built-in components
import { Heading, Paragraph, Label, Caption } from "./typography";
import { Table, List, KeyValue, MetricCard } from "./data";
import { Card, Section, Callout } from "./containers";
import { Badge, StatusIndicator, ProgressBar } from "./feedback";
import { Stack, Row, Grid, Divider, Spacer } from "./layout";

export function registerBuiltInComponents(): void {
  // Typography
  registerComponent("Heading", Heading);
  registerComponent("Paragraph", Paragraph);
  registerComponent("Label", Label);
  registerComponent("Caption", Caption);

  // Data
  registerComponent("Table", Table);
  registerComponent("List", List);
  registerComponent("KeyValue", KeyValue);
  registerComponent("MetricCard", MetricCard);

  // Containers
  registerComponent("Card", Card);
  registerComponent("Section", Section);
  registerComponent("Callout", Callout);

  // Feedback
  registerComponent("Badge", Badge);
  registerComponent("StatusIndicator", StatusIndicator);
  registerComponent("ProgressBar", ProgressBar);

  // Layout
  registerComponent("Stack", Stack);
  registerComponent("Row", Row);
  registerComponent("Grid", Grid);
  registerComponent("Divider", Divider);
  registerComponent("Spacer", Spacer);
}
```

### Example Component

```typescript
// src/components/containers/Card.tsx

import React from 'react';
import { View, StyleSheet } from '@react-pdf/renderer';
import { usePrimitives } from '../../primitives';

export interface CardProps {
  children: React.ReactNode;
  variant?: 'default' | 'outlined' | 'elevated';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  backgroundColor?: string;
  borderColor?: string;
  borderRadius?: 'none' | 'sm' | 'md' | 'lg';
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'default',
  padding = 'md',
  backgroundColor,
  borderColor,
  borderRadius = 'md',
}) => {
  const { colors, spacing, borders } = usePrimitives();

  const paddingValue = {
    none: 0,
    sm: spacing.sm,
    md: spacing.md,
    lg: spacing.lg,
  }[padding];

  const radiusValue = {
    none: 0,
    sm: borders.radius.sm,
    md: borders.radius.md,
    lg: borders.radius.lg,
  }[borderRadius];

  const variantStyles = {
    default: {
      backgroundColor: backgroundColor || colors.neutral[0],
    },
    outlined: {
      backgroundColor: backgroundColor || colors.neutral[0],
      borderWidth: 1,
      borderColor: borderColor || colors.neutral[200],
    },
    elevated: {
      backgroundColor: backgroundColor || colors.neutral[0],
      // Simulated shadow with border
      borderWidth: 1,
      borderColor: colors.neutral[100],
      borderBottomWidth: 3,
      borderBottomColor: colors.neutral[200],
    },
  };

  return (
    <View
      style={[
        { padding: paddingValue, borderRadius: radiusValue },
        variantStyles[variant],
      ]}
    >
      {children}
    </View>
  );
};
```

---

## Layer 3: Templates (Document Layouts)

Concrete document layouts that compose UI components.

### Structure

```
templates/
├── registry.ts           # Template registry
├── base/
│   └── BaseTemplate.tsx  # Abstract base template
├── reports/
│   ├── StandardReport/
│   │   ├── index.tsx
│   │   ├── schema.ts     # Data schema
│   │   ├── sections/     # Template-specific sections
│   │   └── styles.ts
│   ├── ExecutiveReport/
│   ├── TechnicalReport/
│   └── DiagramReport/
├── invoices/
│   ├── StandardInvoice/
│   └── DetailedInvoice/
├── letters/
│   └── BusinessLetter/
└── index.ts
```

### Template Factory

```typescript
// src/templates/TemplateFactory.ts

import React from 'react';

export interface TemplateDefinition<TData = any, TOptions = any> {
  id: string;
  name: string;
  description: string;
  version: string;
  category: 'report' | 'invoice' | 'letter' | 'custom';

  // Schema for validation
  dataSchema: any;  // Zod/Joi schema
  optionsSchema?: any;

  // Default values
  defaultOptions: TOptions;
  sampleData: TData;

  // Component
  component: React.ComponentType<{ data: TData; options?: TOptions }>;

  // Metadata
  thumbnail?: string;
  tags?: string[];
}

class TemplateFactory {
  private templates: Map<string, TemplateDefinition> = new Map();

  register<TData, TOptions>(template: TemplateDefinition<TData, TOptions>): void {
    this.templates.set(template.id, template);
  }

  get<TData = any, TOptions = any>(id: string): TemplateDefinition<TData, TOptions> | undefined {
    return this.templates.get(id) as TemplateDefinition<TData, TOptions>;
  }

  list(category?: string): TemplateDefinition[] {
    const all = Array.from(this.templates.values());
    return category ? all.filter(t => t.category === category) : all;
  }

  create<TData, TOptions>(
    templateId: string,
    data: TData,
    options?: Partial<TOptions>
  ): React.ReactElement {
    const template = this.get<TData, TOptions>(templateId);

    if (!template) {
      throw new Error(`Template not found: ${templateId}`);
    }

    // Validate data against schema
    const validationResult = template.dataSchema.safeParse(data);
    if (!validationResult.success) {
      throw new Error(`Invalid data: ${validationResult.error.message}`);
    }

    // Merge options with defaults
    const mergedOptions = {
      ...template.defaultOptions,
      ...options,
    };

    // Create component
    const Component = template.component;
    return <Component data={data} options={mergedOptions} />;
  }

  // Create from config (for dynamic template selection)
  createFromConfig(config: {
    templateId: string;
    data: any;
    options?: any;
  }): React.ReactElement {
    return this.create(config.templateId, config.data, config.options);
  }
}

export const templateFactory = new TemplateFactory();
```

### Example Template

```typescript
// src/templates/reports/StandardReport/index.tsx

import React from 'react';
import { Document, Page } from '@react-pdf/renderer';
import { z } from 'zod';
import { templateFactory } from '../../TemplateFactory';
import { Header, Footer, TOC, Section } from '../../../components';
import { styles } from './styles';

// Data Schema
export const standardReportSchema = z.object({
  title: z.string(),
  subtitle: z.string().optional(),
  author: z.string(),
  date: z.string(),
  sections: z.array(z.object({
    id: z.string(),
    title: z.string(),
    content: z.any(),  // Can be text, table, diagram, etc.
  })),
  metadata: z.object({
    company: z.string(),
    logo: z.string().optional(),
    confidential: z.boolean().optional(),
  }).optional(),
});

export type StandardReportData = z.infer<typeof standardReportSchema>;

// Options Schema
export interface StandardReportOptions {
  pageSize: 'A4' | 'LETTER';
  orientation: 'portrait' | 'landscape';
  showTOC: boolean;
  showPageNumbers: boolean;
  headerStyle: 'minimal' | 'full';
  colorScheme: 'default' | 'corporate' | 'modern';
}

// Component
const StandardReport: React.FC<{
  data: StandardReportData;
  options?: StandardReportOptions;
}> = ({ data, options = defaultOptions }) => {
  return (
    <Document
      title={data.title}
      author={data.author}
      subject={data.subtitle}
    >
      {/* Cover Page */}
      <Page size={options.pageSize} orientation={options.orientation}>
        <CoverPage data={data} options={options} />
      </Page>

      {/* Table of Contents */}
      {options.showTOC && (
        <Page size={options.pageSize} orientation={options.orientation}>
          <TOC sections={data.sections} />
        </Page>
      )}

      {/* Content Pages */}
      <Page size={options.pageSize} orientation={options.orientation} style={styles.page}>
        <Header
          title={data.title}
          logo={data.metadata?.logo}
          style={options.headerStyle}
        />

        {data.sections.map((section) => (
          <Section key={section.id} id={section.id} title={section.title}>
            <SectionContent content={section.content} />
          </Section>
        ))}

        <Footer
          showPageNumbers={options.showPageNumbers}
          confidential={data.metadata?.confidential}
        />
      </Page>
    </Document>
  );
};

const defaultOptions: StandardReportOptions = {
  pageSize: 'A4',
  orientation: 'portrait',
  showTOC: true,
  showPageNumbers: true,
  headerStyle: 'full',
  colorScheme: 'default',
};

// Register template
templateFactory.register({
  id: 'standard-report',
  name: 'Standard Report',
  description: 'A professional multi-section report template',
  version: '1.0.0',
  category: 'report',
  dataSchema: standardReportSchema,
  defaultOptions,
  sampleData: {
    title: 'Sample Report',
    author: 'John Doe',
    date: '2026-01-28',
    sections: [
      { id: 'intro', title: 'Introduction', content: 'Sample content...' },
    ],
  },
  component: StandardReport,
  tags: ['report', 'professional', 'multi-section'],
});

export default StandardReport;
```

---

## Layer 4: Blueprints (Abstract Structure)

The highest level of abstraction - defines WHAT a document should contain without specifying HOW.

### Structure

```
blueprints/
├── registry.ts           # Blueprint registry
├── types.ts              # Blueprint type definitions
├── reports/
│   ├── financial.json
│   ├── sales.json
│   └── technical.json
├── invoices/
│   └── standard.json
└── index.ts
```

### Blueprint Schema

```typescript
// src/blueprints/types.ts

export interface Blueprint {
  id: string;
  name: string;
  version: string;
  description: string;

  // Compatible templates
  compatibleTemplates: string[];

  // Document structure definition
  structure: BlueprintStructure;

  // Data requirements
  dataRequirements: DataRequirement[];

  // Business rules
  rules?: BusinessRule[];
}

export interface BlueprintStructure {
  pages: PageDefinition[];
}

export interface PageDefinition {
  id: string;
  type: "cover" | "toc" | "content" | "appendix";
  sections: SectionDefinition[];
  required: boolean;
}

export interface SectionDefinition {
  id: string;
  type: "header" | "text" | "table" | "chart" | "diagram" | "image" | "custom";
  name: string;
  required: boolean;
  dataBinding?: string; // JSONPath to data
  componentType?: string; // Specific component to use
  config?: Record<string, any>;
  children?: SectionDefinition[];
}

export interface DataRequirement {
  path: string; // JSONPath
  type: "string" | "number" | "array" | "object" | "date";
  required: boolean;
  description: string;
  validation?: any; // Schema validation
}

export interface BusinessRule {
  id: string;
  description: string;
  condition: string; // JSONLogic or custom expression
  action: "show" | "hide" | "highlight" | "validate";
  target: string; // Section ID
}
```

### Blueprint Factory

```typescript
// src/blueprints/BlueprintFactory.ts

import { Blueprint, SectionDefinition } from "./types";
import { templateFactory } from "../templates/TemplateFactory";
import { createComponent } from "../components/ComponentFactory";

class BlueprintFactory {
  private blueprints: Map<string, Blueprint> = new Map();

  register(blueprint: Blueprint): void {
    this.blueprints.set(blueprint.id, blueprint);
  }

  get(id: string): Blueprint | undefined {
    return this.blueprints.get(id);
  }

  list(): Blueprint[] {
    return Array.from(this.blueprints.values());
  }

  // Create document from blueprint + data
  createDocument(
    blueprintId: string,
    data: any,
    options?: {
      templateId?: string;
      overrides?: Record<string, any>;
    },
  ): React.ReactElement {
    const blueprint = this.get(blueprintId);

    if (!blueprint) {
      throw new Error(`Blueprint not found: ${blueprintId}`);
    }

    // Validate data against requirements
    this.validateData(blueprint, data);

    // Apply business rules
    const processedStructure = this.applyRules(blueprint, data);

    // Select template
    const templateId = options?.templateId || blueprint.compatibleTemplates[0];

    // Transform blueprint structure to template data
    const templateData = this.transformToTemplateData(processedStructure, data);

    // Create document using template
    return templateFactory.create(templateId, templateData, options?.overrides);
  }

  private validateData(blueprint: Blueprint, data: any): void {
    for (const req of blueprint.dataRequirements) {
      const value = this.getValueByPath(data, req.path);

      if (req.required && (value === undefined || value === null)) {
        throw new Error(`Required data missing: ${req.path}`);
      }

      if (req.validation && value !== undefined) {
        const result = req.validation.safeParse(value);
        if (!result.success) {
          throw new Error(
            `Invalid data at ${req.path}: ${result.error.message}`,
          );
        }
      }
    }
  }

  private applyRules(blueprint: Blueprint, data: any): BlueprintStructure {
    if (!blueprint.rules) return blueprint.structure;

    const structure = JSON.parse(JSON.stringify(blueprint.structure));

    for (const rule of blueprint.rules) {
      const conditionMet = this.evaluateCondition(rule.condition, data);

      if (conditionMet) {
        this.applyRuleAction(structure, rule);
      }
    }

    return structure;
  }

  private evaluateCondition(condition: string, data: any): boolean {
    // Simple JSONPath-based condition evaluation
    // In production, use jsonLogic or similar
    try {
      const fn = new Function("data", `return ${condition}`);
      return fn(data);
    } catch {
      return false;
    }
  }

  private applyRuleAction(
    structure: BlueprintStructure,
    rule: BusinessRule,
  ): void {
    // Find target section and apply action
    for (const page of structure.pages) {
      for (const section of page.sections) {
        if (section.id === rule.target) {
          switch (rule.action) {
            case "hide":
              section.required = false;
              (section as any)._hidden = true;
              break;
            case "highlight":
              (section as any)._highlighted = true;
              break;
          }
        }
      }
    }
  }

  private transformToTemplateData(
    structure: BlueprintStructure,
    data: any,
  ): any {
    // Transform blueprint structure to template-specific data format
    const sections = [];

    for (const page of structure.pages) {
      for (const section of page.sections) {
        if ((section as any)._hidden) continue;

        sections.push({
          id: section.id,
          title: section.name,
          type: section.type,
          content: section.dataBinding
            ? this.getValueByPath(data, section.dataBinding)
            : null,
          config: section.config,
        });
      }
    }

    return {
      ...data,
      sections,
    };
  }

  private getValueByPath(obj: any, path: string): any {
    return path.split(".").reduce((o, k) => o?.[k], obj);
  }
}

export const blueprintFactory = new BlueprintFactory();
```

### Example Blueprint (JSON)

```json
// src/blueprints/reports/financial.json
{
  "id": "financial-report",
  "name": "Financial Report Blueprint",
  "version": "1.0.0",
  "description": "Blueprint for quarterly/annual financial reports",

  "compatibleTemplates": ["standard-report", "executive-report"],

  "structure": {
    "pages": [
      {
        "id": "cover",
        "type": "cover",
        "required": true,
        "sections": [
          {
            "id": "title",
            "type": "header",
            "name": "Report Title",
            "required": true,
            "dataBinding": "title"
          },
          {
            "id": "period",
            "type": "text",
            "name": "Reporting Period",
            "required": true,
            "dataBinding": "period"
          }
        ]
      },
      {
        "id": "executive-summary",
        "type": "content",
        "required": true,
        "sections": [
          {
            "id": "summary-text",
            "type": "text",
            "name": "Executive Summary",
            "required": true,
            "dataBinding": "summary"
          },
          {
            "id": "key-metrics",
            "type": "chart",
            "name": "Key Metrics",
            "required": true,
            "dataBinding": "metrics",
            "componentType": "MetricCards",
            "config": {
              "columns": 4,
              "showTrend": true
            }
          }
        ]
      },
      {
        "id": "financials",
        "type": "content",
        "required": true,
        "sections": [
          {
            "id": "income-statement",
            "type": "table",
            "name": "Income Statement",
            "required": true,
            "dataBinding": "financials.income",
            "componentType": "FinancialTable"
          },
          {
            "id": "balance-sheet",
            "type": "table",
            "name": "Balance Sheet",
            "required": true,
            "dataBinding": "financials.balance",
            "componentType": "FinancialTable"
          },
          {
            "id": "cash-flow",
            "type": "table",
            "name": "Cash Flow Statement",
            "required": false,
            "dataBinding": "financials.cashFlow",
            "componentType": "FinancialTable"
          }
        ]
      },
      {
        "id": "analysis",
        "type": "content",
        "required": false,
        "sections": [
          {
            "id": "revenue-chart",
            "type": "chart",
            "name": "Revenue Analysis",
            "dataBinding": "analysis.revenue",
            "componentType": "BarChart"
          },
          {
            "id": "expense-breakdown",
            "type": "chart",
            "name": "Expense Breakdown",
            "dataBinding": "analysis.expenses",
            "componentType": "PieChart"
          }
        ]
      }
    ]
  },

  "dataRequirements": [
    {
      "path": "title",
      "type": "string",
      "required": true,
      "description": "Report title"
    },
    {
      "path": "period",
      "type": "string",
      "required": true,
      "description": "Reporting period (e.g., Q1 2026)"
    },
    {
      "path": "financials.income",
      "type": "array",
      "required": true,
      "description": "Income statement line items"
    },
    {
      "path": "financials.balance",
      "type": "array",
      "required": true,
      "description": "Balance sheet line items"
    }
  ],

  "rules": [
    {
      "id": "hide-cashflow-if-empty",
      "description": "Hide cash flow section if no data",
      "condition": "!data.financials?.cashFlow?.length",
      "action": "hide",
      "target": "cash-flow"
    },
    {
      "id": "highlight-negative-metrics",
      "description": "Highlight metrics with negative trend",
      "condition": "data.metrics?.some(m => m.trend < 0)",
      "action": "highlight",
      "target": "key-metrics"
    }
  ]
}
```

---

## Complete Factory Pattern Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                            API REQUEST                                   │
│                                 │                                        │
│                    { blueprintId, data, options }                        │
│                                 │                                        │
│                                 ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                     BLUEPRINT FACTORY                            │   │
│  │                                                                   │   │
│  │  1. Load blueprint definition                                    │   │
│  │  2. Validate data against requirements                           │   │
│  │  3. Apply business rules                                         │   │
│  │  4. Select compatible template                                   │   │
│  │  5. Transform structure to template format                       │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                 │                                        │
│                                 ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                     TEMPLATE FACTORY                             │   │
│  │                                                                   │   │
│  │  1. Load template component                                      │   │
│  │  2. Apply template options                                       │   │
│  │  3. Create Document structure                                    │   │
│  │  4. Compose sections using components                            │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                 │                                        │
│                                 ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    COMPONENT FACTORY                             │   │
│  │                                                                   │   │
│  │  1. Resolve component by type                                    │   │
│  │  2. Apply component config                                       │   │
│  │  3. Bind data to component                                       │   │
│  │  4. Apply styling from theme                                     │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                 │                                        │
│                                 ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      PRIMITIVES                                  │   │
│  │                                                                   │   │
│  │  Colors │ Fonts │ Spacing │ Icons │ Images                      │   │
│  │                                                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                 │                                        │
│                                 ▼                                        │
│                          React-PDF Render                                │
│                                 │                                        │
│                                 ▼                                        │
│                            PDF OUTPUT                                    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Usage Example

```typescript
// API endpoint
app.post('/api/reports', async (req, res) => {
  const { blueprintId, data, options } = req.body;

  try {
    // Create document using the factory chain
    const document = blueprintFactory.createDocument(blueprintId, data, options);

    // Render to PDF
    const pdfBuffer = await renderToBuffer(document);

    res.setHeader('Content-Type', 'application/pdf');
    res.send(pdfBuffer);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Example request
const request = {
  blueprintId: 'financial-report',
  data: {
    title: 'Q1 2026 Financial Report',
    period: 'January - March 2026',
    summary: 'Strong quarter with 15% revenue growth...',
    metrics: [
      { label: 'Revenue', value: '$1.2M', trend: 15 },
      { label: 'Profit', value: '$320K', trend: 8 },
      { label: 'Customers', value: '1,240', trend: 12 },
    ],
    financials: {
      income: [...],
      balance: [...],
      cashFlow: [...],
    },
    analysis: {
      revenue: [...],
      expenses: [...],
    },
  },
  options: {
    templateId: 'executive-report',
    overrides: {
      colorScheme: 'corporate',
    },
  },
};
```

---

## Summary

The Factory Pattern provides:

| Layer         | Responsibility                       | Abstraction Level |
| ------------- | ------------------------------------ | ----------------- |
| **Blueprint** | WHAT to include (structure + rules)  | Highest           |
| **Template**  | HOW to layout (document composition) | High              |
| **Component** | HOW to display (UI building blocks)  | Medium            |
| **Primitive** | WHAT to use (atoms: colors, fonts)   | Lowest            |

This creates a highly maintainable, extensible system where:

- **Blueprints** can be defined by business users (JSON config)
- **Templates** can be created by designers
- **Components** can be built by developers
- **Primitives** can be managed by brand/design teams

Each layer is decoupled and can evolve independently.
