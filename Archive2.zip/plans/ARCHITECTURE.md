# Autonomous PDF Generation Pipeline - Architecture Plan

## Executive Summary

This document outlines the architecture for an **autonomous server-side PDF generation pipeline** that transforms complex data structures—including node-based diagrams from xyflow—into professional, high-fidelity PDF reports using React-PDF.

---

## Table of Contents

1. [System Architecture Overview](#1-system-architecture-overview)
2. [Project Structure](#2-project-structure)
3. [Core Modules](#3-core-modules)
4. [xyflow-to-SVG Transformation Layer](#4-xyflow-to-svg-transformation-layer)
5. [Table Rendering System](#5-table-rendering-system)
6. [Styling and Theming System](#6-styling-and-theming-system)
7. [Express.js Microservice API](#7-expressjs-microservice-api)
8. [Implementation Roadmap](#8-implementation-roadmap)

---

## 1. System Architecture Overview

### High-Level Architecture

```mermaid
graph TB
    subgraph "Client/External Systems"
        A[API Consumer]
        B[Data Sources]
    end

    subgraph "PDF Generation Microservice"
        C[Express.js API Gateway]
        D[Request Validator]
        E[Report Orchestrator]

        subgraph "Transformation Layer"
            F[xyflow Transformer]
            G[Table Builder]
            H[Content Processor]
        end

        subgraph "Rendering Engine"
            I[React-PDF Renderer]
            J[Font Manager]
            K[Asset Manager]
        end

        subgraph "Output Handler"
            L[Stream Manager]
            M[Buffer Manager]
        end
    end

    subgraph "Storage/Delivery"
        N[S3/Cloud Storage]
        O[Direct Response]
    end

    A --> C
    B --> C
    C --> D
    D --> E
    E --> F
    E --> G
    E --> H
    F --> I
    G --> I
    H --> I
    I --> J
    I --> K
    I --> L
    I --> M
    L --> N
    M --> O
```

### Key Design Principles

| Principle           | Description                                                             |
| ------------------- | ----------------------------------------------------------------------- |
| **Loosely Coupled** | Each module operates independently with well-defined interfaces         |
| **Stream-First**    | Use `renderToStream` for memory-efficient processing of large documents |
| **Stateless**       | No session state; each request is self-contained                        |
| **Scalable**        | Horizontal scaling through container orchestration                      |
| **Resilient**       | Graceful error handling with detailed logging                           |

### Technology Stack

| Layer      | Technology             |
| ---------- | ---------------------- |
| Runtime    | Node.js 18+            |
| Framework  | Express.js             |
| PDF Engine | @react-pdf/renderer v4 |
| Validation | Zod / Joi              |
| Logging    | Winston / Pino         |
| Monitoring | OpenTelemetry          |
| Container  | Docker                 |

---

## 2. Project Structure

```
report-builder-poc/
├── src/
│   ├── index.ts                    # Application entry point
│   ├── server.ts                   # Express server setup
│   │
│   ├── api/
│   │   ├── routes/
│   │   │   ├── index.ts            # Route aggregator
│   │   │   ├── reports.ts          # Report generation endpoints
│   │   │   └── health.ts           # Health check endpoints
│   │   ├── middleware/
│   │   │   ├── validation.ts       # Request validation
│   │   │   ├── errorHandler.ts     # Global error handling
│   │   │   └── rateLimiter.ts      # Rate limiting
│   │   └── validators/
│   │       ├── reportSchema.ts     # Report request schemas
│   │       └── diagramSchema.ts    # Diagram data schemas
│   │
│   ├── core/
│   │   ├── orchestrator/
│   │   │   ├── ReportOrchestrator.ts
│   │   │   └── RenderPipeline.ts
│   │   ├── renderer/
│   │   │   ├── PDFRenderer.ts      # React-PDF wrapper
│   │   │   ├── StreamRenderer.ts   # Stream-based rendering
│   │   │   └── BufferRenderer.ts   # Buffer-based rendering
│   │   └── errors/
│   │       └── CustomErrors.ts     # Domain-specific errors
│   │
│   ├── transformers/
│   │   ├── xyflow/
│   │   │   ├── index.ts
│   │   │   ├── NodeTransformer.ts  # Node to SVG conversion
│   │   │   ├── EdgeTransformer.ts  # Edge to Path conversion
│   │   │   ├── LayoutCalculator.ts # Position calculations
│   │   │   └── types.ts            # xyflow type definitions
│   │   ├── tables/
│   │   │   ├── index.ts
│   │   │   ├── TableBuilder.ts     # Table construction
│   │   │   ├── RowSplitter.ts      # Page break logic
│   │   │   └── HeaderRepeater.ts   # Repeated headers
│   │   └── content/
│   │       ├── TextProcessor.ts    # Text formatting
│   │       └── ImageProcessor.ts   # Image handling
│   │
│   ├── components/
│   │   ├── documents/
│   │   │   ├── BaseDocument.tsx    # Base document template
│   │   │   ├── ReportDocument.tsx  # Main report template
│   │   │   └── InvoiceDocument.tsx # Invoice template
│   │   ├── layout/
│   │   │   ├── Page.tsx            # Page wrapper
│   │   │   ├── Header.tsx          # Fixed header
│   │   │   ├── Footer.tsx          # Fixed footer with page numbers
│   │   │   └── Section.tsx         # Content section
│   │   ├── tables/
│   │   │   ├── Table.tsx           # Base table component
│   │   │   ├── TableHeader.tsx     # Repeatable header
│   │   │   ├── TableRow.tsx        # Row with orphan protection
│   │   │   └── TableCell.tsx       # Cell with alignment
│   │   ├── diagrams/
│   │   │   ├── DiagramContainer.tsx
│   │   │   ├── FlowNode.tsx        # Node component
│   │   │   ├── FlowEdge.tsx        # Edge/connector component
│   │   │   ├── NodeGroup.tsx       # Grouped node elements
│   │   │   └── shapes/
│   │   │       ├── Rectangle.tsx
│   │   │       ├── Circle.tsx
│   │   │       ├── Diamond.tsx
│   │   │       └── CustomShape.tsx
│   │   └── common/
│   │       ├── Typography.tsx      # Text components
│   │       ├── Divider.tsx
│   │       └── Spacer.tsx
│   │
│   ├── styles/
│   │   ├── index.ts                # Style exports
│   │   ├── theme.ts                # Theme configuration
│   │   ├── colors.ts               # Color palette
│   │   ├── typography.ts           # Typography styles
│   │   ├── layout.ts               # Layout styles
│   │   ├── tables.ts               # Table styles
│   │   └── diagrams.ts             # Diagram styles
│   │
│   ├── assets/
│   │   ├── fonts/                  # Custom fonts
│   │   └── images/                 # Static images
│   │
│   ├── config/
│   │   ├── index.ts                # Configuration aggregator
│   │   ├── fonts.ts                # Font registration
│   │   ├── pdf.ts                  # PDF defaults
│   │   └── server.ts               # Server configuration
│   │
│   ├── utils/
│   │   ├── logger.ts               # Logging utility
│   │   ├── metrics.ts              # Performance metrics
│   │   ├── pathBuilder.ts          # SVG path utilities
│   │   └── calculations.ts         # Layout calculations
│   │
│   └── types/
│       ├── index.ts                # Type exports
│       ├── report.ts               # Report types
│       ├── diagram.ts              # Diagram types
│       └── api.ts                  # API types
│
├── tests/
│   ├── unit/
│   ├── integration/
│   └── fixtures/
│
├── docs/
│   └── api/                        # API documentation
│
├── plans/
│   └── ARCHITECTURE.md             # This file
│
├── REACT_PDF_GUIDE.md              # React-PDF reference
├── package.json
├── tsconfig.json
├── Dockerfile
└── docker-compose.yml
```

---

## 3. Core Modules

### 3.1 Report Orchestrator

The central coordinator that manages the entire report generation process.

```typescript
// src/core/orchestrator/ReportOrchestrator.ts

interface ReportOrchestrator {
  // Main entry point
  generateReport(request: ReportRequest): Promise<ReportResult>;

  // Pipeline stages
  validateRequest(request: ReportRequest): ValidationResult;
  transformData(data: ReportData): TransformedData;
  renderDocument(document: ReactElement): Promise<Stream | Buffer>;

  // Lifecycle hooks
  onBeforeRender(callback: RenderCallback): void;
  onAfterRender(callback: RenderCallback): void;
  onError(callback: ErrorCallback): void;
}
```

### 3.2 Render Pipeline

```mermaid
sequenceDiagram
    participant Client
    participant API
    participant Orchestrator
    participant Transformer
    participant Renderer
    participant Output

    Client->>API: POST /api/reports
    API->>Orchestrator: generateReport
    Orchestrator->>Orchestrator: validateRequest
    Orchestrator->>Transformer: transformData
    Transformer-->>Orchestrator: TransformedData
    Orchestrator->>Renderer: renderDocument
    Renderer->>Renderer: React reconciliation
    Renderer->>Renderer: Layout calculation
    Renderer->>Renderer: PDF generation
    Renderer-->>Orchestrator: Stream/Buffer
    Orchestrator->>Output: handleOutput
    Output-->>Client: PDF Response
```

---

## 4. xyflow-to-SVG Transformation Layer

### 4.1 Data Flow

```mermaid
graph LR
    A[xyflow JSON] --> B[Node Transformer]
    A --> C[Edge Transformer]
    B --> D[SVG Groups]
    C --> E[SVG Paths]
    D --> F[Layout Calculator]
    E --> F
    F --> G[DiagramContainer Component]
```

### 4.2 Node Transformation

**Input**: xyflow Node Data

```json
{
  "id": "node-1",
  "type": "custom",
  "position": { "x": 100, "y": 50 },
  "data": {
    "label": "Data Input",
    "icon": "database",
    "status": "active"
  },
  "style": {
    "width": 150,
    "height": 60
  }
}
```

**Output**: React-PDF SVG Components

```jsx
<G transform="translate(100, 50)">
  <Defs>
    <LinearGradient id="node-1-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
      <Stop offset="0%" stopColor="#ffffff" />
      <Stop offset="100%" stopColor="#f0f0f0" />
    </LinearGradient>
  </Defs>
  <Rect
    width={150}
    height={60}
    rx={8}
    fill="url(#node-1-gradient)"
    stroke="#e0e0e0"
    strokeWidth={1}
  />
  <SvgText x={75} y={35} textAnchor="middle" fontSize={12}>
    Data Input
  </SvgText>
</G>
```

### 4.3 Edge Transformation

**Edge Types and Path Generation**:

| Edge Type  | Path Strategy                     | Use Case           |
| ---------- | --------------------------------- | ------------------ |
| Straight   | `M x1,y1 L x2,y2`                 | Simple connections |
| Bezier     | `M x1,y1 C cx1,cy1 cx2,cy2 x2,y2` | Smooth curves      |
| Step       | `M x1,y1 H mx L mx,y2 H x2`       | Orthogonal routing |
| Smoothstep | Bezier with orthogonal anchors    | Modern UI style    |

```typescript
// src/transformers/xyflow/EdgeTransformer.ts

interface EdgeTransformOptions {
  sourceNode: NodePosition;
  targetNode: NodePosition;
  edgeType: "straight" | "bezier" | "step" | "smoothstep";
  sourceHandle?: HandlePosition;
  targetHandle?: HandlePosition;
  curvature?: number;
}

function transformEdge(
  edge: XYFlowEdge,
  options: EdgeTransformOptions,
): string {
  const { sourceNode, targetNode, edgeType } = options;

  switch (edgeType) {
    case "straight":
      return `M ${sourceNode.x},${sourceNode.y} L ${targetNode.x},${targetNode.y}`;

    case "bezier":
      const midX = (sourceNode.x + targetNode.x) / 2;
      return `M ${sourceNode.x},${sourceNode.y} C ${midX},${sourceNode.y} ${midX},${targetNode.y} ${targetNode.x},${targetNode.y}`;

    case "step":
      const stepX = sourceNode.x + (targetNode.x - sourceNode.x) / 2;
      return `M ${sourceNode.x},${sourceNode.y} H ${stepX} V ${targetNode.y} H ${targetNode.x}`;

    case "smoothstep":
      // Smoothstep with rounded corners
      return generateSmoothstepPath(sourceNode, targetNode, options.curvature);
  }
}
```

### 4.4 Layout Calculator

Handles positioning, scaling, and viewport calculations for diagrams.

```typescript
// src/transformers/xyflow/LayoutCalculator.ts

interface DiagramBounds {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  width: number;
  height: number;
}

interface LayoutOptions {
  pageWidth: number;
  pageHeight: number;
  padding: number;
  scale?: "fit" | "fill" | number;
}

class LayoutCalculator {
  // Calculate diagram bounds from all nodes
  calculateBounds(nodes: XYFlowNode[]): DiagramBounds;

  // Calculate scale factor to fit diagram in page
  calculateScale(bounds: DiagramBounds, options: LayoutOptions): number;

  // Transform coordinates for PDF viewport
  transformCoordinates(
    position: Position,
    bounds: DiagramBounds,
    options: LayoutOptions,
  ): Position;

  // Calculate viewBox for SVG container
  calculateViewBox(bounds: DiagramBounds, padding: number): string;
}
```

---

## 5. Table Rendering System

### 5.1 Multi-Page Table Architecture

```mermaid
graph TB
    subgraph "Table Builder"
        A[Raw Data] --> B[Column Definition]
        B --> C[Row Generation]
        C --> D[Page Break Analysis]
    end

    subgraph "Page Break Logic"
        D --> E{Row fits on page?}
        E -->|Yes| F[Add to current page]
        E -->|No| G[Insert page break]
        G --> H[Repeat header]
        H --> F
    end

    subgraph "Orphan Protection"
        F --> I{Orphan check}
        I -->|Orphan detected| J[Move to next page]
        I -->|OK| K[Render row]
    end
```

### 5.2 Table Component Structure

```jsx
// src/components/tables/Table.tsx

interface TableProps {
  data: TableRow[];
  columns: ColumnDefinition[];
  options?: {
    repeatHeader?: boolean;      // Repeat header on each page
    orphanProtection?: number;   // Minimum rows before break
    widowProtection?: number;    // Minimum rows after break
    zebra?: boolean;             // Alternating row colors
    borderStyle?: 'full' | 'horizontal' | 'none';
  };
  styles?: {
    table?: Style;
    header?: Style;
    row?: Style;
    cell?: Style;
  };
}

const Table: React.FC<TableProps> = ({ data, columns, options, styles }) => (
  <View style={styles?.table}>
    {/* Fixed header for first page */}
    <TableHeader columns={columns} style={styles?.header} />

    {/* Rows with automatic wrapping */}
    {data.map((row, index) => (
      <TableRow
        key={row.id || index}
        data={row}
        columns={columns}
        index={index}
        zebra={options?.zebra}
        style={styles?.row}
        // Orphan protection: wrap with minimum rows
        minPresenceAhead={options?.orphanProtection ?
          calculateMinPresence(index, data.length, options.orphanProtection) :
          undefined
        }
      />
    ))}

    {/* Repeated header on page breaks */}
    {options?.repeatHeader && (
      <TableHeader
        columns={columns}
        style={styles?.header}
        fixed  // Appears at top of each page
      />
    )}
  </View>
);
```

### 5.3 Column Definition

```typescript
interface ColumnDefinition {
  key: string;                    // Data key
  header: string;                 // Header text
  width: string | number;         // Column width (%, pt, etc.)
  align?: 'left' | 'center' | 'right';
  format?: (value: any) => string; // Value formatter
  render?: (value: any, row: TableRow) => ReactNode; // Custom render
  wrap?: boolean;                 // Allow text wrapping
}

// Example usage
const columns: ColumnDefinition[] = [
  { key: 'id', header: 'ID', width: '10%', align: 'center' },
  { key: 'name', header: 'Name', width: '30%', wrap: true },
  { key: 'amount', header: 'Amount', width: '20%', align: 'right',
    format: (v) => `$${v.toFixed(2)}` },
  { key: 'date', header: 'Date', width: '20%',
    format: (v) => new Date(v).toLocaleDateString() },
  { key: 'status', header: 'Status', width: '20%',
    render: (v) => <StatusBadge status={v} /> }
];
```

### 5.4 Header Repetition Strategy

```jsx
// src/components/tables/TableHeader.tsx

interface TableHeaderProps {
  columns: ColumnDefinition[];
  style?: Style;
  fixed?: boolean;  // Appears on every page
}

const TableHeader: React.FC<TableHeaderProps> = ({ columns, style, fixed }) => (
  <View
    style={[styles.headerRow, style]}
    fixed={fixed}
    wrap={false}  // Never split header
  >
    {columns.map((col) => (
      <View key={col.key} style={[styles.headerCell, { width: col.width }]}>
        <Text style={[styles.headerText, { textAlign: col.align || 'left' }]}>
          {col.header}
        </Text>
      </View>
    ))}
  </View>
);
```

---

## 6. Styling and Theming System

### 6.1 Theme Structure

```typescript
// src/styles/theme.ts

interface Theme {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: {
      primary: string;
      secondary: string;
      disabled: string;
    };
    border: string;
    error: string;
    success: string;
    warning: string;
  };

  typography: {
    fontFamily: {
      primary: string;
      secondary: string;
      mono: string;
    };
    fontSize: {
      xs: number;
      sm: number;
      base: number;
      lg: number;
      xl: number;
      "2xl": number;
      "3xl": number;
    };
    fontWeight: {
      normal: string;
      medium: string;
      semibold: string;
      bold: string;
    };
    lineHeight: {
      tight: number;
      normal: number;
      relaxed: number;
    };
  };

  spacing: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    "2xl": number;
  };

  borders: {
    radius: {
      sm: number;
      md: number;
      lg: number;
      full: number;
    };
    width: {
      thin: number;
      normal: number;
      thick: number;
    };
  };

  shadows: {
    sm: string;
    md: string;
    lg: string;
  };
}
```

### 6.2 Default Theme

```typescript
// src/styles/theme.ts

export const defaultTheme: Theme = {
  colors: {
    primary: "#2563eb", // Blue 600
    secondary: "#64748b", // Slate 500
    accent: "#8b5cf6", // Violet 500
    background: "#ffffff",
    surface: "#f8fafc", // Slate 50
    text: {
      primary: "#1e293b", // Slate 800
      secondary: "#64748b", // Slate 500
      disabled: "#94a3b8", // Slate 400
    },
    border: "#e2e8f0", // Slate 200
    error: "#ef4444", // Red 500
    success: "#22c55e", // Green 500
    warning: "#f59e0b", // Amber 500
  },

  typography: {
    fontFamily: {
      primary: "Inter",
      secondary: "Georgia",
      mono: "JetBrains Mono",
    },
    fontSize: {
      xs: 10,
      sm: 11,
      base: 12,
      lg: 14,
      xl: 16,
      "2xl": 20,
      "3xl": 24,
    },
    fontWeight: {
      normal: "normal",
      medium: "500",
      semibold: "600",
      bold: "bold",
    },
    lineHeight: {
      tight: 1.2,
      normal: 1.5,
      relaxed: 1.75,
    },
  },

  spacing: {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
    "2xl": 32,
  },

  borders: {
    radius: {
      sm: 2,
      md: 4,
      lg: 8,
      full: 9999,
    },
    width: {
      thin: 0.5,
      normal: 1,
      thick: 2,
    },
  },
};
```

### 6.3 Media Query Support

```typescript
// src/styles/responsive.ts

export const createResponsiveStyles = (theme: Theme) =>
  StyleSheet.create({
    container: {
      padding: theme.spacing.md,

      // Landscape orientation
      "@media orientation: landscape": {
        padding: theme.spacing.lg,
        flexDirection: "row",
      },

      // Smaller page sizes
      "@media max-width: 400": {
        padding: theme.spacing.sm,
        fontSize: theme.typography.fontSize.sm,
      },
    },

    table: {
      // Adjust column widths for different orientations
      "@media orientation: portrait": {
        // Stack columns vertically on narrow pages
      },
      "@media orientation: landscape": {
        // Full horizontal layout
      },
    },
  });
```

### 6.4 SVG Gradient Definitions

```typescript
// src/styles/diagrams.ts

export const createDiagramStyles = (theme: Theme) => ({
  nodeGradients: {
    default: {
      type: "linear",
      stops: [
        { offset: "0%", color: theme.colors.surface },
        { offset: "100%", color: theme.colors.border },
      ],
    },
    primary: {
      type: "linear",
      stops: [
        { offset: "0%", color: theme.colors.primary },
        { offset: "100%", color: adjustColor(theme.colors.primary, -20) },
      ],
    },
    success: {
      type: "radial",
      stops: [
        { offset: "0%", color: theme.colors.success },
        { offset: "100%", color: adjustColor(theme.colors.success, -30) },
      ],
    },
  },

  edgeStyles: {
    default: {
      stroke: theme.colors.border,
      strokeWidth: 1.5,
      fill: "none",
    },
    active: {
      stroke: theme.colors.primary,
      strokeWidth: 2,
      strokeDasharray: "5,5",
    },
  },
});
```

---

## 7. Express.js Microservice API

### 7.1 API Endpoints

| Method | Endpoint              | Description                |
| ------ | --------------------- | -------------------------- |
| POST   | `/api/reports`        | Generate a new report      |
| POST   | `/api/reports/stream` | Generate and stream report |
| GET    | `/api/reports/:id`    | Get report status/download |
| GET    | `/api/health`         | Health check               |
| GET    | `/api/health/ready`   | Readiness probe            |

### 7.2 Request/Response Schemas

```typescript
// POST /api/reports

interface GenerateReportRequest {
  template: "standard" | "invoice" | "diagram" | "custom";
  data: {
    title: string;
    metadata?: Record<string, any>;
    sections: ReportSection[];
  };
  options?: {
    pageSize?: "A4" | "LETTER" | "LEGAL" | { width: number; height: number };
    orientation?: "portrait" | "landscape";
    margins?: { top: number; right: number; bottom: number; left: number };
    fonts?: FontConfig[];
    watermark?: string;
  };
  output?: {
    format: "stream" | "buffer" | "url";
    filename?: string;
  };
}

interface ReportSection {
  type: "text" | "table" | "diagram" | "image" | "chart";
  data: any;
  options?: SectionOptions;
}

interface GenerateReportResponse {
  success: boolean;
  data?: {
    id: string;
    status: "processing" | "completed" | "failed";
    url?: string; // For async/URL output
    buffer?: string; // Base64 encoded for buffer output
    contentType: string;
    filename: string;
    pageCount: number;
    generatedAt: string;
  };
  error?: {
    code: string;
    message: string;
    details?: any;
  };
}
```

### 7.3 Server Implementation

```typescript
// src/server.ts

import express from "express";
import { createReportRouter } from "./api/routes/reports";
import { createHealthRouter } from "./api/routes/health";
import { errorHandler } from "./api/middleware/errorHandler";
import { requestLogger } from "./api/middleware/requestLogger";
import { rateLimiter } from "./api/middleware/rateLimiter";
import { initializeFonts } from "./config/fonts";
import { logger } from "./utils/logger";

export async function createServer() {
  const app = express();

  // Initialize fonts before handling requests
  await initializeFonts();

  // Middleware
  app.use(express.json({ limit: "10mb" }));
  app.use(requestLogger);
  app.use(rateLimiter);

  // Routes
  app.use("/api/reports", createReportRouter());
  app.use("/api/health", createHealthRouter());

  // Error handling
  app.use(errorHandler);

  return app;
}

// src/api/routes/reports.ts

export function createReportRouter() {
  const router = express.Router();
  const orchestrator = new ReportOrchestrator();

  // Generate report - returns buffer or URL
  router.post("/", async (req, res, next) => {
    try {
      const request = validateReportRequest(req.body);
      const result = await orchestrator.generateReport(request);

      if (request.output?.format === "buffer") {
        res.json({
          success: true,
          data: {
            ...result,
            buffer: result.buffer.toString("base64"),
          },
        });
      } else {
        res.json({ success: true, data: result });
      }
    } catch (error) {
      next(error);
    }
  });

  // Stream report directly
  router.post("/stream", async (req, res, next) => {
    try {
      const request = validateReportRequest(req.body);
      const stream = await orchestrator.generateReportStream(request);

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${request.output?.filename || "report.pdf"}"`,
      );

      stream.pipe(res);
    } catch (error) {
      next(error);
    }
  });

  return router;
}
```

### 7.4 Error Handling

```typescript
// src/api/middleware/errorHandler.ts

export function errorHandler(
  error: Error,
  req: express.Request,
  res: express.Response,
  next: express.NextFunction,
) {
  logger.error("Request error", {
    error: error.message,
    stack: error.stack,
    path: req.path,
    method: req.method,
  });

  if (error instanceof ValidationError) {
    return res.status(400).json({
      success: false,
      error: {
        code: "VALIDATION_ERROR",
        message: error.message,
        details: error.details,
      },
    });
  }

  if (error instanceof RenderError) {
    return res.status(500).json({
      success: false,
      error: {
        code: "RENDER_ERROR",
        message: "Failed to generate PDF",
        details: error.details,
      },
    });
  }

  // Unknown error
  return res.status(500).json({
    success: false,
    error: {
      code: "INTERNAL_ERROR",
      message: "An unexpected error occurred",
    },
  });
}
```

---

## 8. Implementation Roadmap

### Phase 1: Foundation (Week 1-2)

| Task                          | Priority | Dependencies          |
| ----------------------------- | -------- | --------------------- |
| Project setup with TypeScript | High     | None                  |
| Express.js server scaffold    | High     | Project setup         |
| Basic React-PDF integration   | High     | Project setup         |
| Font registration system      | High     | React-PDF integration |
| Simple document template      | Medium   | React-PDF integration |
| Health check endpoints        | Medium   | Express.js server     |
| Basic error handling          | Medium   | Express.js server     |
| Unit test setup               | Medium   | Project setup         |

### Phase 2: Core Components (Week 3-4)

| Task                                | Priority | Dependencies       |
| ----------------------------------- | -------- | ------------------ |
| Theme system implementation         | High     | Foundation         |
| Table component with basic features | High     | Theme system       |
| Header/Footer components            | High     | Theme system       |
| Multi-page support                  | High     | Table component    |
| Header repetition                   | High     | Multi-page support |
| Orphan/widow protection             | Medium   | Multi-page support |
| Column alignment system             | Medium   | Table component    |
| Typography components               | Medium   | Theme system       |

### Phase 3: Diagram Integration (Week 5-6)

| Task                    | Priority | Dependencies           |
| ----------------------- | -------- | ---------------------- |
| xyflow data parser      | High     | Foundation             |
| Node transformer        | High     | xyflow parser          |
| Edge transformer        | High     | xyflow parser          |
| Layout calculator       | High     | Node/Edge transformers |
| SVG container component | High     | Layout calculator      |
| Basic node shapes       | High     | SVG container          |
| Edge path generation    | High     | SVG container          |
| Gradient definitions    | Medium   | Node shapes            |
| Group transformations   | Medium   | Node shapes            |
| Complex node types      | Low      | Basic node shapes      |

### Phase 4: API & Production (Week 7-8)

| Task                     | Priority | Dependencies       |
| ------------------------ | -------- | ------------------ |
| Full API implementation  | High     | Core components    |
| Request validation       | High     | API implementation |
| Stream rendering         | High     | API implementation |
| Rate limiting            | Medium   | API implementation |
| Logging system           | Medium   | API implementation |
| Docker containerization  | Medium   | API implementation |
| Integration tests        | Medium   | All components     |
| Performance optimization | Medium   | All components     |
| Documentation            | Medium   | All components     |

### Milestone Checkpoints

```mermaid
gantt
    title Implementation Timeline
    dateFormat  YYYY-MM-DD
    section Phase 1
    Project Setup           :p1a, 2026-02-01, 3d
    Express Server          :p1b, after p1a, 2d
    React-PDF Integration   :p1c, after p1b, 3d
    Font System             :p1d, after p1c, 2d
    Basic Templates         :p1e, after p1d, 4d

    section Phase 2
    Theme System            :p2a, after p1e, 3d
    Table Components        :p2b, after p2a, 5d
    Multi-page Support      :p2c, after p2b, 4d
    Typography              :p2d, after p2a, 2d

    section Phase 3
    xyflow Parser           :p3a, after p2c, 3d
    Node Transformer        :p3b, after p3a, 4d
    Edge Transformer        :p3c, after p3a, 4d
    SVG Components          :p3d, after p3b, 5d

    section Phase 4
    Full API                :p4a, after p3d, 4d
    Containerization        :p4b, after p4a, 2d
    Testing                 :p4c, after p4a, 4d
    Documentation           :p4d, after p4c, 2d
```

---

## Next Steps

1. **Review this architecture** with stakeholders
2. **Approve the project structure** and technology choices
3. **Begin Phase 1 implementation** in Code mode
4. **Set up CI/CD pipeline** for automated testing and deployment

---

_Document Version: 1.0_  
_Created: January 2026_  
_Last Updated: January 2026_
