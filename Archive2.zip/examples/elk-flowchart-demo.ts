/**
 * Elk Flowchart Demo
 *
 * Demonstrates the Elkjs + D3.js hybrid solution for generating
 * pixel-perfect flowchart SVGs with:
 * - Automatic hierarchical layout
 * - Separator lines with labels
 * - Annotation text blocks
 * - Side notes
 * - 50% distribution badges
 */

import { writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import {
  ElkFlowchartEngine,
  FlowchartData,
  createTrustStructureGraph,
  generateTrustStructureSVGForPdf,
} from '../src/utils/ElkFlowchartEngine.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function main() {
  console.log('🎨 Elk Flowchart Engine Demo (Enhanced)');
  console.log('========================================\n');

  // Create engine with custom config
  const engine = new ElkFlowchartEngine({
    width: 600,
    height: 600,
    padding: 30,
    nodeSpacing: 40,
    layerSpacing: 90,
    direction: 'DOWN',
    edgeStyle: 'orthogonal',
  });

  // Create FULL trust structure graph with separators, annotations, and side notes
  console.log('📊 Building trust structure graph (with all features)...');
  const flowchartData: FlowchartData = createTrustStructureGraph();
  
  console.log(`   Nodes: ${flowchartData.nodes.length}`);
  console.log(`   Edges: ${flowchartData.edges.length}`);
  console.log(`   Separators: ${flowchartData.separators?.length || 0}`);
  console.log(`   Annotations: ${flowchartData.annotations?.length || 0}`);
  console.log(`   Side Notes: ${flowchartData.sideNotes?.length || 0}`);
  flowchartData.nodes.forEach(n => console.log(`     - ${n.id}: ${n.label}`));

  // Generate SVG using full flowchart method
  console.log('\n🔧 Running Elk layout algorithm...');
  const startTime = Date.now();
  
  try {
    const result = await engine.generateFlowchart(flowchartData);
    const elapsed = Date.now() - startTime;
    
    console.log(`✅ Layout complete in ${elapsed}ms`);
    console.log(`   SVG size: ${result.width}x${result.height}`);

    // Save SVG to file
    const outputPath = join(__dirname, '../output/elk-trust-structure.svg');
    writeFileSync(outputPath, result.svg, 'utf-8');
    console.log(`\n💾 SVG saved to: ${outputPath}`);

    // Also save an HTML wrapper for easy viewing
    const htmlPath = join(__dirname, '../output/elk-trust-structure.html');
    const html = `<!DOCTYPE html>
<html>
<head>
  <title>Elk Trust Structure Flowchart (Enhanced)</title>
  <style>
    body {
      font-family: Inter, -apple-system, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      background: #f5f5f5;
    }
    .container {
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      padding: 40px;
      max-width: 900px;
    }
    h1 {
      text-align: center;
      color: #2D9B9B;
      margin-bottom: 10px;
    }
    .subtitle {
      text-align: center;
      color: #6B7280;
      margin-bottom: 30px;
    }
    svg {
      display: block;
      margin: 0 auto;
    }
    .features {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-top: 30px;
      padding-top: 20px;
      border-top: 1px solid #E5E7EB;
    }
    .feature {
      background: #F3F4F6;
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 12px;
      color: #374151;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Trust Structure (Elk + D3)</h1>
    <p class="subtitle">Automatic layout with separators, annotations, and side notes</p>
    ${result.svg}
    <div class="features">
      <span class="feature">✓ Elkjs Auto-Layout</span>
      <span class="feature">✓ D3.js SVG Rendering</span>
      <span class="feature">✓ Orthogonal Edges</span>
      <span class="feature">✓ Separators & Annotations</span>
    </div>
  </div>
</body>
</html>`;
    writeFileSync(htmlPath, html, 'utf-8');
    console.log(`📄 HTML preview saved to: ${htmlPath}`);

    // Also test the PDF integration helper
    console.log('\n🧪 Testing PDF integration helper...');
    const pdfSvg = await generateTrustStructureSVGForPdf();
    console.log(`   PDF SVG generated: ${pdfSvg.length} characters`);

  } catch (error) {
    console.error('❌ Error generating flowchart:', error);
    throw error;
  }

  console.log('\n🎉 Demo complete!');
  console.log('\nFeatures demonstrated:');
  console.log('  • Elkjs automatic hierarchical layout');
  console.log('  • D3.js server-side SVG generation (via JSDOM)');
  console.log('  • Separator lines with labels');
  console.log('  • Annotation text blocks');
  console.log('  • Side notes');
  console.log('  • Edge labels (50% badges)');
  console.log('  • Orthogonal edge routing with rounded corners');
}

main().catch(console.error);
