/**
 * Estate Planning Demo
 * Demonstrates generating a wealth management estate planning report using the blueprint system
 */

import { createDocument } from '../src/factories/DocumentFactory.js';
import { renderToStream } from '@react-pdf/renderer';
import { createWriteStream, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import sampleEstatePlanning from '../src/blueprints/samples/sample-estate-planning.json' with { type: 'json' };
import type { EstatePlanningBlueprint } from '../src/blueprints/types.js';

// Get directory paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const outputDir = join(__dirname, '..', 'output');

/**
 * Generate estate planning report PDF
 */
async function generateEstatePlanningReport() {
  console.log('🏛️  Estate Planning Report Demo');
  console.log('================================\n');

  try {
    // Ensure output directory exists
    mkdirSync(outputDir, { recursive: true });

    console.log('📋 Loading estate planning blueprint...');
    const blueprint = sampleEstatePlanning as unknown as EstatePlanningBlueprint;
    
    console.log(`   Client: ${blueprint.content.client.names.join(' & ')}`);
    console.log(`   Trust: ${blueprint.content.client.trustName}`);
    console.log(`   Total Estate Value: $${blueprint.content.estateOverview?.total.toLocaleString('en-US')}`);
    console.log(`   Beneficiaries: ${blueprint.content.beneficiaries?.length || 0}\n`);

    console.log('🎨 Creating PDF document...');
    const doc = createDocument({ blueprint });

    console.log('📄 Rendering PDF to stream...');
    const outputPath = join(outputDir, 'estate-planning-demo.pdf');
    const stream = await renderToStream(doc);
    
    console.log('💾 Writing to file...');
    const fileStream = createWriteStream(outputPath);
    
    stream.pipe(fileStream);

    await new Promise<void>((resolve, reject) => {
      fileStream.on('finish', () => {
        console.log('\n✅ Estate Planning Report generated successfully!');
        console.log(`📁 Output: ${outputPath}\n`);
        console.log('Report Contents:');
        console.log('  • Cover Page');
        console.log('  • Trust Structure Flowchart');
        console.log('  • Key People & Estate Overview');
        console.log('  • Estate Value Breakdown');
        console.log('  • Beneficiaries Grid');
        console.log('\n🎉 Demo complete!');
        resolve();
      });
      
      fileStream.on('error', (error) => {
        console.error('\n❌ Error writing PDF file:', error);
        reject(error);
      });
    });

  } catch (error) {
    console.error('\n❌ Error generating estate planning report:', error);
    if (error instanceof Error) {
      console.error('   Message:', error.message);
      console.error('   Stack:', error.stack);
    }
    process.exit(1);
  }
}

// Run the demo
generateEstatePlanningReport().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});
