/**
 * Unified Flowchart Demo
 *
 * Demonstrates all positioning modes:
 * 1. AUTO mode - Elkjs automatic layout
 * 2. MANUAL mode - Pixel-perfect absolute positioning
 * 3. RELATIVE mode - Percentage/anchor/grid-based positioning
 */

import { writeFileSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import {
  UnifiedFlowchartEngine,
  createAutoTrustStructure,
  createManualTrustStructure,
  createRelativeTrustStructure,
  createGridTrustStructure,
  createAnchorTrustStructure,
} from '../src/utils/UnifiedFlowchartEngine.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function main() {
  console.log('🎨 Unified Flowchart Engine Demo');
  console.log('=================================\n');

  // Ensure output directory exists
  const outputDir = join(__dirname, '../output');
  try { mkdirSync(outputDir, { recursive: true }); } catch {}

  // =========================================================================
  // DEMO 1: AUTO MODE (Elkjs)
  // =========================================================================
  console.log('📊 DEMO 1: AUTO MODE (Elkjs automatic layout)');
  console.log('----------------------------------------------');
  
  const autoEngine = new UnifiedFlowchartEngine({
    mode: 'auto',
    width: 600,
    height: 600,
    padding: 30,
    nodeSpacing: 40,
    layerSpacing: 90,
  });

  const autoData = createAutoTrustStructure();
  console.log(`   Nodes: ${autoData.nodes.length}`);
  console.log(`   Edges: ${autoData.edges.length}`);

  const autoStart = Date.now();
  const autoResult = await autoEngine.generate(autoData);
  console.log(`   Generated in ${Date.now() - autoStart}ms`);
  console.log(`   SVG size: ${autoResult.width}x${autoResult.height}`);

  // Save auto mode output
  const autoSvgPath = join(outputDir, 'unified-auto.svg');
  writeFileSync(autoSvgPath, autoResult.svg, 'utf-8');
  console.log(`   Saved: ${autoSvgPath}`);

  // =========================================================================
  // DEMO 2: MANUAL MODE (Pixel-perfect)
  // =========================================================================
  console.log('\n📊 DEMO 2: MANUAL MODE (Pixel-perfect positioning)');
  console.log('---------------------------------------------------');
  
  const manualEngine = new UnifiedFlowchartEngine({
    mode: 'manual',
    width: 580,
    height: 720,
    padding: 20,
  });

  const manualData = createManualTrustStructure();
  console.log(`   Nodes: ${manualData.nodes.length}`);
  console.log(`   Edges: ${manualData.edges.length}`);
  console.log(`   Separators: ${manualData.separators?.length || 0}`);
  console.log(`   Annotations: ${manualData.annotations?.length || 0}`);
  console.log(`   Side Notes: ${manualData.sideNotes?.length || 0}`);

  const manualStart = Date.now();
  const manualResult = await manualEngine.generate(manualData);
  console.log(`   Generated in ${Date.now() - manualStart}ms`);
  console.log(`   SVG size: ${manualResult.width}x${manualResult.height}`);

  // Save manual mode output
  const manualSvgPath = join(outputDir, 'unified-manual.svg');
  writeFileSync(manualSvgPath, manualResult.svg, 'utf-8');
  console.log(`   Saved: ${manualSvgPath}`);

  // =========================================================================
  // DEMO 3: RELATIVE MODE (Percentage-based)
  // =========================================================================
  console.log('\n📊 DEMO 3: RELATIVE MODE (Percentage-based positioning)');
  console.log('--------------------------------------------------------');
  
  const relativeEngine = new UnifiedFlowchartEngine({
    mode: 'relative',
    width: 580,
    height: 720,
    padding: 40,
  });

  const relativeData = createRelativeTrustStructure();
  console.log(`   Nodes: ${relativeData.nodes.length}`);
  console.log(`   Edges: ${relativeData.edges.length}`);
  console.log(`   Positioning: Percentage-based (xPercent, yPercent)`);

  const relativeStart = Date.now();
  const relativeResult = await relativeEngine.generate(relativeData);
  console.log(`   Generated in ${Date.now() - relativeStart}ms`);
  console.log(`   SVG size: ${relativeResult.width}x${relativeResult.height}`);

  // Save relative mode output
  const relativeSvgPath = join(outputDir, 'unified-relative.svg');
  writeFileSync(relativeSvgPath, relativeResult.svg, 'utf-8');
  console.log(`   Saved: ${relativeSvgPath}`);

  // =========================================================================
  // DEMO 4: ANCHOR MODE (Relative to other nodes)
  // =========================================================================
  console.log('\n📊 DEMO 4: ANCHOR MODE (Relative to other nodes)');
  console.log('-------------------------------------------------');
  
  const anchorEngine = new UnifiedFlowchartEngine({
    mode: 'relative',  // Uses same resolver
    width: 580,
    height: 720,
    padding: 40,
  });

  const anchorData = createAnchorTrustStructure();
  console.log(`   Nodes: ${anchorData.nodes.length}`);
  console.log(`   Edges: ${anchorData.edges.length}`);
  console.log(`   Positioning: Anchor-based (anchorId + offset)`);

  const anchorStart = Date.now();
  const anchorResult = await anchorEngine.generate(anchorData);
  console.log(`   Generated in ${Date.now() - anchorStart}ms`);
  console.log(`   SVG size: ${anchorResult.width}x${anchorResult.height}`);

  // Save anchor mode output
  const anchorSvgPath = join(outputDir, 'unified-anchor.svg');
  writeFileSync(anchorSvgPath, anchorResult.svg, 'utf-8');
  console.log(`   Saved: ${anchorSvgPath}`);

  // =========================================================================
  // Generate comparison HTML
  // =========================================================================
  console.log('\n📄 Generating comparison HTML...');
  
  const htmlPath = join(outputDir, 'unified-comparison.html');
  const html = `<!DOCTYPE html>
<html>
<head>
  <title>Unified Flowchart Engine - Mode Comparison</title>
  <style>
    body {
      font-family: Inter, -apple-system, sans-serif;
      margin: 0;
      padding: 40px;
      background: #f5f5f5;
    }
    h1 {
      text-align: center;
      color: #2D9B9B;
      margin-bottom: 10px;
    }
    .subtitle {
      text-align: center;
      color: #6B7280;
      margin-bottom: 40px;
    }
    .comparison {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 40px;
      max-width: 1400px;
      margin: 0 auto;
    }
    .panel {
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      padding: 30px;
    }
    .panel h2 {
      text-align: center;
      color: #374151;
      margin-bottom: 20px;
      font-size: 18px;
    }
    .mode-badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
      margin-left: 10px;
    }
    .auto { background: #DBEAFE; color: #1D4ED8; }
    .manual { background: #D1FAE5; color: #047857; }
    .features {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      justify-content: center;
      margin-bottom: 20px;
    }
    .feature {
      background: #F3F4F6;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 11px;
      color: #374151;
    }
    svg {
      display: block;
      margin: 0 auto;
      max-width: 100%;
    }
    .notes {
      margin-top: 20px;
      padding: 15px;
      background: #FFFBEB;
      border-radius: 8px;
      font-size: 12px;
      color: #92400E;
    }
    .summary {
      max-width: 1400px;
      margin: 40px auto 0;
      background: white;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }
    .summary h3 {
      color: #374151;
      margin-bottom: 15px;
    }
    .summary table {
      width: 100%;
      border-collapse: collapse;
    }
    .summary th, .summary td {
      padding: 10px 15px;
      text-align: left;
      border-bottom: 1px solid #E5E7EB;
    }
    .summary th {
      background: #F9FAFB;
      font-weight: 600;
    }
    .check { color: #10B981; }
    .cross { color: #EF4444; }
  </style>
</head>
<body>
  <h1>Unified Flowchart Engine</h1>
  <p class="subtitle">Comparison: AUTO vs MANUAL modes</p>
  
  <div class="comparison">
    <div class="panel">
      <h2>AUTO Mode <span class="mode-badge auto">Elkjs Layout</span></h2>
      <div class="features">
        <span class="feature">✓ Automatic positioning</span>
        <span class="feature">✓ Edge routing</span>
        <span class="feature">✓ Crossing minimization</span>
      </div>
      ${autoResult.svg}
      <div class="notes">
        <strong>Best for:</strong> Dynamic data, quick prototyping, when exact positioning doesn't matter.
      </div>
    </div>
    
    <div class="panel">
      <h2>MANUAL Mode <span class="mode-badge manual">Pixel-Perfect</span></h2>
      <div class="features">
        <span class="feature">✓ Exact coordinates</span>
        <span class="feature">✓ Custom paths</span>
        <span class="feature">✓ Design matching</span>
      </div>
      ${manualResult.svg}
      <div class="notes">
        <strong>Best for:</strong> Matching specific designs, PDF reports, when pixel-perfect output is required.
      </div>
    </div>
  </div>
  
  <div class="summary">
    <h3>Feature Comparison</h3>
    <table>
      <thead>
        <tr>
          <th>Feature</th>
          <th>AUTO Mode</th>
          <th>MANUAL Mode</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Automatic node positioning</td>
          <td class="check">✓</td>
          <td class="cross">✗ (explicit positions)</td>
        </tr>
        <tr>
          <td>Automatic edge routing</td>
          <td class="check">✓</td>
          <td class="cross">✗ (explicit paths)</td>
        </tr>
        <tr>
          <td>Pixel-perfect control</td>
          <td class="cross">✗</td>
          <td class="check">✓</td>
        </tr>
        <tr>
          <td>Separators</td>
          <td class="check">✓</td>
          <td class="check">✓</td>
        </tr>
        <tr>
          <td>Annotations</td>
          <td class="check">✓</td>
          <td class="check">✓</td>
        </tr>
        <tr>
          <td>Side Notes</td>
          <td class="check">✓</td>
          <td class="check">✓</td>
        </tr>
        <tr>
          <td>Edge labels (50% badges)</td>
          <td class="check">✓</td>
          <td class="check">✓</td>
        </tr>
        <tr>
          <td>Custom edge paths</td>
          <td class="cross">✗</td>
          <td class="check">✓ (T-junctions, etc.)</td>
        </tr>
        <tr>
          <td>Design matching</td>
          <td>~70% match</td>
          <td>~99% match</td>
        </tr>
      </tbody>
    </table>
  </div>
</body>
</html>`;
  
  writeFileSync(htmlPath, html, 'utf-8');
  console.log(`   Saved: ${htmlPath}`);

  console.log('\n🎉 Demo complete!');
  console.log('\nUsage Guide:');
  console.log('  • Use AUTO mode for dynamic flowcharts with automatic layout');
  console.log('  • Use MANUAL mode when you need pixel-perfect design matching');
  console.log('  • Use HYBRID mode for auto-layout with manual position overrides');
}

main().catch(console.error);
