/**
 * API Client Examples for Report Builder
 *
 * This file demonstrates how to interact with the Report Builder
 * REST API from a client application.
 */

import { writeFileSync } from "fs";

// =============================================================================
// Configuration
// =============================================================================

const API_BASE_URL = process.env.API_URL || "http://localhost:3000";

// =============================================================================
// Helper Functions
// =============================================================================

/**
 * Make an API request with proper headers
 */
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: response.statusText }));
    throw new Error(`API Error: ${error.message || response.statusText}`);
  }

  return response.json();
}

/**
 * Download PDF from API
 */
async function downloadPdf(endpoint: string, body?: object): Promise<Buffer> {
  const url = `${API_BASE_URL}${endpoint}`;
  const response = await fetch(url, {
    method: body ? "POST" : "GET",
    headers: {
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`PDF Generation Error: ${error}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

// =============================================================================
// Example 1: Check API Health
// =============================================================================

async function checkHealth(): Promise<void> {
  console.log("🏥 Checking API health...");

  interface HealthResponse {
    status: string;
    timestamp: string;
  }

  const health = await apiRequest<HealthResponse>("/health");
  console.log("Health check:", health);

  // Check readiness
  const ready = await apiRequest<HealthResponse>("/health/ready");
  console.log("Readiness check:", ready);

  // Get app info
  interface InfoResponse {
    success: boolean;
    data: {
      name: string;
      version: string;
      environment: string;
    };
  }

  const info = await apiRequest<InfoResponse>("/health/info");
  console.log("App info:", info.data);
}

// =============================================================================
// Example 2: List Available Templates
// =============================================================================

async function listTemplates(): Promise<void> {
  console.log("📋 Fetching available templates...");

  interface TemplatesResponse {
    success: boolean;
    data: {
      templates: string[];
    };
  }

  const response = await apiRequest<TemplatesResponse>("/api/pdf/templates");
  console.log("Available templates:", response.data.templates);
}

// =============================================================================
// Example 3: List and Get Sample Blueprints
// =============================================================================

async function exploreSamples(): Promise<void> {
  console.log("📝 Exploring sample blueprints...");

  // List available samples
  interface SamplesListResponse {
    success: boolean;
    data: {
      samples: string[];
    };
  }

  const samples = await apiRequest<SamplesListResponse>("/api/pdf/samples");
  console.log("Available samples:", samples.data.samples);

  // Get a specific sample blueprint
  interface SampleResponse {
    success: boolean;
    data: {
      type: string;
      blueprint: object;
    };
  }

  const reportSample = await apiRequest<SampleResponse>("/api/pdf/samples/report");
  console.log("Report sample blueprint ID:", (reportSample.data.blueprint as any).id);
}

// =============================================================================
// Example 4: Validate a Blueprint
// =============================================================================

async function validateBlueprint(): Promise<void> {
  console.log("✅ Validating a blueprint...");

  const blueprint = {
    id: "validation-test",
    version: "1.0.0",
    type: "report",
    metadata: {
      title: "Test Report",
      author: "Test User",
    },
    content: {
      showCover: true,
      sections: [
        { type: "heading", level: 1, text: "Introduction" },
        { type: "paragraph", text: "This is a test document." },
      ],
    },
  };

  interface ValidationResponse {
    success: boolean;
    data: {
      valid: boolean;
      errors: Array<{ path: string; message: string; code: string }>;
      warnings: Array<{ path: string; message: string }>;
    };
  }

  const result = await apiRequest<ValidationResponse>("/api/pdf/validate", {
    method: "POST",
    body: JSON.stringify(blueprint),
  });

  console.log("Validation result:", {
    valid: result.data.valid,
    errorCount: result.data.errors.length,
    warningCount: result.data.warnings.length,
  });

  if (!result.data.valid) {
    console.log("Errors:", result.data.errors);
  }
}

// =============================================================================
// Example 5: Generate PDF from Sample
// =============================================================================

async function generateSamplePdf(): Promise<void> {
  console.log("📄 Generating PDF from sample...");

  const buffer = await downloadPdf("/api/pdf/samples/report/generate");
  writeFileSync("./output/api-sample-report.pdf", buffer);
  console.log("✅ Sample PDF saved to ./output/api-sample-report.pdf");
}

// =============================================================================
// Example 6: Generate Custom PDF
// =============================================================================

async function generateCustomPdf(): Promise<void> {
  console.log("📄 Generating custom PDF...");

  const blueprint = {
    id: "api-custom-001",
    version: "1.0.0",
    type: "report",
    metadata: {
      title: "API Generated Report",
      subtitle: "Created via REST API",
      author: "API Client",
      date: new Date().toLocaleDateString(),
      pageSize: "A4",
    },
    content: {
      showCover: true,
      companyName: "API Test Corp",
      executiveSummary: "This report was generated programmatically via the REST API.",
      sections: [
        {
          type: "heading",
          level: 1,
          text: "API Integration",
          id: "api-integration",
        },
        {
          type: "paragraph",
          text:
            "This document demonstrates the PDF generation capabilities " +
            "of the Report Builder API. You can create complex documents " +
            "by sending JSON blueprints to the /api/pdf/generate endpoint.",
        },
        {
          type: "callout",
          variant: "info",
          title: "REST API",
          text: "The API supports validation, template listing, and PDF generation.",
        },
        {
          type: "heading",
          level: 2,
          text: "Supported Features",
          id: "features",
        },
        {
          type: "list",
          items: [
            "Multiple document templates (Report, Dashboard, Invoice, DataTable)",
            "Blueprint validation before generation",
            "Custom theming and branding",
            "Tables with automatic pagination",
            "Diagrams and charts",
            "Table of contents generation",
          ],
          ordered: false,
        },
        {
          type: "spacer",
          size: "lg",
        },
        {
          type: "heading",
          level: 2,
          text: "Sample Metrics",
          id: "metrics",
        },
        {
          type: "metrics",
          items: [
            {
              label: "API Requests",
              value: 1250,
              change: 25,
              changeType: "increase",
              format: "number",
            },
            {
              label: "Success Rate",
              value: 99.8,
              format: "percent",
            },
            {
              label: "Avg Response Time",
              value: 250,
              format: "number",
            },
          ],
          columns: 3,
        },
      ],
    },
  };

  const buffer = await downloadPdf("/api/pdf/generate", blueprint);
  writeFileSync("./output/api-custom-report.pdf", buffer);
  console.log("✅ Custom PDF saved to ./output/api-custom-report.pdf");
}

// =============================================================================
// Example 7: Generate Invoice via API
// =============================================================================

async function generateInvoice(): Promise<void> {
  console.log("🧾 Generating invoice via API...");

  const blueprint = {
    id: "api-invoice-001",
    version: "1.0.0",
    type: "invoice",
    metadata: {
      title: "Invoice",
      invoiceNumber: "API-INV-001",
      date: new Date().toLocaleDateString(),
    },
    content: {
      invoiceNumber: "API-INV-001",
      issueDate: new Date().toLocaleDateString(),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString(),
      status: "pending",
      from: {
        name: "Your Company",
        address: ["123 Main Street", "City, State 12345"],
        email: "billing@yourcompany.com",
      },
      to: {
        name: "Client Company",
        address: ["456 Client Ave", "Client City, State 67890"],
        email: "accounts@client.com",
      },
      items: [
        { description: "Consulting Services", quantity: 10, unitPrice: 150, total: 1500 },
        { description: "Software License", quantity: 1, unitPrice: 500, total: 500 },
      ],
      subtotal: 2000,
      tax: 200,
      taxRate: 10,
      total: 2200,
      currency: "USD",
      notes: "Thank you for your business!",
    },
  };

  const buffer = await downloadPdf("/api/pdf/generate", blueprint);
  writeFileSync("./output/api-invoice.pdf", buffer);
  console.log("✅ Invoice saved to ./output/api-invoice.pdf");
}

// =============================================================================
// Example 8: Error Handling
// =============================================================================

async function demonstrateErrorHandling(): Promise<void> {
  console.log("⚠️ Demonstrating error handling...");

  // Try to validate an invalid blueprint
  const invalidBlueprint = {
    id: "invalid",
    // Missing required fields
  };

  try {
    await apiRequest("/api/pdf/validate", {
      method: "POST",
      body: JSON.stringify(invalidBlueprint),
    });
  } catch (error) {
    console.log("Expected validation error:", (error as Error).message);
  }

  // Try to get a non-existent sample
  try {
    await apiRequest("/api/pdf/samples/nonexistent");
  } catch (error) {
    console.log("Expected not found error:", (error as Error).message);
  }
}

// =============================================================================
// TypeScript API Client Class
// =============================================================================

/**
 * Report Builder API Client
 *
 * A reusable class for interacting with the Report Builder API.
 */
export class ReportBuilderClient {
  private baseUrl: string;

  constructor(baseUrl: string = "http://localhost:3000") {
    this.baseUrl = baseUrl;
  }

  /**
   * Check if the API is healthy
   */
  async isHealthy(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/health`);
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * Get available templates
   */
  async getTemplates(): Promise<string[]> {
    const response = await fetch(`${this.baseUrl}/api/pdf/templates`);
    const data = await response.json();
    return data.data.templates;
  }

  /**
   * Validate a blueprint
   */
  async validate(blueprint: object): Promise<{
    valid: boolean;
    errors: Array<{ path: string; message: string; code: string }>;
    warnings: Array<{ path: string; message: string }>;
  }> {
    const response = await fetch(`${this.baseUrl}/api/pdf/validate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(blueprint),
    });
    const data = await response.json();
    return data.data;
  }

  /**
   * Generate a PDF from a blueprint
   */
  async generatePdf(blueprint: object): Promise<Buffer> {
    const response = await fetch(`${this.baseUrl}/api/pdf/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(blueprint),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`PDF generation failed: ${error}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  }

  /**
   * Get a sample blueprint
   */
  async getSample(type: "report" | "dashboard" | "invoice"): Promise<object> {
    const response = await fetch(`${this.baseUrl}/api/pdf/samples/${type}`);
    const data = await response.json();
    return data.data.blueprint;
  }

  /**
   * Generate a PDF from a sample blueprint
   */
  async generateSamplePdf(type: "report" | "dashboard" | "invoice"): Promise<Buffer> {
    const response = await fetch(`${this.baseUrl}/api/pdf/samples/${type}/generate`, {
      method: "POST",
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Sample PDF generation failed: ${error}`);
    }

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  }
}

// =============================================================================
// Main Execution
// =============================================================================

async function main(): Promise<void> {
  console.log("🚀 Report Builder - API Client Examples\n");
  console.log("==========================================\n");

  try {
    // Create output directory
    const { mkdirSync } = await import("fs");
    mkdirSync("./output", { recursive: true });

    // Run examples
    await checkHealth();
    console.log("");

    await listTemplates();
    console.log("");

    await exploreSamples();
    console.log("");

    await validateBlueprint();
    console.log("");

    await generateSamplePdf();
    console.log("");

    await generateCustomPdf();
    console.log("");

    await generateInvoice();
    console.log("");

    await demonstrateErrorHandling();
    console.log("");

    // Demonstrate the client class
    console.log("📦 Using ReportBuilderClient class...");
    const client = new ReportBuilderClient(API_BASE_URL);

    if (await client.isHealthy()) {
      const templates = await client.getTemplates();
      console.log("Templates via client:", templates);
    }

    console.log("==========================================");
    console.log("✅ All API examples completed successfully!");
  } catch (error) {
    console.error("❌ Error running API examples:", error);
    console.log("\n💡 Make sure the API server is running: npm run dev");
    process.exit(1);
  }
}

// Run if executed directly
main().catch(console.error);
