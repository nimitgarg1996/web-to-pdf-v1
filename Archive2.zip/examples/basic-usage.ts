/**
 * Basic Usage Examples for Report Builder
 *
 * This file demonstrates how to use the Report Builder factory
 * to generate PDFs programmatically.
 */

import { createDocument, createDocumentWithTheme, validateBlueprint } from "../src/factories/index.js";
import { renderToStream, renderToBuffer } from "@react-pdf/renderer";
import { createWriteStream, writeFileSync } from "fs";
import type { Blueprint, ReportBlueprint, InvoiceBlueprint, DashboardBlueprint } from "../src/blueprints/types.js";

// =============================================================================
// Example 1: Generate a Simple Report
// =============================================================================

async function generateSimpleReport(): Promise<void> {
  console.log("📄 Generating simple report...");

  const blueprint: ReportBlueprint = {
    id: "example-report-001",
    version: "1.0.0",
    type: "report",
    metadata: {
      title: "Quarterly Sales Report",
      subtitle: "Q4 2025",
      author: "Analytics Team",
      date: "January 2026",
      pageSize: "A4",
      orientation: "portrait",
    },
    content: {
      showCover: true,
      showToc: true,
      companyName: "Acme Corporation",
      companyInfo: ["123 Business Ave", "New York, NY 10001"],
      executiveSummary:
        "This report summarizes the sales performance for Q4 2025. " +
        "Key highlights include a 15% revenue increase and expansion into 3 new markets.",
      sections: [
        {
          type: "heading",
          level: 1,
          text: "Sales Overview",
          id: "sales-overview",
        },
        {
          type: "paragraph",
          text:
            "Our sales team achieved exceptional results this quarter, " +
            "exceeding targets by 12% across all regions.",
        },
        {
          type: "metrics",
          items: [
            {
              label: "Total Revenue",
              value: 2500000,
              change: 15,
              changeType: "increase",
              format: "currency",
            },
            {
              label: "New Customers",
              value: 342,
              change: 23,
              changeType: "increase",
              format: "number",
            },
            {
              label: "Customer Retention",
              value: 94.5,
              change: 2.1,
              changeType: "increase",
              format: "percent",
            },
          ],
          columns: 3,
        },
        {
          type: "spacer",
          size: "lg",
        },
        {
          type: "heading",
          level: 2,
          text: "Regional Performance",
          id: "regional-performance",
        },
        {
          type: "table",
          columns: [
            { key: "region", header: "Region", width: "30%" },
            { key: "revenue", header: "Revenue", align: "right", format: "currency", width: "25%" },
            { key: "growth", header: "Growth", align: "right", format: "percent", width: "20%" },
            { key: "target", header: "Target %", align: "right", format: "percent", width: "25%" },
          ],
          data: [
            { region: "North America", revenue: 1200000, growth: 18.5, target: 112 },
            { region: "Europe", revenue: 800000, growth: 12.3, target: 105 },
            { region: "Asia Pacific", revenue: 500000, growth: 25.7, target: 128 },
          ],
          striped: true,
          showHeader: true,
        },
        {
          type: "callout",
          variant: "success",
          title: "Key Achievement",
          text: "Asia Pacific region exceeded growth targets by 28%, making it our fastest-growing market.",
        },
      ],
    },
  };

  // Validate the blueprint first
  const validation = validateBlueprint(blueprint);
  if (!validation.valid) {
    console.error("❌ Blueprint validation failed:", validation.errors);
    return;
  }

  // Create the document
  const doc = createDocument({ blueprint });

  // Render to stream and save to file
  const stream = await renderToStream(doc);
  const output = createWriteStream("./output/quarterly-report.pdf");
  stream.pipe(output);

  output.on("finish", () => {
    console.log("✅ Report saved to ./output/quarterly-report.pdf");
  });
}

// =============================================================================
// Example 2: Generate an Invoice
// =============================================================================

async function generateInvoice(): Promise<void> {
  console.log("🧾 Generating invoice...");

  const blueprint: InvoiceBlueprint = {
    id: "invoice-2026-001",
    version: "1.0.0",
    type: "invoice",
    metadata: {
      title: "Invoice",
      invoiceNumber: "INV-2026-001",
      date: "January 28, 2026",
      dueDate: "February 28, 2026",
      pageSize: "A4",
    },
    content: {
      invoiceNumber: "INV-2026-001",
      issueDate: "January 28, 2026",
      dueDate: "February 28, 2026",
      status: "pending",
      from: {
        name: "Acme Corporation",
        address: ["123 Business Avenue", "Suite 500", "New York, NY 10001"],
        email: "billing@acme.com",
        phone: "+1 (555) 123-4567",
      },
      to: {
        name: "Widget Industries",
        address: ["456 Commerce Street", "Building B", "Los Angeles, CA 90210"],
        email: "accounts@widgets.com",
        phone: "+1 (555) 987-6543",
      },
      items: [
        {
          description: "Enterprise Software License",
          quantity: 1,
          unitPrice: 5000,
          total: 5000,
        },
        {
          description: "Implementation Services",
          quantity: 40,
          unitPrice: 150,
          total: 6000,
        },
        {
          description: "Training Sessions",
          quantity: 8,
          unitPrice: 500,
          total: 4000,
        },
        {
          description: "Annual Support Plan",
          quantity: 1,
          unitPrice: 2400,
          total: 2400,
        },
      ],
      subtotal: 17400,
      tax: 1740,
      taxRate: 10,
      total: 19140,
      currency: "USD",
      notes: "Payment is due within 30 days. Please include the invoice number in your payment reference.",
      paymentTerms: "Net 30",
      paymentMethods: ["Bank Transfer", "Credit Card", "Check"],
    },
  };

  const doc = createDocument({ blueprint });
  const buffer = await renderToBuffer(doc);
  writeFileSync("./output/invoice.pdf", buffer);
  console.log("✅ Invoice saved to ./output/invoice.pdf");
}

// =============================================================================
// Example 3: Generate a Dashboard Report
// =============================================================================

async function generateDashboard(): Promise<void> {
  console.log("📊 Generating dashboard...");

  const blueprint: DashboardBlueprint = {
    id: "dashboard-001",
    version: "1.0.0",
    type: "dashboard",
    metadata: {
      title: "Executive Dashboard",
      subtitle: "Real-time Business Metrics",
      date: "January 2026",
      pageSize: "A4",
      orientation: "landscape",
    },
    content: {
      title: "Executive Dashboard",
      subtitle: "Key Performance Indicators",
      dateRange: "January 1-28, 2026",
      metrics: [
        {
          label: "Total Revenue",
          value: 1250000,
          change: 12.5,
          changeType: "increase",
          format: "currency",
        },
        {
          label: "Active Users",
          value: 45230,
          change: 8.3,
          changeType: "increase",
          format: "number",
        },
        {
          label: "Conversion Rate",
          value: 3.42,
          change: 0.5,
          changeType: "increase",
          format: "percent",
        },
        {
          label: "Churn Rate",
          value: 2.1,
          change: -0.3,
          changeType: "decrease",
          format: "percent",
        },
      ],
      charts: [],
      tables: [
        {
          title: "Top Products",
          columns: [
            { key: "product", header: "Product", width: "40%" },
            { key: "sales", header: "Sales", align: "right", width: "30%" },
            { key: "growth", header: "Growth", align: "right", width: "30%" },
          ],
          data: [
            { product: "Enterprise Suite", sales: "$450,000", growth: "+15%" },
            { product: "Professional Plan", sales: "$320,000", growth: "+22%" },
            { product: "Starter Pack", sales: "$180,000", growth: "+8%" },
          ],
        },
      ],
    },
  };

  const doc = createDocument({ blueprint });
  const stream = await renderToStream(doc);
  const output = createWriteStream("./output/dashboard.pdf");
  stream.pipe(output);

  output.on("finish", () => {
    console.log("✅ Dashboard saved to ./output/dashboard.pdf");
  });
}

// =============================================================================
// Example 4: Custom Theming
// =============================================================================

async function generateWithCustomTheme(): Promise<void> {
  console.log("🎨 Generating report with custom theme...");

  const blueprint: ReportBlueprint = {
    id: "themed-report",
    version: "1.0.0",
    type: "report",
    metadata: {
      title: "Branded Report",
      subtitle: "With Custom Theme",
      author: "Design Team",
    },
    content: {
      showCover: true,
      sections: [
        { type: "heading", level: 1, text: "Custom Themed Report" },
        {
          type: "paragraph",
          text: "This report uses a custom theme with different colors and typography.",
        },
        {
          type: "callout",
          variant: "info",
          title: "Theme Applied",
          text: "Notice the custom brand colors used throughout this document.",
        },
      ],
    },
  };

  // Custom theme overrides
  const customTheme = {
    colors: {
      palette: {
        brand: {
          50: "#fff5f5",
          100: "#ffe3e3",
          200: "#ffc9c9",
          300: "#ffa8a8",
          400: "#ff8787",
          500: "#ff6b6b", // Primary brand color - coral red
          600: "#fa5252",
          700: "#f03e3e",
          800: "#e03131",
          900: "#c92a2a",
        },
      },
      semantic: {
        text: {
          primary: "#212529",
          secondary: "#495057",
        },
        background: {
          primary: "#ffffff",
          secondary: "#f8f9fa",
        },
      },
    },
    typography: {
      fontFamilies: {
        primary: "Helvetica",
        secondary: "Helvetica-Bold",
        mono: "Courier",
      },
    },
  };

  const doc = createDocumentWithTheme({
    blueprint,
    theme: customTheme,
  });

  const buffer = await renderToBuffer(doc);
  writeFileSync("./output/themed-report.pdf", buffer);
  console.log("✅ Themed report saved to ./output/themed-report.pdf");
}

// =============================================================================
// Example 5: Validation Before Generation
// =============================================================================

function demonstrateValidation(): void {
  console.log("✅ Demonstrating blueprint validation...");

  // Valid blueprint
  const validBlueprint: Blueprint = {
    id: "valid-001",
    version: "1.0.0",
    type: "report",
    metadata: {
      title: "Valid Report",
    },
    content: {
      sections: [],
    },
  };

  const validResult = validateBlueprint(validBlueprint);
  console.log("Valid blueprint result:", {
    valid: validResult.valid,
    errors: validResult.errors.length,
    warnings: validResult.warnings.length,
  });

  // Invalid blueprint (missing required fields)
  const invalidBlueprint = {
    id: "invalid-001",
    // Missing: version, type, metadata, content
  };

  const invalidResult = validateBlueprint(invalidBlueprint as Blueprint);
  console.log("Invalid blueprint result:", {
    valid: invalidResult.valid,
    errors: invalidResult.errors,
  });
}

// =============================================================================
// Main Execution
// =============================================================================

async function main(): Promise<void> {
  console.log("🚀 Report Builder - Basic Usage Examples\n");
  console.log("=========================================\n");

  try {
    // Create output directory
    const { mkdirSync } = await import("fs");
    mkdirSync("./output", { recursive: true });

    // Run examples
    demonstrateValidation();
    console.log("");

    await generateSimpleReport();
    console.log("");

    await generateInvoice();
    console.log("");

    await generateDashboard();
    console.log("");

    await generateWithCustomTheme();
    console.log("");

    console.log("=========================================");
    console.log("✅ All examples completed successfully!");
  } catch (error) {
    console.error("❌ Error running examples:", error);
    process.exit(1);
  }
}

// Run if executed directly
main().catch(console.error);
