/**
 * Estate Planning Report Demo - Puppeteer Version
 * 
 * This demo generates a pixel-perfect PDF using Puppeteer
 * instead of React-PDF for better CSS support.
 */

import { PuppeteerPdfService } from '../src/services/PuppeteerPdfService';
import { EstatePlanningBlueprint } from '../src/blueprints/types';
import { writeFileSync, mkdirSync, existsSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create the estate planning blueprint
const estatePlanningBlueprint: EstatePlanningBlueprint = {
  id: 'doe-family-estate-plan-puppeteer',
  version: '1.0',
  type: 'estate-planning',
  metadata: {
    title: 'John Doe & Jane Doe Estate Plan',
    subtitle: 'Comprehensive Estate Overview',
    date: 'March 2025',
    company: 'wealth.com',
  },
  theme: {
    primary: '#2D9B9B',
    secondary: '#60A5FA',
    accent: '#A78BFA',
    danger: '#EF4444',
    success: '#10B981',
    warning: '#FF8A65',
    charity: '#EC4899',
  },
  content: {
    client: {
      names: ['John Doe', 'Jane Doe'],
      trustName: 'Doe-Smith Revocable Trust',
    },
    trustStructure: {
      nodes: [
        { id: 'root', label: 'Doe-Smith Revocable Trust', icon: 'building', color: '#2D9B9B' },
        { id: 'specific-gifts-1', label: 'Specific Gifts', icon: 'gift', color: '#FF8A65' },
        { id: 'survivor-trust', label: "Survivor's Trust", icon: 'document', color: '#A78BFA' },
        { id: 'bypass-trust', label: 'Bypass Trust', icon: 'document', color: '#60A5FA' },
        { id: 'marital-trust', label: 'Marital Trust', icon: 'document', color: '#5AB2B2' },
        { id: 'specific-gifts-2', label: 'Specific Gifts', icon: 'gift', color: '#FF8A65' },
        { id: 'jane-trust', label: 'Jane Doe Trust', icon: 'document', color: '#2D7B7B' },
        { id: 'john-trust', label: 'John Doe Trust', icon: 'document', color: '#2D7B7B' },
      ],
      separators: [
        { afterNode: 'root', text: 'Death of First Spouse' },
        { afterNode: 'marital-trust', text: 'Death of Surviving Spouse' },
      ],
    },
    keyPeople: {
      documents: [
        { name: 'Trust Agreement', role: 'Trustee', designation: 'John Doe & Jane Doe' },
        { name: 'Trust Agreement', role: 'Successor Trustee', designation: 'Daniel Doe' },
        { name: 'Last Will', role: 'Executor', designation: 'Daniel Doe' },
        { name: 'Power of Attorney', role: 'Attorney-in-Fact', designation: 'Sophie Doe' },
        { name: 'Healthcare Directive', role: 'Healthcare Agent', designation: 'Sophie Doe' },
      ],
    },
    estateOverview: {
      total: 270658850,
      breakdown: [
        { value: 202994137.5, color: '#EF4444', label: 'Inside Taxable Estate' },
        { value: 67664712.5, color: '#5AB2B2', label: 'Outside Taxable Estate' },
      ],
      insideTaxable: [
        { category: 'Primary Residence', amount: 45000000 },
        { category: 'Investment Accounts', amount: 85000000 },
        { category: 'Retirement Accounts', amount: 42500000 },
        { category: 'Business Interests', amount: 25394137.5 },
        { category: 'Personal Property', amount: 5000000 },
      ],
      outsideTaxable: [
        { category: 'Life Insurance', amount: 35000000 },
        { category: 'Irrevocable Trusts', amount: 20000000 },
        { category: 'Charitable Trusts', amount: 8764712.5 },
        { category: 'ILIT Policies', amount: 4000000 },
      ],
    },
    beneficiaries: [
      { name: 'Daniel Doe', icon: 'person', iconColor: '#2D9B9B', inTrust: 50362500, outright: 1750000 },
      { name: 'Sophie Doe', icon: 'person', iconColor: '#2D9B9B', inTrust: 50362500, outright: 0 },
      { name: 'Emily Doe', icon: 'person', iconColor: '#2D9B9B', inTrust: 35000000, outright: 500000 },
      { name: 'Michael Doe', icon: 'person', iconColor: '#2D9B9B', inTrust: 35000000, outright: 500000 },
      { name: 'Heather Jones', icon: 'person', iconColor: '#2D9B9B', inTrust: 0, outright: 150000 },
      { name: 'Family Foundation', icon: 'charity', iconColor: '#EC4899', inTrust: 0, outright: 5000000 },
    ],
  },
};

async function generateEstatePlanningReport() {
  console.log('🏛️  Estate Planning Report Demo (Puppeteer)');
  console.log('==========================================\n');

  const pdfService = new PuppeteerPdfService();

  try {
    console.log('📋 Loading estate planning blueprint...');
    console.log(`   Client: ${estatePlanningBlueprint.content.client.names.join(' & ')}`);
    console.log(`   Trust: ${estatePlanningBlueprint.content.client.trustName}`);
    console.log(`   Total Estate Value: $${estatePlanningBlueprint.content.estateOverview.total.toLocaleString()}`);
    console.log(`   Beneficiaries: ${estatePlanningBlueprint.content.beneficiaries.length}`);
    console.log('');

    console.log('🚀 Launching headless browser...');
    await pdfService.initialize();

    console.log('🎨 Generating PDF with full CSS support...');
    const result = await pdfService.generatePdf(estatePlanningBlueprint, {
      format: 'A4',
      printBackground: true,
      displayHeaderFooter: true,
      headerTemplate: '<div></div>',
      footerTemplate: `
        <div style="width: 100%; font-size: 9px; padding: 10px 40px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #E5E7EB; font-family: Arial, sans-serif;">
          <span style="color: #2D9B9B; font-weight: 600;">wealth.com</span>
          <span style="color: #6B7280; max-width: 400px; text-align: right;">This information is being provided for illustrative purposes only. Please refer to your original sourcing documents for the most accurate information.</span>
        </div>
      `,
      margin: {
        top: '0.5in',
        right: '0.5in',
        bottom: '1in',
        left: '0.5in',
      },
    });

    if (!result.success || !result.buffer) {
      throw new Error(result.error || 'PDF generation failed');
    }

    console.log('💾 Writing PDF to file...');
    
    // Ensure output directory exists
    const outputDir = path.join(__dirname, '..', 'output');
    if (!existsSync(outputDir)) {
      mkdirSync(outputDir, { recursive: true });
    }

    const outputPath = path.join(outputDir, 'estate-planning-puppeteer.pdf');
    writeFileSync(outputPath, result.buffer);

    console.log('');
    console.log('✅ Estate Planning Report generated successfully!');
    console.log(`📁 Output: ${outputPath}`);
    console.log(`⏱️  Generation time: ${result.metadata?.generationTime}ms`);
    console.log('');
    console.log('Report Contents:');
    console.log('  • Cover Page');
    console.log('  • Trust Structure Flowchart');
    console.log('  • Key People & Estate Overview');
    console.log('  • Estate Value Breakdown Tables');
    console.log('  • Beneficiaries Grid (3-column)');
    console.log('');
    console.log('🎉 Demo complete!');

  } catch (error) {
    console.error('❌ Error generating PDF:', error);
  } finally {
    await pdfService.close();
  }
}

// Run the demo
generateEstatePlanningReport();
