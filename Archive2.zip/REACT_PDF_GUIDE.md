# React-PDF Complete Reference Guide

> **Library**: `@react-pdf/renderer`  
> **Website**: [https://react-pdf.org/](https://react-pdf.org/)  
> **Version**: 4.x  
> **Purpose**: React renderer for creating PDF files on the browser and server

---

## Table of Contents

1. [Installation](#installation)
2. [Quick Start](#quick-start)
3. [Core Components](#core-components)
4. [Styling](#styling)
5. [Rendering Methods](#rendering-methods)
6. [Hooks](#hooks)
7. [SVG Support](#svg-support)
8. [Fonts](#fonts)
9. [Advanced Features](#advanced-features)
10. [Best Practices](#best-practices)

---

## Installation

### Using npm

```bash
npm install @react-pdf/renderer --save
```

### Using Yarn

```bash
yarn add @react-pdf/renderer
```

### Using pnpm

```bash
pnpm add @react-pdf/renderer
```

### Using Bun

```bash
bun add @react-pdf/renderer
```

> **Note**: Since a renderer simply implements _how elements render into something_, you still need to have React to make it work (and react-dom for client-side document generation).

---

## Quick Start

```jsx
import React from "react";
import { Page, Text, View, Document, StyleSheet } from "@react-pdf/renderer";

// Create styles
const styles = StyleSheet.create({
  page: {
    flexDirection: "row",
    backgroundColor: "#E4E4E4",
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1,
  },
});

// Create Document Component
const MyDocument = () => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.section}>
        <Text>Section #1</Text>
      </View>
      <View style={styles.section}>
        <Text>Section #2</Text>
      </View>
    </Page>
  </Document>
);

export default MyDocument;
```

---

## Core Components

### Document

The root component that represents the PDF document itself. It **must** be the root of your tree element structure.

```jsx
<Document
  title="My Document"
  author="Author Name"
  subject="Document Subject"
  keywords="pdf, react, document"
  creator="My Application"
  producer="@react-pdf/renderer"
  language="en"
  pdfVersion="1.5"
  onRender={() => console.log("Rendered!")}
>
  {/* Pages go here */}
</Document>
```

#### Document Props

| Prop         | Type     | Default   | Description                                              |
| ------------ | -------- | --------- | -------------------------------------------------------- |
| `title`      | String   | undefined | Sets title info on the document's metadata               |
| `author`     | String   | undefined | Sets author info on the document's metadata              |
| `subject`    | String   | undefined | Sets subject info on the document's metadata             |
| `keywords`   | String   | undefined | Sets keywords associated info on the document's metadata |
| `creator`    | String   | undefined | Sets creator info on the document's metadata             |
| `producer`   | String   | undefined | Sets producer info on the document's metadata            |
| `language`   | String   | undefined | Sets language info on the document's metadata            |
| `pdfVersion` | String   | undefined | Sets PDF version                                         |
| `onRender`   | Function | undefined | Callback after document renders                          |

---

### Page

Represents a single page in the PDF document.

```jsx
<Page
  size="A4"
  orientation="portrait"
  style={styles.page}
  wrap={true}
  debug={false}
  dpi={72}
>
  {/* Page content */}
</Page>
```

#### Page Props

| Prop          | Type          | Default    | Description                                                                   |
| ------------- | ------------- | ---------- | ----------------------------------------------------------------------------- |
| `size`        | String/Object | "A4"       | Page size (A1-A10, B1-B10, LETTER, LEGAL, TABLOID, etc.) or { width, height } |
| `orientation` | String        | "portrait" | "portrait" or "landscape"                                                     |
| `wrap`        | Boolean       | true       | Enable page content wrapping                                                  |
| `debug`       | Boolean       | false      | Show debug borders                                                            |
| `dpi`         | Number        | 72         | Dots per inch                                                                 |
| `style`       | Object/Array  | undefined  | Page styles                                                                   |

#### Standard Page Sizes

- **A Series**: A0, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10
- **B Series**: B0, B1, B2, B3, B4, B5, B6, B7, B8, B9, B10
- **US Sizes**: LETTER, LEGAL, TABLOID, LEDGER, EXECUTIVE, FOLIO

#### Custom Page Size

```jsx
<Page size={{ width: 595, height: 842 }}>{/* Content */}</Page>
```

---

### View

A container element similar to `div` in HTML. Uses Flexbox layout by default.

```jsx
<View style={styles.container}>{/* Child elements */}</View>
```

#### View Props

| Prop     | Type         | Default   | Description                                             |
| -------- | ------------ | --------- | ------------------------------------------------------- |
| `style`  | Object/Array | undefined | View styles                                             |
| `wrap`   | Boolean      | true      | Allow content wrapping across pages                     |
| `break`  | Boolean      | false     | Force page break before this element                    |
| `fixed`  | Boolean      | false     | Fix element position across pages (for headers/footers) |
| `debug`  | Boolean      | false     | Show debug borders                                      |
| `render` | Function     | undefined | Dynamic rendering function                              |

---

### Text

Used to display text content.

```jsx
<Text style={styles.text}>Hello, World!</Text>
```

#### Text Props

| Prop                  | Type         | Default   | Description                          |
| --------------------- | ------------ | --------- | ------------------------------------ |
| `style`               | Object/Array | undefined | Text styles                          |
| `wrap`                | Boolean      | true      | Allow text wrapping                  |
| `break`               | Boolean      | false     | Force page break before this element |
| `fixed`               | Boolean      | false     | Fix element position across pages    |
| `debug`               | Boolean      | false     | Show debug borders                   |
| `hyphenationCallback` | Function     | undefined | Custom hyphenation function          |
| `render`              | Function     | undefined | Dynamic rendering function           |
| `orphans`             | Number       | undefined | Minimum lines at bottom of page      |
| `widows`              | Number       | undefined | Minimum lines at top of page         |

#### Dynamic Text with Page Numbers

```jsx
<Text
  render={({ pageNumber, totalPages }) => `Page ${pageNumber} of ${totalPages}`}
  fixed
/>
```

---

### Image

Used to display images in the PDF.

```jsx
<Image
  src="https://example.com/image.png"
  style={{ width: 200, height: 150 }}
/>
```

#### Image Props

| Prop    | Type          | Default   | Description                                                 |
| ------- | ------------- | --------- | ----------------------------------------------------------- |
| `src`   | String/Object | undefined | Image source (URL, base64, Buffer, or object with uri/data) |
| `style` | Object/Array  | undefined | Image styles                                                |
| `cache` | Boolean       | true      | Enable image caching                                        |
| `debug` | Boolean       | false     | Show debug borders                                          |
| `fixed` | Boolean       | false     | Fix element position across pages                           |

#### Image Source Formats

```jsx
// URL
<Image src="https://example.com/image.png" />

// Base64
<Image src="data:image/png;base64,..." />

// Object with headers
<Image src={{
  uri: 'https://example.com/image.png',
  method: 'GET',
  headers: { Authorization: 'Bearer token' },
  body: ''
}} />

// Buffer (Node.js)
<Image src={imageBuffer} />
```

---

### Link

Creates a hyperlink in the PDF.

```jsx
<Link src="https://react-pdf.org">Visit React-PDF</Link>
```

#### Link Props

| Prop    | Type         | Default   | Description            |
| ------- | ------------ | --------- | ---------------------- |
| `src`   | String       | undefined | URL to link to         |
| `style` | Object/Array | undefined | Link styles            |
| `wrap`  | Boolean      | true      | Allow content wrapping |
| `debug` | Boolean      | false     | Show debug borders     |

---

### Canvas

Used for custom drawing operations.

```jsx
<Canvas
  style={{ width: 200, height: 200 }}
  paint={(painter, availableWidth, availableHeight) => {
    painter
      .save()
      .moveTo(0, 0)
      .lineTo(availableWidth, availableHeight)
      .stroke("#000")
      .restore();
  }}
/>
```

---

### Note

Used for adding PDF annotations/comments.

```jsx
<Note>This is a note annotation</Note>
```

---

## Styling

React-PDF uses a CSS-like styling system with Flexbox layout support.

### StyleSheet API

```jsx
import { StyleSheet } from "@react-pdf/renderer";

const styles = StyleSheet.create({
  page: {
    backgroundColor: "#ffffff",
    padding: 30,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  section: {
    margin: 10,
    padding: 10,
    flexGrow: 1,
  },
});

// Usage
<Page style={styles.page}>
  <Text style={styles.title}>Title</Text>
  <View style={styles.section}>
    <Text>Content</Text>
  </View>
</Page>;
```

### Inline Styling

```jsx
<View
  style={{ color: "white", backgroundColor: "tomato", textAlign: "center" }}
>
  <Text>Styled content</Text>
</View>
```

### Mixed Styling (Array)

```jsx
<View style={[styles.section, { color: "blue" }]}>
  <Text>Combined styles</Text>
</View>
```

---

### Valid Units

| Unit | Description                       |
| ---- | --------------------------------- |
| `pt` | Points (default, based on 72 dpi) |
| `in` | Inches                            |
| `mm` | Millimeters                       |
| `cm` | Centimeters                       |
| `%`  | Percentage                        |
| `vw` | Viewport/page width               |
| `vh` | Viewport/page height              |

```jsx
const styles = StyleSheet.create({
  box: {
    width: "50%", // Percentage
    height: "2in", // Inches
    padding: "5mm", // Millimeters
    margin: 10, // Points (default)
    fontSize: "12pt", // Points
  },
});
```

---

### Supported CSS Properties

#### Flexbox

| Property         | Description                                                             |
| ---------------- | ----------------------------------------------------------------------- |
| `flexDirection`  | row, row-reverse, column, column-reverse                                |
| `flexWrap`       | wrap, nowrap, wrap-reverse                                              |
| `flexGrow`       | Number                                                                  |
| `flexShrink`     | Number                                                                  |
| `flexBasis`      | Number or String                                                        |
| `alignItems`     | flex-start, flex-end, center, stretch, baseline                         |
| `alignContent`   | flex-start, flex-end, center, stretch, space-between, space-around      |
| `alignSelf`      | auto, flex-start, flex-end, center, baseline, stretch                   |
| `justifyContent` | flex-start, flex-end, center, space-between, space-around, space-evenly |

#### Dimensions

| Property    | Description      |
| ----------- | ---------------- |
| `width`     | Number or String |
| `height`    | Number or String |
| `minWidth`  | Number or String |
| `maxWidth`  | Number or String |
| `minHeight` | Number or String |
| `maxHeight` | Number or String |

#### Spacing

| Property            | Description      |
| ------------------- | ---------------- |
| `margin`            | Number or String |
| `marginTop`         | Number or String |
| `marginRight`       | Number or String |
| `marginBottom`      | Number or String |
| `marginLeft`        | Number or String |
| `marginHorizontal`  | Number or String |
| `marginVertical`    | Number or String |
| `padding`           | Number or String |
| `paddingTop`        | Number or String |
| `paddingRight`      | Number or String |
| `paddingBottom`     | Number or String |
| `paddingLeft`       | Number or String |
| `paddingHorizontal` | Number or String |
| `paddingVertical`   | Number or String |

#### Positioning

| Property   | Description        |
| ---------- | ------------------ |
| `position` | relative, absolute |
| `top`      | Number or String   |
| `right`    | Number or String   |
| `bottom`   | Number or String   |
| `left`     | Number or String   |
| `zIndex`   | Number             |

#### Typography

| Property         | Description                            |
| ---------------- | -------------------------------------- |
| `fontSize`       | Number or String                       |
| `fontFamily`     | String                                 |
| `fontWeight`     | normal, bold, 100-900                  |
| `fontStyle`      | normal, italic, oblique                |
| `textAlign`      | left, right, center, justify           |
| `textDecoration` | none, underline, line-through          |
| `textTransform`  | none, uppercase, lowercase, capitalize |
| `lineHeight`     | Number or String                       |
| `letterSpacing`  | Number or String                       |
| `textOverflow`   | ellipsis                               |

#### Colors & Backgrounds

| Property          | Description                     |
| ----------------- | ------------------------------- |
| `color`           | String (hex, rgb, named colors) |
| `backgroundColor` | String                          |
| `opacity`         | Number (0-1)                    |

#### Borders

| Property                  | Description           |
| ------------------------- | --------------------- |
| `border`                  | Shorthand             |
| `borderWidth`             | Number                |
| `borderColor`             | String                |
| `borderStyle`             | solid, dashed, dotted |
| `borderTop`               | Shorthand             |
| `borderRight`             | Shorthand             |
| `borderBottom`            | Shorthand             |
| `borderLeft`              | Shorthand             |
| `borderRadius`            | Number                |
| `borderTopLeftRadius`     | Number                |
| `borderTopRightRadius`    | Number                |
| `borderBottomLeftRadius`  | Number                |
| `borderBottomRightRadius` | Number                |

#### Other

| Property          | Description                                         |
| ----------------- | --------------------------------------------------- |
| `objectFit`       | contain, cover, fill, none, scale-down (for images) |
| `objectPosition`  | String                                              |
| `overflow`        | hidden, visible                                     |
| `transform`       | String                                              |
| `transformOrigin` | String                                              |

---

### Media Queries

Apply different styles based on document context:

```jsx
const styles = StyleSheet.create({
  section: {
    width: 200,
    "@media max-width: 400": {
      width: 300,
    },
    "@media min-width: 500": {
      width: 500,
    },
    "@media orientation: landscape": {
      width: 400,
    },
  },
});
```

#### Supported Media Query Features

- `width` (min-width, max-width)
- `height` (min-height, max-height)
- `orientation` (portrait, landscape)

---

## Rendering Methods

### Server-Side: Save to File

```jsx
import ReactPDF from "@react-pdf/renderer";

ReactPDF.render(<MyDocument />, `${__dirname}/output.pdf`);
```

### Server-Side: Render to Stream

```jsx
import ReactPDF from "@react-pdf/renderer";

const stream = ReactPDF.renderToStream(<MyDocument />);

// Use with Express
app.get("/pdf", async (req, res) => {
  const stream = await ReactPDF.renderToStream(<MyDocument />);
  res.setHeader("Content-Type", "application/pdf");
  stream.pipe(res);
});
```

### Server-Side: Render to Buffer

```jsx
import ReactPDF from "@react-pdf/renderer";

const buffer = await ReactPDF.renderToBuffer(<MyDocument />);
```

### Browser: PDFViewer Component

```jsx
import { PDFViewer } from "@react-pdf/renderer";

const App = () => (
  <PDFViewer width="100%" height={600}>
    <MyDocument />
  </PDFViewer>
);
```

#### PDFViewer Props

| Prop          | Type          | Description      |
| ------------- | ------------- | ---------------- |
| `width`       | String/Number | Viewer width     |
| `height`      | String/Number | Viewer height    |
| `style`       | Object        | Container styles |
| `className`   | String        | CSS class name   |
| `showToolbar` | Boolean       | Show PDF toolbar |

### Browser: PDFDownloadLink Component

```jsx
import { PDFDownloadLink } from "@react-pdf/renderer";

const App = () => (
  <PDFDownloadLink document={<MyDocument />} fileName="document.pdf">
    {({ blob, url, loading, error }) =>
      loading ? "Loading document..." : "Download now!"
    }
  </PDFDownloadLink>
);
```

#### PDFDownloadLink Props

| Prop        | Type          | Description                 |
| ----------- | ------------- | --------------------------- |
| `document`  | Element       | The document to render      |
| `fileName`  | String        | Download file name          |
| `style`     | Object        | Link styles                 |
| `className` | String        | CSS class name              |
| `children`  | Function/Node | Render function or children |

### Browser: BlobProvider Component

```jsx
import { BlobProvider } from "@react-pdf/renderer";

const App = () => (
  <BlobProvider document={<MyDocument />}>
    {({ blob, url, loading, error }) => {
      // Do whatever you need with blob here
      return <div>There's a blob in my code!</div>;
    }}
  </BlobProvider>
);
```

---

## Hooks

### usePDF (Web Only)

A hook that enables accessing all PDF creation capabilities via a React hook API.

```jsx
import { usePDF } from "@react-pdf/renderer";

const MyComponent = () => {
  const [instance, update] = usePDF({ document: <MyDocument /> });

  if (instance.loading) return <div>Loading...</div>;
  if (instance.error) return <div>Error: {instance.error}</div>;

  return (
    <div>
      <a href={instance.url} download="document.pdf">
        Download PDF
      </a>
      <button
        onClick={() => update({ document: <MyDocument data={newData} /> })}
      >
        Update Document
      </button>
    </div>
  );
};
```

#### usePDF Parameters

| Prop       | Type    | Description             |
| ---------- | ------- | ----------------------- |
| `document` | Element | Document's root element |

#### usePDF Instance Object

| Property  | Type    | Description                                                 |
| --------- | ------- | ----------------------------------------------------------- |
| `url`     | String  | Rendered document blob URL. Null if loading or errored      |
| `blob`    | Blob    | Rendered document blob instance. Null if loading or errored |
| `loading` | Boolean | True if current render is in place                          |
| `error`   | String  | Error message if rendering failed                           |

#### usePDF Update Function

Call to trigger a new document render with updated props.

---

## SVG Support

React-PDF provides full SVG support for vector graphics.

### Basic SVG Container

```jsx
import { Svg, Line, Rect, Circle, Path } from "@react-pdf/renderer";

<Svg width={200} height={200} viewBox="0 0 200 200">
  {/* SVG elements */}
</Svg>;
```

### SVG Props

| Prop                  | Type          | Default   | Description                                  |
| --------------------- | ------------- | --------- | -------------------------------------------- |
| `width`               | String/Number | undefined | Displayed width of the rectangular viewport  |
| `height`              | String/Number | undefined | Displayed height of the rectangular viewport |
| `viewBox`             | String        | undefined | The SVG viewport coordinates                 |
| `preserveAspectRatio` | String        | undefined | How the svg fragment must be deformed        |
| `style`               | Object/Array  | undefined | SVG styles                                   |

### Available SVG Elements

#### Line

```jsx
<Line x1={0} y1={0} x2={100} y2={100} stroke="red" strokeWidth={2} />
```

| Prop          | Type          | Description                              |
| ------------- | ------------- | ---------------------------------------- |
| `x1`          | String/Number | X-axis coordinate of line starting point |
| `y1`          | String/Number | Y-axis coordinate of line starting point |
| `x2`          | String/Number | X-axis coordinate of line ending point   |
| `y2`          | String/Number | Y-axis coordinate of line ending point   |
| `stroke`      | String        | Line color                               |
| `strokeWidth` | String/Number | Line width                               |

#### Rect

```jsx
<Rect x={10} y={10} width={80} height={80} fill="blue" rx={5} ry={5} />
```

| Prop     | Type          | Description              |
| -------- | ------------- | ------------------------ |
| `x`      | String/Number | X-axis coordinate        |
| `y`      | String/Number | Y-axis coordinate        |
| `width`  | String/Number | Rectangle width          |
| `height` | String/Number | Rectangle height         |
| `rx`     | String/Number | Horizontal corner radius |
| `ry`     | String/Number | Vertical corner radius   |
| `fill`   | String        | Fill color               |
| `stroke` | String        | Stroke color             |

#### Circle

```jsx
<Circle cx={50} cy={50} r={40} fill="green" />
```

| Prop | Type          | Description              |
| ---- | ------------- | ------------------------ |
| `cx` | String/Number | X-axis center coordinate |
| `cy` | String/Number | Y-axis center coordinate |
| `r`  | String/Number | Circle radius            |

#### Ellipse

```jsx
<Ellipse cx={50} cy={50} rx={40} ry={20} fill="purple" />
```

| Prop | Type          | Description              |
| ---- | ------------- | ------------------------ |
| `cx` | String/Number | X-axis center coordinate |
| `cy` | String/Number | Y-axis center coordinate |
| `rx` | String/Number | X-axis radius            |
| `ry` | String/Number | Y-axis radius            |

#### Polygon

```jsx
<Polygon points="50,5 100,80 10,80" fill="yellow" />
```

| Prop     | Type   | Description                |
| -------- | ------ | -------------------------- |
| `points` | String | List of points (x,y pairs) |

#### Polyline

```jsx
<Polyline points="0,0 50,50 100,0" stroke="black" fill="none" />
```

| Prop     | Type   | Description                |
| -------- | ------ | -------------------------- |
| `points` | String | List of points (x,y pairs) |

#### Path

```jsx
<Path d="M 10 80 Q 95 10 180 80" stroke="black" fill="transparent" />
```

| Prop | Type   | Description                             |
| ---- | ------ | --------------------------------------- |
| `d`  | String | Path definition using SVG path commands |

#### G (Group)

```jsx
<G transform="translate(50, 50)">
  <Circle cx={0} cy={0} r={20} fill="red" />
  <Circle cx={30} cy={0} r={20} fill="blue" />
</G>
```

#### Text (SVG)

```jsx
<Svg>
  <SvgText x={50} y={50} fill="black">
    SVG Text
  </SvgText>
</Svg>
```

#### Tspan

```jsx
<SvgText x={50} y={50}>
  <Tspan fill="red">Red </Tspan>
  <Tspan fill="blue">Blue</Tspan>
</SvgText>
```

#### Defs and ClipPath

```jsx
<Svg>
  <Defs>
    <ClipPath id="clip">
      <Circle cx={50} cy={50} r={40} />
    </ClipPath>
  </Defs>
  <Rect
    x={0}
    y={0}
    width={100}
    height={100}
    fill="blue"
    clipPath="url(#clip)"
  />
</Svg>
```

#### Gradients

```jsx
<Svg>
  <Defs>
    <LinearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
      <Stop offset="0%" stopColor="red" />
      <Stop offset="100%" stopColor="blue" />
    </LinearGradient>
  </Defs>
  <Rect x={10} y={10} width={80} height={80} fill="url(#grad1)" />
</Svg>

<Svg>
  <Defs>
    <RadialGradient id="grad2" cx="50%" cy="50%" r="50%">
      <Stop offset="0%" stopColor="white" />
      <Stop offset="100%" stopColor="black" />
    </RadialGradient>
  </Defs>
  <Circle cx={50} cy={50} r={40} fill="url(#grad2)" />
</Svg>
```

### Complete SVG Example

```jsx
import React from "react";
import {
  Document,
  Page,
  Svg,
  Circle,
  Rect,
  Line,
  Path,
  G,
  Defs,
  LinearGradient,
  Stop,
} from "@react-pdf/renderer";

const SvgDocument = () => (
  <Document>
    <Page size="A4">
      <Svg width={500} height={500} viewBox="0 0 500 500">
        <Defs>
          <LinearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <Stop offset="0%" stopColor="#ff6b6b" />
            <Stop offset="100%" stopColor="#4ecdc4" />
          </LinearGradient>
        </Defs>

        {/* Background */}
        <Rect x={0} y={0} width={500} height={500} fill="#f8f9fa" />

        {/* Gradient circle */}
        <Circle cx={250} cy={250} r={150} fill="url(#gradient)" />

        {/* Grid lines */}
        <G stroke="#dee2e6" strokeWidth={1}>
          <Line x1={0} y1={250} x2={500} y2={250} />
          <Line x1={250} y1={0} x2={250} y2={500} />
        </G>

        {/* Custom path */}
        <Path
          d="M 100 350 Q 250 100 400 350"
          stroke="#495057"
          strokeWidth={3}
          fill="none"
        />
      </Svg>
    </Page>
  </Document>
);
```

---

## Fonts

### Registering Custom Fonts

```jsx
import { Font } from "@react-pdf/renderer";

// Register from URL
Font.register({
  family: "Roboto",
  src: "https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu4mxP.ttf",
});

// Register multiple weights
Font.register({
  family: "Roboto",
  fonts: [
    { src: "/fonts/Roboto-Regular.ttf", fontWeight: "normal" },
    { src: "/fonts/Roboto-Bold.ttf", fontWeight: "bold" },
    { src: "/fonts/Roboto-Italic.ttf", fontStyle: "italic" },
    {
      src: "/fonts/Roboto-BoldItalic.ttf",
      fontWeight: "bold",
      fontStyle: "italic",
    },
  ],
});

// Register from local file (Node.js)
Font.register({
  family: "CustomFont",
  src: path.join(__dirname, "fonts/CustomFont.ttf"),
});
```

### Using Registered Fonts

```jsx
const styles = StyleSheet.create({
  text: {
    fontFamily: "Roboto",
    fontSize: 14,
  },
  boldText: {
    fontFamily: "Roboto",
    fontWeight: "bold",
  },
});
```

### Emoji Support

```jsx
Font.registerEmojiSource({
  format: "png",
  url: "https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72/",
});
```

### Hyphenation

```jsx
import { Font } from "@react-pdf/renderer";

// Register hyphenation callback
Font.registerHyphenationCallback((word) => {
  // Return array of syllables
  return [word]; // No hyphenation
});

// Or use a library like 'hyphen'
import Hypher from "hypher";
import english from "hyphenation.en-us";

const hypher = new Hypher(english);

Font.registerHyphenationCallback((word) => {
  return hypher.hyphenate(word);
});
```

---

## Advanced Features

### Page Numbers and Total Pages

```jsx
<Text
  style={styles.pageNumber}
  render={({ pageNumber, totalPages }) => `${pageNumber} / ${totalPages}`}
  fixed
/>
```

### Dynamic Content

```jsx
<Text
  render={({ pageNumber, totalPages, subPageNumber, subPageTotalPages }) =>
    // Access page information for dynamic content
    pageNumber % 2 === 0 ? "Even Page" : "Odd Page"
  }
/>
```

### Fixed Headers and Footers

```jsx
const Header = () => (
  <View style={styles.header} fixed>
    <Text>Company Name</Text>
  </View>
);

const Footer = () => (
  <View style={styles.footer} fixed>
    <Text render={({ pageNumber }) => `Page ${pageNumber}`} />
  </View>
);

const MyDocument = () => (
  <Document>
    <Page size="A4">
      <Header />
      <View style={styles.content}>{/* Main content */}</View>
      <Footer />
    </Page>
  </Document>
);
```

### Page Breaks

```jsx
// Break before element
<View break>
  <Text>This starts on a new page</Text>
</View>

// Prevent breaks inside element
<View wrap={false}>
  <Text>This content won't be split across pages</Text>
</View>

// Minimum space before break
<View minPresenceAhead={100}>
  <Text>Needs at least 100pt space ahead or breaks to next page</Text>
</View>
```

### Orphans and Widows

```jsx
<Text orphans={3} widows={3}>
  Long text content that might span multiple pages...
</Text>
```

### Bookmarks / Outline

```jsx
<View bookmark="Chapter 1">
  <Text>Chapter 1 Content</Text>
</View>

<View bookmark={{ title: "Chapter 2", fit: true }}>
  <Text>Chapter 2 Content</Text>
</View>
```

### Rulers and Annotations

```jsx
// Add a note annotation
<Note>This is an annotation that appears in PDF readers</Note>
```

### Debug Mode

```jsx
// Enable debug borders on all elements
<Page debug>
  <View debug>
    <Text debug>Debug mode shows element boundaries</Text>
  </View>
</Page>
```

### Conditional Rendering Based on Page

```jsx
<Text
  render={({ pageNumber }) => {
    if (pageNumber === 1) {
      return "Welcome to the first page!";
    }
    return `You're on page ${pageNumber}`;
  }}
/>
```

---

## Best Practices

### 1. Performance Optimization

```jsx
// Memoize document component
const MyDocument = React.memo(({ data }) => (
  <Document>
    <Page size="A4">
      <Text>{data.title}</Text>
    </Page>
  </Document>
));

// Use usePDF hook for better control
const [instance, update] = usePDF({ document: <MyDocument data={data} /> });

// Only update when necessary
useEffect(() => {
  if (shouldUpdate) {
    update({ document: <MyDocument data={newData} /> });
  }
}, [shouldUpdate, newData]);
```

### 2. Organize Styles

```jsx
// styles/pdf.js
export const colors = {
  primary: "#007bff",
  secondary: "#6c757d",
  text: "#212529",
};

export const typography = StyleSheet.create({
  h1: { fontSize: 24, fontWeight: "bold", marginBottom: 10 },
  h2: { fontSize: 20, fontWeight: "bold", marginBottom: 8 },
  body: { fontSize: 12, lineHeight: 1.5 },
});

export const layout = StyleSheet.create({
  page: { padding: 30 },
  section: { marginBottom: 20 },
  row: { flexDirection: "row" },
  col: { flex: 1 },
});
```

### 3. Reusable Components

```jsx
// components/pdf/Table.jsx
const Table = ({ data, columns }) => (
  <View style={styles.table}>
    <View style={styles.tableRow}>
      {columns.map((col) => (
        <View key={col.key} style={[styles.tableCol, { width: col.width }]}>
          <Text style={styles.tableHeader}>{col.header}</Text>
        </View>
      ))}
    </View>
    {data.map((row, i) => (
      <View key={i} style={styles.tableRow}>
        {columns.map((col) => (
          <View key={col.key} style={[styles.tableCol, { width: col.width }]}>
            <Text style={styles.tableCell}>{row[col.key]}</Text>
          </View>
        ))}
      </View>
    ))}
  </View>
);
```

### 4. Error Handling

```jsx
const PDFDocument = ({ data }) => {
  const [instance, update] = usePDF({ document: <MyDocument data={data} /> });

  if (instance.error) {
    console.error("PDF Error:", instance.error);
    return <div>Error generating PDF. Please try again.</div>;
  }

  if (instance.loading) {
    return <div>Generating PDF...</div>;
  }

  return (
    <a href={instance.url} download="document.pdf">
      Download PDF
    </a>
  );
};
```

### 5. Testing

```jsx
// Use renderToBuffer for testing
import ReactPDF from "@react-pdf/renderer";

describe("MyDocument", () => {
  it("should render without errors", async () => {
    const buffer = await ReactPDF.renderToBuffer(
      <MyDocument data={testData} />,
    );
    expect(buffer).toBeDefined();
    expect(buffer.length).toBeGreaterThan(0);
  });
});
```

---

## Common Patterns

### Invoice Template

```jsx
const Invoice = ({ invoice }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      {/* Header */}
      <View style={styles.header}>
        <Image src={logo} style={styles.logo} />
        <View style={styles.companyInfo}>
          <Text style={styles.companyName}>Company Name</Text>
          <Text>123 Business Street</Text>
          <Text>City, State 12345</Text>
        </View>
      </View>

      {/* Invoice Info */}
      <View style={styles.invoiceInfo}>
        <Text style={styles.invoiceTitle}>INVOICE</Text>
        <Text>Invoice #: {invoice.number}</Text>
        <Text>Date: {invoice.date}</Text>
        <Text>Due Date: {invoice.dueDate}</Text>
      </View>

      {/* Bill To */}
      <View style={styles.billTo}>
        <Text style={styles.sectionTitle}>Bill To:</Text>
        <Text>{invoice.customer.name}</Text>
        <Text>{invoice.customer.address}</Text>
      </View>

      {/* Items Table */}
      <View style={styles.table}>
        <View style={styles.tableHeader}>
          <Text style={styles.colDescription}>Description</Text>
          <Text style={styles.colQty}>Qty</Text>
          <Text style={styles.colPrice}>Price</Text>
          <Text style={styles.colTotal}>Total</Text>
        </View>
        {invoice.items.map((item, i) => (
          <View key={i} style={styles.tableRow}>
            <Text style={styles.colDescription}>{item.description}</Text>
            <Text style={styles.colQty}>{item.quantity}</Text>
            <Text style={styles.colPrice}>${item.price.toFixed(2)}</Text>
            <Text style={styles.colTotal}>
              ${(item.quantity * item.price).toFixed(2)}
            </Text>
          </View>
        ))}
      </View>

      {/* Totals */}
      <View style={styles.totals}>
        <View style={styles.totalRow}>
          <Text>Subtotal:</Text>
          <Text>${invoice.subtotal.toFixed(2)}</Text>
        </View>
        <View style={styles.totalRow}>
          <Text>Tax ({invoice.taxRate}%):</Text>
          <Text>${invoice.tax.toFixed(2)}</Text>
        </View>
        <View style={[styles.totalRow, styles.grandTotal]}>
          <Text>Total:</Text>
          <Text>${invoice.total.toFixed(2)}</Text>
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer} fixed>
        <Text>Thank you for your business!</Text>
        <Text
          render={({ pageNumber, totalPages }) =>
            `Page ${pageNumber} of ${totalPages}`
          }
        />
      </View>
    </Page>
  </Document>
);
```

### Report with Charts (Using SVG)

```jsx
const BarChart = ({ data, width, height }) => {
  const maxValue = Math.max(...data.map((d) => d.value));
  const barWidth = width / data.length - 10;

  return (
    <Svg width={width} height={height}>
      {data.map((item, i) => {
        const barHeight = (item.value / maxValue) * (height - 30);
        const x = i * (barWidth + 10) + 5;
        const y = height - barHeight - 20;

        return (
          <G key={i}>
            <Rect
              x={x}
              y={y}
              width={barWidth}
              height={barHeight}
              fill={item.color || "#007bff"}
            />
            <SvgText
              x={x + barWidth / 2}
              y={height - 5}
              textAnchor="middle"
              fontSize={10}
            >
              {item.label}
            </SvgText>
          </G>
        );
      })}
    </Svg>
  );
};
```

---

## Troubleshooting

### Common Issues

1. **Fonts not loading**: Ensure font URLs are accessible and CORS headers are properly set.

2. **Images not appearing**: Check that image URLs are absolute and accessible. Consider using base64 for reliability.

3. **Styles not applying**: Remember that react-pdf uses Flexbox by default. Check for typos in property names (camelCase).

4. **Text overflow**: Use `textOverflow: 'ellipsis'` or ensure proper `width` constraints.

5. **Page breaks in wrong places**: Use `wrap={false}` on elements that shouldn't break, or `break` prop for forced breaks.

6. **Performance issues**: Memoize components, optimize images (size and format), and avoid unnecessary re-renders.

---

## Resources

- **Official Documentation**: [https://react-pdf.org/](https://react-pdf.org/)
- **GitHub Repository**: [https://github.com/diegomura/react-pdf](https://github.com/diegomura/react-pdf)
- **NPM Package**: [https://www.npmjs.com/package/@react-pdf/renderer](https://www.npmjs.com/package/@react-pdf/renderer)
- **REPL/Playground**: Available on the official website ("Try it out!" button)

---

_Last updated: January 2026_
