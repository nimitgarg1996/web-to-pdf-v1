/**
 * Application Entry Point
 * Starts the Express server for PDF generation
 */

import { createApp } from "./server.js";
import { serverConfig, appConfig, registerFonts } from "./config/index.js";
import { logger } from "./utils/logger.js";

/**
 * Initialize and start the server
 */
const startServer = async (): Promise<void> => {
  try {
    // Register fonts for PDF generation
    logger.debug("Registering fonts...");
    registerFonts();
    logger.debug("Fonts registered successfully");

    // Create Express application
    const app = createApp();

    // Start listening
    const server = app.listen(serverConfig.port, serverConfig.host, () => {
      logger.info(`🚀 ${appConfig.name} v${appConfig.version} is running`);
      logger.info(
        `📍 Server listening on http://${serverConfig.host}:${serverConfig.port}`,
      );
      logger.info(`🔧 Environment: ${serverConfig.env}`);
      logger.info("📋 Available endpoints:");
      logger.info("   GET  /health            - Health check");
      logger.info("   GET  /health/ready      - Readiness probe");
      logger.info("   GET  /health/live       - Liveness probe");
      logger.info("   POST /api/pdf/generate  - Generate PDF from blueprint");
      logger.info("   POST /api/pdf/validate  - Validate blueprint");
      logger.info("   GET  /api/pdf/templates - List available templates");
      logger.info("   GET  /api/pdf/samples   - List sample blueprints");
      logger.info("   GET  /api/pdf/samples/:type - Get sample blueprint");
    });

    // Graceful shutdown handling
    const gracefulShutdown = (signal: string): void => {
      logger.info(`\nReceived ${signal}. Starting graceful shutdown...`);
      
      server.close((err) => {
        if (err) {
          logger.error("Error during server shutdown:", err);
          process.exit(1);
        }
        
        logger.info("Server closed successfully");
        process.exit(0);
      });

      // Force shutdown after 10 seconds
      setTimeout(() => {
        logger.warn("Forcing shutdown after timeout");
        process.exit(1);
      }, 10000);
    };

    // Handle termination signals
    process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
    process.on("SIGINT", () => gracefulShutdown("SIGINT"));

    // Handle uncaught exceptions
    process.on("uncaughtException", (error) => {
      logger.error("Uncaught exception:", error);
      gracefulShutdown("uncaughtException");
    });

    // Handle unhandled promise rejections
    process.on("unhandledRejection", (reason, promise) => {
      logger.error("Unhandled promise rejection:", reason as Error, { promise });
    });

  } catch (error) {
    logger.error("Failed to start server:", error as Error);
    process.exit(1);
  }
};

// Start the server
startServer();
