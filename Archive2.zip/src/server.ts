/**
 * Express Server Configuration
 * Sets up the Express application with middleware and routes
 */

import express, { type Express } from "express";
import { logger } from "./utils/logger.js";
import { appConfig } from "./config/index.js";
import type { ApiResponse } from "./types/index.js";

// Import middleware
import {
  corsMiddleware,
  requestLogger,
  errorHandler,
  notFoundHandler,
  validateJsonBody,
} from "./api/middleware/index.js";

// Import routes
import { pdfRouter, healthRouter } from "./api/routes/index.js";

/**
 * Create and configure the Express application
 */
export const createApp = (): Express => {
  const app = express();

  // =========================================================================
  // Pre-route Middleware
  // =========================================================================

  // CORS middleware - must be first to handle preflight requests
  app.use(corsMiddleware);

  // Request body parsing with size limit for large blueprints
  app.use(validateJsonBody);
  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ extended: true, limit: "10mb" }));

  // Request logging
  app.use(requestLogger);

  // =========================================================================
  // Routes
  // =========================================================================

  // Health check routes - no authentication required
  app.use("/health", healthRouter);

  // PDF API routes
  app.use("/api/pdf", pdfRouter);

  // Root endpoint - API info
  app.get(
    "/",
    (
      _req,
      res: express.Response<ApiResponse<{ name: string; version: string; description: string; endpoints: Record<string, string> }>>,
    ) => {
      res.json({
        success: true,
        data: {
          name: appConfig.name,
          version: appConfig.version,
          description: appConfig.description,
          endpoints: {
            health: "/health",
            healthReady: "/health/ready",
            healthLive: "/health/live",
            healthInfo: "/health/info",
            pdfGenerate: "POST /api/pdf/generate",
            pdfValidate: "POST /api/pdf/validate",
            pdfTemplates: "GET /api/pdf/templates",
            pdfSamples: "GET /api/pdf/samples",
            pdfSampleByType: "GET /api/pdf/samples/:type",
            pdfSampleGenerate: "POST /api/pdf/samples/:type/generate",
          },
        },
      });
    },
  );

  // =========================================================================
  // Post-route Middleware
  // =========================================================================

  // 404 handler for undefined routes
  app.use(notFoundHandler);

  // Global error handler - must be last
  app.use(errorHandler);

  logger.debug("Express application configured successfully");

  return app;
};

// Export the app for testing purposes
export { express };
