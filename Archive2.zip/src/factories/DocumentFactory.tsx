/**
 * DocumentFactory
 * Main factory that transforms blueprints into React-PDF documents
 *
 * This is the core of the Blueprint → Template → Component → Primitive architecture.
 * It reads JSON blueprints and generates complete React-PDF documents.
 */

import React from "react";
import type { Theme } from "../primitives/theme.js";
import { defaultTheme, createTheme } from "../primitives/theme.js";
import type {
  Blueprint,
  ReportBlueprint,
  DashboardBlueprint,
  InvoiceBlueprint,
  DataTableBlueprint,
  EstatePlanningBlueprint,
  DocumentFactoryOptions,
  MetricItem,
  TableColumnDef,
} from "../blueprints/types.js";

// Import templates
import { ReportTemplate } from "../templates/ReportTemplate.js";
import { DashboardTemplate } from "../templates/DashboardTemplate.js";
import { InvoiceTemplate } from "../templates/InvoiceTemplate.js";
import { DataTableTemplate } from "../templates/DataTableTemplate.js";
import { EstatePlanningTemplate } from "../templates/EstatePlanningTemplate.js";

// Import template types
import type {
  DashboardMetric,
  KPISection,
  InvoiceLineItem,
  AddressInfo,
  DataTableColumn,
  DataTableFilter,
  DataTableSummary,
} from "../templates/types.js";

// Import content block renderer
import { ContentBlockRenderer, renderContentBlocks } from "./ContentBlockRenderer.js";

// ============================================================================
// Type Mappers
// ============================================================================

/**
 * Map blueprint MetricItem to template DashboardMetric
 */
function mapMetricItemToTemplateMetric(item: MetricItem): DashboardMetric {
  return {
    label: item.label,
    value: item.value,
    change: item.change,
    trend:
      item.changeType === "increase"
        ? "up"
        : item.changeType === "decrease"
        ? "down"
        : "neutral",
    unit: item.unit,
    format: item.format,
  };
}

/**
 * Map blueprint TableColumnDef to template DataTableColumn
 */
function mapColumnDefToDataTableColumn(col: TableColumnDef): DataTableColumn {
  return {
    key: col.key,
    label: col.header,
    width: col.width,
    align: col.align,
    format: col.format,
  };
}

// ============================================================================
// Report Document Creator
// ============================================================================

/**
 * Create a report document from a blueprint
 */
function createReportDocument(
  blueprint: ReportBlueprint,
  theme: Theme
): React.ReactElement {
  const { metadata, content } = blueprint;

  // Build executive summary if provided
  const executiveSummary = content.executiveSummary
    ? {
        title: "Executive Summary",
        content: [content.executiveSummary],
        highlights: [] as string[],
      }
    : undefined;

  return (
    <ReportTemplate
      title={metadata.title}
      subtitle={metadata.subtitle}
      date={metadata.date}
      author={metadata.author}
      logo={metadata.logo}
      theme={theme}
      pageSize={metadata.pageSize}
      orientation={metadata.orientation}
      showCover={content.showCover}
      showTOC={content.showToc}
      companyName={content.companyName || metadata.company}
      companyInfo={content.companyInfo}
      executiveSummary={executiveSummary}
      header={{
        title: metadata.title,
        logo: metadata.logo,
        showPageNumbers: true,
        showDate: true,
        date: metadata.date,
      }}
      footer={{
        companyName: content.companyName || metadata.company,
        showPageNumbers: true,
      }}
    >
      {renderContentBlocks(content.sections, theme)}
    </ReportTemplate>
  );
}

// ============================================================================
// Dashboard Document Creator
// ============================================================================

/**
 * Create a dashboard document from a blueprint
 */
function createDashboardDocument(
  blueprint: DashboardBlueprint,
  theme: Theme
): React.ReactElement {
  const { metadata, content } = blueprint;

  // Map metrics to template format
  const templateMetrics: DashboardMetric[] = content.metrics.map(
    mapMetricItemToTemplateMetric
  );

  // Map KPI sections to template format
  const kpiSections: KPISection[] | undefined = content.kpis?.map((kpi) => ({
    title: kpi.title,
    metrics: kpi.items.map(mapMetricItemToTemplateMetric),
  }));

  return (
    <DashboardTemplate
      title={metadata.title}
      subtitle={metadata.subtitle}
      date={metadata.date}
      author={metadata.author}
      logo={metadata.logo}
      theme={theme}
      pageSize={metadata.pageSize}
      orientation={metadata.orientation || "landscape"}
      dateRange={content.dateRange}
      metrics={templateMetrics}
      kpiSections={kpiSections}
      summary={content.summary}
      header={{
        title: metadata.title,
        logo: metadata.logo,
        showPageNumbers: true,
        showDate: true,
        date: metadata.date,
      }}
      footer={{
        companyName: metadata.company,
        showPageNumbers: true,
      }}
      gridColumns={3}
    >
      {/* Render charts as diagrams */}
      {content.charts?.map((chart, index) => (
        <ContentBlockRenderer
          key={`chart-${index}`}
          block={chart}
          theme={theme}
          index={index}
        />
      ))}
      {/* Render tables */}
      {content.tables?.map((table, index) => (
        <ContentBlockRenderer
          key={`table-${index}`}
          block={table}
          theme={theme}
          index={index}
        />
      ))}
    </DashboardTemplate>
  );
}

// ============================================================================
// Invoice Document Creator
// ============================================================================

/**
 * Create an invoice document from a blueprint
 */
function createInvoiceDocument(
  blueprint: InvoiceBlueprint,
  theme: Theme
): React.ReactElement {
  const { metadata, content } = blueprint;

  // Map address blocks to template AddressInfo
  const mapAddress = (addr: {
    name: string;
    address: string[];
    email?: string;
    phone?: string;
  }): AddressInfo => ({
    name: addr.name,
    address: addr.address,
    email: addr.email,
    phone: addr.phone,
  });

  // Map line items to template format
  const lineItems: InvoiceLineItem[] = content.lineItems.map((item) => ({
    description: item.description,
    quantity: item.quantity,
    unitPrice: item.unitPrice,
    total: item.total,
    unit: item.unit,
  }));

  // Calculate discount amount if needed
  const discountAmount = content.discount?.amount || 0;

  return (
    <InvoiceTemplate
      title={metadata.title || "Invoice"}
      logo={metadata.logo}
      theme={theme}
      pageSize={metadata.pageSize}
      orientation={metadata.orientation}
      invoiceNumber={content.invoiceNumber}
      invoiceDate={content.issueDate}
      dueDate={content.dueDate}
      from={mapAddress(content.from)}
      billTo={mapAddress(content.billTo)}
      shipTo={content.shipTo ? mapAddress(content.shipTo) : undefined}
      lineItems={lineItems}
      subtotal={content.subtotal}
      taxRate={content.tax?.rate}
      taxAmount={content.tax?.amount}
      discount={discountAmount}
      discountDescription={
        content.discount
          ? `${content.discount.value}${
              content.discount.type === "percentage" ? "%" : ""
            } discount`
          : undefined
      }
      total={content.total}
      currency={content.currency}
      payment={
        content.paymentTerms
          ? {
              terms: content.paymentTerms,
              dueDate: content.dueDate,
            }
          : undefined
      }
      notes={content.notes}
      status={content.status}
    />
  );
}

// ============================================================================
// Data Table Document Creator
// ============================================================================

/**
 * Create a data table document from a blueprint
 */
function createDataTableDocument(
  blueprint: DataTableBlueprint,
  theme: Theme
): React.ReactElement {
  const { metadata, content } = blueprint;

  // Map columns to template format
  const columns: DataTableColumn[] = content.columns.map(
    mapColumnDefToDataTableColumn
  );

  // Map filters to template format
  const filters: DataTableFilter[] | undefined = content.filters?.map((f) => ({
    label: f.label,
    value: f.value,
  }));

  // Map summary to template format
  const summaryStats: DataTableSummary[] | undefined = content.summary?.map(
    (s) => ({
      label: s.label,
      value: s.value,
      description: s.description,
    })
  );

  return (
    <DataTableTemplate
      title={metadata.title}
      subtitle={metadata.subtitle}
      description={content.description}
      date={metadata.date}
      logo={metadata.logo}
      theme={theme}
      pageSize={metadata.pageSize}
      orientation={metadata.orientation || "landscape"}
      columns={columns}
      data={content.data}
      filters={filters}
      summaryStats={summaryStats}
      currentPage={content.pagination?.page}
      totalPages={
        content.pagination
          ? Math.ceil(content.pagination.total / content.pagination.pageSize)
          : undefined
      }
      totalRecords={content.pagination?.total}
      showRowNumbers={content.showRowNumbers}
      striped={content.striped}
      header={{
        title: metadata.title,
        logo: metadata.logo,
        showPageNumbers: true,
        showDate: true,
        date: metadata.date,
      }}
      footer={{
        companyName: metadata.company,
        showPageNumbers: true,
      }}
    />
  );
}

// ============================================================================
// Estate Planning Document Creator
// ============================================================================

/**
 * Create an estate planning document from a blueprint
 */
function createEstatePlanningDocument(
  blueprint: EstatePlanningBlueprint,
  theme: Theme
): React.ReactElement {
  const { metadata, content } = blueprint;

  return (
    <EstatePlanningTemplate
      title={metadata.title}
      subtitle={metadata.subtitle}
      date={metadata.date}
      author={metadata.author}
      logo={metadata.logo}
      theme={theme}
      pageSize={metadata.pageSize}
      orientation={metadata.orientation}
      client={content.client}
      trustStructure={content.trustStructure}
      keyPeople={content.keyPeople}
      estateOverview={content.estateOverview}
      beneficiaries={content.beneficiaries}
      beneficiaryTitle={content.beneficiaryTitle}
      showCover={true}
      companyName={content.companyName || metadata.company}
      disclaimer={content.disclaimer}
    />
  );
}

// ============================================================================
// Main Factory Function
// ============================================================================

/**
 * Create a React-PDF document from a blueprint
 *
 * This is the main entry point for the factory system. It takes a blueprint
 * and optional theme, and returns a complete React-PDF document component.
 *
 * @param options - Factory options containing the blueprint and optional theme
 * @returns A React element representing the complete PDF document
 *
 * @example
 * ```tsx
 * import { createDocument } from './factories';
 * import { renderToStream } from '@react-pdf/renderer';
 *
 * const blueprint = {
 *   id: 'report-001',
 *   version: '1.0',
 *   type: 'report',
 *   metadata: { title: 'Annual Report' },
 *   content: {
 *     showCover: true,
 *     sections: [
 *       { type: 'heading', level: 1, text: 'Introduction' },
 *       { type: 'paragraph', text: 'This is the introduction...' }
 *     ]
 *   }
 * };
 *
 * const document = createDocument({ blueprint });
 * const stream = await renderToStream(document);
 * ```
 */
export function createDocument(
  options: DocumentFactoryOptions
): React.ReactElement {
  const { blueprint } = options;

  // Apply theme overrides if provided
  const theme = options.theme
    ? options.theme
    : blueprint.theme
    ? createTheme(blueprint.theme)
    : defaultTheme;

  // Route to the appropriate document creator based on blueprint type
  switch (blueprint.type) {
    case "report":
      return createReportDocument(blueprint as ReportBlueprint, theme);

    case "dashboard":
      return createDashboardDocument(blueprint as DashboardBlueprint, theme);

    case "invoice":
      return createInvoiceDocument(blueprint as InvoiceBlueprint, theme);

    case "data-table":
      return createDataTableDocument(blueprint as DataTableBlueprint, theme);

    case "estate-planning":
      return createEstatePlanningDocument(blueprint as EstatePlanningBlueprint, theme);

    default:
      // TypeScript exhaustiveness check
      const _exhaustiveCheck: never = blueprint;
      throw new Error(`Unknown blueprint type: ${(blueprint as Blueprint).type}`);
  }
}

/**
 * Create a document with a specific theme preset
 */
export function createDocumentWithTheme(
  blueprint: Blueprint,
  theme: Theme
): React.ReactElement {
  return createDocument({ blueprint, theme });
}

// ============================================================================
// Factory Utilities
// ============================================================================

/**
 * Get the document type from a blueprint
 */
export function getBlueprintType(blueprint: Blueprint): string {
  return blueprint.type;
}

/**
 * Get the template component for a blueprint type
 */
export function getTemplateForType(
  type: Blueprint["type"]
): React.ComponentType<unknown> {
  switch (type) {
    case "report":
      return ReportTemplate as React.ComponentType<unknown>;
    case "dashboard":
      return DashboardTemplate as React.ComponentType<unknown>;
    case "invoice":
      return InvoiceTemplate as React.ComponentType<unknown>;
    case "data-table":
      return DataTableTemplate as React.ComponentType<unknown>;
    case "estate-planning":
      return EstatePlanningTemplate as React.ComponentType<unknown>;
    default:
      throw new Error(`Unknown blueprint type: ${type}`);
  }
}

export default createDocument;
