/**
 * ContentBlockRenderer Component
 * Renders individual content blocks from blueprints using the appropriate components
 */

import React from "react";
import { View, Text as PDFText, Image, StyleSheet } from "@react-pdf/renderer";
import type { Theme } from "../primitives/theme.js";
import { defaultTheme } from "../primitives/theme.js";
import type { Style } from "../components/types.js";
import type {
  ContentBlock,
  HeadingBlock,
  ParagraphBlock,
  TableBlock,
  DiagramBlock,
  MetricsBlock,
  KeyValueBlock,
  ListBlock,
  ImageBlock,
  SectionBlock,
  CalloutBlock,
  SpacerBlock,
  DividerBlock,
  PageBreakBlock,
  MetricItem,
} from "../blueprints/types.js";

// Import components
import {
  Heading,
  Paragraph,
  Table,
  Diagram,
  KeyValue,
  List,
  MetricCard,
  Section,
  Callout,
  Spacer,
  Divider,
  Row,
  Box,
} from "../components/index.js";
import type { ColumnDefinition } from "../components/table/types.js";

// ============================================================================
// Props Interface
// ============================================================================

/**
 * Props for ContentBlockRenderer
 */
export interface ContentBlockRendererProps {
  /** Content block to render */
  block: ContentBlock;
  /** Theme configuration */
  theme?: Theme;
  /** Index for key generation */
  index?: number;
}

// ============================================================================
// Helper Components
// ============================================================================

/**
 * Create styles for the renderer
 */
const createStyles = (theme: Theme) =>
  StyleSheet.create({
    metricsGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginHorizontal: -6,
      marginBottom: theme.spacing.md,
    },
    metricCard2Col: {
      width: "47%",
      margin: 6,
    },
    metricCard3Col: {
      width: "30%",
      margin: 6,
    },
    metricCard4Col: {
      width: "22%",
      margin: 6,
    },
    keyValueGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginHorizontal: -8,
    },
    keyValueGridItem: {
      width: "48%",
      margin: 4,
    },
    keyValueVertical: {
      flexDirection: "column",
      gap: 8,
    },
    keyValueHorizontal: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 16,
    },
    imageWrapper: {
      marginVertical: theme.spacing.sm,
    },
    imageWrapperLeft: {
      alignItems: "flex-start",
    },
    imageWrapperCenter: {
      alignItems: "center",
    },
    imageWrapperRight: {
      alignItems: "flex-end",
    },
    imageCaption: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      textAlign: "center",
      marginTop: 4,
    },
  });

// ============================================================================
// Block Renderers
// ============================================================================

/**
 * Render a heading block
 */
function renderHeading(block: HeadingBlock, _theme: Theme): React.ReactElement {
  return (
    <Heading level={block.level}>
      {block.text}
    </Heading>
  );
}

/**
 * Render a paragraph block
 */
function renderParagraph(block: ParagraphBlock, _theme: Theme): React.ReactElement {
  return (
    <Paragraph align={block.align}>
      {block.text}
    </Paragraph>
  );
}

/**
 * Render a table block
 */
function renderTable(block: TableBlock, _theme: Theme): React.ReactElement {
  // Convert TableColumnDef to ColumnDefinition
  const columns: ColumnDefinition[] = block.columns.map((col) => ({
    key: col.key,
    header: col.header,
    width: col.width || "auto",
    align: col.align,
    headerAlign: col.headerAlign,
  }));

  // Determine variant based on block options
  let variant: "default" | "striped" | "bordered" | "minimal" = block.variant || "default";
  if (block.striped && !block.variant) {
    variant = "striped";
  } else if (block.bordered && !block.variant) {
    variant = "bordered";
  }

  return (
    <Table
      columns={columns}
      data={block.data}
      variant={variant}
      repeatHeader={block.showHeader !== false}
    />
  );
}

/**
 * Render a diagram block
 */
function renderDiagram(block: DiagramBlock, _theme: Theme): React.ReactElement {
  return (
    <Diagram
      nodes={block.nodes}
      edges={block.edges}
      width={block.width}
      height={block.height}
      showGrid={block.showGrid}
      nodeDefaults={block.nodeDefaults}
      edgeDefaults={block.edgeDefaults}
    />
  );
}

/**
 * Convert MetricItem to MetricCard props
 */
function mapMetricItemToCardProps(item: MetricItem) {
  // Format value based on format type
  let displayValue: string | number = item.value;
  if (typeof item.value === "number") {
    switch (item.format) {
      case "currency":
        displayValue = `$${item.value.toLocaleString()}`;
        break;
      case "percent":
        displayValue = `${item.value}%`;
        break;
      default:
        displayValue = item.value.toLocaleString();
    }
  }
  if (item.unit) {
    displayValue = `${displayValue}${item.unit}`;
  }

  // Build trend if change is provided
  const trend = item.change !== undefined
    ? {
        value: Math.abs(item.change),
        direction: (item.changeType === "increase" || (item.changeType === undefined && item.change > 0))
          ? "up" as const
          : "down" as const,
      }
    : undefined;

  return {
    label: item.label,
    value: displayValue,
    trend,
  };
}

/**
 * Render a metrics block
 */
function renderMetrics(block: MetricsBlock, theme: Theme): React.ReactElement {
  const styles = createStyles(theme);
  const columns = block.columns || 3;

  const getColumnStyle = () => {
    switch (columns) {
      case 2:
        return styles.metricCard2Col;
      case 4:
        return styles.metricCard4Col;
      default:
        return styles.metricCard3Col;
    }
  };

  return (
    <View style={styles.metricsGrid}>
      {block.items.map((item, idx) => (
        <View key={idx} style={getColumnStyle()}>
          <MetricCard {...mapMetricItemToCardProps(item)} />
        </View>
      ))}
    </View>
  );
}

/**
 * Render a key-value block
 */
function renderKeyValue(block: KeyValueBlock, theme: Theme): React.ReactElement {
  const styles = createStyles(theme);

  // Determine layout style
  const getContainerStyle = () => {
    switch (block.layout) {
      case "horizontal":
        return styles.keyValueHorizontal;
      case "grid":
        return styles.keyValueGrid;
      case "vertical":
      default:
        return styles.keyValueVertical;
    }
  };

  // For grid layout, wrap each item
  if (block.layout === "grid") {
    return (
      <View style={getContainerStyle()}>
        {block.items.map((item, idx) => (
          <View key={idx} style={styles.keyValueGridItem}>
            <KeyValue label={item.key} value={item.value} />
          </View>
        ))}
      </View>
    );
  }

  // For other layouts, render inline or stacked
  return (
    <View style={getContainerStyle()}>
      {block.items.map((item, idx) => (
        <KeyValue 
          key={idx} 
          label={item.key} 
          value={item.value}
          inline={block.layout === "horizontal"}
        />
      ))}
    </View>
  );
}

/**
 * Render a list block
 */
function renderList(block: ListBlock, _theme: Theme): React.ReactElement {
  // Map ordered prop to list type
  const listType = block.ordered ? "number" : "bullet";
  
  // If a custom icon is provided, use it as bullet character
  const bulletChar = block.icon || "•";

  return (
    <List
      items={block.items}
      type={listType}
      bulletChar={bulletChar}
    />
  );
}

/**
 * Render an image block
 */
function renderImage(block: ImageBlock, theme: Theme): React.ReactElement {
  const styles = createStyles(theme);

  const imageStyle: Style = {};
  if (block.width) imageStyle.width = block.width;
  if (block.height) imageStyle.height = block.height;
  if (!block.width && !block.height) {
    imageStyle.maxWidth = "100%";
  }

  // Get alignment style
  const getAlignmentStyle = () => {
    switch (block.align) {
      case "center":
        return styles.imageWrapperCenter;
      case "right":
        return styles.imageWrapperRight;
      default:
        return styles.imageWrapperLeft;
    }
  };

  return (
    <View style={[styles.imageWrapper, getAlignmentStyle()]}>
      <Image src={block.src} style={imageStyle} />
      {block.caption && (
        <PDFText style={styles.imageCaption}>{block.caption}</PDFText>
      )}
    </View>
  );
}

/**
 * Render a section block with nested children
 */
function renderSection(block: SectionBlock, theme: Theme): React.ReactElement {
  return (
    <Section title={block.title}>
      {block.children.map((child, idx) => (
        <ContentBlockRenderer key={idx} block={child} theme={theme} index={idx} />
      ))}
    </Section>
  );
}

/**
 * Render a callout block
 */
function renderCallout(block: CalloutBlock, _theme: Theme): React.ReactElement {
  return (
    <Callout variant={block.variant} title={block.title}>
      {block.text}
    </Callout>
  );
}

/**
 * Map spacer size to spacing value
 */
function mapSpacerSize(size: SpacerBlock["size"]): "xs" | "sm" | "md" | "lg" | "xl" {
  return size;
}

/**
 * Render a spacer block
 */
function renderSpacer(block: SpacerBlock, _theme: Theme): React.ReactElement {
  return <Spacer size={mapSpacerSize(block.size)} />;
}

/**
 * Render a divider block
 */
function renderDivider(block: DividerBlock, _theme: Theme): React.ReactElement {
  return (
    <Divider
      color={block.color}
      thickness={block.thickness}
    />
  );
}

/**
 * Render a page break block
 * Note: React-PDF handles page breaks differently. This creates a break hint.
 */
function renderPageBreak(_block: PageBreakBlock, _theme: Theme): React.ReactElement {
  return <View break />;
}

// ============================================================================
// Main Component
// ============================================================================

/**
 * ContentBlockRenderer component that maps blueprint content blocks to React-PDF components.
 *
 * This is the core rendering engine for the blueprint system. It takes a content block
 * definition and renders the appropriate component with the correct props.
 *
 * @example
 * ```tsx
 * // Render a heading block
 * <ContentBlockRenderer
 *   block={{ type: 'heading', level: 1, text: 'Introduction' }}
 *   theme={theme}
 * />
 *
 * // Render a table block
 * <ContentBlockRenderer
 *   block={{
 *     type: 'table',
 *     columns: [{ key: 'name', header: 'Name' }],
 *     data: [{ name: 'John' }]
 *   }}
 *   theme={theme}
 * />
 * ```
 */
export function ContentBlockRenderer({
  block,
  theme = defaultTheme,
  index = 0,
}: ContentBlockRendererProps): React.ReactElement {
  switch (block.type) {
    case "heading":
      return renderHeading(block, theme);

    case "paragraph":
      return renderParagraph(block, theme);

    case "table":
      return renderTable(block, theme);

    case "diagram":
      return renderDiagram(block, theme);

    case "metrics":
      return renderMetrics(block, theme);

    case "key-value":
      return renderKeyValue(block, theme);

    case "list":
      return renderList(block, theme);

    case "image":
      return renderImage(block, theme);

    case "section":
      return renderSection(block, theme);

    case "callout":
      return renderCallout(block, theme);

    case "spacer":
      return renderSpacer(block, theme);

    case "divider":
      return renderDivider(block, theme);

    case "page-break":
      return renderPageBreak(block, theme);

    default:
      // TypeScript exhaustiveness check - this should never happen
      const _exhaustiveCheck: never = block;
      console.warn(`Unknown block type: ${(block as ContentBlock).type}`);
      return <View />;
  }
}

/**
 * Render multiple content blocks
 */
export function renderContentBlocks(
  blocks: ContentBlock[],
  theme: Theme = defaultTheme
): React.ReactElement[] {
  return blocks.map((block, index) => (
    <ContentBlockRenderer
      key={block.id || `block-${index}`}
      block={block}
      theme={theme}
      index={index}
    />
  ));
}

export default ContentBlockRenderer;
