/**
 * BlueprintValidator
 * Validates blueprint JSON structures before processing
 *
 * Provides comprehensive validation including:
 * - Required field checks
 * - Type validation
 * - Content block structure validation
 * - Warnings for potential issues
 */

import type {
  Blueprint,
  BlueprintType,
  BlueprintMetadata,
  ContentBlock,
  ReportBlueprint,
  DashboardBlueprint,
  InvoiceBlueprint,
  DataTableBlueprint,
  ValidationResult,
  ValidationError,
  ValidationWarning,
  TableColumnDef,
  MetricItem,
  AddressBlock,
  InvoiceItem,
} from "../blueprints/types.js";

// ============================================================================
// Validation Helper Types
// ============================================================================

type ValidationContext = {
  errors: ValidationError[];
  warnings: ValidationWarning[];
  path: string[];
};

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Create a validation error
 */
function createError(
  ctx: ValidationContext,
  code: string,
  message: string
): void {
  ctx.errors.push({
    path: ctx.path.join("."),
    code,
    message,
  });
}

/**
 * Create a validation warning
 */
function createWarning(
  ctx: ValidationContext,
  message: string,
  suggestion?: string
): void {
  ctx.warnings.push({
    path: ctx.path.join("."),
    message,
    suggestion,
  });
}

/**
 * Push a path segment and return a cleanup function
 */
function pushPath(ctx: ValidationContext, segment: string): () => void {
  ctx.path.push(segment);
  return () => ctx.path.pop();
}

/**
 * Check if a value is a non-null object
 */
function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Check if a value is a non-empty string
 */
function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.length > 0;
}

/**
 * Check if a value is a valid number
 */
function isNumber(value: unknown): value is number {
  return typeof value === "number" && !isNaN(value);
}

/**
 * Check if a value is an array
 */
function isArray(value: unknown): value is unknown[] {
  return Array.isArray(value);
}

// ============================================================================
// Field Validators
// ============================================================================

/**
 * Validate a required field exists
 */
function validateRequired(
  ctx: ValidationContext,
  obj: Record<string, unknown>,
  field: string,
  expectedType?: string
): boolean {
  const cleanup = pushPath(ctx, field);

  if (!(field in obj) || obj[field] === undefined || obj[field] === null) {
    createError(ctx, "REQUIRED_FIELD", `Field '${field}' is required`);
    cleanup();
    return false;
  }

  if (expectedType) {
    const actualType = Array.isArray(obj[field]) ? "array" : typeof obj[field];
    if (actualType !== expectedType) {
      createError(
        ctx,
        "INVALID_TYPE",
        `Field '${field}' should be ${expectedType}, got ${actualType}`
      );
      cleanup();
      return false;
    }
  }

  cleanup();
  return true;
}

/**
 * Validate an optional field's type if present
 */
function validateOptional(
  ctx: ValidationContext,
  obj: Record<string, unknown>,
  field: string,
  expectedType: string
): boolean {
  if (!(field in obj) || obj[field] === undefined || obj[field] === null) {
    return true;
  }

  const cleanup = pushPath(ctx, field);
  const actualType = Array.isArray(obj[field]) ? "array" : typeof obj[field];

  if (actualType !== expectedType) {
    createError(
      ctx,
      "INVALID_TYPE",
      `Field '${field}' should be ${expectedType}, got ${actualType}`
    );
    cleanup();
    return false;
  }

  cleanup();
  return true;
}

/**
 * Validate a value is one of allowed values
 */
function validateEnum<T>(
  ctx: ValidationContext,
  value: unknown,
  allowedValues: T[],
  fieldName: string
): boolean {
  if (!allowedValues.includes(value as T)) {
    createError(
      ctx,
      "INVALID_VALUE",
      `Field '${fieldName}' must be one of: ${allowedValues.join(", ")}`
    );
    return false;
  }
  return true;
}

// ============================================================================
// Metadata Validation
// ============================================================================

/**
 * Validate blueprint metadata
 */
function validateMetadata(
  ctx: ValidationContext,
  metadata: unknown
): metadata is BlueprintMetadata {
  const cleanup = pushPath(ctx, "metadata");

  if (!isObject(metadata)) {
    createError(ctx, "INVALID_TYPE", "Metadata must be an object");
    cleanup();
    return false;
  }

  // Required fields
  validateRequired(ctx, metadata, "title", "string");

  // Optional fields with type checking
  validateOptional(ctx, metadata, "subtitle", "string");
  validateOptional(ctx, metadata, "author", "string");
  validateOptional(ctx, metadata, "date", "string");
  validateOptional(ctx, metadata, "logo", "string");
  validateOptional(ctx, metadata, "company", "string");
  validateOptional(ctx, metadata, "pageSize", "string");
  validateOptional(ctx, metadata, "orientation", "string");

  // Validate pageSize enum
  if (metadata.pageSize) {
    const validSizes = ["A4", "LETTER", "LEGAL", "A3", "A5", "TABLOID", "EXECUTIVE"];
    validateEnum(ctx, metadata.pageSize, validSizes, "pageSize");
  }

  // Validate orientation enum
  if (metadata.orientation) {
    validateEnum(ctx, metadata.orientation, ["portrait", "landscape"], "orientation");
  }

  // Warnings
  if (!metadata.date) {
    createWarning(
      ctx,
      "No date specified in metadata",
      "Consider adding a date for document tracking"
    );
  }

  cleanup();
  return ctx.errors.length === 0;
}

// ============================================================================
// Content Block Validation
// ============================================================================

/**
 * Valid content block types
 */
const VALID_BLOCK_TYPES = [
  "heading",
  "paragraph",
  "table",
  "diagram",
  "metrics",
  "key-value",
  "list",
  "image",
  "section",
  "callout",
  "spacer",
  "divider",
  "page-break",
] as const;

/**
 * Validate a single content block
 */
function validateContentBlock(
  ctx: ValidationContext,
  block: unknown,
  index: number
): boolean {
  const cleanup = pushPath(ctx, `[${index}]`);

  if (!isObject(block)) {
    createError(ctx, "INVALID_TYPE", "Content block must be an object");
    cleanup();
    return false;
  }

  // Validate type field
  if (!validateRequired(ctx, block, "type", "string")) {
    cleanup();
    return false;
  }

  const blockType = block.type as string;

  if (!VALID_BLOCK_TYPES.includes(blockType as (typeof VALID_BLOCK_TYPES)[number])) {
    createError(
      ctx,
      "INVALID_BLOCK_TYPE",
      `Invalid block type '${blockType}'. Valid types: ${VALID_BLOCK_TYPES.join(", ")}`
    );
    cleanup();
    return false;
  }

  // Type-specific validation
  switch (blockType) {
    case "heading":
      validateRequired(ctx, block, "text", "string");
      validateRequired(ctx, block, "level", "number");
      if (isNumber(block.level) && (block.level < 1 || block.level > 4)) {
        createError(ctx, "INVALID_VALUE", "Heading level must be between 1 and 4");
      }
      break;

    case "paragraph":
      validateRequired(ctx, block, "text", "string");
      if (block.align) {
        validateEnum(ctx, block.align, ["left", "center", "right", "justify"], "align");
      }
      break;

    case "table":
      validateRequired(ctx, block, "columns", "array");
      validateRequired(ctx, block, "data", "array");
      if (isArray(block.columns)) {
        block.columns.forEach((col, i) => {
          const colCleanup = pushPath(ctx, `columns[${i}]`);
          if (isObject(col)) {
            validateRequired(ctx, col, "key", "string");
            validateRequired(ctx, col, "header", "string");
          } else {
            createError(ctx, "INVALID_TYPE", "Column definition must be an object");
          }
          colCleanup();
        });
      }
      break;

    case "diagram":
      validateRequired(ctx, block, "nodes", "array");
      validateRequired(ctx, block, "edges", "array");
      break;

    case "metrics":
      validateRequired(ctx, block, "items", "array");
      if (isArray(block.items)) {
        block.items.forEach((item, i) => {
          const itemCleanup = pushPath(ctx, `items[${i}]`);
          if (isObject(item)) {
            validateRequired(ctx, item, "label", "string");
            validateRequired(ctx, item, "value");
          }
          itemCleanup();
        });
      }
      break;

    case "key-value":
      validateRequired(ctx, block, "items", "array");
      if (isArray(block.items)) {
        block.items.forEach((item, i) => {
          const itemCleanup = pushPath(ctx, `items[${i}]`);
          if (isObject(item)) {
            validateRequired(ctx, item, "key", "string");
            validateRequired(ctx, item, "value", "string");
          }
          itemCleanup();
        });
      }
      break;

    case "list":
      validateRequired(ctx, block, "items", "array");
      break;

    case "image":
      validateRequired(ctx, block, "src", "string");
      break;

    case "section":
      validateRequired(ctx, block, "children", "array");
      if (isArray(block.children)) {
        block.children.forEach((child, i) => {
          validateContentBlock(ctx, child, i);
        });
      }
      break;

    case "callout":
      validateRequired(ctx, block, "text", "string");
      validateRequired(ctx, block, "variant", "string");
      if (block.variant) {
        validateEnum(ctx, block.variant, ["info", "warning", "success", "error"], "variant");
      }
      break;

    case "spacer":
      validateRequired(ctx, block, "size", "string");
      if (block.size) {
        validateEnum(ctx, block.size, ["xs", "sm", "md", "lg", "xl"], "size");
      }
      break;

    case "divider":
    case "page-break":
      // No additional required fields
      break;
  }

  cleanup();
  return true;
}

/**
 * Validate an array of content blocks
 */
function validateContentBlocks(
  ctx: ValidationContext,
  blocks: unknown
): boolean {
  if (!isArray(blocks)) {
    createError(ctx, "INVALID_TYPE", "Content blocks must be an array");
    return false;
  }

  blocks.forEach((block, index) => {
    validateContentBlock(ctx, block, index);
  });

  if (blocks.length === 0) {
    createWarning(
      ctx,
      "Content sections array is empty",
      "Add content blocks to populate the document"
    );
  }

  return true;
}

// ============================================================================
// Address Block Validation
// ============================================================================

/**
 * Validate an address block
 */
function validateAddressBlock(
  ctx: ValidationContext,
  address: unknown,
  fieldName: string
): boolean {
  const cleanup = pushPath(ctx, fieldName);

  if (!isObject(address)) {
    createError(ctx, "INVALID_TYPE", `${fieldName} must be an object`);
    cleanup();
    return false;
  }

  validateRequired(ctx, address, "name", "string");
  validateRequired(ctx, address, "address", "array");

  cleanup();
  return true;
}

// ============================================================================
// Blueprint Type-Specific Validation
// ============================================================================

/**
 * Validate report blueprint content
 */
function validateReportContent(
  ctx: ValidationContext,
  content: unknown
): boolean {
  const cleanup = pushPath(ctx, "content");

  if (!isObject(content)) {
    createError(ctx, "INVALID_TYPE", "Content must be an object");
    cleanup();
    return false;
  }

  validateRequired(ctx, content, "sections", "array");

  const sectionsCleanup = pushPath(ctx, "sections");
  if (isArray(content.sections)) {
    validateContentBlocks(ctx, content.sections);
  }
  sectionsCleanup();

  // Optional validations
  validateOptional(ctx, content, "showCover", "boolean");
  validateOptional(ctx, content, "showToc", "boolean");
  validateOptional(ctx, content, "executiveSummary", "string");
  validateOptional(ctx, content, "companyName", "string");

  cleanup();
  return true;
}

/**
 * Validate dashboard blueprint content
 */
function validateDashboardContent(
  ctx: ValidationContext,
  content: unknown
): boolean {
  const cleanup = pushPath(ctx, "content");

  if (!isObject(content)) {
    createError(ctx, "INVALID_TYPE", "Content must be an object");
    cleanup();
    return false;
  }

  validateRequired(ctx, content, "metrics", "array");

  if (isArray(content.metrics)) {
    const metricsCleanup = pushPath(ctx, "metrics");
    content.metrics.forEach((metric, i) => {
      const itemCleanup = pushPath(ctx, `[${i}]`);
      if (isObject(metric)) {
        validateRequired(ctx, metric, "label", "string");
        validateRequired(ctx, metric, "value");
      }
      itemCleanup();
    });
    metricsCleanup();
  }

  // Validate KPIs if present
  if (content.kpis && isArray(content.kpis)) {
    const kpisCleanup = pushPath(ctx, "kpis");
    content.kpis.forEach((kpi, i) => {
      const itemCleanup = pushPath(ctx, `[${i}]`);
      if (isObject(kpi)) {
        validateRequired(ctx, kpi, "title", "string");
        validateRequired(ctx, kpi, "items", "array");
      }
      itemCleanup();
    });
    kpisCleanup();
  }

  cleanup();
  return true;
}

/**
 * Validate invoice blueprint content
 */
function validateInvoiceContent(
  ctx: ValidationContext,
  content: unknown
): boolean {
  const cleanup = pushPath(ctx, "content");

  if (!isObject(content)) {
    createError(ctx, "INVALID_TYPE", "Content must be an object");
    cleanup();
    return false;
  }

  // Required fields
  validateRequired(ctx, content, "invoiceNumber", "string");
  validateRequired(ctx, content, "issueDate", "string");
  validateRequired(ctx, content, "dueDate", "string");
  validateRequired(ctx, content, "lineItems", "array");
  validateRequired(ctx, content, "subtotal", "number");
  validateRequired(ctx, content, "total", "number");

  // Address blocks
  validateAddressBlock(ctx, content.from, "from");
  validateAddressBlock(ctx, content.billTo, "billTo");

  // Validate line items
  if (isArray(content.lineItems)) {
    const itemsCleanup = pushPath(ctx, "lineItems");
    content.lineItems.forEach((item, i) => {
      const itemCleanup = pushPath(ctx, `[${i}]`);
      if (isObject(item)) {
        validateRequired(ctx, item, "description", "string");
        validateRequired(ctx, item, "quantity", "number");
        validateRequired(ctx, item, "unitPrice", "number");
      }
      itemCleanup();
    });
    itemsCleanup();
  }

  // Warnings
  if (!content.tax) {
    createWarning(
      ctx,
      "No tax information provided",
      "Consider adding tax rate and amount if applicable"
    );
  }

  cleanup();
  return true;
}

/**
 * Validate data table blueprint content
 */
function validateDataTableContent(
  ctx: ValidationContext,
  content: unknown
): boolean {
  const cleanup = pushPath(ctx, "content");

  if (!isObject(content)) {
    createError(ctx, "INVALID_TYPE", "Content must be an object");
    cleanup();
    return false;
  }

  validateRequired(ctx, content, "columns", "array");
  validateRequired(ctx, content, "data", "array");

  // Validate columns
  if (isArray(content.columns)) {
    const colsCleanup = pushPath(ctx, "columns");
    content.columns.forEach((col, i) => {
      const itemCleanup = pushPath(ctx, `[${i}]`);
      if (isObject(col)) {
        validateRequired(ctx, col, "key", "string");
        validateRequired(ctx, col, "header", "string");
      }
      itemCleanup();
    });
    colsCleanup();
  }

  // Validate data has expected columns
  if (isArray(content.columns) && isArray(content.data) && content.data.length > 0) {
    const columnKeys = content.columns
      .filter(isObject)
      .map((col) => col.key as string);

    const firstRow = content.data[0];
    if (isObject(firstRow)) {
      columnKeys.forEach((key) => {
        if (!(key in firstRow)) {
          createWarning(
            ctx,
            `Column '${key}' not found in data rows`,
            "Ensure data rows contain all column keys"
          );
        }
      });
    }
  }

  cleanup();
  return true;
}

// ============================================================================
// Main Validation Function
// ============================================================================

/**
 * Validate a blueprint structure
 *
 * @param blueprint - The blueprint object to validate (can be unknown type)
 * @returns ValidationResult with valid flag, errors, and warnings
 *
 * @example
 * ```typescript
 * const result = validateBlueprint(blueprintJson);
 *
 * if (!result.valid) {
 *   console.error('Blueprint validation failed:');
 *   result.errors.forEach(err => {
 *     console.error(`  ${err.path}: ${err.message}`);
 *   });
 * }
 *
 * if (result.warnings.length > 0) {
 *   console.warn('Blueprint warnings:');
 *   result.warnings.forEach(warn => {
 *     console.warn(`  ${warn.path}: ${warn.message}`);
 *   });
 * }
 * ```
 */
export function validateBlueprint(blueprint: unknown): ValidationResult {
  const ctx: ValidationContext = {
    errors: [],
    warnings: [],
    path: [],
  };

  // Check if blueprint is an object
  if (!isObject(blueprint)) {
    ctx.errors.push({
      path: "",
      code: "INVALID_BLUEPRINT",
      message: "Blueprint must be an object",
    });
    return { valid: false, errors: ctx.errors, warnings: ctx.warnings };
  }

  // Validate base blueprint fields
  validateRequired(ctx, blueprint, "id", "string");
  validateRequired(ctx, blueprint, "version", "string");
  validateRequired(ctx, blueprint, "type", "string");
  validateRequired(ctx, blueprint, "metadata", "object");
  validateRequired(ctx, blueprint, "content", "object");

  // Validate type enum
  if (blueprint.type) {
    const validTypes: BlueprintType[] = ["report", "dashboard", "invoice", "data-table"];
    if (!validTypes.includes(blueprint.type as BlueprintType)) {
      ctx.errors.push({
        path: "type",
        code: "INVALID_TYPE",
        message: `Invalid blueprint type '${blueprint.type}'. Valid types: ${validTypes.join(", ")}`,
      });
    }
  }

  // If we have critical errors, return early
  if (ctx.errors.length > 0) {
    return { valid: false, errors: ctx.errors, warnings: ctx.warnings };
  }

  // Validate metadata
  validateMetadata(ctx, blueprint.metadata);

  // Validate type-specific content
  switch (blueprint.type) {
    case "report":
      validateReportContent(ctx, blueprint.content);
      break;
    case "dashboard":
      validateDashboardContent(ctx, blueprint.content);
      break;
    case "invoice":
      validateInvoiceContent(ctx, blueprint.content);
      break;
    case "data-table":
      validateDataTableContent(ctx, blueprint.content);
      break;
  }

  return {
    valid: ctx.errors.length === 0,
    errors: ctx.errors,
    warnings: ctx.warnings,
  };
}

/**
 * Validate a blueprint and throw if invalid
 *
 * @param blueprint - The blueprint to validate
 * @throws Error if the blueprint is invalid
 */
export function assertValidBlueprint(blueprint: unknown): asserts blueprint is Blueprint {
  const result = validateBlueprint(blueprint);

  if (!result.valid) {
    const errorMessages = result.errors
      .map((err) => `  ${err.path}: ${err.message}`)
      .join("\n");
    throw new Error(`Invalid blueprint:\n${errorMessages}`);
  }
}

/**
 * Check if a value is a valid blueprint (type guard)
 */
export function isValidBlueprint(value: unknown): value is Blueprint {
  return validateBlueprint(value).valid;
}

export default validateBlueprint;
