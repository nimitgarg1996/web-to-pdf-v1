/**
 * Factories Index
 * Export all factory functions for document generation
 *
 * The factory system transforms blueprints into React-PDF documents:
 * Blueprint (JSON) → DocumentFactory → Template → Component → Primitive → PDF
 */

// ============================================================================
// Document Factory
// ============================================================================

export {
  createDocument,
  createDocumentWithTheme,
  getBlueprintType,
  getTemplateForType,
} from "./DocumentFactory.js";

// ============================================================================
// Content Block Renderer
// ============================================================================

export {
  ContentBlockRenderer,
  renderContentBlocks,
  type ContentBlockRendererProps,
} from "./ContentBlockRenderer.js";

// ============================================================================
// Blueprint Validator
// ============================================================================

export {
  validateBlueprint,
  assertValidBlueprint,
  isValidBlueprint,
} from "./BlueprintValidator.js";

// ============================================================================
// Re-export types for convenience
// ============================================================================

export type {
  Blueprint,
  ReportBlueprint,
  DashboardBlueprint,
  InvoiceBlueprint,
  DataTableBlueprint,
  DocumentFactoryOptions,
  ValidationResult,
  ValidationError,
  ValidationWarning,
} from "../blueprints/types.js";
