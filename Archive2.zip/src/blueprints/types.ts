/**
 * Blueprint Types
 * JSON schema definitions for document blueprints
 *
 * Blueprints define the structure, content, and styling of documents
 * in a JSON format that can be transformed into React-PDF documents
 * using the DocumentFactory.
 */

import type { Theme, ThemeOverrides } from "../primitives/theme.js";
import type {
  PageSize,
  PageOrientation,
  AddressInfo,
  InvoiceLineItem,
  DataTableColumn,
} from "../templates/types.js";
import type {
  DiagramNodeType,
  DiagramEdgeType,
  NodeDefaults,
  EdgeDefaults,
} from "../components/diagram/types.js";
import type { ColumnDefinition, TableVariant } from "../components/table/types.js";

// ============================================================================
// Blueprint Metadata
// ============================================================================

/**
 * Metadata for document blueprints
 */
export interface BlueprintMetadata {
  /** Document title */
  title: string;
  /** Document subtitle */
  subtitle?: string;
  /** Document author or prepared by */
  author?: string;
  /** Document date (ISO format or display string) */
  date?: string;
  /** Logo image source (URL or path) */
  logo?: string;
  /** Company name */
  company?: string;
  /** Page size for the document */
  pageSize?: PageSize;
  /** Page orientation */
  orientation?: PageOrientation;
  /** Document version number */
  version?: string;
  /** Document description */
  description?: string;
}

// ============================================================================
// Content Block Types
// ============================================================================

/**
 * Base interface for all content blocks
 */
export interface BaseContentBlock {
  /** Unique identifier for the block */
  id?: string;
}

/**
 * Heading block for section titles
 */
export interface HeadingBlock extends BaseContentBlock {
  type: "heading";
  /** Heading level (1-4) */
  level: 1 | 2 | 3 | 4;
  /** Heading text content */
  text: string;
}

/**
 * Paragraph block for body text
 */
export interface ParagraphBlock extends BaseContentBlock {
  type: "paragraph";
  /** Paragraph text content */
  text: string;
  /** Text alignment */
  align?: "left" | "center" | "right" | "justify";
}

/**
 * Column definition for table blocks
 */
export interface TableColumnDef {
  /** Data field key */
  key: string;
  /** Column header label */
  header: string;
  /** Column width (percentage or points) */
  width?: string | number;
  /** Text alignment */
  align?: "left" | "center" | "right";
  /** Header text alignment */
  headerAlign?: "left" | "center" | "right";
  /** Value format type */
  format?: "text" | "number" | "currency" | "percent" | "date";
}

/**
 * Table block for tabular data
 */
export interface TableBlock extends BaseContentBlock {
  type: "table";
  /** Column definitions */
  columns: TableColumnDef[];
  /** Table row data */
  data: Record<string, unknown>[];
  /** Show header row */
  showHeader?: boolean;
  /** Striped rows */
  striped?: boolean;
  /** Bordered style */
  bordered?: boolean;
  /** Table variant style */
  variant?: TableVariant;
}

/**
 * Diagram block for flowcharts and diagrams
 */
export interface DiagramBlock extends BaseContentBlock {
  type: "diagram";
  /** Diagram nodes */
  nodes: DiagramNodeType[];
  /** Diagram edges/connections */
  edges: DiagramEdgeType[];
  /** Diagram width in points */
  width?: number;
  /** Diagram height in points */
  height?: number;
  /** Show grid background */
  showGrid?: boolean;
  /** Default node styling */
  nodeDefaults?: NodeDefaults;
  /** Default edge styling */
  edgeDefaults?: EdgeDefaults;
}

/**
 * Single metric item for metrics blocks
 */
export interface MetricItem {
  /** Metric label */
  label: string;
  /** Metric value */
  value: string | number;
  /** Change percentage */
  change?: number;
  /** Change direction */
  changeType?: "increase" | "decrease" | "neutral";
  /** Icon identifier */
  icon?: string;
  /** Unit (e.g., "$", "%", "users") */
  unit?: string;
  /** Value format type */
  format?: "number" | "currency" | "percent";
}

/**
 * Metrics block for displaying KPIs
 */
export interface MetricsBlock extends BaseContentBlock {
  type: "metrics";
  /** Metric items to display */
  items: MetricItem[];
  /** Number of columns (2, 3, or 4) */
  columns?: 2 | 3 | 4;
}

/**
 * Key-value pair item
 */
export interface KeyValueItem {
  /** Key/label */
  key: string;
  /** Value */
  value: string;
}

/**
 * Key-value block for property lists
 */
export interface KeyValueBlock extends BaseContentBlock {
  type: "key-value";
  /** Key-value pairs */
  items: KeyValueItem[];
  /** Layout style */
  layout?: "vertical" | "horizontal" | "grid";
}

/**
 * List block for bullet/numbered lists
 */
export interface ListBlock extends BaseContentBlock {
  type: "list";
  /** List items */
  items: string[];
  /** Ordered (numbered) list */
  ordered?: boolean;
  /** Icon for bullet points */
  icon?: string;
}

/**
 * Image block for embedded images
 */
export interface ImageBlock extends BaseContentBlock {
  type: "image";
  /** Image source URL or path */
  src: string;
  /** Image width in points */
  width?: number;
  /** Image height in points */
  height?: number;
  /** Image caption */
  caption?: string;
  /** Image alignment */
  align?: "left" | "center" | "right";
}

/**
 * Section block for grouping content
 */
export interface SectionBlock extends BaseContentBlock {
  type: "section";
  /** Optional section title */
  title?: string;
  /** Nested content blocks */
  children: ContentBlock[];
}

/**
 * Callout block for highlighted content
 */
export interface CalloutBlock extends BaseContentBlock {
  type: "callout";
  /** Callout variant */
  variant: "info" | "warning" | "success" | "error";
  /** Optional callout title */
  title?: string;
  /** Callout text content */
  text: string;
}

/**
 * Spacer block for vertical spacing
 */
export interface SpacerBlock extends BaseContentBlock {
  type: "spacer";
  /** Spacer size */
  size: "xs" | "sm" | "md" | "lg" | "xl";
}

/**
 * Divider block for horizontal rules
 */
export interface DividerBlock extends BaseContentBlock {
  type: "divider";
  /** Divider color (optional) */
  color?: string;
  /** Divider thickness (optional) */
  thickness?: number;
}

/**
 * Page break block to force new page
 */
export interface PageBreakBlock extends BaseContentBlock {
  type: "page-break";
}

/**
 * Union type of all content blocks
 */
export type ContentBlock =
  | HeadingBlock
  | ParagraphBlock
  | TableBlock
  | DiagramBlock
  | MetricsBlock
  | KeyValueBlock
  | ListBlock
  | ImageBlock
  | SectionBlock
  | CalloutBlock
  | SpacerBlock
  | DividerBlock
  | PageBreakBlock;

/**
 * Type guard helpers for content blocks
 */
export const isHeadingBlock = (block: ContentBlock): block is HeadingBlock =>
  block.type === "heading";
export const isParagraphBlock = (block: ContentBlock): block is ParagraphBlock =>
  block.type === "paragraph";
export const isTableBlock = (block: ContentBlock): block is TableBlock =>
  block.type === "table";
export const isDiagramBlock = (block: ContentBlock): block is DiagramBlock =>
  block.type === "diagram";
export const isMetricsBlock = (block: ContentBlock): block is MetricsBlock =>
  block.type === "metrics";
export const isKeyValueBlock = (block: ContentBlock): block is KeyValueBlock =>
  block.type === "key-value";
export const isListBlock = (block: ContentBlock): block is ListBlock =>
  block.type === "list";
export const isImageBlock = (block: ContentBlock): block is ImageBlock =>
  block.type === "image";
export const isSectionBlock = (block: ContentBlock): block is SectionBlock =>
  block.type === "section";
export const isCalloutBlock = (block: ContentBlock): block is CalloutBlock =>
  block.type === "callout";
export const isSpacerBlock = (block: ContentBlock): block is SpacerBlock =>
  block.type === "spacer";
export const isDividerBlock = (block: ContentBlock): block is DividerBlock =>
  block.type === "divider";
export const isPageBreakBlock = (block: ContentBlock): block is PageBreakBlock =>
  block.type === "page-break";

// ============================================================================
// Base Blueprint
// ============================================================================

/**
 * Blueprint document types
 */
export type BlueprintType = "report" | "dashboard" | "invoice" | "data-table" | "estate-planning";

/**
 * Base blueprint interface
 */
export interface BaseBlueprint {
  /** Unique blueprint identifier */
  id: string;
  /** Blueprint schema version */
  version: string;
  /** Document type */
  type: BlueprintType;
  /** Document metadata */
  metadata: BlueprintMetadata;
  /** Theme overrides */
  theme?: ThemeOverrides;
}

// ============================================================================
// Report Blueprint
// ============================================================================

/**
 * Report content configuration
 */
export interface ReportContent {
  /** Show cover page */
  showCover?: boolean;
  /** Show table of contents */
  showToc?: boolean;
  /** Company name for cover */
  companyName?: string;
  /** Company info lines */
  companyInfo?: string[];
  /** Executive summary text */
  executiveSummary?: string;
  /** Main content sections */
  sections: ContentBlock[];
}

/**
 * Report blueprint for formal documents
 */
export interface ReportBlueprint extends BaseBlueprint {
  type: "report";
  content: ReportContent;
}

// ============================================================================
// Dashboard Blueprint
// ============================================================================

/**
 * KPI section for dashboards
 */
export interface KPISection {
  /** Section title */
  title: string;
  /** KPI items */
  items: MetricItem[];
}

/**
 * Dashboard content configuration
 */
export interface DashboardContent {
  /** Date range for data */
  dateRange?: {
    start: string;
    end: string;
  };
  /** Main metrics row */
  metrics: MetricItem[];
  /** KPI sections */
  kpis?: KPISection[];
  /** Charts/diagrams */
  charts?: DiagramBlock[];
  /** Data tables */
  tables?: TableBlock[];
  /** Summary text */
  summary?: string;
}

/**
 * Dashboard blueprint for data visualization
 */
export interface DashboardBlueprint extends BaseBlueprint {
  type: "dashboard";
  content: DashboardContent;
}

// ============================================================================
// Invoice Blueprint
// ============================================================================

/**
 * Address block for invoices
 */
export interface AddressBlock {
  /** Name (company or person) */
  name: string;
  /** Address lines */
  address: string[];
  /** Email address */
  email?: string;
  /** Phone number */
  phone?: string;
}

/**
 * Invoice line item
 */
export interface InvoiceItem {
  /** Item description */
  description: string;
  /** Quantity */
  quantity: number;
  /** Unit price */
  unitPrice: number;
  /** Total (calculated if not provided) */
  total?: number;
  /** Unit of measurement */
  unit?: string;
}

/**
 * Invoice content configuration
 */
export interface InvoiceContent {
  /** Invoice number */
  invoiceNumber: string;
  /** Issue date */
  issueDate: string;
  /** Due date */
  dueDate: string;
  /** From/sender information */
  from: AddressBlock;
  /** Bill to information */
  billTo: AddressBlock;
  /** Ship to information */
  shipTo?: AddressBlock;
  /** Line items */
  lineItems: InvoiceItem[];
  /** Subtotal amount */
  subtotal: number;
  /** Tax configuration */
  tax?: {
    rate: number;
    amount: number;
  };
  /** Discount configuration */
  discount?: {
    type: "percentage" | "fixed";
    value: number;
    amount: number;
  };
  /** Total amount */
  total: number;
  /** Currency symbol */
  currency?: string;
  /** Payment terms */
  paymentTerms?: string;
  /** Additional notes */
  notes?: string;
  /** Invoice status */
  status?: "draft" | "pending" | "paid" | "overdue";
}

/**
 * Invoice blueprint for billing documents
 */
export interface InvoiceBlueprint extends BaseBlueprint {
  type: "invoice";
  content: InvoiceContent;
}

// ============================================================================
// Data Table Blueprint
// ============================================================================

/**
 * Filter/parameter display
 */
export interface DataFilterItem {
  /** Filter label */
  label: string;
  /** Filter value */
  value: string;
}

/**
 * Summary statistic
 */
export interface DataSummaryItem {
  /** Statistic label */
  label: string;
  /** Statistic value */
  value: string | number;
  /** Optional description */
  description?: string;
}

/**
 * Pagination configuration
 */
export interface PaginationConfig {
  /** Current page number */
  page: number;
  /** Items per page */
  pageSize: number;
  /** Total number of items */
  total: number;
}

/**
 * Data table content configuration
 */
export interface DataTableContent {
  /** Table description */
  description?: string;
  /** Active filters */
  filters?: DataFilterItem[];
  /** Column definitions */
  columns: TableColumnDef[];
  /** Table data rows */
  data: Record<string, unknown>[];
  /** Pagination info */
  pagination?: PaginationConfig;
  /** Summary statistics */
  summary?: DataSummaryItem[];
  /** Show row numbers */
  showRowNumbers?: boolean;
  /** Striped rows */
  striped?: boolean;
}

/**
 * Data table blueprint for tabular reports
 */
export interface DataTableBlueprint extends BaseBlueprint {
  type: "data-table";
  content: DataTableContent;
}

// ============================================================================
// Estate Planning Blueprint
// ============================================================================

/**
 * Trust node for trust structure diagrams
 */
export interface TrustNode {
  id: string;
  label: string;
  icon: string;
  color: string;
}

/**
 * Trust connection between nodes
 */
export interface TrustConnection {
  from: string;
  to: string;
  label?: string;
}

/**
 * Trust flow separator
 */
export interface TrustSeparator {
  afterNode: string;
  text: string;
}

/**
 * Trust structure configuration
 */
export interface TrustStructure {
  nodes: TrustNode[];
  connections: TrustConnection[];
  separators?: TrustSeparator[];
}

/**
 * Key people document
 */
export interface KeyPeopleDocument {
  name: string;
  role: string;
  designation: string;
}

/**
 * Donut chart segment
 */
export interface DonutSegment {
  value: number;
  color: string;
  label: string;
}

/**
 * Estate overview with breakdown
 */
export interface EstateOverview {
  total: number;
  breakdown: DonutSegment[];
  details?: {
    insideTaxable?: Array<{ label: string; value: number }>;
    outsideTaxable?: Array<{ label: string; value: number }>;
  };
}

/**
 * Beneficiary information
 */
export interface Beneficiary {
  name: string;
  icon?: 'person' | 'charity';
  iconColor?: string;
  inTrust?: number;
  outright?: number;
}

/**
 * Estate planning content configuration
 */
export interface EstatePlanningContent {
  /** Client information */
  client: {
    names: string[];
    trustName: string;
  };
  /** Trust structure diagram */
  trustStructure?: TrustStructure;
  /** Key people and roles */
  keyPeople?: {
    documents: KeyPeopleDocument[];
  };
  /** Estate value overview */
  estateOverview?: EstateOverview;
  /** Beneficiaries */
  beneficiaries?: Beneficiary[];
  /** Beneficiary section title */
  beneficiaryTitle?: string;
  /** Company name for branding */
  companyName?: string;
  /** Legal disclaimer text */
  disclaimer?: string;
}

/**
 * Estate planning blueprint for wealth management reports
 */
export interface EstatePlanningBlueprint extends BaseBlueprint {
  type: "estate-planning";
  content: EstatePlanningContent;
}

// ============================================================================
// Union Types
// ============================================================================

/**
 * Union type of all blueprint types
 */
export type Blueprint =
  | ReportBlueprint
  | DashboardBlueprint
  | InvoiceBlueprint
  | DataTableBlueprint
  | EstatePlanningBlueprint;

/**
 * Type guard helpers for blueprints
 */
export const isReportBlueprint = (blueprint: Blueprint): blueprint is ReportBlueprint =>
  blueprint.type === "report";
export const isDashboardBlueprint = (blueprint: Blueprint): blueprint is DashboardBlueprint =>
  blueprint.type === "dashboard";
export const isInvoiceBlueprint = (blueprint: Blueprint): blueprint is InvoiceBlueprint =>
  blueprint.type === "invoice";
export const isDataTableBlueprint = (blueprint: Blueprint): blueprint is DataTableBlueprint =>
  blueprint.type === "data-table";
export const isEstatePlanningBlueprint = (blueprint: Blueprint): blueprint is EstatePlanningBlueprint =>
  blueprint.type === "estate-planning";

// ============================================================================
// Factory Options
// ============================================================================

/**
 * Options for document factory
 */
export interface DocumentFactoryOptions {
  /** Blueprint to render */
  blueprint: Blueprint;
  /** Theme to apply (uses default if not provided) */
  theme?: Theme;
}

// ============================================================================
// Validation Types
// ============================================================================

/**
 * Validation error detail
 */
export interface ValidationError {
  /** Path to the invalid field */
  path: string;
  /** Error message */
  message: string;
  /** Error code */
  code: string;
}

/**
 * Validation warning detail
 */
export interface ValidationWarning {
  /** Path to the field */
  path: string;
  /** Warning message */
  message: string;
  /** Suggestion for improvement */
  suggestion?: string;
}

/**
 * Result of blueprint validation
 */
export interface ValidationResult {
  /** Whether the blueprint is valid */
  valid: boolean;
  /** Validation errors (prevents rendering) */
  errors: ValidationError[];
  /** Validation warnings (suggestions for improvement) */
  warnings: ValidationWarning[];
}
