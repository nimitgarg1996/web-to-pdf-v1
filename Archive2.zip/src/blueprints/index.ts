/**
 * Blueprints Index
 * Export all blueprint types, validators, and samples
 *
 * Blueprints are JSON schemas that define document structure, content, and styling.
 * They form the top layer of the Factory Pattern architecture:
 * Blueprint → Template → Component → Primitive
 */

// ============================================================================
// Type Exports
// ============================================================================

export type {
  // Base types
  Blueprint,
  BlueprintType,
  BaseBlueprint,
  BlueprintMetadata,

  // Content block types
  ContentBlock,
  BaseContentBlock,
  HeadingBlock,
  ParagraphBlock,
  TableBlock,
  DiagramBlock,
  MetricsBlock,
  KeyValueBlock,
  ListBlock,
  ImageBlock,
  SectionBlock,
  CalloutBlock,
  SpacerBlock,
  DividerBlock,
  PageBreakBlock,

  // Data types
  TableColumnDef,
  MetricItem,
  KeyValueItem,
  AddressBlock,
  InvoiceItem,
  KPISection,
  DataFilterItem,
  DataSummaryItem,
  PaginationConfig,

  // Blueprint-specific types
  ReportBlueprint,
  ReportContent,
  DashboardBlueprint,
  DashboardContent,
  InvoiceBlueprint,
  InvoiceContent,
  DataTableBlueprint,
  DataTableContent,

  // Factory types
  DocumentFactoryOptions,

  // Validation types
  ValidationResult,
  ValidationError,
  ValidationWarning,
} from "./types.js";

// ============================================================================
// Type Guards
// ============================================================================

export {
  // Content block type guards
  isHeadingBlock,
  isParagraphBlock,
  isTableBlock,
  isDiagramBlock,
  isMetricsBlock,
  isKeyValueBlock,
  isListBlock,
  isImageBlock,
  isSectionBlock,
  isCalloutBlock,
  isSpacerBlock,
  isDividerBlock,
  isPageBreakBlock,

  // Blueprint type guards
  isReportBlueprint,
  isDashboardBlueprint,
  isInvoiceBlueprint,
  isDataTableBlueprint,
} from "./types.js";

// ============================================================================
// Sample Blueprints
// ============================================================================

export {
  sampleReport,
  sampleInvoice,
  sampleDashboard,
  samples,
  getSampleBlueprint,
} from "./samples/index.js";
