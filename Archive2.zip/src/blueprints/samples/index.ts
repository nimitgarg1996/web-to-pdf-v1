/**
 * Sample Blueprints Index
 * Pre-built blueprint examples for testing and demonstration
 */

import type {
  ReportBlueprint,
  InvoiceBlueprint,
  DashboardBlueprint,
  EstatePlanningBlueprint,
} from "../types.js";

// Import JSON samples
// Note: In actual usage, these would be loaded from JSON files
// For TypeScript, we define them as typed objects

import sampleReportJson from "./sample-report.json" with { type: "json" };
import sampleInvoiceJson from "./sample-invoice.json" with { type: "json" };
import sampleDashboardJson from "./sample-dashboard.json" with { type: "json" };
import sampleEstatePlanningJson from "./sample-estate-planning.json" with { type: "json" };

/**
 * Sample report blueprint demonstrating all content block types
 */
export const sampleReport = sampleReportJson as unknown as ReportBlueprint;

/**
 * Sample invoice blueprint with complete billing information
 */
export const sampleInvoice = sampleInvoiceJson as unknown as InvoiceBlueprint;

/**
 * Sample dashboard blueprint with metrics and KPIs
 */
export const sampleDashboard = sampleDashboardJson as unknown as DashboardBlueprint;

/**
 * Sample estate planning blueprint for wealth management reports
 */
export const sampleEstatePlanning = sampleEstatePlanningJson as unknown as EstatePlanningBlueprint;

/**
 * All sample blueprints
 */
export const samples = {
  report: sampleReport,
  invoice: sampleInvoice,
  dashboard: sampleDashboard,
  estatePlanning: sampleEstatePlanning,
} as const;

/**
 * Get a sample blueprint by type
 */
export function getSampleBlueprint(
  type: "report" | "invoice" | "dashboard" | "estate-planning"
): ReportBlueprint | InvoiceBlueprint | DashboardBlueprint | EstatePlanningBlueprint {
  if (type === "estate-planning") {
    return samples.estatePlanning;
  }
  return samples[type];
}

export default samples;
