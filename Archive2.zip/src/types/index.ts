/**
 * Types Index
 * Exports all type definitions for the application
 */

// Re-export primitive types
export type {
  Palette,
  SemanticColors,
  BrandColors,
  NeutralColors,
  TextColors,
  BackgroundColors,
  BorderColors,
  FontSizes,
  FontWeights,
  LineHeights,
  FontFamilies,
  TextStyles,
  Spacing,
  BorderRadius,
  BorderWidth,
  PageSizes,
  PageMargins,
  LetterSpacing,
} from "../primitives/index.js";

// Server types
export interface ServerConfig {
  port: number;
  host: string;
  env: "development" | "production" | "test";
}

// Health check response
export interface HealthCheckResponse {
  status: "ok" | "error";
  timestamp: string;
  uptime: number;
}

// API response wrapper
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
  };
}

// PDF generation request
export interface PDFGenerationRequest {
  blueprintId: string;
  data: Record<string, unknown>;
  options?: PDFGenerationOptions;
}

// PDF generation options
export interface PDFGenerationOptions {
  filename?: string;
  pageSize?: "A4" | "A3" | "A5" | "LETTER" | "LEGAL" | "TABLOID";
  orientation?: "portrait" | "landscape";
}

// PDF generation response
export interface PDFGenerationResponse {
  success: boolean;
  filename?: string;
  size?: number;
  generatedAt?: string;
}
