/**
 * Font Registration Configuration
 * This file handles font registration for React-PDF
 *
 * React-PDF supports:
 * - System fonts (Helvetica, Times-Roman, Courier)
 * - Custom fonts loaded from URLs or file paths
 * - Font families with multiple weights and styles
 */

import { Font } from "@react-pdf/renderer";

// ============================================================================
// Font Family Definitions
// ============================================================================

/**
 * Font family configuration interface
 */
export interface FontFamilyConfig {
  /** Display name of the font family */
  name: string;
  /** Font sources for different weights */
  weights: {
    normal?: FontSource;
    medium?: FontSource;
    semibold?: FontSource;
    bold?: FontSource;
  };
  /** Font sources for italic styles */
  styles?: {
    italic?: FontSource;
    boldItalic?: FontSource;
  };
}

/**
 * Font source - can be a URL, file path, or system font name
 */
export type FontSource = string;

/**
 * Available font families for PDF rendering
 * Using system fonts by default (no external files needed)
 */
export const fontFamilyConfigs: Record<string, FontFamilyConfig> = {
  // Primary sans-serif font (Helvetica family)
  primary: {
    name: "Helvetica",
    weights: {
      normal: "Helvetica",
      bold: "Helvetica-Bold",
    },
    styles: {
      italic: "Helvetica-Oblique",
      boldItalic: "Helvetica-BoldOblique",
    },
  },

  // Secondary serif font (Times family)
  secondary: {
    name: "Times-Roman",
    weights: {
      normal: "Times-Roman",
      bold: "Times-Bold",
    },
    styles: {
      italic: "Times-Italic",
      boldItalic: "Times-BoldItalic",
    },
  },

  // Monospace font (Courier family)
  mono: {
    name: "Courier",
    weights: {
      normal: "Courier",
      bold: "Courier-Bold",
    },
    styles: {
      italic: "Courier-Oblique",
      boldItalic: "Courier-BoldOblique",
    },
  },
};

// ============================================================================
// Font Registration
// ============================================================================

/**
 * Tracks whether fonts have been registered
 */
let fontsRegistered = false;

/**
 * Registers all configured font families with React-PDF
 * Safe to call multiple times - will only register once
 */
export function registerFonts(): void {
  if (fontsRegistered) {
    return;
  }

  // Note: System fonts (Helvetica, Times-Roman, Courier) are built into PDF
  // and don't need explicit registration. This function is here for future
  // custom font support.

  // Example of registering a custom web font:
  // Font.register({
  //   family: 'Inter',
  //   fonts: [
  //     { src: 'https://fonts.gstatic.com/s/inter/v12/regular.ttf', fontWeight: 400 },
  //     { src: 'https://fonts.gstatic.com/s/inter/v12/medium.ttf', fontWeight: 500 },
  //     { src: 'https://fonts.gstatic.com/s/inter/v12/semibold.ttf', fontWeight: 600 },
  //     { src: 'https://fonts.gstatic.com/s/inter/v12/bold.ttf', fontWeight: 700 },
  //   ],
  // });

  fontsRegistered = true;
}

/**
 * Registers a custom font family
 * @param familyName - The family name to use in styles
 * @param fonts - Array of font configurations
 */
export function registerCustomFont(
  familyName: string,
  fonts: Array<{
    src: string;
    fontWeight?: number | "normal" | "bold";
    fontStyle?: "normal" | "italic";
  }>
): void {
  Font.register({
    family: familyName,
    fonts,
  });
}

/**
 * Registers a font from a URL
 * @param familyName - The family name to use in styles
 * @param url - URL to the font file
 * @param options - Optional weight and style
 */
export function registerFontFromUrl(
  familyName: string,
  url: string,
  options?: {
    fontWeight?: number | "normal" | "bold";
    fontStyle?: "normal" | "italic";
  }
): void {
  Font.register({
    family: familyName,
    src: url,
    ...options,
  });
}

// ============================================================================
// Font Utilities
// ============================================================================

/**
 * Gets the appropriate font family name for a given weight
 * Handles system fonts that use separate font names for weights
 *
 * @param baseFamily - Base font family (e.g., "Helvetica")
 * @param weight - Desired weight
 * @returns The correct font family name
 */
export function getFontForWeight(
  baseFamily: string,
  weight: "normal" | "medium" | "semibold" | "bold"
): string {
  const config = Object.values(fontFamilyConfigs).find(
    (fc) => fc.name === baseFamily
  );

  if (!config) {
    return baseFamily;
  }

  return config.weights[weight] || config.weights.normal || baseFamily;
}

/**
 * Gets the appropriate font family name for italic style
 *
 * @param baseFamily - Base font family (e.g., "Helvetica")
 * @param bold - Whether to use bold italic
 * @returns The correct font family name for italic
 */
export function getFontForItalic(baseFamily: string, bold = false): string {
  const config = Object.values(fontFamilyConfigs).find(
    (fc) => fc.name === baseFamily
  );

  if (!config || !config.styles) {
    return baseFamily;
  }

  if (bold && config.styles.boldItalic) {
    return config.styles.boldItalic;
  }

  return config.styles.italic || baseFamily;
}

/**
 * Checks if a font family is available
 * @param familyName - The font family name to check
 * @returns True if the font is a system font or has been registered
 */
export function isFontAvailable(familyName: string): boolean {
  // System fonts are always available
  const systemFonts = [
    "Helvetica",
    "Helvetica-Bold",
    "Helvetica-Oblique",
    "Helvetica-BoldOblique",
    "Times-Roman",
    "Times-Bold",
    "Times-Italic",
    "Times-BoldItalic",
    "Courier",
    "Courier-Bold",
    "Courier-Oblique",
    "Courier-BoldOblique",
    "Symbol",
    "ZapfDingbats",
  ];

  return systemFonts.includes(familyName);
}

/**
 * Gets a list of all available system fonts
 * @returns Array of system font names
 */
export function getSystemFonts(): string[] {
  return [
    "Helvetica",
    "Helvetica-Bold",
    "Helvetica-Oblique",
    "Helvetica-BoldOblique",
    "Times-Roman",
    "Times-Bold",
    "Times-Italic",
    "Times-BoldItalic",
    "Courier",
    "Courier-Bold",
    "Courier-Oblique",
    "Courier-BoldOblique",
    "Symbol",
    "ZapfDingbats",
  ];
}
