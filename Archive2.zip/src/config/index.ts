/**
 * Configuration Index
 * Exports all configuration settings for the application
 */

import type { ServerConfig } from "../types/index.js";

// Server configuration
export const serverConfig: ServerConfig = {
  port: parseInt(process.env.PORT || "3000", 10),
  host: process.env.HOST || "0.0.0.0",
  env: (process.env.NODE_ENV as ServerConfig["env"]) || "development",
};

// Application configuration
export const appConfig = {
  name: "Report Builder",
  version: "1.0.0",
  description: "Autonomous Server-Side PDF Generation Pipeline",
} as const;

// PDF configuration defaults
export const pdfConfig = {
  defaultPageSize: "A4" as const,
  defaultOrientation: "portrait" as const,
  defaultMargins: {
    top: 54,
    right: 54,
    bottom: 54,
    left: 54,
  },
} as const;

// Re-export font configuration
export { registerFonts } from "./fonts.js";
