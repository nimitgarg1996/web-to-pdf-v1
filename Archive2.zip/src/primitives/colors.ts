/**
 * Color Primitives
 * Defines the complete color palette and semantic color mappings for PDF templates
 */

// ============================================================================
// Color Palette
// ============================================================================

/**
 * Brand color scale (blue-based primary)
 * Used for primary actions, links, and brand elements
 */
export const brandColors = {
  50: "#eff6ff",
  100: "#dbeafe",
  200: "#bfdbfe",
  300: "#93c5fd",
  400: "#60a5fa",
  500: "#3b82f6",
  600: "#2563eb",
  700: "#1d4ed8",
  800: "#1e40af",
  900: "#1e3a8a",
} as const;

/**
 * Neutral color scale (slate-based)
 * Used for text, backgrounds, and borders
 */
export const neutralColors = {
  0: "#ffffff",
  50: "#f8fafc",
  100: "#f1f5f9",
  200: "#e2e8f0",
  300: "#cbd5e1",
  400: "#94a3b8",
  500: "#64748b",
  600: "#475569",
  700: "#334155",
  800: "#1e293b",
  900: "#0f172a",
} as const;

/**
 * Success color variants
 * Used for positive states, confirmations, and success messages
 */
export const successColors = {
  light: "#dcfce7",
  main: "#22c55e",
  dark: "#15803d",
} as const;

/**
 * Warning color variants
 * Used for warnings, cautions, and attention-needed states
 */
export const warningColors = {
  light: "#fef3c7",
  main: "#f59e0b",
  dark: "#b45309",
} as const;

/**
 * Error color variants
 * Used for errors, destructive actions, and critical states
 */
export const errorColors = {
  light: "#fee2e2",
  main: "#ef4444",
  dark: "#b91c1c",
} as const;

/**
 * Info color variants
 * Used for informational messages and neutral highlights
 */
export const infoColors = {
  light: "#dbeafe",
  main: "#3b82f6",
  dark: "#1d4ed8",
} as const;

/**
 * Complete color palette combining all color scales
 */
export const palette = {
  brand: brandColors,
  neutral: neutralColors,
  success: successColors,
  warning: warningColors,
  error: errorColors,
  info: infoColors,
} as const;

// ============================================================================
// Semantic Colors
// ============================================================================

/**
 * Text colors for different contexts
 */
export const textColors = {
  /** Primary text color - used for main content */
  primary: neutralColors[900],
  /** Secondary text color - used for supporting content */
  secondary: neutralColors[600],
  /** Disabled text color - used for inactive elements */
  disabled: neutralColors[400],
  /** Inverse text color - used on dark backgrounds */
  inverse: neutralColors[0],
  /** Muted text color - even lighter than secondary */
  muted: neutralColors[500],
  /** Link text color */
  link: brandColors[600],
  /** Link hover text color */
  linkHover: brandColors[700],
} as const;

/**
 * Background colors for different surfaces
 */
export const backgroundColors = {
  /** Primary background - main page background */
  primary: neutralColors[0],
  /** Secondary background - cards, sections */
  secondary: neutralColors[50],
  /** Elevated background - modals, popovers */
  elevated: neutralColors[0],
  /** Accent background - highlighted sections */
  accent: brandColors[50],
  /** Muted background - subtle highlights */
  muted: neutralColors[100],
  /** Canvas background - off-white for documents */
  canvas: "#fafafa",
} as const;

/**
 * Border colors for different emphasis levels
 */
export const borderColors = {
  /** Default border color */
  default: neutralColors[200],
  /** Strong border color - for emphasis */
  strong: neutralColors[400],
  /** Subtle border color - for light separation */
  subtle: neutralColors[100],
  /** Focus border color - for focus states */
  focus: brandColors[500],
  /** Error border color - for error states */
  error: errorColors.main,
} as const;

/**
 * Status colors for different states
 */
export const statusColors = {
  success: successColors.main,
  successBackground: successColors.light,
  warning: warningColors.main,
  warningBackground: warningColors.light,
  error: errorColors.main,
  errorBackground: errorColors.light,
  info: infoColors.main,
  infoBackground: infoColors.light,
} as const;

/**
 * Interactive colors for buttons and clickable elements
 */
export const interactiveColors = {
  /** Primary action color */
  primary: brandColors[600],
  /** Primary action hover color */
  primaryHover: brandColors[700],
  /** Primary action active color */
  primaryActive: brandColors[800],
  /** Secondary action color */
  secondary: neutralColors[100],
  /** Secondary action hover color */
  secondaryHover: neutralColors[200],
  /** Secondary action active color */
  secondaryActive: neutralColors[300],
  /** Destructive action color */
  destructive: errorColors.main,
  /** Destructive action hover color */
  destructiveHover: errorColors.dark,
} as const;

/**
 * Combined semantic colors object
 */
export const semanticColors = {
  text: textColors,
  background: backgroundColors,
  border: borderColors,
  status: statusColors,
  interactive: interactiveColors,
} as const;

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Gets a color from the palette by path
 * @param path - Dot-separated path like "brand.500" or "success.main"
 * @returns The color value or undefined if not found
 */
export function getColor(path: string): string | undefined {
  const parts = path.split(".");
  let current: unknown = palette;

  for (const part of parts) {
    if (current && typeof current === "object" && part in current) {
      current = (current as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }

  return typeof current === "string" ? current : undefined;
}

/**
 * Creates an alpha variant of a hex color
 * @param hex - Hex color string (with or without #)
 * @param alpha - Alpha value between 0 and 1
 * @returns RGBA color string
 */
export function withAlpha(hex: string, alpha: number): string {
  const cleanHex = hex.replace("#", "");
  const r = parseInt(cleanHex.substring(0, 2), 16);
  const g = parseInt(cleanHex.substring(2, 4), 16);
  const b = parseInt(cleanHex.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// ============================================================================
// Type Exports
// ============================================================================

export type BrandColors = typeof brandColors;
export type NeutralColors = typeof neutralColors;
export type SuccessColors = typeof successColors;
export type WarningColors = typeof warningColors;
export type ErrorColors = typeof errorColors;
export type InfoColors = typeof infoColors;
export type Palette = typeof palette;

export type TextColors = typeof textColors;
export type BackgroundColors = typeof backgroundColors;
export type BorderColors = typeof borderColors;
export type StatusColors = typeof statusColors;
export type InteractiveColors = typeof interactiveColors;
export type SemanticColors = typeof semanticColors;

/** Type for brand color scale keys */
export type BrandColorKey = keyof typeof brandColors;

/** Type for neutral color scale keys */
export type NeutralColorKey = keyof typeof neutralColors;

/** Type for semantic status variants */
export type SemanticVariant = "light" | "main" | "dark";

/** Type for palette category keys */
export type PaletteCategory = keyof typeof palette;
