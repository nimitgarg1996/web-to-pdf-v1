/**
 * Spacing Primitives
 * Defines spacing, sizing, and layout values for PDF templates
 */

// ============================================================================
// Spacing Scale
// ============================================================================

/**
 * Spacing scale (in points)
 * Based on a 4pt base unit for consistent spacing
 */
export const spacing = {
  /** No spacing (0pt) */
  none: 0,
  /** Extra extra small spacing (2pt) */
  xxs: 2,
  /** Extra small spacing (4pt) */
  xs: 4,
  /** Small spacing (8pt) */
  sm: 8,
  /** Medium spacing (12pt) */
  md: 12,
  /** Large spacing (16pt) */
  lg: 16,
  /** Extra large spacing (24pt) */
  xl: 24,
  /** 2x large spacing (32pt) */
  "2xl": 32,
  /** 3x large spacing (48pt) */
  "3xl": 48,
  /** 4x large spacing (64pt) */
  "4xl": 64,
  /** 5x large spacing (96pt) */
  "5xl": 96,
} as const;

// ============================================================================
// Border Radius
// ============================================================================

/**
 * Border radius scale (in points)
 * For rounded corners on boxes and containers
 */
export const borderRadius = {
  /** No rounding (0pt) */
  none: 0,
  /** Small rounding (2pt) */
  sm: 2,
  /** Medium rounding (4pt) */
  md: 4,
  /** Large rounding (8pt) */
  lg: 8,
  /** Extra large rounding (12pt) */
  xl: 12,
  /** 2x large rounding (16pt) */
  "2xl": 16,
  /** Full rounding - pills/circles (9999pt) */
  full: 9999,
} as const;

// ============================================================================
// Border Width
// ============================================================================

/**
 * Border width scale (in points)
 * For consistent border sizing
 */
export const borderWidth = {
  /** No border (0pt) */
  none: 0,
  /** Hairline border (0.5pt) */
  hairline: 0.5,
  /** Thin border (1pt) */
  thin: 1,
  /** Normal border (1.5pt) */
  normal: 1.5,
  /** Thick border (2pt) */
  thick: 2,
  /** Extra thick border (4pt) */
  extraThick: 4,
} as const;

// ============================================================================
// Page Sizes
// ============================================================================

/**
 * Standard page sizes (in points)
 * 72 points = 1 inch
 */
export const pageSizes = {
  /** A4 - International standard (210mm × 297mm) */
  A4: { width: 595, height: 842 },
  /** A3 - Double A4 (297mm × 420mm) */
  A3: { width: 842, height: 1191 },
  /** A5 - Half A4 (148mm × 210mm) */
  A5: { width: 420, height: 595 },
  /** Letter - US standard (8.5" × 11") */
  LETTER: { width: 612, height: 792 },
  /** Legal - US legal (8.5" × 14") */
  LEGAL: { width: 612, height: 1008 },
  /** Tabloid - US tabloid (11" × 17") */
  TABLOID: { width: 792, height: 1224 },
  /** Executive - US executive (7.25" × 10.5") */
  EXECUTIVE: { width: 522, height: 756 },
} as const;

// ============================================================================
// Page Margins
// ============================================================================

/**
 * Margin values for a page
 */
export interface PageMargin {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

/**
 * Pre-defined page margin presets (in points)
 */
export const pageMargins = {
  /** No margins */
  none: { top: 0, right: 0, bottom: 0, left: 0 } as PageMargin,
  /** Narrow margins (0.5") */
  narrow: { top: 36, right: 36, bottom: 36, left: 36 } as PageMargin,
  /** Normal margins (0.75") */
  normal: { top: 54, right: 54, bottom: 54, left: 54 } as PageMargin,
  /** Wide margins (1") */
  wide: { top: 72, right: 72, bottom: 72, left: 72 } as PageMargin,
  /** Extra wide margins (1.25") */
  extraWide: { top: 90, right: 90, bottom: 90, left: 90 } as PageMargin,
  /** Asymmetric for binding (wider left) */
  binding: { top: 72, right: 54, bottom: 72, left: 90 } as PageMargin,
  /** Minimal header space (larger top for headers) */
  withHeader: { top: 96, right: 54, bottom: 72, left: 54 } as PageMargin,
  /** Minimal footer space (larger bottom for footers) */
  withFooter: { top: 72, right: 54, bottom: 96, left: 54 } as PageMargin,
  /** Both header and footer space */
  withHeaderFooter: { top: 96, right: 54, bottom: 96, left: 54 } as PageMargin,
} as const;

// ============================================================================
// Container Sizes
// ============================================================================

/**
 * Maximum widths for content containers
 * Used for constraining content within pages
 */
export const containerSizes = {
  /** Extra small container (280pt) */
  xs: 280,
  /** Small container (320pt) */
  sm: 320,
  /** Medium container (480pt) */
  md: 480,
  /** Large container (640pt) */
  lg: 640,
  /** Extra large container (768pt) */
  xl: 768,
  /** Full width - no constraint */
  full: "100%",
} as const;

// ============================================================================
// Gap Sizes
// ============================================================================

/**
 * Gap sizes for flex/grid layouts
 * Matches spacing scale for consistency
 */
export const gaps = {
  /** No gap (0pt) */
  none: 0,
  /** Extra small gap (4pt) */
  xs: 4,
  /** Small gap (8pt) */
  sm: 8,
  /** Medium gap (12pt) */
  md: 12,
  /** Large gap (16pt) */
  lg: 16,
  /** Extra large gap (24pt) */
  xl: 24,
  /** 2x large gap (32pt) */
  "2xl": 32,
} as const;

// ============================================================================
// Z-Index Scale
// ============================================================================

/**
 * Z-index values for layering
 * Note: Limited use in PDFs but useful for component ordering
 */
export const zIndex = {
  /** Base level */
  base: 0,
  /** Raised elements */
  raised: 1,
  /** Dropdown menus */
  dropdown: 10,
  /** Sticky elements */
  sticky: 20,
  /** Fixed elements */
  fixed: 30,
  /** Modal overlays */
  modal: 40,
  /** Popover/tooltip */
  popover: 50,
  /** Toast notifications */
  toast: 60,
  /** Maximum z-index */
  max: 9999,
} as const;

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Creates custom page margins
 * @param top - Top margin in points
 * @param right - Right margin in points (defaults to top)
 * @param bottom - Bottom margin in points (defaults to top)
 * @param left - Left margin in points (defaults to right)
 * @returns PageMargin object
 */
export function createMargins(
  top: number,
  right?: number,
  bottom?: number,
  left?: number
): PageMargin {
  return {
    top,
    right: right ?? top,
    bottom: bottom ?? top,
    left: left ?? right ?? top,
  };
}

/**
 * Creates uniform margins (same on all sides)
 * @param value - Margin value in points
 * @returns PageMargin object with uniform margins
 */
export function uniformMargins(value: number): PageMargin {
  return { top: value, right: value, bottom: value, left: value };
}

/**
 * Calculates content area dimensions from page size and margins
 * @param pageSize - Page size object with width and height
 * @param margins - Page margins object
 * @returns Content area dimensions
 */
export function getContentArea(
  pageSize: { width: number; height: number },
  margins: PageMargin
): { width: number; height: number } {
  return {
    width: pageSize.width - margins.left - margins.right,
    height: pageSize.height - margins.top - margins.bottom,
  };
}

/**
 * Gets page size with orientation
 * @param size - Page size name
 * @param orientation - Page orientation
 * @returns Page dimensions
 */
export function getPageSize(
  size: keyof typeof pageSizes,
  orientation: "portrait" | "landscape" = "portrait"
): { width: number; height: number } {
  const pageSize = pageSizes[size];
  if (orientation === "landscape") {
    return { width: pageSize.height, height: pageSize.width };
  }
  return pageSize;
}

// ============================================================================
// Type Exports
// ============================================================================

export type Spacing = typeof spacing;
export type BorderRadius = typeof borderRadius;
export type BorderWidth = typeof borderWidth;
export type PageSizes = typeof pageSizes;
export type PageMargins = typeof pageMargins;
export type ContainerSizes = typeof containerSizes;
export type Gaps = typeof gaps;
export type ZIndex = typeof zIndex;

/** Type for spacing keys */
export type SpacingKey = keyof typeof spacing;

/** Type for border radius keys */
export type BorderRadiusKey = keyof typeof borderRadius;

/** Type for border width keys */
export type BorderWidthKey = keyof typeof borderWidth;

/** Type for page size keys */
export type PageSizeKey = keyof typeof pageSizes;

/** Type for page margin preset keys */
export type PageMarginKey = keyof typeof pageMargins;

/** Type for container size keys */
export type ContainerSizeKey = keyof typeof containerSizes;

/** Type for gap keys */
export type GapKey = keyof typeof gaps;
