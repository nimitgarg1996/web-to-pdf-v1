/**
 * Primitives Index
 * Exports all primitive design tokens for the PDF report builder
 *
 * Primitives are the atomic foundation layer containing:
 * - Colors: palette and semantic color mappings
 * - Typography: fonts, sizes, weights, and text styles
 * - Spacing: margins, padding, gaps, and layout values
 * - Icons: SVG icon registry
 * - Theme: combined theme system
 */

// ============================================================================
// Color Exports
// ============================================================================

export {
  // Individual color scales
  brandColors,
  neutralColors,
  successColors,
  warningColors,
  errorColors,
  infoColors,
  // Combined palette
  palette,
  // Semantic color mappings
  textColors,
  backgroundColors,
  borderColors,
  statusColors,
  interactiveColors,
  semanticColors,
  // Utility functions
  getColor,
  withAlpha,
} from "./colors.js";

export type {
  BrandColors,
  NeutralColors,
  SuccessColors,
  WarningColors,
  ErrorColors,
  InfoColors,
  Palette,
  TextColors,
  BackgroundColors,
  BorderColors,
  StatusColors,
  InteractiveColors,
  SemanticColors,
  BrandColorKey,
  NeutralColorKey,
  SemanticVariant,
  PaletteCategory,
} from "./colors.js";

// ============================================================================
// Typography Exports
// ============================================================================

export {
  // Font definitions
  fontFamilies,
  fontSizes,
  fontWeights,
  lineHeights,
  letterSpacing,
  // Pre-built text styles
  textStyles,
  // Utility functions
  getTextStyle,
  createTextStyle,
  calculateLineHeight,
} from "./typography.js";

export type {
  TextStyle,
  FontFamilies,
  FontSizes,
  FontWeights,
  LineHeights,
  LetterSpacing,
  TextStyles,
  FontFamilyKey,
  FontSizeKey,
  FontWeightKey,
  LineHeightKey,
  LetterSpacingKey,
  TextStyleKey,
} from "./typography.js";

// ============================================================================
// Spacing Exports
// ============================================================================

export {
  // Spacing scale
  spacing,
  // Border values
  borderRadius,
  borderWidth,
  // Page configuration
  pageSizes,
  pageMargins,
  // Layout values
  containerSizes,
  gaps,
  zIndex,
  // Utility functions
  createMargins,
  uniformMargins,
  getContentArea,
  getPageSize,
} from "./spacing.js";

export type {
  PageMargin,
  Spacing,
  BorderRadius,
  BorderWidth,
  PageSizes,
  PageMargins,
  ContainerSizes,
  Gaps,
  ZIndex,
  SpacingKey,
  BorderRadiusKey,
  BorderWidthKey,
  PageSizeKey,
  PageMarginKey,
  ContainerSizeKey,
  GapKey,
} from "./spacing.js";

// ============================================================================
// Icon Exports
// ============================================================================

export {
  // Icon registry
  icons,
  // Utility functions
  getIcon,
  getIconNames,
  hasIcon,
  createSvgMarkup,
} from "./icons.js";

export type {
  IconDefinition,
  IconName,
  IconRegistry,
  IconCategory,
} from "./icons.js";

// ============================================================================
// Theme Exports
// ============================================================================

export {
  // Default theme
  defaultTheme,
  // Theme creation
  createTheme,
  // Theme presets
  corporateTheme,
  modernTheme,
  minimalTheme,
  // Theme accessors
  getThemeValue,
  getThemeColor,
  getThemeSpacing,
  getThemeTextStyle,
} from "./theme.js";

export type { Theme, ThemeOverrides } from "./theme.js";
