/**
 * Theme Primitives
 * Combines all primitives into a cohesive theme system
 */

import {
  palette,
  semanticColors,
  type Palette,
  type SemanticColors,
} from "./colors.js";

import {
  fontFamilies,
  fontSizes,
  fontWeights,
  lineHeights,
  letterSpacing,
  textStyles,
  type FontFamilies,
  type FontSizes,
  type FontWeights,
  type LineHeights,
  type LetterSpacing,
  type TextStyles,
} from "./typography.js";

import {
  spacing,
  borderRadius,
  borderWidth,
  pageSizes,
  pageMargins,
  containerSizes,
  gaps,
  type Spacing,
  type BorderRadius,
  type BorderWidth,
  type PageSizes,
  type PageMargins,
  type ContainerSizes,
  type Gaps,
} from "./spacing.js";

import { icons, type IconRegistry } from "./icons.js";

// ============================================================================
// Theme Interface
// ============================================================================

/**
 * Complete theme interface defining all design tokens
 * Uses looser types to allow overrides in custom themes
 */
export interface Theme {
  /** Color system */
  colors: {
    /** Raw color palette */
    palette: {
      brand: Record<number, string>;
      neutral: Record<number, string>;
      success: { light: string; main: string; dark: string };
      warning: { light: string; main: string; dark: string };
      error: { light: string; main: string; dark: string };
      info: { light: string; main: string; dark: string };
    };
    /** Semantic color mappings */
    semantic: {
      text: Record<string, string>;
      background: Record<string, string>;
      border: Record<string, string>;
      status: Record<string, string>;
      interactive: Record<string, string>;
    };
  };

  /** Typography system */
  typography: {
    /** Available font families */
    fontFamilies: Record<string, string>;
    /** Font size scale */
    fontSizes: Record<string, number>;
    /** Font weight options */
    fontWeights: Record<string, string | number>;
    /** Line height multipliers */
    lineHeights: Record<string, number>;
    /** Letter spacing values */
    letterSpacing: Record<string, number>;
    /** Pre-built text styles */
    textStyles: Record<
      string,
      {
        fontSize: number;
        fontFamily: string;
        fontWeight: string | number;
        lineHeight: number;
        letterSpacing?: number;
        textTransform?: string;
        color?: string;
      }
    >;
  };

  /** Spacing system */
  spacing: Record<string, number>;

  /** Border system */
  borders: {
    /** Border radius scale */
    radius: Record<string, number>;
    /** Border width scale */
    width: Record<string, number>;
  };

  /** Page configuration */
  page: {
    /** Standard page sizes */
    sizes: Record<string, { width: number; height: number }>;
    /** Page margin presets */
    margins: Record<
      string,
      { top: number; right: number; bottom: number; left: number }
    >;
  };

  /** Layout system */
  layout: {
    /** Container max-widths */
    containers: Record<string, number | string>;
    /** Gap sizes for flex/grid */
    gaps: Record<string, number>;
  };

  /** Icon registry */
  icons: Record<string, { viewBox: string; path: string; fillRule?: string }>;
}

// ============================================================================
// Default Theme
// ============================================================================

/**
 * The default theme with all primitives
 */
export const defaultTheme: Theme = {
  colors: {
    palette: palette as Theme["colors"]["palette"],
    semantic: semanticColors as Theme["colors"]["semantic"],
  },
  typography: {
    fontFamilies: fontFamilies as Theme["typography"]["fontFamilies"],
    fontSizes: fontSizes as Theme["typography"]["fontSizes"],
    fontWeights: fontWeights as Theme["typography"]["fontWeights"],
    lineHeights: lineHeights as Theme["typography"]["lineHeights"],
    letterSpacing: letterSpacing as Theme["typography"]["letterSpacing"],
    textStyles: textStyles as Theme["typography"]["textStyles"],
  },
  spacing: spacing as Theme["spacing"],
  borders: {
    radius: borderRadius as Theme["borders"]["radius"],
    width: borderWidth as Theme["borders"]["width"],
  },
  page: {
    sizes: pageSizes as Theme["page"]["sizes"],
    margins: pageMargins as Theme["page"]["margins"],
  },
  layout: {
    containers: containerSizes as Theme["layout"]["containers"],
    gaps: gaps as Theme["layout"]["gaps"],
  },
  icons: icons as Theme["icons"],
};

// ============================================================================
// Theme Creation & Utilities
// ============================================================================

/**
 * Deep merge utility for theme objects
 */
function deepMerge<T extends object>(target: T, source: Partial<T>): T {
  const result = { ...target } as T;

  for (const key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      const sourceValue = source[key];
      const targetValue = (result as Record<string, unknown>)[key];

      if (
        sourceValue &&
        typeof sourceValue === "object" &&
        !Array.isArray(sourceValue) &&
        targetValue &&
        typeof targetValue === "object" &&
        !Array.isArray(targetValue)
      ) {
        (result as Record<string, unknown>)[key] = deepMerge(
          targetValue as object,
          sourceValue as object
        );
      } else if (sourceValue !== undefined) {
        (result as Record<string, unknown>)[key] = sourceValue;
      }
    }
  }

  return result;
}

/**
 * Partial theme type for overrides
 */
export interface ThemeOverrides {
  colors?: Partial<Theme["colors"]>;
  typography?: Partial<Theme["typography"]>;
  spacing?: Partial<Theme["spacing"]>;
  borders?: Partial<Theme["borders"]>;
  page?: Partial<Theme["page"]>;
  layout?: Partial<Theme["layout"]>;
}

/**
 * Creates a new theme by merging overrides with the default theme
 * @param overrides - Partial theme values to override defaults
 * @returns A complete theme with overrides applied
 */
export function createTheme(overrides?: ThemeOverrides): Theme {
  if (!overrides) {
    return defaultTheme;
  }

  return deepMerge(defaultTheme, overrides as Partial<Theme>);
}

// ============================================================================
// Theme Presets
// ============================================================================

/**
 * Corporate theme preset - more formal, subdued colors
 */
export const corporateTheme: Theme = createTheme({
  colors: {
    palette: {
      ...defaultTheme.colors.palette,
      brand: {
        ...defaultTheme.colors.palette.brand,
        500: "#1e40af", // Darker blue
        600: "#1e3a8a",
        700: "#172554",
      },
    },
  },
  typography: {
    ...defaultTheme.typography,
    fontFamilies: {
      ...defaultTheme.typography.fontFamilies,
      primary: "Times-Roman",
      secondary: "Helvetica-Bold",
    },
  },
});

/**
 * Modern theme preset - vibrant, contemporary feel
 */
export const modernTheme: Theme = createTheme({
  colors: {
    palette: {
      ...defaultTheme.colors.palette,
      brand: {
        ...defaultTheme.colors.palette.brand,
        500: "#8b5cf6", // Purple
        600: "#7c3aed",
        700: "#6d28d9",
      },
    },
  },
  borders: {
    ...defaultTheme.borders,
    radius: {
      ...defaultTheme.borders.radius,
      md: 8,
      lg: 12,
    },
  },
});

/**
 * Minimal theme preset - clean, lots of whitespace
 */
export const minimalTheme: Theme = createTheme({
  colors: {
    ...defaultTheme.colors,
    semantic: {
      ...defaultTheme.colors.semantic,
      text: {
        ...defaultTheme.colors.semantic.text,
        primary: "#1e293b",
        secondary: "#64748b",
      },
    },
  },
  spacing: {
    ...defaultTheme.spacing,
    md: 16,
    lg: 24,
    xl: 32,
  },
});

// ============================================================================
// Theme Accessors
// ============================================================================

/**
 * Gets a value from the theme using a dot-notation path
 * @param theme - The theme object
 * @param path - Dot-separated path (e.g., "colors.palette.brand.500")
 * @returns The value at the path or undefined
 */
export function getThemeValue(theme: Theme, path: string): unknown {
  const parts = path.split(".");
  let current: unknown = theme;

  for (const part of parts) {
    if (current && typeof current === "object" && part in current) {
      current = (current as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }

  return current;
}

/**
 * Gets a color from the theme
 * @param theme - The theme object
 * @param colorPath - Path to the color (e.g., "palette.brand.500" or "semantic.text.primary")
 * @returns The color value or undefined
 */
export function getThemeColor(
  theme: Theme,
  colorPath: string
): string | undefined {
  const value = getThemeValue(theme, `colors.${colorPath}`);
  return typeof value === "string" ? value : undefined;
}

/**
 * Gets a spacing value from the theme
 * @param theme - The theme object
 * @param size - The spacing size key
 * @returns The spacing value in points
 */
export function getThemeSpacing(theme: Theme, size: string): number | undefined {
  return theme.spacing[size];
}

/**
 * Gets a text style from the theme
 * @param theme - The theme object
 * @param style - The text style key
 * @returns The text style object
 */
export function getThemeTextStyle(
  theme: Theme,
  style: string
): Theme["typography"]["textStyles"][string] | undefined {
  return theme.typography.textStyles[style];
}
