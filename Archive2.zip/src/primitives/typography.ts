/**
 * Typography Primitives
 * Defines the complete typography system for PDF templates
 */

// ============================================================================
// Font Families
// ============================================================================

/**
 * Font family definitions
 * These map to system fonts or registered custom fonts
 */
export const fontFamilies = {
  /** Primary font for body text and UI */
  primary: "Helvetica",
  /** Secondary font for headings and emphasis */
  secondary: "Helvetica-Bold",
  /** Monospace font for code and technical content */
  mono: "Courier",
  /** Serif font for formal documents */
  serif: "Times-Roman",
} as const;

// ============================================================================
// Font Sizes
// ============================================================================

/**
 * Font size scale (in points)
 * Based on a minor third (1.2) scale for harmonious sizing
 */
export const fontSizes = {
  /** Extra small - footnotes, legal text (10pt) */
  xs: 10,
  /** Small - captions, labels (11pt) */
  sm: 11,
  /** Base - body text (12pt) */
  base: 12,
  /** Large - emphasized body, small headings (14pt) */
  lg: 14,
  /** Extra large - subheadings (16pt) */
  xl: 16,
  /** 2x large - section headings (20pt) */
  "2xl": 20,
  /** 3x large - major headings (24pt) */
  "3xl": 24,
  /** 4x large - page titles (30pt) */
  "4xl": 30,
  /** 5x large - cover titles (36pt) */
  "5xl": 36,
  /** 6x large - display text (48pt) */
  "6xl": 48,
} as const;

// ============================================================================
// Font Weights
// ============================================================================

/**
 * Font weight definitions
 * Maps semantic names to CSS font-weight values
 * Note: In PDF, we typically use font family variants for weights
 */
export const fontWeights = {
  /** Normal weight for body text */
  normal: "normal" as const,
  /** Medium weight for subtle emphasis */
  medium: 500,
  /** Semibold weight for moderate emphasis */
  semibold: 600,
  /** Bold weight for strong emphasis */
  bold: "bold" as const,
} as const;

// ============================================================================
// Line Heights
// ============================================================================

/**
 * Line height multipliers
 * Applied as multiples of the font size
 */
export const lineHeights = {
  /** None - single line height (1) */
  none: 1,
  /** Tight - compact spacing (1.2) */
  tight: 1.2,
  /** Snug - slightly compact (1.35) */
  snug: 1.35,
  /** Normal - standard reading (1.5) */
  normal: 1.5,
  /** Relaxed - comfortable reading (1.75) */
  relaxed: 1.75,
  /** Loose - very open spacing (2) */
  loose: 2,
} as const;

// ============================================================================
// Letter Spacing
// ============================================================================

/**
 * Letter spacing values (in points)
 * Positive values spread letters, negative values tighten
 */
export const letterSpacing = {
  /** Tighter letter spacing (-0.5pt) */
  tighter: -0.5,
  /** Tight letter spacing (-0.25pt) */
  tight: -0.25,
  /** Normal letter spacing (0pt) */
  normal: 0,
  /** Wide letter spacing (0.25pt) */
  wide: 0.25,
  /** Wider letter spacing (0.5pt) */
  wider: 0.5,
  /** Widest letter spacing (1pt) */
  widest: 1,
} as const;

// ============================================================================
// Text Styles (Pre-built Combinations)
// ============================================================================

/**
 * Text style interface for type safety
 */
export interface TextStyle {
  fontSize: number;
  fontFamily: string;
  fontWeight: string | number;
  lineHeight: number;
  letterSpacing?: number;
  textTransform?: "uppercase" | "lowercase" | "capitalize" | "none";
  color?: string;
}

/**
 * Pre-built text styles combining font properties
 * These provide consistent typography throughout documents
 */
export const textStyles = {
  /** Display - large decorative headings */
  display: {
    fontSize: fontSizes["6xl"],
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.bold,
    lineHeight: lineHeights.tight,
    letterSpacing: letterSpacing.tight,
  },

  /** H1 - main page headings */
  h1: {
    fontSize: fontSizes["4xl"],
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.bold,
    lineHeight: lineHeights.tight,
    letterSpacing: letterSpacing.tight,
  },

  /** H2 - section headings */
  h2: {
    fontSize: fontSizes["3xl"],
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.bold,
    lineHeight: lineHeights.tight,
    letterSpacing: letterSpacing.normal,
  },

  /** H3 - subsection headings */
  h3: {
    fontSize: fontSizes["2xl"],
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.semibold,
    lineHeight: lineHeights.snug,
    letterSpacing: letterSpacing.normal,
  },

  /** H4 - minor headings */
  h4: {
    fontSize: fontSizes.xl,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.semibold,
    lineHeight: lineHeights.snug,
    letterSpacing: letterSpacing.normal,
  },

  /** H5 - small headings */
  h5: {
    fontSize: fontSizes.lg,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.medium,
    lineHeight: lineHeights.normal,
    letterSpacing: letterSpacing.normal,
  },

  /** H6 - smallest headings */
  h6: {
    fontSize: fontSizes.base,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.medium,
    lineHeight: lineHeights.normal,
    letterSpacing: letterSpacing.wide,
    textTransform: "uppercase" as const,
  },

  /** Body - standard paragraph text */
  body: {
    fontSize: fontSizes.base,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.normal,
    letterSpacing: letterSpacing.normal,
  },

  /** Body Large - emphasized body text */
  bodyLarge: {
    fontSize: fontSizes.lg,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.relaxed,
    letterSpacing: letterSpacing.normal,
  },

  /** Body Small - secondary body text */
  bodySmall: {
    fontSize: fontSizes.sm,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.normal,
    letterSpacing: letterSpacing.normal,
  },

  /** Caption - image captions, footnotes */
  caption: {
    fontSize: fontSizes.xs,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.normal,
    letterSpacing: letterSpacing.normal,
  },

  /** Label - form labels, table headers */
  label: {
    fontSize: fontSizes.sm,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.medium,
    lineHeight: lineHeights.tight,
    letterSpacing: letterSpacing.wide,
  },

  /** Overline - category labels, metadata */
  overline: {
    fontSize: fontSizes.xs,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.semibold,
    lineHeight: lineHeights.tight,
    letterSpacing: letterSpacing.widest,
    textTransform: "uppercase" as const,
  },

  /** Code - inline code snippets */
  code: {
    fontSize: fontSizes.sm,
    fontFamily: fontFamilies.mono,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.normal,
    letterSpacing: letterSpacing.normal,
  },

  /** Code Block - multi-line code */
  codeBlock: {
    fontSize: fontSizes.sm,
    fontFamily: fontFamilies.mono,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.relaxed,
    letterSpacing: letterSpacing.normal,
  },

  /** Blockquote - quoted text */
  blockquote: {
    fontSize: fontSizes.lg,
    fontFamily: fontFamilies.serif,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.relaxed,
    letterSpacing: letterSpacing.normal,
  },

  /** Legal - fine print, disclaimers */
  legal: {
    fontSize: fontSizes.xs,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.snug,
    letterSpacing: letterSpacing.normal,
  },

  /** Metric Value - large numbers for dashboards */
  metricValue: {
    fontSize: fontSizes["3xl"],
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.bold,
    lineHeight: lineHeights.none,
    letterSpacing: letterSpacing.tight,
  },

  /** Metric Label - labels for metric cards */
  metricLabel: {
    fontSize: fontSizes.xs,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.medium,
    lineHeight: lineHeights.tight,
    letterSpacing: letterSpacing.wide,
    textTransform: "uppercase" as const,
  },

  /** Table Header - column headers in tables */
  tableHeader: {
    fontSize: fontSizes.sm,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.semibold,
    lineHeight: lineHeights.tight,
    letterSpacing: letterSpacing.normal,
  },

  /** Table Cell - cell content in tables */
  tableCell: {
    fontSize: fontSizes.sm,
    fontFamily: fontFamilies.primary,
    fontWeight: fontWeights.normal,
    lineHeight: lineHeights.snug,
    letterSpacing: letterSpacing.normal,
  },
} as const;

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Gets a text style by name
 * @param name - The name of the text style
 * @returns The text style object or undefined
 */
export function getTextStyle(
  name: keyof typeof textStyles
): (typeof textStyles)[keyof typeof textStyles] {
  return textStyles[name];
}

/**
 * Creates a custom text style by merging with a base style
 * @param base - The base text style name or object
 * @param overrides - Properties to override
 * @returns A new text style object
 */
export function createTextStyle(
  base: keyof typeof textStyles | TextStyle,
  overrides: Partial<TextStyle>
): TextStyle {
  const baseStyle = typeof base === "string" ? textStyles[base] : base;
  return { ...baseStyle, ...overrides };
}

/**
 * Calculates line height in points from font size and multiplier
 * @param fontSize - Font size in points
 * @param lineHeightMultiplier - Line height multiplier
 * @returns Line height in points
 */
export function calculateLineHeight(
  fontSize: number,
  lineHeightMultiplier: number
): number {
  return fontSize * lineHeightMultiplier;
}

// ============================================================================
// Type Exports
// ============================================================================

export type FontFamilies = typeof fontFamilies;
export type FontSizes = typeof fontSizes;
export type FontWeights = typeof fontWeights;
export type LineHeights = typeof lineHeights;
export type LetterSpacing = typeof letterSpacing;
export type TextStyles = typeof textStyles;

/** Type for font family keys */
export type FontFamilyKey = keyof typeof fontFamilies;

/** Type for font size keys */
export type FontSizeKey = keyof typeof fontSizes;

/** Type for font weight keys */
export type FontWeightKey = keyof typeof fontWeights;

/** Type for line height keys */
export type LineHeightKey = keyof typeof lineHeights;

/** Type for letter spacing keys */
export type LetterSpacingKey = keyof typeof letterSpacing;

/** Type for text style keys */
export type TextStyleKey = keyof typeof textStyles;
