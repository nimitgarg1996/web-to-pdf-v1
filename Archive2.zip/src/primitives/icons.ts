/**
 * Icon Primitives
 * Defines SVG icons for use in PDF templates
 * Icons are stored as path data to be rendered in SVG components
 */

// ============================================================================
// Icon Definition Interface
// ============================================================================

/**
 * Definition of an SVG icon
 */
export interface IconDefinition {
  /** SVG viewBox attribute (e.g., "0 0 24 24") */
  viewBox: string;
  /** SVG path data */
  path: string;
  /** Optional fill rule */
  fillRule?: "nonzero" | "evenodd";
}

// ============================================================================
// Icon Registry
// ============================================================================

/**
 * Collection of common icons for PDF documents
 * All icons use a 24x24 viewBox by default
 */
export const icons = {
  // Status Icons
  check: {
    viewBox: "0 0 24 24",
    path: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z",
  },
  checkCircle: {
    viewBox: "0 0 24 24",
    path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z",
  },
  warning: {
    viewBox: "0 0 24 24",
    path: "M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z",
  },
  error: {
    viewBox: "0 0 24 24",
    path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z",
  },
  info: {
    viewBox: "0 0 24 24",
    path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z",
  },
  close: {
    viewBox: "0 0 24 24",
    path: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
  },

  // Arrow Icons
  arrowRight: {
    viewBox: "0 0 24 24",
    path: "M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z",
  },
  arrowLeft: {
    viewBox: "0 0 24 24",
    path: "M14 6l1.41 1.41L10.83 12l4.58 4.59L14 18l-6-6z",
  },
  arrowUp: {
    viewBox: "0 0 24 24",
    path: "M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z",
  },
  arrowDown: {
    viewBox: "0 0 24 24",
    path: "M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z",
  },
  arrowForward: {
    viewBox: "0 0 24 24",
    path: "M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z",
  },
  arrowBack: {
    viewBox: "0 0 24 24",
    path: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z",
  },

  // Document Icons
  document: {
    viewBox: "0 0 24 24",
    path: "M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z",
  },
  folder: {
    viewBox: "0 0 24 24",
    path: "M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z",
  },
  attachment: {
    viewBox: "0 0 24 24",
    path: "M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z",
  },
  download: {
    viewBox: "0 0 24 24",
    path: "M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z",
  },

  // UI Icons
  menu: {
    viewBox: "0 0 24 24",
    path: "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z",
  },
  moreVertical: {
    viewBox: "0 0 24 24",
    path: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",
  },
  moreHorizontal: {
    viewBox: "0 0 24 24",
    path: "M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z",
  },
  search: {
    viewBox: "0 0 24 24",
    path: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
  },
  settings: {
    viewBox: "0 0 24 24",
    path: "M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z",
  },

  // Action Icons
  edit: {
    viewBox: "0 0 24 24",
    path: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z",
  },
  delete: {
    viewBox: "0 0 24 24",
    path: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z",
  },
  add: {
    viewBox: "0 0 24 24",
    path: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z",
  },
  remove: {
    viewBox: "0 0 24 24",
    path: "M19 13H5v-2h14v2z",
  },
  copy: {
    viewBox: "0 0 24 24",
    path: "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z",
  },

  // Communication Icons
  email: {
    viewBox: "0 0 24 24",
    path: "M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z",
  },
  phone: {
    viewBox: "0 0 24 24",
    path: "M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z",
  },
  location: {
    viewBox: "0 0 24 24",
    path: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z",
  },

  // Data/Chart Icons
  chartBar: {
    viewBox: "0 0 24 24",
    path: "M5 9.2h3V19H5V9.2zM10.6 5h2.8v14h-2.8V5zm5.6 8H19v6h-2.8v-6z",
  },
  chartLine: {
    viewBox: "0 0 24 24",
    path: "M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z",
  },
  chartPie: {
    viewBox: "0 0 24 24",
    path: "M11 2v20c-5.07-.5-9-4.79-9-10s3.93-9.5 9-10zm2.03 0v8.99H22c-.47-4.74-4.24-8.52-8.97-8.99zm0 11.01V22c4.74-.47 8.5-4.25 8.97-8.99h-8.97z",
  },
  table: {
    viewBox: "0 0 24 24",
    path: "M3 3v18h18V3H3zm8 16H5v-6h6v6zm0-8H5V5h6v6zm8 8h-6v-6h6v6zm0-8h-6V5h6v6z",
  },

  // Misc Icons
  star: {
    viewBox: "0 0 24 24",
    path: "M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z",
  },
  starOutline: {
    viewBox: "0 0 24 24",
    path: "M22 9.24l-7.19-.62L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.63-7.03L22 9.24zM12 15.4l-3.76 2.27 1-4.28-3.32-2.88 4.38-.38L12 6.1l1.71 4.04 4.38.38-3.32 2.88 1 4.28L12 15.4z",
  },
  heart: {
    viewBox: "0 0 24 24",
    path: "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z",
  },
  calendar: {
    viewBox: "0 0 24 24",
    path: "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM9 10H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2z",
  },
  clock: {
    viewBox: "0 0 24 24",
    path: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z",
  },
  user: {
    viewBox: "0 0 24 24",
    path: "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z",
  },
  users: {
    viewBox: "0 0 24 24",
    path: "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z",
  },
  link: {
    viewBox: "0 0 24 24",
    path: "M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z",
  },
  externalLink: {
    viewBox: "0 0 24 24",
    path: "M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z",
  },
  print: {
    viewBox: "0 0 24 24",
    path: "M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z",
  },
} as const;

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Gets an icon definition by name
 * @param name - The name of the icon
 * @returns The icon definition or undefined if not found
 */
export function getIcon(name: IconName): IconDefinition | undefined {
  return icons[name];
}

/**
 * Gets all available icon names
 * @returns Array of icon names
 */
export function getIconNames(): IconName[] {
  return Object.keys(icons) as IconName[];
}

/**
 * Checks if an icon exists in the registry
 * @param name - The name to check
 * @returns True if the icon exists
 */
export function hasIcon(name: string): name is IconName {
  return name in icons;
}

/**
 * Creates an SVG path string with the given icon
 * Useful for direct SVG rendering
 * @param name - The icon name
 * @param color - Optional fill color
 * @returns SVG markup string or empty string if icon not found
 */
export function createSvgMarkup(name: IconName, color?: string): string {
  const icon = icons[name];
  if (!icon) return "";

  const fill = color ? ` fill="${color}"` : "";
  return `<svg viewBox="${icon.viewBox}"${fill}><path d="${icon.path}"/></svg>`;
}

// ============================================================================
// Type Exports
// ============================================================================

/** Type for icon names in the registry */
export type IconName = keyof typeof icons;

/** Type for the icons registry object */
export type IconRegistry = typeof icons;

/** Type for icon category (derived from naming convention) */
export type IconCategory =
  | "status"
  | "arrow"
  | "document"
  | "ui"
  | "action"
  | "communication"
  | "data"
  | "misc";
