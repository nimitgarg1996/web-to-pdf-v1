/**
 * Blueprint Validator Tests
 *
 * Tests for the blueprint validation system that ensures
 * blueprints conform to the expected schema before document generation.
 */

import { validateBlueprint, isValidBlueprint, assertValidBlueprint } from "../../factories/index.js";
import type { Blueprint, ReportBlueprint, InvoiceBlueprint } from "../../blueprints/types.js";
import { createTestBlueprint, createTestContentBlock } from "../setup.js";

describe("BlueprintValidator", () => {
  // ===========================================================================
  // Basic Validation
  // ===========================================================================

  describe("validateBlueprint", () => {
    it("validates a correct report blueprint", () => {
      const blueprint: ReportBlueprint = {
        id: "valid-report-001",
        version: "1.0.0",
        type: "report",
        metadata: {
          title: "Valid Report",
          author: "Test Author",
          date: "2026-01-28",
        },
        content: {
          showCover: true,
          sections: [
            { type: "heading", level: 1, text: "Introduction" },
            { type: "paragraph", text: "This is a valid report." },
          ],
        },
      };

      const result = validateBlueprint(blueprint);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("validates a correct invoice blueprint", () => {
      const blueprint: InvoiceBlueprint = {
        id: "valid-invoice-001",
        version: "1.0.0",
        type: "invoice",
        metadata: {
          title: "Invoice",
          invoiceNumber: "INV-001",
          date: "2026-01-28",
        },
        content: {
          invoiceNumber: "INV-001",
          issueDate: "2026-01-28",
          dueDate: "2026-02-28",
          status: "pending",
          from: {
            name: "Company A",
            address: ["123 Main St"],
          },
          to: {
            name: "Client B",
            address: ["456 Oak Ave"],
          },
          items: [
            { description: "Service", quantity: 1, unitPrice: 100, total: 100 },
          ],
          subtotal: 100,
          total: 100,
          currency: "USD",
        },
      };

      const result = validateBlueprint(blueprint);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("rejects blueprint missing id", () => {
      const blueprint = createTestBlueprint({ id: undefined });
      delete blueprint.id;

      const result = validateBlueprint(blueprint as Blueprint);

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
      expect(result.errors.some((e) => e.path.includes("id"))).toBe(true);
    });

    it("rejects blueprint missing version", () => {
      const blueprint = createTestBlueprint({ version: undefined });
      delete blueprint.version;

      const result = validateBlueprint(blueprint as Blueprint);

      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.path.includes("version"))).toBe(true);
    });

    it("rejects blueprint with invalid type", () => {
      const blueprint = createTestBlueprint({ type: "invalid-type" });

      const result = validateBlueprint(blueprint as Blueprint);

      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.path.includes("type"))).toBe(true);
    });

    it("rejects blueprint missing metadata", () => {
      const blueprint = createTestBlueprint({ metadata: undefined });
      delete blueprint.metadata;

      const result = validateBlueprint(blueprint as Blueprint);

      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.path.includes("metadata"))).toBe(true);
    });

    it("rejects blueprint missing content", () => {
      const blueprint = createTestBlueprint({ content: undefined });
      delete blueprint.content;

      const result = validateBlueprint(blueprint as Blueprint);

      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.path.includes("content"))).toBe(true);
    });

    it("rejects completely invalid input", () => {
      const result = validateBlueprint({ invalid: true } as unknown as Blueprint);

      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    it("rejects null input", () => {
      const result = validateBlueprint(null as unknown as Blueprint);

      expect(result.valid).toBe(false);
    });

    it("rejects undefined input", () => {
      const result = validateBlueprint(undefined as unknown as Blueprint);

      expect(result.valid).toBe(false);
    });
  });

  // ===========================================================================
  // Metadata Validation
  // ===========================================================================

  describe("metadata validation", () => {
    it("requires title in metadata", () => {
      const blueprint = createTestBlueprint({
        metadata: { author: "Test" },
      });

      const result = validateBlueprint(blueprint as Blueprint);

      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.message.toLowerCase().includes("title"))).toBe(
        true
      );
    });

    it("accepts optional metadata fields", () => {
      const blueprint = createTestBlueprint({
        metadata: {
          title: "Test",
          subtitle: "Subtitle",
          author: "Author",
          date: "2026-01-28",
          logo: "/path/to/logo.png",
          company: "Company",
          pageSize: "A4",
          orientation: "portrait",
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);

      expect(result.valid).toBe(true);
    });

    it("validates pageSize enum values", () => {
      const validPageSizes = ["A4", "Letter", "Legal"];

      for (const pageSize of validPageSizes) {
        const blueprint = createTestBlueprint({
          metadata: { title: "Test", pageSize },
        });

        const result = validateBlueprint(blueprint as Blueprint);
        expect(result.valid).toBe(true);
      }
    });

    it("validates orientation enum values", () => {
      const validOrientations = ["portrait", "landscape"];

      for (const orientation of validOrientations) {
        const blueprint = createTestBlueprint({
          metadata: { title: "Test", orientation },
        });

        const result = validateBlueprint(blueprint as Blueprint);
        expect(result.valid).toBe(true);
      }
    });
  });

  // ===========================================================================
  // Content Block Validation
  // ===========================================================================

  describe("content block validation", () => {
    it("validates heading blocks", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [createTestContentBlock("heading", { level: 1, text: "Title" })],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("validates paragraph blocks", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [createTestContentBlock("paragraph", { text: "Content here" })],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("validates table blocks", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            createTestContentBlock("table", {
              columns: [
                { key: "name", header: "Name" },
                { key: "value", header: "Value" },
              ],
              data: [
                { name: "Item 1", value: 100 },
                { name: "Item 2", value: 200 },
              ],
            }),
          ],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("validates list blocks", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            createTestContentBlock("list", {
              items: ["Item 1", "Item 2", "Item 3"],
              ordered: true,
            }),
          ],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("validates callout blocks", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            createTestContentBlock("callout", {
              variant: "info",
              title: "Note",
              text: "Important information here",
            }),
          ],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("validates heading levels 1-4", () => {
      for (let level = 1; level <= 4; level++) {
        const blueprint = createTestBlueprint({
          content: {
            sections: [createTestContentBlock("heading", { level, text: `H${level}` })],
          },
        });

        const result = validateBlueprint(blueprint as Blueprint);
        expect(result.valid).toBe(true);
      }
    });
  });

  // ===========================================================================
  // isValidBlueprint Helper
  // ===========================================================================

  describe("isValidBlueprint", () => {
    it("returns true for valid blueprint", () => {
      const blueprint = createTestBlueprint();
      expect(isValidBlueprint(blueprint as Blueprint)).toBe(true);
    });

    it("returns false for invalid blueprint", () => {
      expect(isValidBlueprint({} as Blueprint)).toBe(false);
    });
  });

  // ===========================================================================
  // assertValidBlueprint Helper
  // ===========================================================================

  describe("assertValidBlueprint", () => {
    it("does not throw for valid blueprint", () => {
      const blueprint = createTestBlueprint();
      expect(() => assertValidBlueprint(blueprint as Blueprint)).not.toThrow();
    });

    it("throws for invalid blueprint", () => {
      expect(() => assertValidBlueprint({} as Blueprint)).toThrow();
    });

    it("throws with meaningful error message", () => {
      try {
        assertValidBlueprint({ invalid: true } as unknown as Blueprint);
        fail("Expected an error to be thrown");
      } catch (error) {
        expect((error as Error).message).toContain("Invalid blueprint");
      }
    });
  });

  // ===========================================================================
  // Warnings
  // ===========================================================================

  describe("validation warnings", () => {
    it("returns warnings for missing optional but recommended fields", () => {
      const blueprint: ReportBlueprint = {
        id: "minimal-001",
        version: "1.0.0",
        type: "report",
        metadata: {
          title: "Minimal Report",
          // Missing: author, date, company
        },
        content: {
          sections: [],
          // Missing: showCover, executiveSummary
        },
      };

      const result = validateBlueprint(blueprint);

      // Should be valid but may have warnings
      expect(result.valid).toBe(true);
      // Warnings are optional, so just verify the structure
      expect(Array.isArray(result.warnings)).toBe(true);
    });
  });

  // ===========================================================================
  // Edge Cases
  // ===========================================================================

  describe("edge cases", () => {
    it("handles empty sections array", () => {
      const blueprint = createTestBlueprint({
        content: { sections: [] },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("handles deeply nested sections", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            {
              type: "section",
              title: "Parent Section",
              children: [
                { type: "heading", level: 2, text: "Nested Heading" },
                { type: "paragraph", text: "Nested content" },
              ],
            },
          ],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("handles special characters in text", () => {
      const blueprint = createTestBlueprint({
        metadata: {
          title: "Report with émojis 🎉 and spëcial châräctërs",
        },
        content: {
          sections: [
            {
              type: "paragraph",
              text: "Unicode: 你好世界 • Greek: Ελληνικά • Math: ∑∫∂",
            },
          ],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });

    it("handles very long text content", () => {
      const longText = "A".repeat(10000);
      const blueprint = createTestBlueprint({
        content: {
          sections: [{ type: "paragraph", text: longText }],
        },
      });

      const result = validateBlueprint(blueprint as Blueprint);
      expect(result.valid).toBe(true);
    });
  });
});
