/**
 * Jest Test Setup
 *
 * This file configures the test environment for the Report Builder project.
 * It runs before each test file.
 */

// =============================================================================
// Environment Setup
// =============================================================================

// Set test environment variables
process.env.NODE_ENV = "test";
process.env.PORT = "3001";
process.env.LOG_LEVEL = "error"; // Minimize logging during tests

// =============================================================================
// Global Mocks
// =============================================================================

// Mock console methods to reduce noise in tests (optional)
// Uncomment to suppress console output during tests
// global.console = {
//   ...console,
//   log: jest.fn(),
//   debug: jest.fn(),
//   info: jest.fn(),
//   warn: jest.fn(),
//   // Keep error for debugging failed tests
//   error: console.error,
// };

// =============================================================================
// React-PDF Mocks
// =============================================================================

/**
 * Mock @react-pdf/renderer for unit testing components
 * without actually rendering PDFs
 */
jest.mock("@react-pdf/renderer", () => ({
  Document: ({ children }: { children: React.ReactNode }) => children,
  Page: ({ children }: { children: React.ReactNode }) => children,
  View: ({ children }: { children: React.ReactNode }) => children,
  Text: ({ children }: { children: React.ReactNode }) => children,
  Image: () => null,
  Link: ({ children }: { children: React.ReactNode }) => children,
  StyleSheet: {
    create: <T extends Record<string, unknown>>(styles: T): T => styles,
  },
  Font: {
    register: jest.fn(),
    registerHyphenationCallback: jest.fn(),
  },
  Svg: ({ children }: { children: React.ReactNode }) => children,
  Path: () => null,
  Rect: () => null,
  Circle: () => null,
  Line: () => null,
  Polygon: () => null,
  Polyline: () => null,
  Ellipse: () => null,
  G: ({ children }: { children: React.ReactNode }) => children,
  Defs: ({ children }: { children: React.ReactNode }) => children,
  LinearGradient: ({ children }: { children: React.ReactNode }) => children,
  Stop: () => null,
  ClipPath: ({ children }: { children: React.ReactNode }) => children,
  renderToStream: jest.fn().mockResolvedValue({
    pipe: jest.fn(),
  }),
  renderToBuffer: jest.fn().mockResolvedValue(Buffer.from("mock-pdf")),
  renderToString: jest.fn().mockResolvedValue("<pdf>mock</pdf>"),
}));

// =============================================================================
// Custom Matchers
// =============================================================================

/**
 * Custom Jest matchers for Report Builder testing
 */
expect.extend({
  /**
   * Check if a blueprint has valid structure
   */
  toBeValidBlueprint(received: unknown) {
    const blueprint = received as Record<string, unknown>;
    const hasId = typeof blueprint?.id === "string";
    const hasVersion = typeof blueprint?.version === "string";
    const hasType = ["report", "dashboard", "invoice", "data-table"].includes(
      blueprint?.type as string
    );
    const hasMetadata = typeof blueprint?.metadata === "object";
    const hasContent = typeof blueprint?.content === "object";

    const pass = hasId && hasVersion && hasType && hasMetadata && hasContent;

    return {
      pass,
      message: () =>
        pass
          ? `Expected blueprint not to be valid`
          : `Expected blueprint to be valid but missing: ${[
              !hasId && "id",
              !hasVersion && "version",
              !hasType && "valid type",
              !hasMetadata && "metadata",
              !hasContent && "content",
            ]
              .filter(Boolean)
              .join(", ")}`,
    };
  },

  /**
   * Check if validation result indicates success
   */
  toBeValidValidationResult(received: unknown) {
    const result = received as { valid: boolean; errors: unknown[] };
    const pass = result?.valid === true && result?.errors?.length === 0;

    return {
      pass,
      message: () =>
        pass
          ? `Expected validation to fail`
          : `Expected validation to pass but got errors: ${JSON.stringify(
              result?.errors
            )}`,
    };
  },
});

// =============================================================================
// TypeScript Declarations
// =============================================================================

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace jest {
    interface Matchers<R> {
      toBeValidBlueprint(): R;
      toBeValidValidationResult(): R;
    }
  }
}

// =============================================================================
// Global Test Utilities
// =============================================================================

/**
 * Create a minimal valid report blueprint for testing
 */
export function createTestBlueprint(
  overrides: Record<string, unknown> = {}
): Record<string, unknown> {
  return {
    id: "test-blueprint-001",
    version: "1.0.0",
    type: "report",
    metadata: {
      title: "Test Report",
      author: "Test User",
    },
    content: {
      sections: [],
    },
    ...overrides,
  };
}

/**
 * Create a test content block
 */
export function createTestContentBlock(
  type: string,
  props: Record<string, unknown> = {}
): Record<string, unknown> {
  switch (type) {
    case "heading":
      return { type: "heading", level: 1, text: "Test Heading", ...props };
    case "paragraph":
      return { type: "paragraph", text: "Test paragraph text.", ...props };
    case "table":
      return {
        type: "table",
        columns: [{ key: "col1", header: "Column 1" }],
        data: [{ col1: "Value 1" }],
        ...props,
      };
    case "list":
      return { type: "list", items: ["Item 1", "Item 2"], ordered: false, ...props };
    case "callout":
      return { type: "callout", variant: "info", text: "Test callout", ...props };
    default:
      return { type, ...props };
  }
}

// =============================================================================
// Cleanup
// =============================================================================

// Reset all mocks after each test
afterEach(() => {
  jest.clearAllMocks();
});

// Cleanup after all tests
afterAll(() => {
  jest.restoreAllMocks();
});
