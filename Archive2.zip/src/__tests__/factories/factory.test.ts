/**
 * Document Factory Tests
 *
 * Tests for the document factory that transforms blueprints
 * into React-PDF documents.
 */

import {
  createDocument,
  createDocumentWithTheme,
  getBlueprintType,
  getTemplateForType,
} from "../../factories/index.js";
import type { Blueprint, ReportBlueprint, InvoiceBlueprint } from "../../blueprints/types.js";
import { createTestBlueprint } from "../setup.js";

describe("DocumentFactory", () => {
  // ===========================================================================
  // createDocument
  // ===========================================================================

  describe("createDocument", () => {
    it("creates document from report blueprint", () => {
      const blueprint: ReportBlueprint = {
        id: "test-report",
        version: "1.0.0",
        type: "report",
        metadata: {
          title: "Test Report",
          author: "Test Author",
        },
        content: {
          showCover: true,
          sections: [
            { type: "heading", level: 1, text: "Introduction" },
            { type: "paragraph", text: "This is a test report." },
          ],
        },
      };

      const doc = createDocument({ blueprint });

      expect(doc).toBeDefined();
      expect(doc).not.toBeNull();
    });

    it("creates document from invoice blueprint", () => {
      const blueprint: InvoiceBlueprint = {
        id: "test-invoice",
        version: "1.0.0",
        type: "invoice",
        metadata: {
          title: "Invoice",
          invoiceNumber: "INV-001",
        },
        content: {
          invoiceNumber: "INV-001",
          issueDate: "2026-01-28",
          dueDate: "2026-02-28",
          status: "pending",
          from: {
            name: "Seller",
            address: ["123 Main St"],
          },
          to: {
            name: "Buyer",
            address: ["456 Oak Ave"],
          },
          items: [
            { description: "Item 1", quantity: 1, unitPrice: 100, total: 100 },
          ],
          subtotal: 100,
          total: 100,
          currency: "USD",
        },
      };

      const doc = createDocument({ blueprint });

      expect(doc).toBeDefined();
    });

    it("creates document from dashboard blueprint", () => {
      const blueprint = {
        id: "test-dashboard",
        version: "1.0.0",
        type: "dashboard" as const,
        metadata: {
          title: "Test Dashboard",
        },
        content: {
          title: "Dashboard",
          metrics: [
            { label: "Revenue", value: 1000000, format: "currency" as const },
          ],
          charts: [],
          tables: [],
        },
      };

      const doc = createDocument({ blueprint });

      expect(doc).toBeDefined();
    });

    it("creates document from data-table blueprint", () => {
      const blueprint = {
        id: "test-datatable",
        version: "1.0.0",
        type: "data-table" as const,
        metadata: {
          title: "Data Table",
        },
        content: {
          title: "Test Data",
          columns: [
            { key: "id", header: "ID" },
            { key: "name", header: "Name" },
          ],
          data: [
            { id: 1, name: "Item 1" },
            { id: 2, name: "Item 2" },
          ],
        },
      };

      const doc = createDocument({ blueprint });

      expect(doc).toBeDefined();
    });

    it("throws error for invalid blueprint", () => {
      const invalidBlueprint = { invalid: true };

      expect(() =>
        createDocument({ blueprint: invalidBlueprint as unknown as Blueprint })
      ).toThrow();
    });

    it("accepts options parameter", () => {
      const blueprint = createTestBlueprint() as Blueprint;

      // Should not throw with empty options
      const doc = createDocument({ blueprint, options: {} });

      expect(doc).toBeDefined();
    });
  });

  // ===========================================================================
  // createDocumentWithTheme
  // ===========================================================================

  describe("createDocumentWithTheme", () => {
    it("creates document with custom theme", () => {
      const blueprint = createTestBlueprint() as Blueprint;
      const customTheme = {
        colors: {
          palette: {
            brand: {
              500: "#ff0000",
            },
          },
        },
      };

      const doc = createDocumentWithTheme({
        blueprint,
        theme: customTheme,
      });

      expect(doc).toBeDefined();
    });

    it("uses default theme when theme is empty", () => {
      const blueprint = createTestBlueprint() as Blueprint;

      const doc = createDocumentWithTheme({
        blueprint,
        theme: {},
      });

      expect(doc).toBeDefined();
    });

    it("merges partial theme with defaults", () => {
      const blueprint = createTestBlueprint() as Blueprint;
      const partialTheme = {
        typography: {
          fontFamilies: {
            primary: "Arial",
          },
        },
      };

      const doc = createDocumentWithTheme({
        blueprint,
        theme: partialTheme,
      });

      expect(doc).toBeDefined();
    });
  });

  // ===========================================================================
  // getBlueprintType
  // ===========================================================================

  describe("getBlueprintType", () => {
    it("returns report for report blueprint", () => {
      const blueprint = createTestBlueprint({ type: "report" }) as Blueprint;
      expect(getBlueprintType(blueprint)).toBe("report");
    });

    it("returns invoice for invoice blueprint", () => {
      const blueprint = {
        id: "test",
        version: "1.0.0",
        type: "invoice",
        metadata: { title: "Invoice" },
        content: {},
      } as Blueprint;

      expect(getBlueprintType(blueprint)).toBe("invoice");
    });

    it("returns dashboard for dashboard blueprint", () => {
      const blueprint = {
        id: "test",
        version: "1.0.0",
        type: "dashboard",
        metadata: { title: "Dashboard" },
        content: {},
      } as Blueprint;

      expect(getBlueprintType(blueprint)).toBe("dashboard");
    });

    it("returns data-table for data-table blueprint", () => {
      const blueprint = {
        id: "test",
        version: "1.0.0",
        type: "data-table",
        metadata: { title: "Data" },
        content: {},
      } as Blueprint;

      expect(getBlueprintType(blueprint)).toBe("data-table");
    });
  });

  // ===========================================================================
  // getTemplateForType
  // ===========================================================================

  describe("getTemplateForType", () => {
    it("returns template for report type", () => {
      const template = getTemplateForType("report");
      expect(template).toBeDefined();
    });

    it("returns template for invoice type", () => {
      const template = getTemplateForType("invoice");
      expect(template).toBeDefined();
    });

    it("returns template for dashboard type", () => {
      const template = getTemplateForType("dashboard");
      expect(template).toBeDefined();
    });

    it("returns template for data-table type", () => {
      const template = getTemplateForType("data-table");
      expect(template).toBeDefined();
    });

    it("throws for unknown type", () => {
      expect(() => getTemplateForType("unknown" as any)).toThrow();
    });
  });

  // ===========================================================================
  // Content Rendering
  // ===========================================================================

  describe("content rendering", () => {
    it("renders multiple content blocks", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            { type: "heading", level: 1, text: "Title" },
            { type: "paragraph", text: "Paragraph 1" },
            { type: "paragraph", text: "Paragraph 2" },
            { type: "divider" },
            { type: "heading", level: 2, text: "Subtitle" },
          ],
        },
      }) as Blueprint;

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });

    it("renders tables in content", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            {
              type: "table",
              columns: [
                { key: "a", header: "A" },
                { key: "b", header: "B" },
              ],
              data: [
                { a: 1, b: 2 },
                { a: 3, b: 4 },
              ],
            },
          ],
        },
      }) as Blueprint;

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });

    it("renders metrics in content", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            {
              type: "metrics",
              items: [
                { label: "Revenue", value: 1000, format: "currency" as const },
                { label: "Users", value: 500, format: "number" as const },
              ],
              columns: 2,
            },
          ],
        },
      }) as Blueprint;

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });

    it("renders callouts in content", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            { type: "callout", variant: "info", title: "Info", text: "Information" },
            { type: "callout", variant: "warning", title: "Warning", text: "Caution" },
            { type: "callout", variant: "success", title: "Success", text: "Done" },
            { type: "callout", variant: "error", title: "Error", text: "Failed" },
          ],
        },
      }) as Blueprint;

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });

    it("renders lists in content", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [
            { type: "list", items: ["A", "B", "C"], ordered: false },
            { type: "list", items: ["1", "2", "3"], ordered: true },
          ],
        },
      }) as Blueprint;

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });
  });

  // ===========================================================================
  // Report Features
  // ===========================================================================

  describe("report features", () => {
    it("renders cover page when showCover is true", () => {
      const blueprint: ReportBlueprint = {
        id: "cover-test",
        version: "1.0.0",
        type: "report",
        metadata: {
          title: "Report with Cover",
          subtitle: "Testing Cover Page",
          author: "Test",
        },
        content: {
          showCover: true,
          sections: [],
        },
      };

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });

    it("renders TOC when showToc is true", () => {
      const blueprint: ReportBlueprint = {
        id: "toc-test",
        version: "1.0.0",
        type: "report",
        metadata: {
          title: "Report with TOC",
        },
        content: {
          showToc: true,
          sections: [
            { type: "heading", level: 1, text: "Chapter 1", id: "ch1" },
            { type: "heading", level: 2, text: "Section 1.1", id: "s11" },
            { type: "heading", level: 1, text: "Chapter 2", id: "ch2" },
          ],
        },
      };

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });

    it("renders executive summary", () => {
      const blueprint: ReportBlueprint = {
        id: "summary-test",
        version: "1.0.0",
        type: "report",
        metadata: {
          title: "Report with Summary",
        },
        content: {
          executiveSummary: "This is the executive summary of the report.",
          sections: [],
        },
      };

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });

    it("renders headers and footers", () => {
      const blueprint: ReportBlueprint = {
        id: "header-footer-test",
        version: "1.0.0",
        type: "report",
        metadata: {
          title: "Report with Header/Footer",
        },
        content: {
          header: {
            title: "Custom Header",
            showPageNumbers: true,
          },
          footer: {
            companyName: "Acme Corp",
            showPageNumbers: true,
          },
          sections: [],
        },
      };

      const doc = createDocument({ blueprint });
      expect(doc).toBeDefined();
    });
  });

  // ===========================================================================
  // Error Handling
  // ===========================================================================

  describe("error handling", () => {
    it("handles missing required fields gracefully", () => {
      const incompleteBlueprint = {
        id: "incomplete",
        // Missing version, type, metadata, content
      };

      expect(() =>
        createDocument({ blueprint: incompleteBlueprint as Blueprint })
      ).toThrow();
    });

    it("handles invalid content block types", () => {
      const blueprint = createTestBlueprint({
        content: {
          sections: [{ type: "nonexistent-type" as any, data: "invalid" }],
        },
      }) as Blueprint;

      // Should handle gracefully without crashing
      expect(() => createDocument({ blueprint })).not.toThrow();
    });
  });
});
