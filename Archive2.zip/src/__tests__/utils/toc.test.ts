/**
 * Table of Contents Utility Tests
 *
 * Tests for the TOC extraction and generation utilities.
 */

import {
  extractTocEntries,
  generateToc,
  buildTocTree,
  slugify,
  generateHeadingId,
  flattenTocTree,
  filterByDepth,
  updatePageNumbers,
} from "../../utils/toc.js";
import type { Blueprint, ReportBlueprint } from "../../blueprints/types.js";

describe("TOC Utilities", () => {
  // ===========================================================================
  // slugify
  // ===========================================================================

  describe("slugify", () => {
    it("converts text to lowercase slug", () => {
      expect(slugify("Hello World")).toBe("hello-world");
    });

    it("replaces spaces with hyphens", () => {
      expect(slugify("This Is A Test")).toBe("this-is-a-test");
    });

    it("removes special characters", () => {
      expect(slugify("Hello! World?")).toBe("hello-world");
    });

    it("removes multiple consecutive hyphens", () => {
      expect(slugify("Hello   World")).toBe("hello-world");
    });

    it("removes leading/trailing hyphens", () => {
      expect(slugify("  Hello World  ")).toBe("hello-world");
    });

    it("handles empty string", () => {
      expect(slugify("")).toBe("");
    });

    it("handles string with only special characters", () => {
      expect(slugify("!@#$%")).toBe("");
    });

    it("handles numbers", () => {
      expect(slugify("Chapter 1")).toBe("chapter-1");
    });

    it("replaces underscores with hyphens", () => {
      expect(slugify("hello_world")).toBe("hello-world");
    });
  });

  // ===========================================================================
  // generateHeadingId
  // ===========================================================================

  describe("generateHeadingId", () => {
    it("generates ID from text with index", () => {
      const id = generateHeadingId("Introduction", 0);
      expect(id).toContain("introduction");
      expect(id).toContain("0");
    });

    it("uses custom prefix", () => {
      const id = generateHeadingId("Chapter One", 1, "section");
      expect(id).toContain("section");
    });

    it("handles empty text", () => {
      const id = generateHeadingId("", 5, "heading");
      expect(id).toContain("heading");
      expect(id).toContain("5");
    });

    it("creates unique IDs for same text at different indices", () => {
      const id1 = generateHeadingId("Title", 0);
      const id2 = generateHeadingId("Title", 1);
      expect(id1).not.toBe(id2);
    });
  });

  // ===========================================================================
  // extractTocEntries
  // ===========================================================================

  describe("extractTocEntries", () => {
    it("extracts headings from blueprint", () => {
      const blueprint: ReportBlueprint = {
        id: "toc-test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: {
          sections: [
            { type: "heading", level: 1, text: "Chapter 1", id: "ch1" },
            { type: "paragraph", text: "Some text" },
            { type: "heading", level: 2, text: "Section 1.1", id: "s11" },
            { type: "heading", level: 1, text: "Chapter 2", id: "ch2" },
          ],
        },
      };

      const entries = extractTocEntries(blueprint);

      expect(entries).toHaveLength(3);
      expect(entries[0].title).toBe("Chapter 1");
      expect(entries[0].level).toBe(1);
      expect(entries[1].title).toBe("Section 1.1");
      expect(entries[1].level).toBe(2);
      expect(entries[2].title).toBe("Chapter 2");
    });

    it("uses existing IDs when provided", () => {
      const blueprint: ReportBlueprint = {
        id: "test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: {
          sections: [{ type: "heading", level: 1, text: "Custom", id: "custom-id" }],
        },
      };

      const entries = extractTocEntries(blueprint);

      expect(entries[0].id).toBe("custom-id");
    });

    it("generates IDs when not provided", () => {
      const blueprint: ReportBlueprint = {
        id: "test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: {
          sections: [{ type: "heading", level: 1, text: "Auto ID" }],
        },
      };

      const entries = extractTocEntries(blueprint);

      expect(entries[0].id).toBeDefined();
      expect(entries[0].id.length).toBeGreaterThan(0);
    });

    it("respects maxDepth configuration", () => {
      const blueprint: ReportBlueprint = {
        id: "test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: {
          sections: [
            { type: "heading", level: 1, text: "H1" },
            { type: "heading", level: 2, text: "H2" },
            { type: "heading", level: 3, text: "H3" },
            { type: "heading", level: 4, text: "H4" },
          ],
        },
      };

      const entries = extractTocEntries(blueprint, { maxDepth: 2 });

      expect(entries).toHaveLength(2);
      expect(entries.every((e) => e.level <= 2)).toBe(true);
    });

    it("extracts headings from nested sections", () => {
      const blueprint: ReportBlueprint = {
        id: "test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: {
          sections: [
            {
              type: "section",
              title: "Parent",
              children: [
                { type: "heading", level: 2, text: "Nested Heading" },
              ],
            },
          ],
        },
      };

      const entries = extractTocEntries(blueprint);

      expect(entries.some((e) => e.title === "Nested Heading")).toBe(true);
    });

    it("returns empty array for empty sections", () => {
      const blueprint: ReportBlueprint = {
        id: "test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: { sections: [] },
      };

      const entries = extractTocEntries(blueprint);

      expect(entries).toHaveLength(0);
    });

    it("returns empty array for non-report blueprints", () => {
      const blueprint: Blueprint = {
        id: "test",
        version: "1.0.0",
        type: "invoice",
        metadata: { title: "Invoice" },
        content: {},
      } as Blueprint;

      const entries = extractTocEntries(blueprint);

      expect(entries).toHaveLength(0);
    });
  });

  // ===========================================================================
  // buildTocTree
  // ===========================================================================

  describe("buildTocTree", () => {
    it("builds nested tree from flat entries", () => {
      const entries = [
        { id: "h1", title: "Chapter 1", level: 1 },
        { id: "h2", title: "Section 1.1", level: 2 },
        { id: "h3", title: "Section 1.2", level: 2 },
        { id: "h4", title: "Chapter 2", level: 1 },
      ];

      const tree = buildTocTree(entries);

      expect(tree).toHaveLength(2); // Two top-level chapters
      expect(tree[0].children).toHaveLength(2); // Chapter 1 has 2 sections
      expect(tree[1].children).toHaveLength(0); // Chapter 2 has no sections
    });

    it("handles deeply nested structure", () => {
      const entries = [
        { id: "h1", title: "Level 1", level: 1 },
        { id: "h2", title: "Level 2", level: 2 },
        { id: "h3", title: "Level 3", level: 3 },
        { id: "h4", title: "Level 4", level: 4 },
      ];

      const tree = buildTocTree(entries);

      expect(tree).toHaveLength(1);
      expect(tree[0].children?.[0].children?.[0].children?.[0].title).toBe("Level 4");
    });

    it("handles jump in levels", () => {
      const entries = [
        { id: "h1", title: "Level 1", level: 1 },
        { id: "h3", title: "Level 3", level: 3 }, // Skipped level 2
        { id: "h1b", title: "Level 1 Again", level: 1 },
      ];

      const tree = buildTocTree(entries);

      expect(tree).toHaveLength(2);
    });

    it("returns empty array for empty input", () => {
      const tree = buildTocTree([]);
      expect(tree).toHaveLength(0);
    });

    it("preserves entry properties in tree", () => {
      const entries = [
        { id: "h1", title: "Test", level: 1, pageNumber: 5 },
      ];

      const tree = buildTocTree(entries);

      expect(tree[0].id).toBe("h1");
      expect(tree[0].title).toBe("Test");
      expect(tree[0].level).toBe(1);
      expect(tree[0].pageNumber).toBe(5);
    });
  });

  // ===========================================================================
  // generateToc
  // ===========================================================================

  describe("generateToc", () => {
    it("generates complete TOC result", () => {
      const blueprint: ReportBlueprint = {
        id: "test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: {
          sections: [
            { type: "heading", level: 1, text: "Chapter 1" },
            { type: "heading", level: 2, text: "Section 1.1" },
            { type: "heading", level: 1, text: "Chapter 2" },
          ],
        },
      };

      const result = generateToc(blueprint);

      expect(result.entries).toHaveLength(3);
      expect(result.tree).toHaveLength(2);
      expect(result.headingCount).toBe(3);
    });

    it("includes both flat and nested structures", () => {
      const blueprint: ReportBlueprint = {
        id: "test",
        version: "1.0.0",
        type: "report",
        metadata: { title: "Test" },
        content: {
          sections: [
            { type: "heading", level: 1, text: "Title" },
          ],
        },
      };

      const result = generateToc(blueprint);

      expect(Array.isArray(result.entries)).toBe(true);
      expect(Array.isArray(result.tree)).toBe(true);
      expect(typeof result.headingCount).toBe("number");
    });
  });

  // ===========================================================================
  // flattenTocTree
  // ===========================================================================

  describe("flattenTocTree", () => {
    it("flattens nested tree to array", () => {
      const tree = [
        {
          id: "h1",
          title: "Chapter 1",
          level: 1,
          children: [
            { id: "h2", title: "Section 1.1", level: 2, children: [] },
          ],
        },
        { id: "h3", title: "Chapter 2", level: 1, children: [] },
      ];

      const flat = flattenTocTree(tree);

      expect(flat).toHaveLength(3);
      expect(flat[0].title).toBe("Chapter 1");
      expect(flat[1].title).toBe("Section 1.1");
      expect(flat[2].title).toBe("Chapter 2");
    });

    it("preserves entry order", () => {
      const tree = [
        {
          id: "a",
          title: "A",
          level: 1,
          children: [
            {
              id: "a1",
              title: "A1",
              level: 2,
              children: [{ id: "a1a", title: "A1a", level: 3 }],
            },
          ],
        },
      ];

      const flat = flattenTocTree(tree);

      expect(flat.map((e) => e.id)).toEqual(["a", "a1", "a1a"]);
    });

    it("returns empty array for empty tree", () => {
      const flat = flattenTocTree([]);
      expect(flat).toHaveLength(0);
    });
  });

  // ===========================================================================
  // filterByDepth
  // ===========================================================================

  describe("filterByDepth", () => {
    it("filters entries by maximum depth", () => {
      const entries = [
        { id: "h1", title: "L1", level: 1 },
        { id: "h2", title: "L2", level: 2 },
        { id: "h3", title: "L3", level: 3 },
        { id: "h4", title: "L4", level: 4 },
      ];

      const filtered = filterByDepth(entries, 2);

      expect(filtered).toHaveLength(2);
      expect(filtered.every((e) => e.level <= 2)).toBe(true);
    });

    it("filters nested children as well", () => {
      const entries = [
        {
          id: "h1",
          title: "L1",
          level: 1,
          children: [
            {
              id: "h2",
              title: "L2",
              level: 2,
              children: [{ id: "h3", title: "L3", level: 3 }],
            },
          ],
        },
      ];

      const filtered = filterByDepth(entries, 2);

      expect(filtered[0].children?.[0].children).toHaveLength(0);
    });

    it("returns empty array when maxDepth is 0", () => {
      const entries = [{ id: "h1", title: "L1", level: 1 }];

      const filtered = filterByDepth(entries, 0);

      expect(filtered).toHaveLength(0);
    });
  });

  // ===========================================================================
  // updatePageNumbers
  // ===========================================================================

  describe("updatePageNumbers", () => {
    it("updates page numbers from map", () => {
      const entries = [
        { id: "h1", title: "Chapter 1", level: 1 },
        { id: "h2", title: "Chapter 2", level: 1 },
      ];

      const pageNumbers = new Map([
        ["h1", 1],
        ["h2", 5],
      ]);

      const updated = updatePageNumbers(entries, pageNumbers);

      expect(updated[0].pageNumber).toBe(1);
      expect(updated[1].pageNumber).toBe(5);
    });

    it("preserves existing page numbers when not in map", () => {
      const entries = [
        { id: "h1", title: "Chapter 1", level: 1, pageNumber: 10 },
      ];

      const pageNumbers = new Map<string, number>();

      const updated = updatePageNumbers(entries, pageNumbers);

      expect(updated[0].pageNumber).toBe(10);
    });

    it("updates nested children", () => {
      const entries = [
        {
          id: "h1",
          title: "Chapter 1",
          level: 1,
          children: [{ id: "h2", title: "Section", level: 2 }],
        },
      ];

      const pageNumbers = new Map([
        ["h1", 1],
        ["h2", 3],
      ]);

      const updated = updatePageNumbers(entries, pageNumbers);

      expect(updated[0].pageNumber).toBe(1);
      expect(updated[0].children?.[0].pageNumber).toBe(3);
    });

    it("does not mutate original entries", () => {
      const entries = [{ id: "h1", title: "Test", level: 1 }];

      const pageNumbers = new Map([["h1", 5]]);

      updatePageNumbers(entries, pageNumbers);

      expect(entries[0].pageNumber).toBeUndefined();
    });
  });
});
