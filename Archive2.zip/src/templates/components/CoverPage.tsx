/**
 * CoverPage Component
 * Professional cover page for reports and documents
 */

import React from "react";
import { Page, View, Text as PDFText, Image, StyleSheet } from "@react-pdf/renderer";
import type { CoverPageProps } from "../types.js";
import { defaultTheme } from "../../primitives/theme.js";
import { pageSizes } from "../../primitives/spacing.js";

/**
 * Create styles for the cover page
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    page: {
      flexDirection: "column",
      backgroundColor: theme.colors.semantic.background.primary,
    },
    container: {
      flex: 1,
      paddingHorizontal: 60,
      paddingVertical: 80,
      flexDirection: "column",
      justifyContent: "space-between",
    },
    topSection: {
      alignItems: "center",
    },
    logoContainer: {
      marginBottom: 40,
    },
    logo: {
      objectFit: "contain",
    },
    middleSection: {
      alignItems: "center",
      paddingVertical: 60,
    },
    title: {
      fontSize: 36,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
      textAlign: "center",
      marginBottom: 16,
    },
    subtitle: {
      fontSize: 18,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.normal,
      color: theme.colors.semantic.text.secondary,
      textAlign: "center",
      marginBottom: 8,
    },
    divider: {
      width: 120,
      height: 3,
      backgroundColor: theme.colors.palette.brand[500],
      marginVertical: 32,
    },
    metaSection: {
      alignItems: "center",
      gap: 8,
    },
    metaLabel: {
      fontSize: 10,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.text.muted,
      textTransform: "uppercase",
      letterSpacing: 1,
    },
    metaValue: {
      fontSize: 14,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.normal,
      color: theme.colors.semantic.text.secondary,
    },
    authorSection: {
      marginTop: 24,
    },
    dateSection: {
      marginTop: 16,
    },
    bottomSection: {
      alignItems: "center",
      gap: 4,
    },
    companyName: {
      fontSize: 12,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.primary,
    },
    companyInfo: {
      fontSize: 10,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.normal,
      color: theme.colors.semantic.text.muted,
    },
  });

/**
 * Get page dimensions based on size and orientation
 */
function getPageDimensions(
  pageSize: CoverPageProps["pageSize"] = "A4",
  orientation: CoverPageProps["orientation"] = "portrait"
) {
  const size = pageSizes[pageSize] || pageSizes.A4;
  if (orientation === "landscape") {
    return { width: size.height, height: size.width };
  }
  return size;
}

/**
 * CoverPage component for professional document covers.
 * Features logo, title, subtitle, author, date, and company info.
 *
 * @example
 * ```tsx
 * <CoverPage
 *   title="Annual Financial Report"
 *   subtitle="Fiscal Year 2024"
 *   author="Finance Department"
 *   date="January 2024"
 *   logo="/assets/logo.png"
 *   companyName="Acme Corporation"
 *   companyInfo={["123 Business St.", "New York, NY 10001"]}
 * />
 * ```
 */
export const CoverPage: React.FC<CoverPageProps> = ({
  title,
  subtitle,
  author,
  date,
  logo,
  logoWidth = 150,
  companyName,
  companyInfo,
  theme = defaultTheme,
  pageSize = "A4",
  orientation = "portrait",
}) => {
  const styles = createStyles(theme);
  const dimensions = getPageDimensions(pageSize, orientation);

  return (
    <Page size={dimensions} style={styles.page}>
      <View style={styles.container}>
        {/* Top Section - Logo */}
        <View style={styles.topSection}>
          {logo && (
            <View style={styles.logoContainer}>
              <Image src={logo} style={[styles.logo, { width: logoWidth }]} />
            </View>
          )}
        </View>

        {/* Middle Section - Title and Meta */}
        <View style={styles.middleSection}>
          <PDFText style={styles.title}>{title}</PDFText>
          {subtitle && <PDFText style={styles.subtitle}>{subtitle}</PDFText>}

          <View style={styles.divider} />

          {author && (
            <View style={[styles.metaSection, styles.authorSection]}>
              <PDFText style={styles.metaLabel}>Prepared By</PDFText>
              <PDFText style={styles.metaValue}>{author}</PDFText>
            </View>
          )}

          {date && (
            <View style={[styles.metaSection, styles.dateSection]}>
              <PDFText style={styles.metaLabel}>Date</PDFText>
              <PDFText style={styles.metaValue}>{date}</PDFText>
            </View>
          )}
        </View>

        {/* Bottom Section - Company Info */}
        <View style={styles.bottomSection}>
          {companyName && (
            <PDFText style={styles.companyName}>{companyName}</PDFText>
          )}
          {companyInfo?.map((info, index) => (
            <PDFText key={index} style={styles.companyInfo}>
              {info}
            </PDFText>
          ))}
        </View>
      </View>
    </Page>
  );
};

export default CoverPage;
