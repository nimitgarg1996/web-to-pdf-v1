/**
 * PageFooter Component
 * Reusable page footer for all templates
 */

import React from "react";
import { View, Text as PDFText, StyleSheet } from "@react-pdf/renderer";
import type { FooterProps } from "../types.js";
import { defaultTheme } from "../../primitives/theme.js";

/**
 * Create styles for the page footer
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    footer: {
      position: "absolute",
      bottom: 20,
      left: 40,
      right: 40,
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      paddingTop: 8,
      borderTopWidth: 1,
      borderTopColor: theme.colors.semantic.border.subtle,
    },
    leftSection: {
      flexDirection: "row",
      alignItems: "center",
      gap: 16,
    },
    companyName: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
    },
    confidential: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.status.warning,
      textTransform: "uppercase",
      letterSpacing: 0.5,
    },
    centerSection: {
      flex: 1,
      alignItems: "center",
    },
    customText: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      textAlign: "center",
    },
    rightSection: {
      flexDirection: "row",
      alignItems: "center",
    },
    pageNumber: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
    },
  });

/**
 * PageFooter component for consistent footers across all templates.
 * Features company name, page numbers, and confidential watermark.
 *
 * @example
 * ```tsx
 * <PageFooter
 *   companyName="Acme Corporation"
 *   showPageNumbers
 *   confidential
 * />
 * ```
 */
export const PageFooter: React.FC<FooterProps> = ({
  companyName,
  confidential = false,
  showPageNumbers = true,
  customText,
  theme = defaultTheme,
}) => {
  const styles = createStyles(theme);

  return (
    <View style={styles.footer} fixed>
      <View style={styles.leftSection}>
        {companyName && (
          <PDFText style={styles.companyName}>{companyName}</PDFText>
        )}
        {confidential && (
          <PDFText style={styles.confidential}>Confidential</PDFText>
        )}
      </View>
      <View style={styles.centerSection}>
        {customText && <PDFText style={styles.customText}>{customText}</PDFText>}
      </View>
      <View style={styles.rightSection}>
        {showPageNumbers && (
          <PDFText
            style={styles.pageNumber}
            render={({ pageNumber, totalPages }) =>
              `Page ${pageNumber} of ${totalPages}`
            }
          />
        )}
      </View>
    </View>
  );
};

export default PageFooter;
