/**
 * PageHeader Component
 * Reusable page header for all templates
 */

import React from "react";
import { View, Text as PDFText, Image, StyleSheet } from "@react-pdf/renderer";
import type { HeaderProps } from "../types.js";
import { defaultTheme } from "../../primitives/theme.js";

/**
 * Create styles for the page header
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    header: {
      position: "absolute",
      top: 20,
      left: 40,
      right: 40,
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      paddingBottom: 8,
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.semantic.border.default,
    },
    leftSection: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
    },
    logo: {
      objectFit: "contain",
    },
    title: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.text.secondary,
    },
    rightSection: {
      flexDirection: "row",
      alignItems: "center",
      gap: 16,
    },
    date: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
    },
    pageNumber: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
    },
  });

/**
 * PageHeader component for consistent headers across all templates.
 * Features logo, title, date, and page numbers.
 *
 * @example
 * ```tsx
 * <PageHeader
 *   title="Annual Report 2024"
 *   logo="/assets/logo.png"
 *   showDate
 *   showPageNumbers
 * />
 * ```
 */
export const PageHeader: React.FC<HeaderProps> = ({
  title,
  logo,
  logoWidth = 60,
  showPageNumbers = false,
  showDate = false,
  date,
  theme = defaultTheme,
}) => {
  const styles = createStyles(theme);

  return (
    <View style={styles.header} fixed>
      <View style={styles.leftSection}>
        {logo && (
          <Image src={logo} style={[styles.logo, { width: logoWidth }]} />
        )}
        <PDFText style={styles.title}>{title}</PDFText>
      </View>
      <View style={styles.rightSection}>
        {showDate && date && <PDFText style={styles.date}>{date}</PDFText>}
        {showPageNumbers && (
          <PDFText
            style={styles.pageNumber}
            render={({ pageNumber, totalPages }) =>
              `Page ${pageNumber} of ${totalPages}`
            }
          />
        )}
      </View>
    </View>
  );
};

export default PageHeader;
