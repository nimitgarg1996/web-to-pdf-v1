/**
 * Template Components Index
 * Exports reusable template components (header, footer, cover page)
 */

export { PageHeader } from "./PageHeader.js";
export { PageFooter } from "./PageFooter.js";
export { CoverPage } from "./CoverPage.js";
