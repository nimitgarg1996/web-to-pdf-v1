/**
 * Template Types
 * TypeScript interfaces for document templates
 */

import type { Theme } from "../primitives/theme.js";

// ============================================================================
// Page Configuration Types
// ============================================================================

/**
 * Supported page sizes
 */
export type PageSize = "A4" | "LETTER" | "LEGAL" | "A3" | "A5" | "TABLOID" | "EXECUTIVE";

/**
 * Page orientation
 */
export type PageOrientation = "portrait" | "landscape";

// ============================================================================
// Base Template Props
// ============================================================================

/**
 * Common props shared by all templates
 */
export interface BaseTemplateProps {
  /** Document title */
  title: string;
  /** Document subtitle */
  subtitle?: string;
  /** Document date (defaults to current date if not provided) */
  date?: string;
  /** Document author or prepared by */
  author?: string;
  /** Logo image source (URL or path) */
  logo?: string;
  /** Theme configuration */
  theme?: Theme;
  /** Page size */
  pageSize?: PageSize;
  /** Page orientation */
  orientation?: PageOrientation;
  /** Children content */
  children?: React.ReactNode;
}

// ============================================================================
// Header/Footer Props
// ============================================================================

/**
 * Props for page header component
 */
export interface HeaderProps {
  /** Header title text */
  title: string;
  /** Logo image source */
  logo?: string;
  /** Logo width in points */
  logoWidth?: number;
  /** Show page numbers in header */
  showPageNumbers?: boolean;
  /** Show date in header */
  showDate?: boolean;
  /** Date string to display */
  date?: string;
  /** Theme for styling */
  theme?: Theme;
}

/**
 * Props for page footer component
 */
export interface FooterProps {
  /** Company name to display */
  companyName?: string;
  /** Show confidential watermark */
  confidential?: boolean;
  /** Show page numbers (Page X of Y) */
  showPageNumbers?: boolean;
  /** Custom footer text */
  customText?: string;
  /** Theme for styling */
  theme?: Theme;
}

// ============================================================================
// Cover Page Props
// ============================================================================

/**
 * Props for cover page component
 */
export interface CoverPageProps {
  /** Report/document title */
  title: string;
  /** Report subtitle */
  subtitle?: string;
  /** Author or prepared by */
  author?: string;
  /** Document date */
  date?: string;
  /** Logo image source */
  logo?: string;
  /** Logo width in points */
  logoWidth?: number;
  /** Company name */
  companyName?: string;
  /** Company address or info */
  companyInfo?: string[];
  /** Theme for styling */
  theme?: Theme;
  /** Page size */
  pageSize?: PageSize;
  /** Page orientation */
  orientation?: PageOrientation;
}

// ============================================================================
// Report Template Props
// ============================================================================

/**
 * Section definition for table of contents
 */
export interface TOCSection {
  /** Section title */
  title: string;
  /** Page number (placeholder for future implementation) */
  page?: number;
}

/**
 * Executive summary section content
 */
export interface ExecutiveSummary {
  /** Summary title */
  title?: string;
  /** Summary paragraphs */
  content: string[];
  /** Key highlights (bullet points) */
  highlights?: string[];
}

/**
 * Props for report template
 */
export interface ReportTemplateProps extends BaseTemplateProps {
  /** Show cover page */
  showCover?: boolean;
  /** Company name for cover */
  companyName?: string;
  /** Company info lines */
  companyInfo?: string[];
  /** Executive summary content */
  executiveSummary?: ExecutiveSummary;
  /** Table of contents sections (placeholder for Phase 9) */
  tocSections?: TOCSection[];
  /** Show table of contents placeholder */
  showTOC?: boolean;
  /** Header configuration */
  header?: Omit<HeaderProps, "theme">;
  /** Footer configuration */
  footer?: Omit<FooterProps, "theme">;
}

// ============================================================================
// Dashboard Template Props
// ============================================================================

/**
 * Single metric definition for dashboard
 */
export interface DashboardMetric {
  /** Metric label */
  label: string;
  /** Metric value */
  value: string | number;
  /** Previous value for comparison */
  previousValue?: string | number;
  /** Change percentage */
  change?: number;
  /** Trend direction */
  trend?: "up" | "down" | "neutral";
  /** Unit (e.g., "$", "%", "units") */
  unit?: string;
  /** Format type */
  format?: "number" | "currency" | "percent";
}

/**
 * KPI section definition
 */
export interface KPISection {
  /** Section title */
  title: string;
  /** Metrics in this section */
  metrics: DashboardMetric[];
}

/**
 * Props for dashboard template
 */
export interface DashboardTemplateProps extends BaseTemplateProps {
  /** Date range for the dashboard */
  dateRange?: {
    start: string;
    end: string;
  };
  /** Main metrics (top row) */
  metrics?: DashboardMetric[];
  /** KPI sections */
  kpiSections?: KPISection[];
  /** Summary text */
  summary?: string;
  /** Header configuration */
  header?: Omit<HeaderProps, "theme">;
  /** Footer configuration */
  footer?: Omit<FooterProps, "theme">;
  /** Number of columns for metric grid (2, 3, or 4) */
  gridColumns?: 2 | 3 | 4;
}

// ============================================================================
// Invoice Template Props
// ============================================================================

/**
 * Address/contact information
 */
export interface AddressInfo {
  /** Name (company or person) */
  name: string;
  /** Address lines */
  address: string[];
  /** Email address */
  email?: string;
  /** Phone number */
  phone?: string;
}

/**
 * Invoice line item
 */
export interface InvoiceLineItem {
  /** Item description */
  description: string;
  /** Quantity */
  quantity: number;
  /** Unit price */
  unitPrice: number;
  /** Total (quantity * unitPrice) - calculated if not provided */
  total?: number;
  /** Unit of measurement */
  unit?: string;
}

/**
 * Payment terms and info
 */
export interface PaymentInfo {
  /** Payment terms (e.g., "Net 30") */
  terms?: string;
  /** Due date */
  dueDate?: string;
  /** Payment methods accepted */
  methods?: string[];
  /** Bank details or payment instructions */
  instructions?: string[];
}

/**
 * Props for invoice template
 */
export interface InvoiceTemplateProps extends BaseTemplateProps {
  /** Invoice number */
  invoiceNumber: string;
  /** Invoice date */
  invoiceDate?: string;
  /** Due date */
  dueDate?: string;
  /** From/sender information */
  from: AddressInfo;
  /** Bill to information */
  billTo: AddressInfo;
  /** Ship to information (optional, different from bill to) */
  shipTo?: AddressInfo;
  /** Line items */
  lineItems: InvoiceLineItem[];
  /** Subtotal (calculated if not provided) */
  subtotal?: number;
  /** Tax rate (as decimal, e.g., 0.08 for 8%) */
  taxRate?: number;
  /** Tax amount (calculated if not provided) */
  taxAmount?: number;
  /** Discount amount */
  discount?: number;
  /** Discount description */
  discountDescription?: string;
  /** Total amount (calculated if not provided) */
  total?: number;
  /** Currency symbol */
  currency?: string;
  /** Payment information */
  payment?: PaymentInfo;
  /** Notes */
  notes?: string;
  /** Legal/terms text for footer */
  legalText?: string;
  /** Status (paid, pending, overdue) */
  status?: "draft" | "pending" | "paid" | "overdue";
}

// ============================================================================
// Data Table Template Props
// ============================================================================

/**
 * Column definition for data table
 */
export interface DataTableColumn {
  /** Column key/id */
  key: string;
  /** Column header label */
  label: string;
  /** Column width (percentage or fixed) */
  width?: number | string;
  /** Text alignment */
  align?: "left" | "center" | "right";
  /** Format type */
  format?: "text" | "number" | "currency" | "percent" | "date";
}

/**
 * Filter/parameter display
 */
export interface DataTableFilter {
  /** Filter label */
  label: string;
  /** Filter value */
  value: string;
}

/**
 * Summary statistic
 */
export interface DataTableSummary {
  /** Statistic label */
  label: string;
  /** Statistic value */
  value: string | number;
  /** Optional description */
  description?: string;
}

/**
 * Props for data table template
 */
export interface DataTableTemplateProps extends BaseTemplateProps {
  /** Table description */
  description?: string;
  /** Columns definition */
  columns: DataTableColumn[];
  /** Data rows */
  data: Record<string, unknown>[];
  /** Active filters/parameters */
  filters?: DataTableFilter[];
  /** Summary statistics */
  summaryStats?: DataTableSummary[];
  /** Current page number */
  currentPage?: number;
  /** Total pages */
  totalPages?: number;
  /** Total records */
  totalRecords?: number;
  /** Header configuration */
  header?: Omit<HeaderProps, "theme">;
  /** Footer configuration */
  footer?: Omit<FooterProps, "theme">;
  /** Show row numbers */
  showRowNumbers?: boolean;
  /** Striped rows */
  striped?: boolean;
  /** Currency symbol for currency formatting */
  currency?: string;
}

// ============================================================================
// Template Registry Type
// ============================================================================

/**
 * Template type identifier
 */
export type TemplateType = "report" | "dashboard" | "invoice" | "dataTable";

/**
 * Union of all template props
 */
export type TemplateProps =
  | ReportTemplateProps
  | DashboardTemplateProps
  | InvoiceTemplateProps
  | DataTableTemplateProps;
