/**
 * Templates Index
 * Exports document templates composed of components
 *
 * Templates are the middle layer in the Factory Pattern architecture:
 * Blueprint → Template → Component → Primitive
 *
 * Templates define concrete document layouts that:
 * - Compose UI components into reusable page structures
 * - Define overall document structure (pages, headers, footers)
 * - Accept data props to populate the document
 * - Support theming via the theme system
 * - Are designed to be driven by Blueprint JSON data
 */

// ============================================================================
// Types
// ============================================================================

export type {
  // Base types
  PageSize,
  PageOrientation,
  BaseTemplateProps,
  HeaderProps,
  FooterProps,
  CoverPageProps,
  // Report types
  TOCSection,
  ExecutiveSummary,
  ReportTemplateProps,
  // Dashboard types
  DashboardMetric,
  KPISection,
  DashboardTemplateProps,
  // Invoice types
  AddressInfo,
  InvoiceLineItem,
  PaymentInfo,
  InvoiceTemplateProps,
  // Data table types
  DataTableColumn,
  DataTableFilter,
  DataTableSummary,
  DataTableTemplateProps,
  // Registry types
  TemplateType,
  TemplateProps,
} from "./types.js";

// Estate Planning types are exported from EstatePlanningTemplate
export type {
  EstatePlanningTemplateProps,
  EstatePlanningClient,
  TrustStructure,
  KeyPeopleDocument,
  EstateOverview,
} from "./EstatePlanningTemplate.js";

// ============================================================================
// Template Components (Headers, Footers, Cover Pages)
// ============================================================================

export {
  PageHeader,
  PageFooter,
  CoverPage,
} from "./components/index.js";

// ============================================================================
// Main Templates
// ============================================================================

export { ReportTemplate } from "./ReportTemplate.js";
export { DashboardTemplate } from "./DashboardTemplate.js";
export { InvoiceTemplate } from "./InvoiceTemplate.js";
export { DataTableTemplate } from "./DataTableTemplate.js";
export { EstatePlanningTemplate } from "./EstatePlanningTemplate.js";

// ============================================================================
// Template Registry
// ============================================================================

import { ReportTemplate } from "./ReportTemplate.js";
import { DashboardTemplate } from "./DashboardTemplate.js";
import { InvoiceTemplate } from "./InvoiceTemplate.js";
import { DataTableTemplate } from "./DataTableTemplate.js";
import { EstatePlanningTemplate } from "./EstatePlanningTemplate.js";

/**
 * Registry of all available templates
 * Used by the factory system to instantiate templates by type
 */
export const templateRegistry = {
  report: ReportTemplate,
  dashboard: DashboardTemplate,
  invoice: InvoiceTemplate,
  dataTable: DataTableTemplate,
  estatePlanning: EstatePlanningTemplate,
} as const;

/**
 * Get a template component by type
 * @param type - The template type identifier
 * @returns The template component or undefined if not found
 */
export function getTemplate(type: keyof typeof templateRegistry) {
  return templateRegistry[type];
}
