/**
 * DataTableTemplate Component
 * Template for data-heavy reports with large tables and summary statistics
 */

import React from "react";
import { Document, Page, View, Text as PDFText, StyleSheet } from "@react-pdf/renderer";
import type { DataTableTemplateProps, DataTableColumn } from "./types.js";
import { defaultTheme } from "../primitives/theme.js";
import { pageSizes } from "../primitives/spacing.js";
import { PageHeader } from "./components/PageHeader.js";
import { PageFooter } from "./components/PageFooter.js";

/**
 * Create styles for the data table template
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    page: {
      flexDirection: "column",
      backgroundColor: theme.colors.semantic.background.primary,
      paddingTop: 70,
      paddingBottom: 50,
      paddingHorizontal: 40,
    },
    // Title Section
    titleSection: {
      marginBottom: 16,
    },
    title: {
      fontSize: theme.typography.fontSizes["2xl"],
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 4,
    },
    description: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
      lineHeight: 1.5,
    },
    // Filters Section
    filtersSection: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginBottom: 16,
      padding: 12,
      backgroundColor: theme.colors.semantic.background.secondary,
      borderRadius: theme.borders.radius.md,
      gap: 16,
    },
    filtersTitle: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.muted,
      textTransform: "uppercase",
      marginBottom: 4,
      width: "100%",
    },
    filterItem: {
      flexDirection: "column",
    },
    filterLabel: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
    },
    filterValue: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.text.primary,
    },
    // Table Styles
    table: {
      flex: 1,
      marginBottom: 16,
    },
    tableHeader: {
      flexDirection: "row",
      backgroundColor: theme.colors.semantic.background.muted,
      paddingVertical: 10,
      paddingHorizontal: 8,
      borderTopLeftRadius: theme.borders.radius.sm,
      borderTopRightRadius: theme.borders.radius.sm,
      borderBottomWidth: 2,
      borderBottomColor: theme.colors.semantic.border.default,
    },
    tableHeaderCell: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.secondary,
      textTransform: "uppercase",
    },
    tableRow: {
      flexDirection: "row",
      paddingVertical: 8,
      paddingHorizontal: 8,
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.semantic.border.subtle,
    },
    tableRowStriped: {
      backgroundColor: theme.colors.semantic.background.secondary,
    },
    tableCell: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.primary,
    },
    rowNumber: {
      width: 30,
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      textAlign: "center",
    },
    // Pagination Info
    paginationSection: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 16,
      paddingVertical: 8,
    },
    paginationText: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
    },
    paginationPageInfo: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.text.secondary,
    },
    // Summary Statistics
    summarySection: {
      marginTop: "auto",
    },
    summaryTitle: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 12,
      textTransform: "uppercase",
      letterSpacing: 0.5,
    },
    summaryGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginHorizontal: -6,
    },
    summaryCard: {
      width: "23%",
      margin: 6,
      padding: 12,
      backgroundColor: theme.colors.semantic.background.secondary,
      borderRadius: theme.borders.radius.md,
      borderLeftWidth: 3,
      borderLeftColor: theme.colors.palette.brand[500],
    },
    summaryLabel: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      marginBottom: 4,
    },
    summaryValue: {
      fontSize: theme.typography.fontSizes.lg,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
    },
    summaryDescription: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      marginTop: 4,
    },
    // Content area
    content: {
      flex: 1,
    },
  });

/**
 * Get page dimensions based on size and orientation
 */
function getPageDimensions(
  pageSize: DataTableTemplateProps["pageSize"] = "A4",
  orientation: DataTableTemplateProps["orientation"] = "portrait"
) {
  const size = pageSizes[pageSize] || pageSizes.A4;
  if (orientation === "landscape") {
    return { width: size.height, height: size.width };
  }
  return size;
}

/**
 * Format cell value based on format type
 */
function formatCellValue(
  value: unknown,
  format?: DataTableColumn["format"],
  currency = "$"
): string {
  if (value === null || value === undefined) return "-";
  if (typeof value === "string") return value;

  const numValue = Number(value);

  switch (format) {
    case "currency":
      return `${currency}${numValue.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })}`;
    case "percent":
      return `${numValue.toFixed(1)}%`;
    case "number":
      return numValue.toLocaleString();
    case "date":
      if (value instanceof Date) {
        return value.toLocaleDateString();
      }
      return String(value);
    default:
      return String(value);
  }
}

/**
 * Get text alignment style
 */
function getAlignStyle(align?: DataTableColumn["align"]): { textAlign: "left" | "center" | "right" } {
  return { textAlign: align || "left" };
}

/**
 * DataTableTemplate component for data-heavy reports.
 * Features filters display, large table, pagination info, and summary statistics.
 *
 * @example
 * ```tsx
 * <DataTableTemplate
 *   title="Sales Report"
 *   description="Monthly sales data for Q1 2024"
 *   columns={[
 *     { key: "date", label: "Date", format: "date" },
 *     { key: "product", label: "Product" },
 *     { key: "quantity", label: "Qty", align: "center", format: "number" },
 *     { key: "revenue", label: "Revenue", align: "right", format: "currency" },
 *   ]}
 *   data={[
 *     { date: "2024-01-01", product: "Widget A", quantity: 100, revenue: 5000 },
 *     { date: "2024-01-02", product: "Widget B", quantity: 150, revenue: 7500 },
 *   ]}
 *   filters={[
 *     { label: "Date Range", value: "Jan 1 - Jan 31, 2024" },
 *     { label: "Category", value: "All Products" },
 *   ]}
 *   summaryStats={[
 *     { label: "Total Records", value: 500 },
 *     { label: "Total Revenue", value: "$125,000" },
 *   ]}
 *   showRowNumbers
 *   striped
 * />
 * ```
 */
export const DataTableTemplate: React.FC<DataTableTemplateProps> = ({
  title,
  subtitle,
  description,
  date,
  logo,
  theme = defaultTheme,
  pageSize = "A4",
  orientation = "landscape",
  columns,
  data,
  filters,
  summaryStats,
  currentPage,
  totalPages,
  totalRecords,
  header,
  footer,
  showRowNumbers = false,
  striped = true,
  currency = "$",
  children,
}) => {
  const styles = createStyles(theme);
  const dimensions = getPageDimensions(pageSize, orientation);

  // Calculate column widths
  const totalDefinedWidth = columns.reduce((sum, col) => {
    if (typeof col.width === "number") return sum + col.width;
    return sum;
  }, 0);

  const undefinedWidthCount = columns.filter(
    (col) => col.width === undefined
  ).length;

  const defaultWidth = undefinedWidthCount > 0 
    ? `${((100 - totalDefinedWidth - (showRowNumbers ? 5 : 0)) / undefinedWidthCount).toFixed(0)}%`
    : "auto";

  // Merge header with defaults
  const headerProps = header
    ? {
        title: header.title || title,
        logo: header.logo || logo,
        showPageNumbers: header.showPageNumbers ?? true,
        showDate: header.showDate ?? true,
        date: header.date || date,
      }
    : {
        title,
        logo,
        showPageNumbers: true,
        showDate: true,
        date,
      };

  // Merge footer with defaults
  const footerProps = footer
    ? {
        companyName: footer.companyName,
        showPageNumbers: footer.showPageNumbers ?? true,
        confidential: footer.confidential,
        customText: footer.customText,
      }
    : {
        showPageNumbers: true,
      };

  return (
    <Document>
      <Page size={dimensions} style={styles.page}>
        <PageHeader {...headerProps} theme={theme} />

        {/* Title Section */}
        <View style={styles.titleSection}>
          <PDFText style={styles.title}>{title}</PDFText>
          {description && (
            <PDFText style={styles.description}>{description}</PDFText>
          )}
        </View>

        {/* Filters Section */}
        {filters && filters.length > 0 && (
          <View style={styles.filtersSection}>
            <PDFText style={styles.filtersTitle}>Active Filters</PDFText>
            {filters.map((filter, index) => (
              <View key={index} style={styles.filterItem}>
                <PDFText style={styles.filterLabel}>{filter.label}</PDFText>
                <PDFText style={styles.filterValue}>{filter.value}</PDFText>
              </View>
            ))}
          </View>
        )}

        {/* Data Table */}
        <View style={styles.table}>
          {/* Table Header */}
          <View style={styles.tableHeader}>
            {showRowNumbers && (
              <PDFText style={[styles.tableHeaderCell, styles.rowNumber]}>
                #
              </PDFText>
            )}
            {columns.map((column, index) => (
              <PDFText
                key={index}
                style={[
                  styles.tableHeaderCell,
                  {
                    width: column.width || defaultWidth,
                  },
                  getAlignStyle(column.align),
                ]}
              >
                {column.label}
              </PDFText>
            ))}
          </View>

          {/* Table Rows */}
          {data.map((row, rowIndex) => (
            <View
              key={rowIndex}
              style={[
                styles.tableRow,
                striped && rowIndex % 2 === 1 ? styles.tableRowStriped : {},
              ]}
            >
              {showRowNumbers && (
                <PDFText style={styles.rowNumber}>{rowIndex + 1}</PDFText>
              )}
              {columns.map((column, colIndex) => (
                <PDFText
                  key={colIndex}
                  style={[
                    styles.tableCell,
                    {
                      width: column.width || defaultWidth,
                    },
                    getAlignStyle(column.align),
                  ]}
                >
                  {formatCellValue(row[column.key], column.format, currency)}
                </PDFText>
              ))}
            </View>
          ))}
        </View>

        {/* Pagination Info */}
        {(totalRecords !== undefined || currentPage !== undefined) && (
          <View style={styles.paginationSection}>
            {totalRecords !== undefined && (
              <PDFText style={styles.paginationText}>
                Showing {data.length} of {totalRecords.toLocaleString()} records
              </PDFText>
            )}
            {currentPage !== undefined && totalPages !== undefined && (
              <PDFText style={styles.paginationPageInfo}>
                Page {currentPage} of {totalPages}
              </PDFText>
            )}
          </View>
        )}

        {/* Custom Content */}
        {children && <View style={styles.content}>{children}</View>}

        {/* Summary Statistics */}
        {summaryStats && summaryStats.length > 0 && (
          <View style={styles.summarySection}>
            <PDFText style={styles.summaryTitle}>Summary Statistics</PDFText>
            <View style={styles.summaryGrid}>
              {summaryStats.map((stat, index) => (
                <View key={index} style={styles.summaryCard}>
                  <PDFText style={styles.summaryLabel}>{stat.label}</PDFText>
                  <PDFText style={styles.summaryValue}>
                    {typeof stat.value === "number"
                      ? stat.value.toLocaleString()
                      : stat.value}
                  </PDFText>
                  {stat.description && (
                    <PDFText style={styles.summaryDescription}>
                      {stat.description}
                    </PDFText>
                  )}
                </View>
              ))}
            </View>
          </View>
        )}

        <PageFooter {...footerProps} theme={theme} />
      </Page>
    </Document>
  );
};

export default DataTableTemplate;
