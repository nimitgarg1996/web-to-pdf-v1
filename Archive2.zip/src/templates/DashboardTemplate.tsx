/**
 * DashboardTemplate Component
 * Template for metric-heavy dashboards with KPIs and summary sections
 */

import React from "react";
import { Document, Page, View, Text as PDFText, StyleSheet } from "@react-pdf/renderer";
import type { DashboardTemplateProps, DashboardMetric } from "./types.js";
import { defaultTheme } from "../primitives/theme.js";
import { pageSizes } from "../primitives/spacing.js";
import { PageHeader } from "./components/PageHeader.js";
import { PageFooter } from "./components/PageFooter.js";

/**
 * Create styles for the dashboard template
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    page: {
      flexDirection: "column",
      backgroundColor: theme.colors.semantic.background.primary,
      paddingTop: 70,
      paddingBottom: 50,
      paddingHorizontal: 40,
    },
    titleSection: {
      marginBottom: 20,
    },
    title: {
      fontSize: theme.typography.fontSizes["2xl"],
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 4,
    },
    subtitle: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
    },
    dateRange: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      marginTop: 8,
    },
    // Metric Grid
    metricsGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginBottom: 24,
      marginHorizontal: -6,
    },
    metricCard: {
      padding: 16,
      backgroundColor: theme.colors.semantic.background.secondary,
      borderRadius: theme.borders.radius.md,
      borderWidth: 1,
      borderColor: theme.colors.semantic.border.default,
      margin: 6,
    },
    metricCard2Col: {
      width: "47%",
    },
    metricCard3Col: {
      width: "30%",
    },
    metricCard4Col: {
      width: "22%",
    },
    metricLabel: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.text.muted,
      textTransform: "uppercase",
      letterSpacing: 0.5,
      marginBottom: 8,
    },
    metricValue: {
      fontSize: theme.typography.fontSizes["2xl"],
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 4,
    },
    metricTrendContainer: {
      flexDirection: "row",
      alignItems: "center",
      marginTop: 4,
    },
    metricTrendUp: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.status.success,
    },
    metricTrendDown: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.status.error,
    },
    metricTrendNeutral: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.medium,
      color: theme.colors.semantic.text.muted,
    },
    metricPrevious: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      marginLeft: 8,
    },
    // KPI Section
    kpiSection: {
      marginBottom: 24,
    },
    kpiSectionTitle: {
      fontSize: theme.typography.fontSizes.lg,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 12,
      paddingBottom: 8,
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.semantic.border.subtle,
    },
    kpiGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginHorizontal: -4,
    },
    kpiCard: {
      width: "48%",
      padding: 12,
      backgroundColor: theme.colors.semantic.background.muted,
      borderRadius: theme.borders.radius.sm,
      margin: 4,
    },
    // Summary Section
    summarySection: {
      marginTop: "auto",
      padding: 16,
      backgroundColor: theme.colors.palette.brand[50],
      borderRadius: theme.borders.radius.md,
      borderLeftWidth: 3,
      borderLeftColor: theme.colors.palette.brand[500],
    },
    summaryText: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
      lineHeight: 1.5,
    },
    // Content area for children
    content: {
      flex: 1,
    },
  });

/**
 * Get page dimensions based on size and orientation
 */
function getPageDimensions(
  pageSize: DashboardTemplateProps["pageSize"] = "A4",
  orientation: DashboardTemplateProps["orientation"] = "portrait"
) {
  const size = pageSizes[pageSize] || pageSizes.A4;
  if (orientation === "landscape") {
    return { width: size.height, height: size.width };
  }
  return size;
}

/**
 * Format metric value based on format type
 */
function formatMetricValue(
  value: string | number,
  format?: DashboardMetric["format"],
  currency = "$"
): string {
  if (typeof value === "string") return value;

  switch (format) {
    case "currency":
      return `${currency}${value.toLocaleString()}`;
    case "percent":
      return `${value}%`;
    case "number":
    default:
      return value.toLocaleString();
  }
}

/**
 * Get trend arrow symbol
 */
function getTrendArrow(trend?: DashboardMetric["trend"]): string {
  switch (trend) {
    case "up":
      return "↑";
    case "down":
      return "↓";
    default:
      return "→";
  }
}

/**
 * MetricCard Component
 */
const MetricCard: React.FC<{
  metric: DashboardMetric;
  gridColumns: number;
  theme: typeof defaultTheme;
  currency?: string;
}> = ({ metric, gridColumns, theme, currency = "$" }) => {
  const styles = createStyles(theme);

  const getColumnStyle = () => {
    switch (gridColumns) {
      case 2:
        return styles.metricCard2Col;
      case 4:
        return styles.metricCard4Col;
      default:
        return styles.metricCard3Col;
    }
  };

  const getTrendStyle = () => {
    switch (metric.trend) {
      case "up":
        return styles.metricTrendUp;
      case "down":
        return styles.metricTrendDown;
      default:
        return styles.metricTrendNeutral;
    }
  };

  const formattedValue = formatMetricValue(metric.value, metric.format, currency);
  const unit = metric.unit || "";

  return (
    <View style={[styles.metricCard, getColumnStyle()]}>
      <PDFText style={styles.metricLabel}>{metric.label}</PDFText>
      <PDFText style={styles.metricValue}>
        {formattedValue}
        {unit}
      </PDFText>
      {(metric.change !== undefined || metric.previousValue !== undefined) && (
        <View style={styles.metricTrendContainer}>
          {metric.change !== undefined && (
            <PDFText style={getTrendStyle()}>
              {getTrendArrow(metric.trend)} {Math.abs(metric.change)}%
            </PDFText>
          )}
          {metric.previousValue !== undefined && (
            <PDFText style={styles.metricPrevious}>
              vs {formatMetricValue(metric.previousValue, metric.format, currency)}
            </PDFText>
          )}
        </View>
      )}
    </View>
  );
};

/**
 * KPI Section Component
 */
const KPISection: React.FC<{
  title: string;
  metrics: DashboardMetric[];
  theme: typeof defaultTheme;
  currency?: string;
}> = ({ title, metrics, theme, currency }) => {
  const styles = createStyles(theme);

  return (
    <View style={styles.kpiSection}>
      <PDFText style={styles.kpiSectionTitle}>{title}</PDFText>
      <View style={styles.kpiGrid}>
        {metrics.map((metric, index) => (
          <View key={index} style={styles.kpiCard}>
            <PDFText style={styles.metricLabel}>{metric.label}</PDFText>
            <PDFText style={[styles.metricValue, { fontSize: 18 }]}>
              {formatMetricValue(metric.value, metric.format, currency)}
            </PDFText>
          </View>
        ))}
      </View>
    </View>
  );
};

/**
 * DashboardTemplate component for metric-heavy reports.
 * Features metric cards in a grid layout, KPI sections, and summary.
 *
 * @example
 * ```tsx
 * <DashboardTemplate
 *   title="Sales Dashboard"
 *   subtitle="Monthly Performance Overview"
 *   dateRange={{ start: "Jan 1, 2024", end: "Jan 31, 2024" }}
 *   metrics={[
 *     { label: "Revenue", value: 125000, format: "currency", change: 12, trend: "up" },
 *     { label: "Orders", value: 1250, change: 8, trend: "up" },
 *     { label: "Customers", value: 450, change: -2, trend: "down" },
 *   ]}
 *   kpiSections={[
 *     { title: "Sales Metrics", metrics: [...] },
 *   ]}
 *   summary="Overall performance exceeded expectations with a 12% increase in revenue."
 *   gridColumns={3}
 * />
 * ```
 */
export const DashboardTemplate: React.FC<DashboardTemplateProps> = ({
  title,
  subtitle,
  date,
  author,
  logo,
  theme = defaultTheme,
  pageSize = "A4",
  orientation = "landscape",
  dateRange,
  metrics,
  kpiSections,
  summary,
  header,
  footer,
  gridColumns = 3,
  children,
}) => {
  const styles = createStyles(theme);
  const dimensions = getPageDimensions(pageSize, orientation);

  // Merge header with defaults
  const headerProps = header
    ? {
        title: header.title || title,
        logo: header.logo || logo,
        showPageNumbers: header.showPageNumbers ?? true,
        showDate: header.showDate ?? true,
        date: header.date || date,
      }
    : {
        title,
        logo,
        showPageNumbers: true,
        showDate: true,
        date,
      };

  // Merge footer with defaults
  const footerProps = footer
    ? {
        companyName: footer.companyName,
        showPageNumbers: footer.showPageNumbers ?? true,
        confidential: footer.confidential,
        customText: footer.customText,
      }
    : {
        showPageNumbers: true,
      };

  return (
    <Document>
      <Page size={dimensions} style={styles.page}>
        <PageHeader {...headerProps} theme={theme} />

        {/* Title Section */}
        <View style={styles.titleSection}>
          <PDFText style={styles.title}>{title}</PDFText>
          {subtitle && <PDFText style={styles.subtitle}>{subtitle}</PDFText>}
          {dateRange && (
            <PDFText style={styles.dateRange}>
              {dateRange.start} - {dateRange.end}
            </PDFText>
          )}
        </View>

        {/* Main Metrics Grid */}
        {metrics && metrics.length > 0 && (
          <View style={styles.metricsGrid}>
            {metrics.map((metric, index) => (
              <MetricCard
                key={index}
                metric={metric}
                gridColumns={gridColumns}
                theme={theme}
              />
            ))}
          </View>
        )}

        {/* KPI Sections */}
        {kpiSections?.map((section, index) => (
          <KPISection
            key={index}
            title={section.title}
            metrics={section.metrics}
            theme={theme}
          />
        ))}

        {/* Custom Content */}
        {children && <View style={styles.content}>{children}</View>}

        {/* Summary Section */}
        {summary && (
          <View style={styles.summarySection}>
            <PDFText style={styles.summaryText}>{summary}</PDFText>
          </View>
        )}

        <PageFooter {...footerProps} theme={theme} />
      </Page>
    </Document>
  );
};

export default DashboardTemplate;
