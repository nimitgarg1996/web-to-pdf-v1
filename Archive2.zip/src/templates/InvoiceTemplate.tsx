/**
 * InvoiceTemplate Component
 * Professional invoice layout with company info, line items, and totals
 */

import React from "react";
import { Document, Page, View, Text as PDFText, Image, StyleSheet } from "@react-pdf/renderer";
import type { InvoiceTemplateProps, AddressInfo, InvoiceLineItem } from "./types.js";
import { defaultTheme } from "../primitives/theme.js";
import { pageSizes } from "../primitives/spacing.js";

/**
 * Create styles for the invoice template
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    page: {
      flexDirection: "column",
      backgroundColor: theme.colors.semantic.background.primary,
      padding: 40,
    },
    // Header Section
    header: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 40,
    },
    logoSection: {
      flexDirection: "column",
    },
    logo: {
      width: 120,
      objectFit: "contain",
      marginBottom: 8,
    },
    companyName: {
      fontSize: theme.typography.fontSizes.lg,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
    },
    invoiceTitle: {
      fontSize: theme.typography.fontSizes["3xl"],
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.palette.brand[600],
      textTransform: "uppercase",
    },
    invoiceDetails: {
      alignItems: "flex-end",
    },
    invoiceNumber: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
      marginTop: 8,
    },
    invoiceDates: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      marginTop: 4,
    },
    statusBadge: {
      marginTop: 8,
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: theme.borders.radius.sm,
    },
    statusPaid: {
      backgroundColor: theme.colors.semantic.status.successBackground,
    },
    statusPending: {
      backgroundColor: theme.colors.semantic.status.warningBackground,
    },
    statusOverdue: {
      backgroundColor: theme.colors.semantic.status.errorBackground,
    },
    statusDraft: {
      backgroundColor: theme.colors.semantic.background.muted,
    },
    statusText: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      textTransform: "uppercase",
    },
    statusTextPaid: {
      color: theme.colors.semantic.status.success,
    },
    statusTextPending: {
      color: theme.colors.semantic.status.warning,
    },
    statusTextOverdue: {
      color: theme.colors.semantic.status.error,
    },
    statusTextDraft: {
      color: theme.colors.semantic.text.muted,
    },
    // Address Sections
    addressSection: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 32,
    },
    addressBlock: {
      width: "30%",
    },
    addressLabel: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.muted,
      textTransform: "uppercase",
      marginBottom: 8,
    },
    addressName: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 4,
    },
    addressLine: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
      marginBottom: 2,
    },
    // Line Items Table
    table: {
      marginBottom: 24,
    },
    tableHeader: {
      flexDirection: "row",
      backgroundColor: theme.colors.semantic.background.muted,
      paddingVertical: 10,
      paddingHorizontal: 8,
      borderTopLeftRadius: theme.borders.radius.sm,
      borderTopRightRadius: theme.borders.radius.sm,
    },
    tableHeaderCell: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.secondary,
      textTransform: "uppercase",
    },
    tableRow: {
      flexDirection: "row",
      paddingVertical: 10,
      paddingHorizontal: 8,
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.semantic.border.subtle,
    },
    tableCell: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.primary,
    },
    colDescription: {
      flex: 3,
    },
    colQuantity: {
      width: 60,
      textAlign: "center",
    },
    colUnitPrice: {
      width: 80,
      textAlign: "right",
    },
    colTotal: {
      width: 90,
      textAlign: "right",
    },
    // Totals Section
    totalsSection: {
      flexDirection: "row",
      justifyContent: "flex-end",
      marginBottom: 32,
    },
    totalsTable: {
      width: 250,
    },
    totalsRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      paddingVertical: 6,
    },
    totalsLabel: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
    },
    totalsValue: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.primary,
    },
    totalsDivider: {
      borderTopWidth: 1,
      borderTopColor: theme.colors.semantic.border.default,
      marginVertical: 4,
    },
    grandTotalRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      paddingVertical: 8,
      backgroundColor: theme.colors.semantic.background.muted,
      paddingHorizontal: 8,
      marginHorizontal: -8,
      borderRadius: theme.borders.radius.sm,
    },
    grandTotalLabel: {
      fontSize: theme.typography.fontSizes.base,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
    },
    grandTotalValue: {
      fontSize: theme.typography.fontSizes.base,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.palette.brand[600],
    },
    // Payment Section
    paymentSection: {
      marginBottom: 24,
      padding: 16,
      backgroundColor: theme.colors.palette.brand[50],
      borderRadius: theme.borders.radius.md,
    },
    paymentTitle: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 8,
    },
    paymentText: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
      marginBottom: 4,
    },
    // Notes Section
    notesSection: {
      marginBottom: 24,
    },
    notesLabel: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.muted,
      textTransform: "uppercase",
      marginBottom: 4,
    },
    notesText: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
      lineHeight: 1.5,
    },
    // Footer Section
    footer: {
      marginTop: "auto",
      paddingTop: 16,
      borderTopWidth: 1,
      borderTopColor: theme.colors.semantic.border.subtle,
    },
    legalText: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      textAlign: "center",
      lineHeight: 1.5,
    },
  });

/**
 * Get page dimensions based on size and orientation
 */
function getPageDimensions(
  pageSize: InvoiceTemplateProps["pageSize"] = "A4",
  orientation: InvoiceTemplateProps["orientation"] = "portrait"
) {
  const size = pageSizes[pageSize] || pageSizes.A4;
  if (orientation === "landscape") {
    return { width: size.height, height: size.width };
  }
  return size;
}

/**
 * Format currency value
 */
function formatCurrency(value: number, currency = "$"): string {
  return `${currency}${value.toFixed(2)}`;
}

/**
 * Calculate line item total
 */
function calculateLineTotal(item: InvoiceLineItem): number {
  return item.total ?? item.quantity * item.unitPrice;
}

/**
 * Address Block Component
 */
const AddressBlock: React.FC<{
  label: string;
  address: AddressInfo;
  theme: typeof defaultTheme;
}> = ({ label, address, theme }) => {
  const styles = createStyles(theme);

  return (
    <View style={styles.addressBlock}>
      <PDFText style={styles.addressLabel}>{label}</PDFText>
      <PDFText style={styles.addressName}>{address.name}</PDFText>
      {address.address.map((line, index) => (
        <PDFText key={index} style={styles.addressLine}>
          {line}
        </PDFText>
      ))}
      {address.email && (
        <PDFText style={styles.addressLine}>{address.email}</PDFText>
      )}
      {address.phone && (
        <PDFText style={styles.addressLine}>{address.phone}</PDFText>
      )}
    </View>
  );
};

/**
 * Status Badge Component
 */
const StatusBadge: React.FC<{
  status: InvoiceTemplateProps["status"];
  theme: typeof defaultTheme;
}> = ({ status, theme }) => {
  if (!status) return null;

  const styles = createStyles(theme);

  const statusStyles = {
    paid: { badge: styles.statusPaid, text: styles.statusTextPaid },
    pending: { badge: styles.statusPending, text: styles.statusTextPending },
    overdue: { badge: styles.statusOverdue, text: styles.statusTextOverdue },
    draft: { badge: styles.statusDraft, text: styles.statusTextDraft },
  };

  const { badge, text } = statusStyles[status];

  return (
    <View style={[styles.statusBadge, badge]}>
      <PDFText style={[styles.statusText, text]}>{status}</PDFText>
    </View>
  );
};

/**
 * InvoiceTemplate component for professional invoices.
 * Features letterhead, address blocks, line items table, totals, and payment info.
 *
 * @example
 * ```tsx
 * <InvoiceTemplate
 *   title="Invoice"
 *   invoiceNumber="INV-2024-001"
 *   invoiceDate="January 15, 2024"
 *   dueDate="February 15, 2024"
 *   logo="/assets/logo.png"
 *   from={{
 *     name: "Acme Corporation",
 *     address: ["123 Business St", "New York, NY 10001"],
 *     email: "billing@acme.com"
 *   }}
 *   billTo={{
 *     name: "Client Company",
 *     address: ["456 Client Ave", "Los Angeles, CA 90001"],
 *   }}
 *   lineItems={[
 *     { description: "Consulting Services", quantity: 10, unitPrice: 150 },
 *     { description: "Development Work", quantity: 20, unitPrice: 200 },
 *   ]}
 *   taxRate={0.08}
 *   status="pending"
 * />
 * ```
 */
export const InvoiceTemplate: React.FC<InvoiceTemplateProps> = ({
  title = "Invoice",
  logo,
  theme = defaultTheme,
  pageSize = "A4",
  orientation = "portrait",
  invoiceNumber,
  invoiceDate,
  dueDate,
  from,
  billTo,
  shipTo,
  lineItems,
  subtotal: providedSubtotal,
  taxRate,
  taxAmount: providedTaxAmount,
  discount,
  discountDescription,
  total: providedTotal,
  currency = "$",
  payment,
  notes,
  legalText,
  status,
}) => {
  const styles = createStyles(theme);
  const dimensions = getPageDimensions(pageSize, orientation);

  // Calculate totals
  const calculatedSubtotal =
    providedSubtotal ?? lineItems.reduce((sum, item) => sum + calculateLineTotal(item), 0);
  const calculatedTaxAmount =
    providedTaxAmount ?? (taxRate ? calculatedSubtotal * taxRate : 0);
  const calculatedTotal =
    providedTotal ?? calculatedSubtotal + calculatedTaxAmount - (discount ?? 0);

  return (
    <Document>
      <Page size={dimensions} style={styles.page}>
        {/* Header Section */}
        <View style={styles.header}>
          <View style={styles.logoSection}>
            {logo && <Image src={logo} style={styles.logo} />}
            <PDFText style={styles.companyName}>{from.name}</PDFText>
          </View>
          <View style={styles.invoiceDetails}>
            <PDFText style={styles.invoiceTitle}>{title}</PDFText>
            <PDFText style={styles.invoiceNumber}># {invoiceNumber}</PDFText>
            {invoiceDate && (
              <PDFText style={styles.invoiceDates}>
                Date: {invoiceDate}
              </PDFText>
            )}
            {dueDate && (
              <PDFText style={styles.invoiceDates}>Due: {dueDate}</PDFText>
            )}
            <StatusBadge status={status} theme={theme} />
          </View>
        </View>

        {/* Address Section */}
        <View style={styles.addressSection}>
          <AddressBlock label="From" address={from} theme={theme} />
          <AddressBlock label="Bill To" address={billTo} theme={theme} />
          {shipTo && <AddressBlock label="Ship To" address={shipTo} theme={theme} />}
        </View>

        {/* Line Items Table */}
        <View style={styles.table}>
          {/* Table Header */}
          <View style={styles.tableHeader}>
            <PDFText style={[styles.tableHeaderCell, styles.colDescription]}>
              Description
            </PDFText>
            <PDFText style={[styles.tableHeaderCell, styles.colQuantity]}>
              Qty
            </PDFText>
            <PDFText style={[styles.tableHeaderCell, styles.colUnitPrice]}>
              Unit Price
            </PDFText>
            <PDFText style={[styles.tableHeaderCell, styles.colTotal]}>
              Total
            </PDFText>
          </View>

          {/* Table Rows */}
          {lineItems.map((item, index) => (
            <View key={index} style={styles.tableRow}>
              <PDFText style={[styles.tableCell, styles.colDescription]}>
                {item.description}
              </PDFText>
              <PDFText style={[styles.tableCell, styles.colQuantity]}>
                {item.quantity} {item.unit || ""}
              </PDFText>
              <PDFText style={[styles.tableCell, styles.colUnitPrice]}>
                {formatCurrency(item.unitPrice, currency)}
              </PDFText>
              <PDFText style={[styles.tableCell, styles.colTotal]}>
                {formatCurrency(calculateLineTotal(item), currency)}
              </PDFText>
            </View>
          ))}
        </View>

        {/* Totals Section */}
        <View style={styles.totalsSection}>
          <View style={styles.totalsTable}>
            <View style={styles.totalsRow}>
              <PDFText style={styles.totalsLabel}>Subtotal</PDFText>
              <PDFText style={styles.totalsValue}>
                {formatCurrency(calculatedSubtotal, currency)}
              </PDFText>
            </View>

            {discount !== undefined && discount > 0 && (
              <View style={styles.totalsRow}>
                <PDFText style={styles.totalsLabel}>
                  Discount {discountDescription ? `(${discountDescription})` : ""}
                </PDFText>
                <PDFText style={styles.totalsValue}>
                  -{formatCurrency(discount, currency)}
                </PDFText>
              </View>
            )}

            {taxRate !== undefined && taxRate > 0 && (
              <View style={styles.totalsRow}>
                <PDFText style={styles.totalsLabel}>
                  Tax ({(taxRate * 100).toFixed(0)}%)
                </PDFText>
                <PDFText style={styles.totalsValue}>
                  {formatCurrency(calculatedTaxAmount, currency)}
                </PDFText>
              </View>
            )}

            <View style={styles.totalsDivider} />

            <View style={styles.grandTotalRow}>
              <PDFText style={styles.grandTotalLabel}>Total Due</PDFText>
              <PDFText style={styles.grandTotalValue}>
                {formatCurrency(calculatedTotal, currency)}
              </PDFText>
            </View>
          </View>
        </View>

        {/* Payment Section */}
        {payment && (
          <View style={styles.paymentSection}>
            <PDFText style={styles.paymentTitle}>Payment Information</PDFText>
            {payment.terms && (
              <PDFText style={styles.paymentText}>
                Terms: {payment.terms}
              </PDFText>
            )}
            {payment.dueDate && (
              <PDFText style={styles.paymentText}>
                Due Date: {payment.dueDate}
              </PDFText>
            )}
            {payment.methods && payment.methods.length > 0 && (
              <PDFText style={styles.paymentText}>
                Accepted Methods: {payment.methods.join(", ")}
              </PDFText>
            )}
            {payment.instructions?.map((instruction, index) => (
              <PDFText key={index} style={styles.paymentText}>
                {instruction}
              </PDFText>
            ))}
          </View>
        )}

        {/* Notes Section */}
        {notes && (
          <View style={styles.notesSection}>
            <PDFText style={styles.notesLabel}>Notes</PDFText>
            <PDFText style={styles.notesText}>{notes}</PDFText>
          </View>
        )}

        {/* Footer Section */}
        {legalText && (
          <View style={styles.footer}>
            <PDFText style={styles.legalText}>{legalText}</PDFText>
          </View>
        )}
      </Page>
    </Document>
  );
};

export default InvoiceTemplate;
