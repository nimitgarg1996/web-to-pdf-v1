/**
 * ReportTemplate Component
 * Comprehensive report template with cover page, TOC placeholder, and content sections
 */

import React from "react";
import { Document, Page, View, Text as PDFText, StyleSheet } from "@react-pdf/renderer";
import type { ReportTemplateProps } from "./types.js";
import { defaultTheme } from "../primitives/theme.js";
import { pageSizes } from "../primitives/spacing.js";
import { PageHeader } from "./components/PageHeader.js";
import { PageFooter } from "./components/PageFooter.js";
import { CoverPage } from "./components/CoverPage.js";

/**
 * Create styles for the report template
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    page: {
      flexDirection: "column",
      backgroundColor: theme.colors.semantic.background.primary,
      paddingTop: 70,
      paddingBottom: 50,
      paddingHorizontal: 40,
    },
    contentPage: {
      flexDirection: "column",
      backgroundColor: theme.colors.semantic.background.primary,
      paddingTop: 70,
      paddingBottom: 50,
      paddingHorizontal: 40,
    },
    // TOC Placeholder Styles
    tocPage: {
      flexDirection: "column",
      backgroundColor: theme.colors.semantic.background.primary,
      paddingTop: 70,
      paddingBottom: 50,
      paddingHorizontal: 40,
    },
    tocTitle: {
      fontSize: theme.typography.fontSizes["2xl"],
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 24,
    },
    tocPlaceholder: {
      padding: 20,
      backgroundColor: theme.colors.semantic.background.muted,
      borderRadius: theme.borders.radius.md,
      borderWidth: 1,
      borderColor: theme.colors.semantic.border.default,
      borderStyle: "dashed",
    },
    tocPlaceholderText: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      textAlign: "center",
      fontStyle: "italic",
    },
    // Executive Summary Styles
    executiveSummarySection: {
      marginBottom: 24,
    },
    executiveSummaryTitle: {
      fontSize: theme.typography.fontSizes.xl,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 16,
    },
    executiveSummaryContent: {
      fontSize: theme.typography.fontSizes.base,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.normal,
      color: theme.colors.semantic.text.secondary,
      lineHeight: 1.6,
      marginBottom: 12,
    },
    highlightsContainer: {
      marginTop: 16,
      paddingLeft: 16,
    },
    highlightsTitle: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.semibold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 8,
    },
    highlightItem: {
      flexDirection: "row",
      alignItems: "flex-start",
      marginBottom: 6,
    },
    highlightBullet: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.palette.brand[500],
      marginRight: 8,
      width: 12,
    },
    highlightText: {
      flex: 1,
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.secondary,
      lineHeight: 1.5,
    },
    // Content area
    content: {
      flex: 1,
    },
  });

/**
 * Get page dimensions based on size and orientation
 */
function getPageDimensions(
  pageSize: ReportTemplateProps["pageSize"] = "A4",
  orientation: ReportTemplateProps["orientation"] = "portrait"
) {
  const size = pageSizes[pageSize] || pageSizes.A4;
  if (orientation === "landscape") {
    return { width: size.height, height: size.width };
  }
  return size;
}

/**
 * TOC Placeholder Component
 */
const TOCPlaceholder: React.FC<{
  theme: typeof defaultTheme;
  header?: ReportTemplateProps["header"];
  footer?: ReportTemplateProps["footer"];
  pageSize: { width: number; height: number };
}> = ({ theme, header, footer, pageSize }) => {
  const styles = createStyles(theme);

  return (
    <Page size={pageSize} style={styles.tocPage}>
      {header && (
        <PageHeader
          {...header}
          theme={theme}
        />
      )}
      <PDFText style={styles.tocTitle}>Table of Contents</PDFText>
      <View style={styles.tocPlaceholder}>
        <PDFText style={styles.tocPlaceholderText}>
          Table of Contents will be automatically generated in Phase 9
        </PDFText>
      </View>
      {footer && (
        <PageFooter
          {...footer}
          theme={theme}
        />
      )}
    </Page>
  );
};

/**
 * Executive Summary Component
 */
const ExecutiveSummarySection: React.FC<{
  summary: ReportTemplateProps["executiveSummary"];
  theme: typeof defaultTheme;
}> = ({ summary, theme }) => {
  if (!summary) return null;

  const styles = createStyles(theme);

  return (
    <View style={styles.executiveSummarySection}>
      <PDFText style={styles.executiveSummaryTitle}>
        {summary.title || "Executive Summary"}
      </PDFText>
      {summary.content.map((paragraph, index) => (
        <PDFText key={index} style={styles.executiveSummaryContent}>
          {paragraph}
        </PDFText>
      ))}
      {summary.highlights && summary.highlights.length > 0 && (
        <View style={styles.highlightsContainer}>
          <PDFText style={styles.highlightsTitle}>Key Highlights</PDFText>
          {summary.highlights.map((highlight, index) => (
            <View key={index} style={styles.highlightItem}>
              <PDFText style={styles.highlightBullet}>•</PDFText>
              <PDFText style={styles.highlightText}>{highlight}</PDFText>
            </View>
          ))}
        </View>
      )}
    </View>
  );
};

/**
 * ReportTemplate component for comprehensive documents.
 * Features cover page, table of contents placeholder, executive summary, and content sections.
 *
 * @example
 * ```tsx
 * <ReportTemplate
 *   title="Annual Report 2024"
 *   subtitle="Financial Overview"
 *   author="Finance Team"
 *   date="January 2024"
 *   logo="/assets/logo.png"
 *   showCover
 *   showTOC
 *   executiveSummary={{
 *     content: ["This report covers the financial performance..."],
 *     highlights: ["Revenue up 15%", "Costs reduced by 8%"]
 *   }}
 *   header={{ title: "Annual Report", showPageNumbers: true }}
 *   footer={{ companyName: "Acme Corp", showPageNumbers: true }}
 * >
 *   <Section title="Financial Overview">
 *     <Text>Content goes here...</Text>
 *   </Section>
 * </ReportTemplate>
 * ```
 */
export const ReportTemplate: React.FC<ReportTemplateProps> = ({
  title,
  subtitle,
  date,
  author,
  logo,
  theme = defaultTheme,
  pageSize = "A4",
  orientation = "portrait",
  showCover = true,
  companyName,
  companyInfo,
  executiveSummary,
  showTOC = false,
  header,
  footer,
  children,
}) => {
  const styles = createStyles(theme);
  const dimensions = getPageDimensions(pageSize, orientation);

  // Merge header with defaults
  const headerProps = header ? {
    title: header.title || title,
    logo: header.logo || logo,
    showPageNumbers: header.showPageNumbers ?? true,
    showDate: header.showDate ?? true,
    date: header.date || date,
  } : undefined;

  // Merge footer with defaults
  const footerProps = footer ? {
    companyName: footer.companyName || companyName,
    showPageNumbers: footer.showPageNumbers ?? true,
    confidential: footer.confidential,
    customText: footer.customText,
  } : undefined;

  return (
    <Document>
      {/* Cover Page */}
      {showCover && (
        <CoverPage
          title={title}
          subtitle={subtitle}
          author={author}
          date={date}
          logo={logo}
          companyName={companyName}
          companyInfo={companyInfo}
          theme={theme}
          pageSize={pageSize}
          orientation={orientation}
        />
      )}

      {/* Table of Contents Placeholder */}
      {showTOC && (
        <TOCPlaceholder
          theme={theme}
          header={headerProps}
          footer={footerProps}
          pageSize={dimensions}
        />
      )}

      {/* Main Content Pages */}
      <Page size={dimensions} style={styles.contentPage}>
        {headerProps && (
          <PageHeader
            {...headerProps}
            theme={theme}
          />
        )}

        {/* Executive Summary */}
        {executiveSummary && (
          <ExecutiveSummarySection summary={executiveSummary} theme={theme} />
        )}

        {/* Main Content */}
        <View style={styles.content}>{children}</View>

        {footerProps && (
          <PageFooter
            {...footerProps}
            theme={theme}
          />
        )}
      </Page>
    </Document>
  );
};

export default ReportTemplate;
