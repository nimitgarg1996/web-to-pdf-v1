/**
 * EstatePlanningTemplate Component
 * Professional estate planning report template matching wealth.com design
 */

import React from 'react';
import { Document, Page, View, Text as PDFText, StyleSheet } from '@react-pdf/renderer';
import type { BaseTemplateProps } from './types.js';
import { defaultTheme } from '../primitives/theme.js';
import { pageSizes } from '../primitives/spacing.js';
import { PageHeader } from './components/PageHeader.js';
import { PageFooter } from './components/PageFooter.js';
import { CoverPage } from './components/CoverPage.js';
import { DonutChart, DonutSegment } from '../components/charts/DonutChart.js';
import { BeneficiaryGrid } from '../components/estate/BeneficiaryGrid.js';
import { BeneficiaryCardProps } from '../components/estate/BeneficiaryCard.js';
import { TrustFlowChart, TrustNode, TrustConnection, TrustSeparator } from '../components/estate/TrustFlowChart.js';
import { Table } from '../components/table/Table.js';

/**
 * Estate planning client information
 */
export interface EstatePlanningClient {
  names: string[];
  trustName: string;
}

/**
 * Trust structure configuration
 */
export interface TrustStructure {
  nodes: TrustNode[];
  connections: TrustConnection[];
  separators?: TrustSeparator[];
}

/**
 * Key people document information
 */
export interface KeyPeopleDocument {
  name: string;
  role: string;
  designation: string;
}

/**
 * Estate overview with financial breakdown
 */
export interface EstateOverview {
  total: number;
  breakdown: DonutSegment[];
  details?: {
    insideTaxable?: Array<{ label: string; value: number }>;
    outsideTaxable?: Array<{ label: string; value: number }>;
  };
}

/**
 * Props for estate planning template
 */
export interface EstatePlanningTemplateProps extends BaseTemplateProps {
  client: EstatePlanningClient;
  trustStructure?: TrustStructure;
  keyPeople?: {
    documents: KeyPeopleDocument[];
  };
  estateOverview?: EstateOverview;
  beneficiaries?: BeneficiaryCardProps[];
  beneficiaryTitle?: string;
  showCover?: boolean;
  companyName?: string;
  disclaimer?: string;
}

/**
 * Create styles for the estate planning template
 */
const createStyles = (theme = defaultTheme) =>
  StyleSheet.create({
    page: {
      flexDirection: 'column',
      backgroundColor: '#FFFFFF',
      padding: 40,
    },
    pageWithHeader: {
      flexDirection: 'column',
      backgroundColor: '#FFFFFF',
      paddingTop: 70,
      paddingBottom: 50,
      paddingHorizontal: 40,
    },
    sectionTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: '#111827',
      marginBottom: 20,
    },
    subsectionTitle: {
      fontSize: 16,
      fontWeight: 'bold',
      color: '#111827',
      marginBottom: 12,
      marginTop: 16,
    },
    twoColumnLayout: {
      flexDirection: 'row',
      marginBottom: 24,
    },
    columnLeft: {
      flex: 1,
      marginRight: 12,
    },
    columnRight: {
      flex: 1,
      marginLeft: 12,
    },
    tableContainer: {
      marginBottom: 20,
    },
    disclaimerText: {
      fontSize: 8,
      color: '#6B7280',
      lineHeight: 1.4,
      marginTop: 20,
      paddingTop: 16,
      borderTop: '1px solid #E5E7EB',
    },
    brandFooter: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginTop: 20,
      paddingTop: 16,
      borderTop: '1px solid #E5E7EB',
    },
    companyName: {
      fontSize: 14,
      fontWeight: 'bold',
      color: '#2D9B9B',
    },
    centeredContent: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
  });

/**
 * Get page dimensions
 */
function getPageDimensions(
  pageSize: EstatePlanningTemplateProps['pageSize'] = 'A4',
  orientation: EstatePlanningTemplateProps['orientation'] = 'portrait'
) {
  const size = pageSizes[pageSize] || pageSizes.A4;
  if (orientation === 'landscape') {
    return { width: size.height, height: size.width };
  }
  return size;
}

/**
 * EstatePlanningTemplate component for wealth management estate planning reports.
 * Matches the professional design from wealth.com samples.
 *
 * @example
 * ```tsx
 * <EstatePlanningTemplate
 *   title="Estate Plan Overview"
 *   client={{
 *     names: ["John Doe", "Jane Doe"],
 *     trustName: "Doe Family Trust"
 *   }}
 *   trustStructure={{
 *     nodes: [...],
 *     connections: [...],
 *     separators: [...]
 *   }}
 *   estateOverview={{
 *     total: 270658850,
 *     breakdown: [...]
 *   }}
 *   beneficiaries={[...]}
 *   companyName="wealth.com"
 * />
 * ```
 */
export const EstatePlanningTemplate: React.FC<EstatePlanningTemplateProps> = ({
  title,
  subtitle,
  date,
  author,
  logo,
  theme = defaultTheme,
  pageSize = 'A4',
  orientation = 'portrait',
  client,
  trustStructure,
  keyPeople,
  estateOverview,
  beneficiaries,
  beneficiaryTitle = "Beneficiaries",
  showCover = true,
  companyName = 'wealth.com',
  disclaimer,
  children,
}) => {
  const styles = createStyles(theme);
  const dimensions = getPageDimensions(pageSize, orientation);

  // Format client names
  const clientNames = client.names.join(' & ');
  const fullTitle = title || `${clientNames} Estate Plan`;

  return (
    <Document>
      {/* Cover Page */}
      {showCover && (
        <CoverPage
          title={fullTitle}
          subtitle={subtitle || client.trustName}
          author={author}
          date={date}
          logo={logo}
          companyName={companyName}
          theme={theme}
          pageSize={pageSize}
          orientation={orientation}
        />
      )}

      {/* Trust Structure Page */}
      {trustStructure && (
        <Page size={dimensions} style={styles.page}>
          <PDFText style={styles.sectionTitle}>Trust Structure</PDFText>
          
          <TrustFlowChart
            nodes={trustStructure.nodes}
            connections={trustStructure.connections}
            separators={trustStructure.separators}
          />

          {/* Footer */}
          <View style={styles.brandFooter}>
            <PDFText style={styles.companyName}>{companyName}</PDFText>
          </View>
        </Page>
      )}

      {/* Key People & Estate Overview Page */}
      {(keyPeople || estateOverview) && (
        <Page size={dimensions} style={styles.page}>
          <PDFText style={styles.sectionTitle}>Estate Overview</PDFText>

          <View style={styles.twoColumnLayout}>
            {/* Left Column - Key People */}
            {keyPeople && keyPeople.documents && keyPeople.documents.length > 0 && (
              <View style={styles.columnLeft}>
                <PDFText style={styles.subsectionTitle}>Key People</PDFText>
                <View style={styles.tableContainer}>
                  <Table
                    columns={[
                      { key: 'name', header: 'Document', width: '35%', align: 'left' },
                      { key: 'role', header: 'Role', width: '30%', align: 'left' },
                      { key: 'designation', header: 'Designation', width: '35%', align: 'left' },
                    ]}
                    data={keyPeople.documents.map(doc => ({ ...doc } as Record<string, unknown>))}
                    variant="striped"
                  />
                </View>
              </View>
            )}

            {/* Right Column - Estate Donut Chart */}
            {estateOverview && (
              <View style={styles.columnRight}>
                <PDFText style={styles.subsectionTitle}>Total Estate Value</PDFText>
                <DonutChart
                  segments={estateOverview.breakdown}
                  total={estateOverview.total}
                  size={220}
                  thickness={40}
                  showLegend={true}
                />
              </View>
            )}
          </View>

          {/* Estate Details Breakdown */}
          {estateOverview?.details && (
            <View style={{ marginTop: 24 }}>
              <View style={{ flexDirection: 'row' }}>
                {/* Inside Taxable Estate */}
                {estateOverview.details.insideTaxable && (
                  <View style={{ flex: 1, marginRight: 10 }}>
                    <PDFText style={styles.subsectionTitle}>Inside Taxable Estate</PDFText>
                    <Table
                      columns={[
                        { key: 'label', header: 'Category', width: '60%', align: 'left' },
                        {
                          key: 'value',
                          header: 'Amount',
                          width: '40%',
                          align: 'right',
                          format: (value: unknown) => {
                            const num = typeof value === 'number' ? value : 0;
                            return `$${num.toLocaleString('en-US')}`;
                          }
                        },
                      ]}
                      data={estateOverview.details.insideTaxable.map(item => ({ ...item } as Record<string, unknown>))}
                      variant="striped"
                    />
                  </View>
                )}

                {/* Outside Taxable Estate */}
                {estateOverview.details.outsideTaxable && (
                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <PDFText style={styles.subsectionTitle}>Outside Taxable Estate</PDFText>
                    <Table
                      columns={[
                        { key: 'label', header: 'Category', width: '60%', align: 'left' },
                        {
                          key: 'value',
                          header: 'Amount',
                          width: '40%',
                          align: 'right',
                          format: (value: unknown) => {
                            const num = typeof value === 'number' ? value : 0;
                            return `$${num.toLocaleString('en-US')}`;
                          }
                        },
                      ]}
                      data={estateOverview.details.outsideTaxable.map(item => ({ ...item } as Record<string, unknown>))}
                      variant="striped"
                    />
                  </View>
                )}
              </View>
            </View>
          )}

          {/* Disclaimer */}
          {disclaimer && (
            <PDFText style={styles.disclaimerText}>{disclaimer}</PDFText>
          )}

          {/* Footer */}
          <View style={styles.brandFooter}>
            <PDFText style={styles.companyName}>{companyName}</PDFText>
          </View>
        </Page>
      )}

      {/* Beneficiaries Page */}
      {beneficiaries && beneficiaries.length > 0 && (
        <Page size={dimensions} style={styles.page}>
          <BeneficiaryGrid
            title={beneficiaryTitle}
            beneficiaries={beneficiaries}
            columns={3}
          />

          {/* Footer */}
          <View style={styles.brandFooter}>
            <PDFText style={styles.companyName}>{companyName}</PDFText>
          </View>
        </Page>
      )}

      {/* Additional Custom Content Pages - only render if children is truthy and non-empty */}
      {children && React.Children.count(children) > 0 && (
        <Page size={dimensions} style={styles.page}>
          {children}

          {/* Footer */}
          <View style={styles.brandFooter}>
            <PDFText style={styles.companyName}>{companyName}</PDFText>
          </View>
        </Page>
      )}
    </Document>
  );
};

export default EstatePlanningTemplate;
