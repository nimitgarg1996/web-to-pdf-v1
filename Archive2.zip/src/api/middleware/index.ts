/**
 * API Middleware Index
 * Exports all middleware functions
 */

// Error handling
export {
  errorHandler,
  notFoundHandler,
  ApiError,
  ValidationError,
  NotFoundError,
  PdfGenerationError,
  BadRequestError,
} from "./errorHandler.js";

// Request validation
export {
  validateBlueprintRequest,
  validateJsonBody,
  validateParams,
  validateSampleType,
  type BlueprintRequest,
} from "./validateRequest.js";

// Request logging
export {
  requestLogger,
  simpleRequestLogger,
} from "./requestLogger.js";

// CORS
export {
  corsMiddleware,
  createCorsMiddleware,
  defaultCorsOptions,
  type CorsOptions,
} from "./cors.js";
