/**
 * Request Logger Middleware
 * Logs all incoming requests and response details
 */

import type { Request, Response, NextFunction } from "express";
import { logger } from "../../utils/logger.js";

/**
 * Generate a unique request ID
 */
function generateRequestId(): string {
  return `req_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 9)}`;
}

/**
 * Calculate content size from various headers/body
 */
function getContentSize(req: Request): string {
  const contentLength = req.headers["content-length"];
  
  if (contentLength) {
    const size = parseInt(contentLength, 10);
    if (size < 1024) {
      return `${size}B`;
    } else if (size < 1024 * 1024) {
      return `${(size / 1024).toFixed(1)}KB`;
    } else {
      return `${(size / (1024 * 1024)).toFixed(2)}MB`;
    }
  }
  
  return "-";
}

/**
 * Extended request with timing info
 */
interface TimedRequest extends Request {
  startTime?: number;
  requestId?: string;
}

/**
 * Request logger middleware
 * Logs request details on entry and response details on completion
 */
export function requestLogger(
  req: TimedRequest,
  res: Response,
  next: NextFunction
): void {
  // Add timing and request ID
  req.startTime = Date.now();
  req.requestId = generateRequestId();

  // Log incoming request
  const contentSize = getContentSize(req);
  const userAgent = req.headers["user-agent"] || "-";
  
  logger.debug(`→ ${req.method} ${req.path}`, {
    requestId: req.requestId,
    method: req.method,
    path: req.path,
    query: Object.keys(req.query).length > 0 ? req.query : undefined,
    contentSize,
    userAgent: userAgent.substring(0, 100), // Truncate long user agents
    ip: req.ip || req.socket.remoteAddress,
  });

  // Log response on finish
  res.on("finish", () => {
    // Calculate response time
    const responseTime = req.startTime ? Date.now() - req.startTime : 0;
    const statusCode = res.statusCode;
    
    // Determine log level based on status code
    const logMethod = statusCode >= 500 ? "error" : statusCode >= 400 ? "warn" : "info";
    
    // Log response
    logger[logMethod](`← ${req.method} ${req.path} ${statusCode} ${responseTime}ms`, {
      requestId: req.requestId,
      method: req.method,
      path: req.path,
      statusCode,
      responseTime,
      contentType: res.getHeader("content-type"),
    });
  });

  next();
}

/**
 * Simple request logger for development
 * Less verbose than the full request logger
 */
export function simpleRequestLogger(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const startTime = Date.now();

  res.on("finish", () => {
    const responseTime = Date.now() - startTime;
    const statusColor = res.statusCode >= 500 
      ? "\x1b[31m" // Red for 5xx
      : res.statusCode >= 400 
        ? "\x1b[33m" // Yellow for 4xx
        : "\x1b[32m"; // Green for 2xx/3xx
    const reset = "\x1b[0m";
    
    console.log(
      `${statusColor}${req.method}${reset} ${req.path} - ${statusColor}${res.statusCode}${reset} - ${responseTime}ms`
    );
  });

  next();
}

export default requestLogger;
