/**
 * Request Validator Middleware
 * Validates incoming requests for the PDF API
 */

import type { Request, Response, NextFunction } from "express";
import { ValidationError, BadRequestError } from "./errorHandler.js";
import type { Blueprint, BlueprintType } from "../../blueprints/types.js";

/**
 * Extended request interface with validated blueprint
 */
export interface BlueprintRequest extends Request {
  validatedBlueprint?: Blueprint;
}

/**
 * Valid blueprint types
 */
const VALID_BLUEPRINT_TYPES: BlueprintType[] = [
  "report",
  "dashboard",
  "invoice",
  "data-table",
];

/**
 * Validate that the request has the correct Content-Type
 */
function validateContentType(req: Request): void {
  const contentType = req.headers["content-type"];
  
  if (!contentType || !contentType.includes("application/json")) {
    throw new BadRequestError(
      "Content-Type must be application/json",
      { receivedContentType: contentType }
    );
  }
}

/**
 * Validate blueprint structure
 * Performs basic structural validation before passing to the BlueprintValidator
 */
function validateBlueprintStructure(body: unknown): Blueprint {
  if (!body || typeof body !== "object") {
    throw new ValidationError("Request body must be a valid JSON object");
  }

  const blueprint = body as Record<string, unknown>;

  // Check required top-level fields
  if (!blueprint.id || typeof blueprint.id !== "string") {
    throw new ValidationError("Blueprint must have a valid 'id' field", {
      field: "id",
      expected: "string",
      received: typeof blueprint.id,
    });
  }

  if (!blueprint.version || typeof blueprint.version !== "string") {
    throw new ValidationError("Blueprint must have a valid 'version' field", {
      field: "version",
      expected: "string",
      received: typeof blueprint.version,
    });
  }

  if (!blueprint.type || typeof blueprint.type !== "string") {
    throw new ValidationError("Blueprint must have a valid 'type' field", {
      field: "type",
      expected: "string",
      received: typeof blueprint.type,
    });
  }

  if (!VALID_BLUEPRINT_TYPES.includes(blueprint.type as BlueprintType)) {
    throw new ValidationError(
      `Invalid blueprint type: '${blueprint.type}'`,
      {
        field: "type",
        received: blueprint.type,
        validTypes: VALID_BLUEPRINT_TYPES,
      }
    );
  }

  if (!blueprint.metadata || typeof blueprint.metadata !== "object") {
    throw new ValidationError("Blueprint must have a valid 'metadata' object", {
      field: "metadata",
      expected: "object",
      received: typeof blueprint.metadata,
    });
  }

  const metadata = blueprint.metadata as Record<string, unknown>;
  if (!metadata.title || typeof metadata.title !== "string") {
    throw new ValidationError("Blueprint metadata must have a valid 'title' field", {
      field: "metadata.title",
      expected: "string",
      received: typeof metadata.title,
    });
  }

  if (!blueprint.content || typeof blueprint.content !== "object") {
    throw new ValidationError("Blueprint must have a valid 'content' object", {
      field: "content",
      expected: "object",
      received: typeof blueprint.content,
    });
  }

  return blueprint as unknown as Blueprint;
}

/**
 * Middleware to validate blueprint request
 * Validates Content-Type, body structure, and attaches validated blueprint to request
 */
export function validateBlueprintRequest(
  req: BlueprintRequest,
  _res: Response,
  next: NextFunction
): void {
  try {
    // Validate Content-Type header
    validateContentType(req);

    // Validate body is present
    if (!req.body) {
      throw new BadRequestError("Request body is required");
    }

    // Validate blueprint structure
    const blueprint = validateBlueprintStructure(req.body);

    // Attach validated blueprint to request
    req.validatedBlueprint = blueprint;

    next();
  } catch (error) {
    next(error);
  }
}

/**
 * Middleware to validate that request body is valid JSON
 * Use as a wrapper for express.json() to provide better error messages
 */
export function validateJsonBody(
  req: Request,
  _res: Response,
  next: NextFunction
): void {
  // Check if body is empty
  const contentLength = parseInt(req.headers["content-length"] || "0", 10);
  
  if (contentLength === 0 && req.method === "POST") {
    return next(new BadRequestError("Request body is required"));
  }

  next();
}

/**
 * Validate route parameters
 */
export function validateParams(allowedParams: string[]) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const invalidParams = Object.keys(req.params).filter(
      (param) => !allowedParams.includes(param)
    );

    if (invalidParams.length > 0) {
      return next(
        new BadRequestError(`Invalid route parameters: ${invalidParams.join(", ")}`)
      );
    }

    next();
  };
}

/**
 * Validate sample type parameter
 */
export function validateSampleType(
  req: Request,
  _res: Response,
  next: NextFunction
): void {
  const type = req.params.type;
  const validTypes = ["report", "dashboard", "invoice", "data-table"];

  // Handle case where type might be an array (shouldn't happen but TypeScript requires it)
  const typeStr = Array.isArray(type) ? type[0] : type;

  if (!typeStr || !validTypes.includes(typeStr)) {
    return next(
      new ValidationError(`Invalid sample type: '${typeStr}'`, {
        received: typeStr,
        validTypes,
      })
    );
  }

  next();
}

export default validateBlueprintRequest;
