/**
 * Error Handler Middleware
 * Centralized error handling for the API
 */

import type { Request, Response, NextFunction } from "express";
import { logger } from "../../utils/logger.js";
import type { ApiResponse } from "../../types/index.js";

/**
 * Custom API Error class with status code and error code
 */
export class ApiError extends Error {
  statusCode: number;
  code: string;
  details?: unknown;

  constructor(
    message: string,
    statusCode: number = 500,
    code: string = "INTERNAL_ERROR",
    details?: unknown
  ) {
    super(message);
    this.name = "ApiError";
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

/**
 * Validation error for blueprint and request validation
 */
export class ValidationError extends ApiError {
  constructor(message: string, details?: unknown) {
    super(message, 400, "VALIDATION_ERROR", details);
    this.name = "ValidationError";
  }
}

/**
 * Not found error for missing resources
 */
export class NotFoundError extends ApiError {
  constructor(message: string = "Resource not found") {
    super(message, 404, "NOT_FOUND");
    this.name = "NotFoundError";
  }
}

/**
 * PDF generation error
 */
export class PdfGenerationError extends ApiError {
  constructor(message: string, details?: unknown) {
    super(message, 500, "PDF_GENERATION_ERROR", details);
    this.name = "PdfGenerationError";
  }
}

/**
 * Bad request error for malformed requests
 */
export class BadRequestError extends ApiError {
  constructor(message: string, details?: unknown) {
    super(message, 400, "BAD_REQUEST", details);
    this.name = "BadRequestError";
  }
}

/**
 * Map of HTTP status codes to error codes
 */
const statusCodeToErrorCode: Record<number, string> = {
  400: "BAD_REQUEST",
  401: "UNAUTHORIZED",
  403: "FORBIDDEN",
  404: "NOT_FOUND",
  405: "METHOD_NOT_ALLOWED",
  409: "CONFLICT",
  422: "UNPROCESSABLE_ENTITY",
  429: "TOO_MANY_REQUESTS",
  500: "INTERNAL_ERROR",
  502: "BAD_GATEWAY",
  503: "SERVICE_UNAVAILABLE",
};

/**
 * Get error code from status code
 */
function getErrorCode(statusCode: number): string {
  return statusCodeToErrorCode[statusCode] || "INTERNAL_ERROR";
}

/**
 * Error handler middleware
 * Catches all errors and returns a standardized JSON response
 */
export function errorHandler(
  err: Error,
  _req: Request,
  res: Response<ApiResponse>,
  _next: NextFunction
): void {
  // Determine status code and error code
  let statusCode = 500;
  let errorCode = "INTERNAL_ERROR";
  let message = "An internal server error occurred";
  let details: unknown = undefined;

  if (err instanceof ApiError) {
    statusCode = err.statusCode;
    errorCode = err.code;
    message = err.message;
    details = err.details;
  } else if (err instanceof SyntaxError && "body" in err) {
    // JSON parse error
    statusCode = 400;
    errorCode = "INVALID_JSON";
    message = "Invalid JSON in request body";
  } else {
    // Unknown error - log full details but return generic message in production
    errorCode = getErrorCode(statusCode);
    message =
      process.env.NODE_ENV === "production"
        ? "An internal server error occurred"
        : err.message;
  }

  // Log the error
  logger.error(`[${errorCode}] ${err.message}`, err, {
    statusCode,
    errorCode,
    stack: err.stack,
  });

  // Build response
  const response: ApiResponse = {
    success: false,
    error: {
      code: errorCode,
      message,
    },
  };

  // Include details in development mode
  if (process.env.NODE_ENV !== "production" && details) {
    (response.error as Record<string, unknown>).details = details;
  }

  res.status(statusCode).json(response);
}

/**
 * Not found handler for undefined routes
 */
export function notFoundHandler(
  _req: Request,
  res: Response<ApiResponse>,
  _next: NextFunction
): void {
  res.status(404).json({
    success: false,
    error: {
      code: "NOT_FOUND",
      message: "The requested resource was not found",
    },
  });
}

export default errorHandler;
