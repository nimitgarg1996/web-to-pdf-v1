/**
 * CORS Middleware
 * Configures Cross-Origin Resource Sharing for the API
 */

import type { Request, Response, NextFunction } from "express";

/**
 * CORS configuration options
 */
export interface CorsOptions {
  /** Allowed origins (comma-separated string or array) */
  origin: string | string[] | boolean;
  /** Allowed HTTP methods */
  methods: string[];
  /** Allowed headers */
  allowedHeaders: string[];
  /** Exposed headers (accessible to client) */
  exposedHeaders?: string[];
  /** Allow credentials (cookies, authorization headers) */
  credentials?: boolean;
  /** Preflight cache duration in seconds */
  maxAge?: number;
}

/**
 * Default CORS options
 */
export const defaultCorsOptions: CorsOptions = {
  origin: process.env.ALLOWED_ORIGINS?.split(",").map(o => o.trim()) || "*",
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Accept", "Authorization", "X-Request-ID"],
  exposedHeaders: ["Content-Disposition", "Content-Length", "X-Generation-Time"],
  credentials: false,
  maxAge: 86400, // 24 hours
};

/**
 * Check if origin is allowed
 */
function isOriginAllowed(
  origin: string | undefined,
  allowedOrigins: string | string[] | boolean
): boolean {
  // Allow all origins
  if (allowedOrigins === "*" || allowedOrigins === true) {
    return true;
  }

  // No origin header (same-origin or non-browser request)
  if (!origin) {
    return true;
  }

  // Disallow all origins
  if (allowedOrigins === false) {
    return false;
  }

  // Check against list of allowed origins
  if (Array.isArray(allowedOrigins)) {
    return allowedOrigins.some((allowed) => {
      // Support wildcard patterns
      if (allowed.includes("*")) {
        const pattern = allowed
          .replace(/\./g, "\\.")
          .replace(/\*/g, ".*");
        return new RegExp(`^${pattern}$`).test(origin);
      }
      return allowed === origin;
    });
  }

  // Single origin check
  return allowedOrigins === origin;
}

/**
 * Create CORS middleware with custom options
 */
export function createCorsMiddleware(options: Partial<CorsOptions> = {}) {
  const corsOptions: CorsOptions = {
    ...defaultCorsOptions,
    ...options,
  };

  return function corsMiddleware(
    req: Request,
    res: Response,
    next: NextFunction
  ): void {
    const origin = req.headers.origin;
    const isAllowed = isOriginAllowed(origin, corsOptions.origin);

    // Set CORS headers
    if (isAllowed) {
      // Set origin header (echo back the origin or use *)
      if (origin && corsOptions.origin !== "*") {
        res.setHeader("Access-Control-Allow-Origin", origin);
      } else if (corsOptions.origin === "*" || corsOptions.origin === true) {
        res.setHeader("Access-Control-Allow-Origin", "*");
      }

      // Set credentials header
      if (corsOptions.credentials) {
        res.setHeader("Access-Control-Allow-Credentials", "true");
      }

      // Set exposed headers
      if (corsOptions.exposedHeaders && corsOptions.exposedHeaders.length > 0) {
        res.setHeader(
          "Access-Control-Expose-Headers",
          corsOptions.exposedHeaders.join(", ")
        );
      }
    }

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      if (isAllowed) {
        // Set allowed methods
        res.setHeader(
          "Access-Control-Allow-Methods",
          corsOptions.methods.join(", ")
        );

        // Set allowed headers
        res.setHeader(
          "Access-Control-Allow-Headers",
          corsOptions.allowedHeaders.join(", ")
        );

        // Set max age for caching preflight response
        if (corsOptions.maxAge) {
          res.setHeader("Access-Control-Max-Age", corsOptions.maxAge.toString());
        }
      }

      // Respond to preflight request
      res.status(204).end();
      return;
    }

    next();
  };
}

/**
 * Default CORS middleware with environment-based configuration
 */
export const corsMiddleware = createCorsMiddleware();

export default corsMiddleware;
