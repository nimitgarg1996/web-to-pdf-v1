/**
 * PDF Routes
 * Express routes for PDF generation API
 */

import { Router, type Request, type Response, type NextFunction } from "express";
import { pdfService } from "../../services/index.js";
import {
  validateBlueprintRequest,
  validateSampleType,
  type BlueprintRequest,
} from "../middleware/validateRequest.js";
import { NotFoundError, PdfGenerationError } from "../middleware/errorHandler.js";
import { samples, getSampleBlueprint } from "../../blueprints/samples/index.js";
import type { ApiResponse } from "../../types/index.js";
import type { Blueprint, BlueprintType } from "../../blueprints/types.js";
import { logger } from "../../utils/logger.js";

// Create router
export const pdfRouter = Router();

/**
 * Available templates response type
 */
interface TemplatesResponse {
  templates: string[];
}

/**
 * Sample blueprint response type
 */
interface SampleResponse {
  type: string;
  blueprint: Blueprint;
}

/**
 * Validation response type
 */
interface ValidationResponse {
  valid: boolean;
  errors: Array<{ path: string; message: string; code: string }>;
  warnings: Array<{ path: string; message: string; suggestion?: string }>;
}

/**
 * POST /api/pdf/generate
 * Generate PDF from blueprint
 * 
 * Request body: Blueprint JSON
 * Response: PDF stream (default) or buffer based on Accept header
 * 
 * Query params:
 *   - format: 'stream' | 'buffer' (default: 'stream')
 *   - disposition: 'attachment' | 'inline' (default: 'attachment')
 *   - filename: custom filename for the PDF
 */
pdfRouter.post(
  "/generate",
  validateBlueprintRequest,
  async (req: BlueprintRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      const blueprint = req.validatedBlueprint!;
      const format = (req.query.format as "stream" | "buffer") || "stream";
      const disposition = (req.query.disposition as "attachment" | "inline") || "attachment";
      const filename = req.query.filename as string | undefined;

      logger.info("PDF generation requested", {
        blueprintId: blueprint.id,
        blueprintType: blueprint.type,
        format,
        disposition,
      });

      // Generate PDF
      const result = await pdfService.generatePdf({
        blueprint,
        format,
        filename,
      });

      if (!result.success || !result.data) {
        throw new PdfGenerationError(result.error || "Failed to generate PDF", {
          validation: result.validation,
        });
      }

      // Set response headers
      const pdfFilename = result.metadata?.filename || "document.pdf";
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `${disposition}; filename="${pdfFilename}"`);
      
      // Add generation metadata headers
      if (result.metadata) {
        res.setHeader("X-Generation-Time", result.metadata.generationTime.toString());
        res.setHeader("X-Blueprint-Type", result.metadata.blueprintType);
        res.setHeader("X-Blueprint-Id", result.metadata.blueprintId);
      }

      // Handle warnings in response header
      if (result.validation && result.validation.warnings.length > 0) {
        res.setHeader(
          "X-Validation-Warnings",
          result.validation.warnings.length.toString()
        );
      }

      // Send the PDF
      if (Buffer.isBuffer(result.data)) {
        res.setHeader("Content-Length", result.data.length.toString());
        res.send(result.data);
      } else {
        // Stream the PDF
        result.data.pipe(res);
      }
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/pdf/validate
 * Validate blueprint without generating PDF
 * 
 * Request body: Blueprint JSON
 * Response: { valid: boolean, errors: [], warnings: [] }
 */
pdfRouter.post(
  "/validate",
  validateBlueprintRequest,
  async (req: BlueprintRequest, res: Response<ApiResponse<ValidationResponse>>, next: NextFunction): Promise<void> => {
    try {
      const blueprint = req.validatedBlueprint!;

      logger.debug("Blueprint validation requested", {
        blueprintId: blueprint.id,
        blueprintType: blueprint.type,
      });

      const result = await pdfService.validateBlueprint(blueprint);

      res.json({
        success: true,
        data: {
          valid: result.valid,
          errors: result.errors,
          warnings: result.warnings,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * GET /api/pdf/templates
 * List available templates
 * 
 * Response: { templates: ['report', 'dashboard', 'invoice', 'data-table'] }
 */
pdfRouter.get(
  "/templates",
  (_req: Request, res: Response<ApiResponse<TemplatesResponse>>): void => {
    const templates = pdfService.getAvailableTemplates();

    res.json({
      success: true,
      data: {
        templates,
      },
    });
  }
);

/**
 * GET /api/pdf/samples
 * List available sample blueprints
 * 
 * Response: { samples: ['report', 'dashboard', 'invoice'] }
 */
pdfRouter.get(
  "/samples",
  (_req: Request, res: Response<ApiResponse<{ samples: string[] }>>): void => {
    const availableSamples = Object.keys(samples);

    res.json({
      success: true,
      data: {
        samples: availableSamples,
      },
    });
  }
);

/**
 * GET /api/pdf/samples/:type
 * Get sample blueprint for a specific template type
 * 
 * Params:
 *   - type: 'report' | 'dashboard' | 'invoice'
 * 
 * Response: Sample blueprint JSON
 */
pdfRouter.get(
  "/samples/:type",
  validateSampleType,
  (req: Request, res: Response<ApiResponse<SampleResponse>>, next: NextFunction): void => {
    try {
      const type = req.params.type as "report" | "dashboard" | "invoice";

      // Check if sample exists
      if (!(type in samples)) {
        throw new NotFoundError(`Sample blueprint not found for type: ${type}`);
      }

      const blueprint = getSampleBlueprint(type);

      res.json({
        success: true,
        data: {
          type,
          blueprint,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * POST /api/pdf/samples/:type/generate
 * Generate PDF from a sample blueprint
 * 
 * Params:
 *   - type: 'report' | 'dashboard' | 'invoice'
 * 
 * Response: PDF stream
 */
pdfRouter.post(
  "/samples/:type/generate",
  validateSampleType,
  async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const type = req.params.type as "report" | "dashboard" | "invoice";
      const disposition = (req.query.disposition as "attachment" | "inline") || "attachment";

      // Check if sample exists
      if (!(type in samples)) {
        throw new NotFoundError(`Sample blueprint not found for type: ${type}`);
      }

      const blueprint = getSampleBlueprint(type);

      logger.info("Sample PDF generation requested", {
        type,
        blueprintId: blueprint.id,
      });

      // Generate PDF
      const result = await pdfService.generatePdf({
        blueprint,
        format: "stream",
      });

      if (!result.success || !result.data) {
        throw new PdfGenerationError(result.error || "Failed to generate sample PDF");
      }

      // Set response headers
      const pdfFilename = result.metadata?.filename || `sample-${type}.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `${disposition}; filename="${pdfFilename}"`);
      
      if (result.metadata) {
        res.setHeader("X-Generation-Time", result.metadata.generationTime.toString());
      }

      // Stream the PDF
      if (Buffer.isBuffer(result.data)) {
        res.send(result.data);
      } else {
        result.data.pipe(res);
      }
    } catch (error) {
      next(error);
    }
  }
);

export default pdfRouter;
