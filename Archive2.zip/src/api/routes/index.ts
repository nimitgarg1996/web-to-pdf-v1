/**
 * API Routes Index
 * Exports all API route handlers
 */

// PDF routes
export { pdfRouter } from "./pdf.routes.js";

// Health routes
export { healthRouter } from "./health.routes.js";
