/**
 * Health Routes
 * Health check and status endpoints for the API
 */

import { Router, type Request, type Response } from "express";
import type { ApiResponse } from "../../types/index.js";
import { appConfig, serverConfig } from "../../config/index.js";

// Create router
export const healthRouter = Router();

/**
 * Health check response type
 */
interface HealthResponse {
  status: "ok" | "error";
  timestamp: string;
  uptime: number;
  version: string;
}

/**
 * Readiness check response type
 */
interface ReadinessResponse {
  ready: boolean;
  checks: {
    server: "ok" | "error";
    memory: "ok" | "warning" | "error";
  };
  details: {
    memoryUsage: {
      heapUsed: string;
      heapTotal: string;
      rss: string;
      percentUsed: number;
    };
    uptime: number;
    environment: string;
  };
}

/**
 * Format bytes to human-readable string
 */
function formatBytes(bytes: number): string {
  const mb = bytes / (1024 * 1024);
  return `${mb.toFixed(2)}MB`;
}

/**
 * Get memory status based on usage percentage
 */
function getMemoryStatus(percentUsed: number): "ok" | "warning" | "error" {
  if (percentUsed >= 90) return "error";
  if (percentUsed >= 75) return "warning";
  return "ok";
}

/**
 * GET /health
 * Basic health check endpoint
 * 
 * Response: { status: 'ok', timestamp: Date, uptime: number, version: string }
 */
healthRouter.get(
  "/",
  (_req: Request, res: Response<ApiResponse<HealthResponse>>): void => {
    const health: HealthResponse = {
      status: "ok",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: appConfig.version,
    };

    res.json({
      success: true,
      data: health,
    });
  }
);

/**
 * GET /health/live
 * Liveness probe - checks if the server is running
 * Returns 200 if server is alive, useful for Kubernetes liveness probes
 * 
 * Response: { alive: true }
 */
healthRouter.get(
  "/live",
  (_req: Request, res: Response<ApiResponse<{ alive: boolean }>>): void => {
    res.json({
      success: true,
      data: { alive: true },
    });
  }
);

/**
 * GET /health/ready
 * Readiness probe - checks if the server is ready to accept requests
 * Includes memory and other system checks
 * 
 * Response: { ready: boolean, checks: { server: 'ok', memory: 'ok' }, details: {...} }
 */
healthRouter.get(
  "/ready",
  (_req: Request, res: Response<ApiResponse<ReadinessResponse>>): void => {
    const memoryUsage = process.memoryUsage();
    const heapUsedPercent = (memoryUsage.heapUsed / memoryUsage.heapTotal) * 100;
    const memoryStatus = getMemoryStatus(heapUsedPercent);

    const readiness: ReadinessResponse = {
      ready: memoryStatus !== "error",
      checks: {
        server: "ok",
        memory: memoryStatus,
      },
      details: {
        memoryUsage: {
          heapUsed: formatBytes(memoryUsage.heapUsed),
          heapTotal: formatBytes(memoryUsage.heapTotal),
          rss: formatBytes(memoryUsage.rss),
          percentUsed: Math.round(heapUsedPercent),
        },
        uptime: process.uptime(),
        environment: serverConfig.env,
      },
    };

    // Return 503 if not ready
    const statusCode = readiness.ready ? 200 : 503;

    res.status(statusCode).json({
      success: readiness.ready,
      data: readiness,
    });
  }
);

/**
 * GET /health/info
 * Server information endpoint
 * 
 * Response: Server and application info
 */
healthRouter.get(
  "/info",
  (_req: Request, res: Response<ApiResponse<{
    name: string;
    version: string;
    description: string;
    environment: string;
    nodeVersion: string;
    platform: string;
  }>>): void => {
    res.json({
      success: true,
      data: {
        name: appConfig.name,
        version: appConfig.version,
        description: appConfig.description,
        environment: serverConfig.env,
        nodeVersion: process.version,
        platform: process.platform,
      },
    });
  }
);

export default healthRouter;
