/**
 * Page Number Utilities
 * Format and style page numbers in various formats
 */

// ============================================================================
// Types
// ============================================================================

/**
 * Page number format options
 */
export type PageNumberFormat = "numeric" | "roman" | "roman-lower" | "alpha" | "alpha-lower";

/**
 * Configuration for page number formatting
 */
export interface PageNumberConfig {
  /** Format type for page numbers */
  format: PageNumberFormat;
  /** Starting page number (default: 1) */
  startFrom?: number;
  /** Prefix to add before page number */
  prefix?: string;
  /** Suffix to add after page number */
  suffix?: string;
  /** Show total pages (e.g., "Page 1 of 10") */
  showTotal?: boolean;
  /** Separator between current and total (default: " of ") */
  totalSeparator?: string;
}

/**
 * Default page number configuration
 */
export const defaultPageNumberConfig: PageNumberConfig = {
  format: "numeric",
  startFrom: 1,
  prefix: "",
  suffix: "",
  showTotal: true,
  totalSeparator: " of ",
};

// ============================================================================
// Conversion Functions
// ============================================================================

/**
 * Roman numeral mappings
 */
const ROMAN_NUMERALS: Array<[number, string]> = [
  [1000, "M"],
  [900, "CM"],
  [500, "D"],
  [400, "CD"],
  [100, "C"],
  [90, "XC"],
  [50, "L"],
  [40, "XL"],
  [10, "X"],
  [9, "IX"],
  [5, "V"],
  [4, "IV"],
  [1, "I"],
];

/**
 * Convert a number to Roman numerals
 * @param num - Number to convert (1-3999)
 * @returns Roman numeral string
 */
export function toRoman(num: number): string {
  if (num < 1 || num > 3999) {
    return String(num); // Fallback to numeric for out of range
  }

  let result = "";
  let remaining = num;

  for (const [value, numeral] of ROMAN_NUMERALS) {
    while (remaining >= value) {
      result += numeral;
      remaining -= value;
    }
  }

  return result;
}

/**
 * Convert a number to lowercase Roman numerals
 * @param num - Number to convert
 * @returns Lowercase Roman numeral string
 */
export function toRomanLower(num: number): string {
  return toRoman(num).toLowerCase();
}

/**
 * Convert a number to alphabetic representation (A, B, C... Z, AA, AB...)
 * @param num - Number to convert (1-based)
 * @returns Alphabetic string
 */
export function toAlpha(num: number): string {
  if (num < 1) return String(num);

  let result = "";
  let remaining = num;

  while (remaining > 0) {
    remaining -= 1; // Convert to 0-based
    const char = String.fromCharCode(65 + (remaining % 26)); // A = 65
    result = char + result;
    remaining = Math.floor(remaining / 26);
  }

  return result;
}

/**
 * Convert a number to lowercase alphabetic representation
 * @param num - Number to convert
 * @returns Lowercase alphabetic string
 */
export function toAlphaLower(num: number): string {
  return toAlpha(num).toLowerCase();
}

// ============================================================================
// Formatting Functions
// ============================================================================

/**
 * Convert page number to specified format
 * @param page - Page number
 * @param format - Format type
 * @returns Formatted page string
 */
export function convertPageNumber(
  page: number,
  format: PageNumberFormat
): string {
  switch (format) {
    case "roman":
      return toRoman(page);
    case "roman-lower":
      return toRomanLower(page);
    case "alpha":
      return toAlpha(page);
    case "alpha-lower":
      return toAlphaLower(page);
    case "numeric":
    default:
      return String(page);
  }
}

/**
 * Format a page number with full configuration
 * @param page - Current page number (1-based from React-PDF)
 * @param total - Total number of pages
 * @param config - Formatting configuration
 * @returns Formatted page number string
 */
export function formatPageNumber(
  page: number,
  total: number,
  config: Partial<PageNumberConfig> = {}
): string {
  const {
    format = "numeric",
    startFrom = 1,
    prefix = "",
    suffix = "",
    showTotal = true,
    totalSeparator = " of ",
  } = config;

  // Adjust page number based on startFrom
  const adjustedPage = page - 1 + startFrom;
  const adjustedTotal = total - 1 + startFrom;

  const formattedPage = convertPageNumber(adjustedPage, format);
  const formattedTotal = convertPageNumber(adjustedTotal, format);

  let result = `${prefix}${formattedPage}`;

  if (showTotal) {
    result += `${totalSeparator}${formattedTotal}`;
  }

  result += suffix;

  return result;
}

/**
 * Format page number with "Page X of Y" style
 * @param page - Current page
 * @param total - Total pages
 * @param config - Optional configuration
 * @returns Formatted string like "Page 1 of 10"
 */
export function formatPageOfTotal(
  page: number,
  total: number,
  config: Partial<PageNumberConfig> = {}
): string {
  return formatPageNumber(page, total, {
    ...config,
    prefix: config.prefix ?? "Page ",
    showTotal: true,
  });
}

/**
 * Format page number for section numbering (e.g., "Section A", "Section I")
 * @param section - Section number
 * @param format - Format type
 * @param label - Label prefix (default: "Section ")
 * @returns Formatted section string
 */
export function formatSectionNumber(
  section: number,
  format: PageNumberFormat = "alpha",
  label: string = "Section "
): string {
  return `${label}${convertPageNumber(section, format)}`;
}

// ============================================================================
// Presets
// ============================================================================

/**
 * Common page number format presets
 */
export const pageNumberPresets = {
  /** Standard numeric: "Page 1 of 10" */
  standard: {
    format: "numeric" as PageNumberFormat,
    prefix: "Page ",
    showTotal: true,
  },

  /** Simple numeric: "1 / 10" */
  simple: {
    format: "numeric" as PageNumberFormat,
    prefix: "",
    showTotal: true,
    totalSeparator: " / ",
  },

  /** Current only: "1" */
  currentOnly: {
    format: "numeric" as PageNumberFormat,
    prefix: "",
    showTotal: false,
  },

  /** Roman numerals: "i, ii, iii..." (for front matter) */
  frontMatter: {
    format: "roman-lower" as PageNumberFormat,
    prefix: "",
    showTotal: false,
  },

  /** Roman numerals with total: "Page I of X" */
  romanFull: {
    format: "roman" as PageNumberFormat,
    prefix: "Page ",
    showTotal: true,
  },

  /** Alphabetic: "Page A of Z" */
  alphabetic: {
    format: "alpha" as PageNumberFormat,
    prefix: "Page ",
    showTotal: true,
  },

  /** Bracketed: "[1]" */
  bracketed: {
    format: "numeric" as PageNumberFormat,
    prefix: "[",
    suffix: "]",
    showTotal: false,
  },

  /** Dash style: "- 1 -" */
  dashed: {
    format: "numeric" as PageNumberFormat,
    prefix: "- ",
    suffix: " -",
    showTotal: false,
  },
} as const;

/**
 * Get a preset configuration
 * @param preset - Preset name
 * @returns Page number configuration
 */
export function getPreset(
  preset: keyof typeof pageNumberPresets
): Partial<PageNumberConfig> {
  return { ...pageNumberPresets[preset] };
}

// ============================================================================
// Validation
// ============================================================================

/**
 * Validate page number configuration
 * @param config - Configuration to validate
 * @returns Validation result with errors if any
 */
export function validateConfig(config: Partial<PageNumberConfig>): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (config.startFrom !== undefined && config.startFrom < 1) {
    errors.push("startFrom must be at least 1");
  }

  if (
    config.format &&
    !["numeric", "roman", "roman-lower", "alpha", "alpha-lower"].includes(
      config.format
    )
  ) {
    errors.push(`Invalid format: ${config.format}`);
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// ============================================================================
// Default Export
// ============================================================================

export default {
  toRoman,
  toRomanLower,
  toAlpha,
  toAlphaLower,
  convertPageNumber,
  formatPageNumber,
  formatPageOfTotal,
  formatSectionNumber,
  getPreset,
  validateConfig,
  pageNumberPresets,
  defaultPageNumberConfig,
};
