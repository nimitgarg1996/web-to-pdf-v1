/**
 * ElkFlowchartEngine
 *
 * A hybrid Elkjs + D3.js solution for generating pixel-perfect flowchart SVGs.
 *
 * Features:
 * - Elkjs handles automatic layout (node positioning, edge routing)
 * - D3.js generates clean SVG output
 * - Supports hierarchical/layered graphs (perfect for trust structures)
 * - Configurable node styles, colors, icons
 * - Edge labels (percentages, annotations)
 * - Orthogonal edge routing with rounded corners
 * - Separator lines with labels
 * - Annotation text blocks
 * - Side notes
 */

import ELK, { ElkNode, ElkExtendedEdge, LayoutOptions } from 'elkjs';
import * as d3 from 'd3';
import { JSDOM } from 'jsdom';

// ============================================================================
// Type Definitions
// ============================================================================

export interface FlowchartNode {
  id: string;
  label: string;
  type?: 'default' | 'trust' | 'gift' | 'separator' | 'annotation';
  icon?: 'building' | 'gift' | 'document' | 'none';
  color?: string;
  width?: number;
  height?: number;
  metadata?: Record<string, any>;
}

export interface FlowchartEdge {
  id: string;
  source: string;
  target: string;
  label?: string;  // e.g., "50%"
  type?: 'default' | 'orthogonal' | 'spline';
}

export interface FlowchartSeparator {
  id: string;
  label: string;
  afterNodeId: string;  // Position after this node
  style?: 'dashed' | 'solid';
}

export interface FlowchartAnnotation {
  id: string;
  lines: string[];
  position: 'left' | 'right' | 'center';
  nearNodeId: string;  // Position near this node
  offsetX?: number;
  offsetY?: number;
}

export interface FlowchartSideNote {
  id: string;
  lines: string[];
  position: { x: number; y: number };
}

export interface FlowchartConfig {
  width?: number;
  height?: number;
  padding?: number;
  nodeSpacing?: number;  // Horizontal spacing between nodes
  layerSpacing?: number; // Vertical spacing between layers
  edgeStyle?: 'orthogonal' | 'spline' | 'polyline';
  direction?: 'DOWN' | 'RIGHT' | 'UP' | 'LEFT';
  colors?: {
    line?: string;
    text?: string;
    muted?: string;
    background?: string;
    separator?: string;
  };
  fonts?: {
    family?: string;
    labelSize?: number;
    edgeLabelSize?: number;
    annotationSize?: number;
  };
}

export interface LayoutResult {
  svg: string;
  width: number;
  height: number;
}

export interface FlowchartData {
  nodes: FlowchartNode[];
  edges: FlowchartEdge[];
  separators?: FlowchartSeparator[];
  annotations?: FlowchartAnnotation[];
  sideNotes?: FlowchartSideNote[];
}

// ============================================================================
// Default Configuration
// ============================================================================

const DEFAULT_CONFIG: FlowchartConfig = {
  width: 600,
  height: 700,
  padding: 40,
  nodeSpacing: 50,
  layerSpacing: 100,
  edgeStyle: 'orthogonal',
  direction: 'DOWN',
  colors: {
    line: '#C9CDD3',
    text: '#374151',
    muted: '#6B7280',
    background: 'white',
    separator: '#9CA3AF',
  },
  fonts: {
    family: 'Inter, -apple-system, sans-serif',
    labelSize: 11,
    edgeLabelSize: 10,
    annotationSize: 10,
  },
};

const DEFAULT_NODE_COLORS: Record<string, string> = {
  trust: '#2D9B9B',
  gift: '#FF8A65',
  survivor: '#A78BFA',
  bypass: '#60A5FA',
  marital: '#5AB2B2',
  child: '#2D7B7B',
  default: '#6B7280',
};

// ============================================================================
// SVG Icons
// ============================================================================

const ICONS: Record<string, string> = {
  building: `<g transform="scale(0.9)"><path d="M12 2L3 9v13h18V9L12 2z" fill="white"/><rect x="7" y="12" width="3" height="3" fill="currentColor" opacity="0.5"/><rect x="11" y="12" width="3" height="3" fill="currentColor" opacity="0.5"/><rect x="9" y="17" width="4" height="5" fill="currentColor" opacity="0.5"/></g>`,
  gift: `<g transform="scale(0.85)"><rect x="4" y="11" width="16" height="9" rx="1" fill="white"/><rect x="3" y="8" width="18" height="4" rx="1" fill="white"/><line x1="12" y1="8" x2="12" y2="20" stroke="currentColor" stroke-width="2.5"/></g>`,
  document: `<g transform="scale(0.85)"><rect x="5" y="2" width="14" height="18" rx="1.5" fill="white"/><rect x="7" y="6" width="10" height="2.5" rx="1" fill="currentColor" opacity="0.3"/><rect x="7" y="10" width="10" height="2.5" rx="1" fill="currentColor" opacity="0.3"/><rect x="7" y="14" width="6" height="2.5" rx="1" fill="currentColor" opacity="0.3"/></g>`,
};

// ============================================================================
// Elk Flowchart Engine Class
// ============================================================================

export class ElkFlowchartEngine {
  private elk: ELK;
  private config: FlowchartConfig;

  constructor(config: Partial<FlowchartConfig> = {}) {
    this.elk = new ELK();
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Generate SVG from nodes and edges (simple API)
   */
  async generateSVG(
    nodes: FlowchartNode[],
    edges: FlowchartEdge[]
  ): Promise<LayoutResult> {
    return this.generateFlowchart({ nodes, edges });
  }

  /**
   * Generate SVG from complete flowchart data (with separators, annotations, etc.)
   */
  async generateFlowchart(data: FlowchartData): Promise<LayoutResult> {
    const { nodes, edges, separators, annotations, sideNotes } = data;
    
    // Build ELK graph
    const elkGraph = this.buildElkGraph(nodes, edges);
    
    // Run ELK layout algorithm
    const layoutedGraph = await this.elk.layout(elkGraph);
    
    // Generate SVG using D3
    const svg = this.renderSVG(layoutedGraph, nodes, edges, separators, annotations, sideNotes);
    
    return {
      svg,
      width: layoutedGraph.width || this.config.width!,
      height: layoutedGraph.height || this.config.height!,
    };
  }

  /**
   * Build ELK graph structure from flowchart nodes/edges
   */
  private buildElkGraph(
    nodes: FlowchartNode[],
    edges: FlowchartEdge[]
  ): ElkNode {
    const layoutOptions: LayoutOptions = {
      'elk.algorithm': 'layered',
      'elk.direction': this.config.direction,
      'elk.spacing.nodeNode': String(this.config.nodeSpacing),
      'elk.layered.spacing.nodeNodeBetweenLayers': String(this.config.layerSpacing),
      'elk.edgeRouting': this.config.edgeStyle === 'orthogonal' ? 'ORTHOGONAL' : 'SPLINES',
      'elk.layered.nodePlacement.strategy': 'NETWORK_SIMPLEX',
      'elk.layered.crossingMinimization.strategy': 'LAYER_SWEEP',
    };

    // Convert to ELK nodes
    const elkNodes: ElkNode[] = nodes.map((node) => ({
      id: node.id,
      width: node.width || 80,
      height: node.height || 55,
      labels: [{ text: node.label }],
    }));

    // Convert to ELK edges
    const elkEdges: ElkExtendedEdge[] = edges.map((edge) => ({
      id: edge.id,
      sources: [edge.source],
      targets: [edge.target],
      labels: edge.label ? [{ text: edge.label }] : [],
    }));

    return {
      id: 'root',
      layoutOptions,
      children: elkNodes,
      edges: elkEdges,
    };
  }

  /**
   * Render SVG using D3
   */
  private renderSVG(
    graph: ElkNode,
    originalNodes: FlowchartNode[],
    originalEdges: FlowchartEdge[],
    separators?: FlowchartSeparator[],
    annotations?: FlowchartAnnotation[],
    sideNotes?: FlowchartSideNote[]
  ): string {
    // Create virtual DOM for D3
    const dom = new JSDOM('<!DOCTYPE html><html><body></body></html>');
    const document = dom.window.document;

    // Create SVG container
    const width = graph.width || this.config.width!;
    const height = graph.height || this.config.height!;
    const padding = this.config.padding!;

    const svg = d3.select(document.body)
      .append('svg')
      .attr('xmlns', 'http://www.w3.org/2000/svg')
      .attr('viewBox', `${-padding} ${-padding} ${width + padding * 2} ${height + padding * 2}`)
      .attr('style', `font-family: ${this.config.fonts?.family}; background: ${this.config.colors?.background}`);

    // Add defs for markers
    const defs = svg.append('defs');
    
    // Arrow marker
    defs.append('marker')
      .attr('id', 'arrowhead')
      .attr('markerWidth', 10)
      .attr('markerHeight', 7)
      .attr('refX', 9)
      .attr('refY', 3.5)
      .attr('orient', 'auto')
      .append('polygon')
      .attr('points', '0 0, 10 3.5, 0 7')
      .attr('fill', this.config.colors?.line);

    // Build position map for annotations and separators
    const nodePositions = this.buildNodePositionMap(graph);

    // Render edges first (so nodes are on top)
    this.renderEdges(svg, graph, originalEdges);

    // Render separators
    if (separators?.length) {
      this.renderSeparators(svg, separators, nodePositions, width);
    }

    // Render annotations
    if (annotations?.length) {
      this.renderAnnotations(svg, annotations, nodePositions);
    }

    // Render nodes
    this.renderNodes(svg, graph, originalNodes);

    // Render side notes
    if (sideNotes?.length) {
      this.renderSideNotes(svg, sideNotes);
    }

    return document.body.innerHTML;
  }

  /**
   * Build a map of node ID to position
   */
  private buildNodePositionMap(graph: ElkNode): Map<string, { x: number; y: number; width: number; height: number }> {
    const map = new Map();
    if (graph.children) {
      for (const node of graph.children) {
        map.set(node.id, {
          x: (node.x || 0) + (node.width || 0) / 2,
          y: (node.y || 0) + (node.height || 0) / 2,
          width: node.width || 80,
          height: node.height || 55,
        });
      }
    }
    return map;
  }

  /**
   * Render separator lines with labels
   */
  private renderSeparators(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    separators: FlowchartSeparator[],
    nodePositions: Map<string, { x: number; y: number; width: number; height: number }>,
    totalWidth: number
  ): void {
    const separatorGroup = svg.append('g').attr('class', 'separators');
    const separatorColor = this.config.colors?.separator || '#9CA3AF';
    const lineColor = this.config.colors?.line || '#C9CDD3';
    
    for (const sep of separators) {
      const nodePos = nodePositions.get(sep.afterNodeId);
      if (!nodePos) continue;
      
      // Position separator below the reference node
      const y = nodePos.y + nodePos.height / 2 + 30;
      const gapWidth = 80; // Gap for text
      const centerX = totalWidth / 2;
      
      // Left dashed line
      separatorGroup.append('line')
        .attr('x1', 20)
        .attr('y1', y)
        .attr('x2', centerX - gapWidth)
        .attr('y2', y)
        .attr('stroke', lineColor)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', sep.style === 'solid' ? 'none' : '6,4');
      
      // Right dashed line
      separatorGroup.append('line')
        .attr('x1', centerX + gapWidth)
        .attr('y1', y)
        .attr('x2', totalWidth - 20)
        .attr('y2', y)
        .attr('stroke', lineColor)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', sep.style === 'solid' ? 'none' : '6,4');
      
      // Label text
      separatorGroup.append('text')
        .attr('x', centerX)
        .attr('y', y + 4)
        .attr('text-anchor', 'middle')
        .attr('font-size', 11)
        .attr('fill', separatorColor)
        .text(sep.label);
    }
  }

  /**
   * Render annotation text blocks
   */
  private renderAnnotations(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    annotations: FlowchartAnnotation[],
    nodePositions: Map<string, { x: number; y: number; width: number; height: number }>
  ): void {
    const annotGroup = svg.append('g').attr('class', 'annotations');
    const mutedColor = this.config.colors?.muted || '#6B7280';
    const fontSize = this.config.fonts?.annotationSize || 10;
    
    for (const annot of annotations) {
      const nodePos = nodePositions.get(annot.nearNodeId);
      if (!nodePos) continue;
      
      // Calculate position based on alignment
      let x = nodePos.x + (annot.offsetX || 0);
      const y = nodePos.y - nodePos.height / 2 - 30 + (annot.offsetY || 0);
      
      let anchor: string;
      switch (annot.position) {
        case 'left':
          x -= 60;
          anchor = 'end';
          break;
        case 'right':
          x += 60;
          anchor = 'start';
          break;
        default:
          anchor = 'middle';
      }
      
      // Render each line
      annot.lines.forEach((line, i) => {
        annotGroup.append('text')
          .attr('x', x)
          .attr('y', y + i * (fontSize + 5))
          .attr('text-anchor', anchor)
          .attr('font-size', fontSize)
          .attr('fill', mutedColor)
          .text(line);
      });
    }
  }

  /**
   * Render side notes
   */
  private renderSideNotes(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    sideNotes: FlowchartSideNote[]
  ): void {
    const noteGroup = svg.append('g').attr('class', 'side-notes');
    const mutedColor = this.config.colors?.muted || '#6B7280';
    
    for (const note of sideNotes) {
      note.lines.forEach((line, i) => {
        noteGroup.append('text')
          .attr('x', note.position.x)
          .attr('y', note.position.y + i * 12)
          .attr('font-size', 9)
          .attr('fill', mutedColor)
          .text(line);
      });
    }
  }

  /**
   * Render edges with D3
   */
  private renderEdges(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    graph: ElkNode,
    originalEdges: FlowchartEdge[]
  ): void {
    if (!graph.edges) return;

    const edgeGroup = svg.append('g').attr('class', 'edges');
    const lineColor = this.config.colors?.line!;

    for (const edge of graph.edges) {
      const originalEdge = originalEdges.find((e) => e.id === edge.id);
      
      // Get edge sections (ELK provides routed points)
      if (edge.sections && edge.sections.length > 0) {
        const section = edge.sections[0];
        const points = [
          section.startPoint,
          ...(section.bendPoints || []),
          section.endPoint,
        ];

        // Draw path
        const pathData = this.createEdgePath(points);
        edgeGroup.append('path')
          .attr('d', pathData)
          .attr('fill', 'none')
          .attr('stroke', lineColor)
          .attr('stroke-width', 2)
          .attr('marker-end', 'url(#arrowhead)');

        // Draw edge label (e.g., "50%")
        if (originalEdge?.label && edge.labels && edge.labels.length > 0) {
          const labelPos = edge.labels[0];
          if (labelPos.x !== undefined && labelPos.y !== undefined) {
            // Badge background
            edgeGroup.append('rect')
              .attr('x', labelPos.x - 20)
              .attr('y', labelPos.y - 10)
              .attr('width', 40)
              .attr('height', 20)
              .attr('rx', 10)
              .attr('fill', 'white')
              .attr('stroke', '#E5E7EB');

            // Badge text
            edgeGroup.append('text')
              .attr('x', labelPos.x)
              .attr('y', labelPos.y + 4)
              .attr('text-anchor', 'middle')
              .attr('font-size', this.config.fonts?.edgeLabelSize)
              .attr('fill', this.config.colors?.muted)
              .text(originalEdge.label);
          }
        }
      }
    }
  }

  /**
   * Create SVG path from points with optional rounded corners
   */
  private createEdgePath(points: { x: number; y: number }[]): string {
    if (points.length < 2) return '';

    const radius = 8; // Corner radius
    let d = `M ${points[0].x},${points[0].y}`;

    for (let i = 1; i < points.length - 1; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const next = points[i + 1];

      // Calculate directions
      const dx1 = curr.x - prev.x;
      const dy1 = curr.y - prev.y;
      const dx2 = next.x - curr.x;
      const dy2 = next.y - curr.y;

      // Normalize directions
      const len1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);
      const len2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);

      if (len1 === 0 || len2 === 0) {
        d += ` L ${curr.x},${curr.y}`;
        continue;
      }

      // Calculate the corner radius (don't exceed half the segment length)
      const r = Math.min(radius, len1 / 2, len2 / 2);

      // Points before and after the corner
      const x1 = curr.x - (dx1 / len1) * r;
      const y1 = curr.y - (dy1 / len1) * r;
      const x2 = curr.x + (dx2 / len2) * r;
      const y2 = curr.y + (dy2 / len2) * r;

      // Line to start of curve, then quadratic curve through corner
      d += ` L ${x1},${y1}`;
      d += ` Q ${curr.x},${curr.y} ${x2},${y2}`;
    }

    // Final segment
    const last = points[points.length - 1];
    d += ` L ${last.x},${last.y}`;

    return d;
  }

  /**
   * Render nodes with D3
   */
  private renderNodes(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    graph: ElkNode,
    originalNodes: FlowchartNode[]
  ): void {
    if (!graph.children) return;

    const nodeGroup = svg.append('g').attr('class', 'nodes');

    for (const elkNode of graph.children) {
      const original = originalNodes.find((n) => n.id === elkNode.id);
      if (!original) continue;

      const x = elkNode.x || 0;
      const y = elkNode.y || 0;
      const w = elkNode.width || 80;
      const h = elkNode.height || 55;
      const cx = x + w / 2;
      const cy = y + h / 2;

      // Determine color
      const color = original.color || DEFAULT_NODE_COLORS[original.type || 'default'];

      // Node group
      const g = nodeGroup.append('g')
        .attr('transform', `translate(${cx}, ${cy})`);

      // Rectangle
      g.append('rect')
        .attr('x', -w / 2)
        .attr('y', -h / 2)
        .attr('width', w)
        .attr('height', h)
        .attr('rx', 12)
        .attr('fill', color);

      // Icon
      const icon = original.icon ? ICONS[original.icon] : ICONS.document;
      g.append('g')
        .attr('transform', 'translate(-12, -12)')
        .attr('color', color)
        .html(icon);

      // Label
      g.append('text')
        .attr('y', h / 2 + 15)
        .attr('text-anchor', 'middle')
        .attr('font-size', this.config.fonts?.labelSize)
        .attr('font-weight', '500')
        .attr('fill', this.config.colors?.text)
        .text(original.label);
    }
  }
}

// ============================================================================
// Helper: Create Trust Structure Graph (with all features)
// ============================================================================

export function createTrustStructureGraph(): FlowchartData {
  const nodes: FlowchartNode[] = [
    { id: 'root', label: 'Doe-Smith Revocable Trust', type: 'trust', icon: 'building', color: '#2D9B9B' },
    { id: 'gift1', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 65, height: 50 },
    { id: 'survivor', label: "Survivor's Trust", type: 'trust', icon: 'document', color: '#A78BFA' },
    { id: 'bypass', label: 'Bypass Trust', type: 'trust', icon: 'document', color: '#60A5FA' },
    { id: 'marital', label: 'Marital Trust', type: 'trust', icon: 'document', color: '#5AB2B2' },
    { id: 'gift2', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 65, height: 50 },
    { id: 'jane', label: 'Jane Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B' },
    { id: 'john', label: 'John Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B' },
  ];

  const edges: FlowchartEdge[] = [
    { id: 'e1', source: 'root', target: 'gift1' },
    { id: 'e2', source: 'root', target: 'survivor' },
    { id: 'e3', source: 'root', target: 'bypass' },
    { id: 'e4', source: 'root', target: 'marital' },
    { id: 'e5', source: 'bypass', target: 'gift2' },
    { id: 'e6', source: 'bypass', target: 'jane', label: '50%' },
    { id: 'e7', source: 'bypass', target: 'john', label: '50%' },
  ];

  const separators: FlowchartSeparator[] = [
    { id: 'sep1', label: 'Death of First Spouse', afterNodeId: 'root', style: 'dashed' },
    { id: 'sep2', label: 'Death of Surviving Spouse', afterNodeId: 'bypass', style: 'dashed' },
  ];

  const annotations: FlowchartAnnotation[] = [
    {
      id: 'annot1',
      lines: ["Surviving Spouse's Separate", "Property and Share of Marital Property"],
      position: 'left',
      nearNodeId: 'survivor',
      offsetY: -20
    },
    {
      id: 'annot2',
      lines: ["Deceased Spouse's Separate Property", "and Share of Marital Property"],
      position: 'right',
      nearNodeId: 'marital',
      offsetY: -20
    },
  ];

  const sideNotes: FlowchartSideNote[] = [
    {
      id: 'note1',
      lines: [
        "If a child of the Grantors has",
        "not yet attained 21 years of",
        "age, trust assets will be held",
        "in a pot trust for the benefit of",
        "the Grantors' descendants",
        "until such time as the",
        "youngest living child of the",
        "Grantors attains age 21."
      ],
      position: { x: 20, y: 480 }
    }
  ];

  return { nodes, edges, separators, annotations, sideNotes };
}

/**
 * Create simple trust structure (nodes and edges only)
 */
export function createSimpleTrustStructure(): { nodes: FlowchartNode[]; edges: FlowchartEdge[] } {
  const full = createTrustStructureGraph();
  return { nodes: full.nodes, edges: full.edges };
}

// Export singleton
export const elkFlowchartEngine = new ElkFlowchartEngine();

// ============================================================================
// Integration Helper for PuppeteerPdfService
// ============================================================================

/**
 * Generate trust structure SVG for PDF embedding
 * This can be used directly in PuppeteerPdfService.renderTrustStructurePage()
 */
export async function generateTrustStructureSVGForPdf(
  trustData?: FlowchartData,
  config?: Partial<FlowchartConfig>
): Promise<string> {
  const engine = new ElkFlowchartEngine({
    width: 580,
    height: 700,
    padding: 20,
    nodeSpacing: 40,
    layerSpacing: 80,
    ...config
  });
  
  const data = trustData || createTrustStructureGraph();
  const result = await engine.generateFlowchart(data);
  
  return result.svg;
}
