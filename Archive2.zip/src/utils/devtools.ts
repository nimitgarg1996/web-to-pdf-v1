/**
 * Developer Tools Utilities
 * Debugging, profiling, and analysis tools for PDF development
 */

import type {
  Blueprint,
  ContentBlock,
  ValidationResult,
  ValidationWarning,
} from "../blueprints/types.js";
import { analyzeContent, estimatePageCount } from "./preview.js";

// ============================================================================
// Types
// ============================================================================

/**
 * Blueprint statistics
 */
export interface BlueprintStats {
  /** Blueprint type */
  type: string;
  /** Total content blocks */
  blocks: number;
  /** Number of tables */
  tables: number;
  /** Number of diagrams */
  diagrams: number;
  /** Number of images */
  images: number;
  /** Number of headings */
  headings: number;
  /** Estimated page count */
  estimatedPages: number;
  /** Has nested sections */
  hasNestedSections: boolean;
  /** Maximum nesting depth */
  maxNestingDepth: number;
}

/**
 * Performance timing information
 */
export interface PerformanceTiming {
  /** Operation name */
  operation: string;
  /** Duration in milliseconds */
  duration: number;
  /** Start timestamp */
  startTime: number;
  /** End timestamp */
  endTime: number;
}

/**
 * Debug information structure
 */
export interface DebugInfo {
  /** Blueprint analysis */
  blueprint: {
    type: string;
    blockCount: number;
    estimatedPages: number;
  };
  /** Performance metrics */
  performance: {
    validationTime: number;
    factoryTime: number;
    renderTime: number;
    totalTime: number;
  };
  /** Warnings found */
  warnings: string[];
  /** Suggestions for improvement */
  suggestions: string[];
}

/**
 * Analysis result with warnings and suggestions
 */
export interface AnalysisResult {
  /** Warnings about potential issues */
  warnings: string[];
  /** Suggestions for improvement */
  suggestions: string[];
  /** Statistics about the blueprint */
  stats: BlueprintStats;
}

/**
 * Timer result from timing wrapper
 */
export interface TimerResult<T> {
  /** Function result */
  result: T;
  /** Time taken in milliseconds */
  time: number;
}

// ============================================================================
// Performance Timing
// ============================================================================

/**
 * Performance timing wrapper for synchronous functions
 * @param fn - Function to time
 * @returns Result and timing
 */
export function withTiming<T>(fn: () => T): TimerResult<T> {
  const start = performance.now();
  const result = fn();
  const time = performance.now() - start;
  return { result, time };
}

/**
 * Performance timing wrapper for async functions
 * @param fn - Async function to time
 * @returns Promise of result and timing
 */
export async function withTimingAsync<T>(
  fn: () => Promise<T>
): Promise<TimerResult<T>> {
  const start = performance.now();
  const result = await fn();
  const time = performance.now() - start;
  return { result, time };
}

/**
 * Create a timing tracker for multiple operations
 */
export function createTimingTracker(): {
  start: (operation: string) => void;
  end: (operation: string) => void;
  getTimings: () => PerformanceTiming[];
  getTotalTime: () => number;
  clear: () => void;
} {
  const timings: Map<string, { start: number; end?: number }> = new Map();
  const completed: PerformanceTiming[] = [];

  return {
    start(operation: string) {
      timings.set(operation, { start: performance.now() });
    },
    end(operation: string) {
      const timing = timings.get(operation);
      if (timing && timing.start !== undefined) {
        const endTime = performance.now();
        completed.push({
          operation,
          duration: endTime - timing.start,
          startTime: timing.start,
          endTime,
        });
        timings.delete(operation);
      }
    },
    getTimings() {
      return [...completed];
    },
    getTotalTime() {
      return completed.reduce((sum, t) => sum + t.duration, 0);
    },
    clear() {
      timings.clear();
      completed.length = 0;
    },
  };
}

// ============================================================================
// Blueprint Analysis
// ============================================================================

/**
 * Get content blocks from blueprint
 * @param blueprint - Blueprint to extract content from
 * @returns Array of content blocks
 */
function getBlueprintBlocks(blueprint: Blueprint): ContentBlock[] {
  switch (blueprint.type) {
    case "report":
      return blueprint.content.sections || [];
    case "dashboard":
      const dashboardBlocks: ContentBlock[] = [];
      if (blueprint.content.tables) {
        dashboardBlocks.push(...blueprint.content.tables);
      }
      if (blueprint.content.charts) {
        dashboardBlocks.push(...blueprint.content.charts);
      }
      return dashboardBlocks;
    case "data-table":
      return [];
    case "invoice":
      return [];
    default:
      return [];
  }
}

/**
 * Calculate maximum nesting depth of content blocks
 * @param blocks - Content blocks to analyze
 * @param currentDepth - Current depth level
 * @returns Maximum depth found
 */
function calculateMaxDepth(
  blocks: ContentBlock[],
  currentDepth: number = 1
): number {
  let maxDepth = currentDepth;

  for (const block of blocks) {
    if (block.type === "section" && block.children) {
      const childDepth = calculateMaxDepth(block.children, currentDepth + 1);
      maxDepth = Math.max(maxDepth, childDepth);
    }
  }

  return maxDepth;
}

/**
 * Check if blueprint has nested sections
 * @param blocks - Content blocks to check
 * @returns True if nested sections found
 */
function hasNestedSections(blocks: ContentBlock[]): boolean {
  for (const block of blocks) {
    if (block.type === "section" && block.children) {
      for (const child of block.children) {
        if (child.type === "section") {
          return true;
        }
      }
    }
  }
  return false;
}

/**
 * Analyze blueprint for potential issues and gather statistics
 * @param blueprint - Blueprint to analyze
 * @returns Analysis result with warnings, suggestions, and stats
 */
export function analyzeBlueprint(blueprint: Blueprint): AnalysisResult {
  const warnings: string[] = [];
  const suggestions: string[] = [];

  const blocks = getBlueprintBlocks(blueprint);
  const contentAnalysis = analyzeContent(blocks);
  const pageEstimate = estimatePageCount(contentAnalysis);

  // Build stats
  const stats: BlueprintStats = {
    type: blueprint.type,
    blocks: contentAnalysis.blockCount,
    tables: contentAnalysis.tableCount,
    diagrams: contentAnalysis.diagramCount,
    images: contentAnalysis.imageCount,
    headings: contentAnalysis.headingCount,
    estimatedPages: pageEstimate.estimatedPages,
    hasNestedSections: hasNestedSections(blocks),
    maxNestingDepth: calculateMaxDepth(blocks),
  };

  // Check for potential issues
  if (!blueprint.metadata.title) {
    warnings.push("Blueprint is missing a title");
  }

  if (contentAnalysis.blockCount === 0) {
    warnings.push("Blueprint has no content blocks");
  }

  if (contentAnalysis.totalTableRows > 100) {
    warnings.push(
      `Large table detected (${contentAnalysis.totalTableRows} rows) - may impact performance`
    );
    suggestions.push(
      "Consider paginating large tables or using data-table template"
    );
  }

  if (contentAnalysis.diagramCount > 5) {
    warnings.push(
      `Multiple diagrams (${contentAnalysis.diagramCount}) may increase render time`
    );
  }

  if (contentAnalysis.imageCount > 10) {
    warnings.push(
      `Many images (${contentAnalysis.imageCount}) may increase file size`
    );
    suggestions.push("Consider optimizing images before including in PDF");
  }

  if (stats.maxNestingDepth > 4) {
    warnings.push(`Deep nesting detected (${stats.maxNestingDepth} levels)`);
    suggestions.push("Consider flattening deeply nested content");
  }

  if (contentAnalysis.headingCount === 0 && blueprint.type === "report") {
    suggestions.push("Consider adding headings for better document structure");
  }

  if (pageEstimate.estimatedPages > 50) {
    suggestions.push(
      "Large document - consider adding a table of contents"
    );
  }

  // Type-specific checks
  if (blueprint.type === "report") {
    if (!blueprint.content.showCover && pageEstimate.estimatedPages > 10) {
      suggestions.push("Consider adding a cover page for longer reports");
    }
    if (!blueprint.content.showToc && pageEstimate.estimatedPages > 5) {
      suggestions.push(
        "Consider adding a table of contents for documents with 5+ pages"
      );
    }
  }

  if (blueprint.type === "invoice") {
    if (blueprint.content.lineItems.length === 0) {
      warnings.push("Invoice has no line items");
    }
    if (!blueprint.content.total) {
      warnings.push("Invoice is missing total amount");
    }
  }

  return { warnings, suggestions, stats };
}

// ============================================================================
// Debug Formatting
// ============================================================================

/**
 * Format blueprint for debugging output
 * @param blueprint - Blueprint to format
 * @param options - Formatting options
 * @returns Formatted string representation
 */
export function formatBlueprint(
  blueprint: Blueprint,
  options: {
    indent?: number;
    maxDepth?: number;
    highlightKeys?: string[];
  } = {}
): string {
  const { indent = 2, maxDepth = 5, highlightKeys = [] } = options;

  function formatValue(value: unknown, depth: number, key?: string): string {
    if (depth > maxDepth) {
      return "[...]";
    }

    const prefix = highlightKeys.includes(key || "") ? ">>> " : "";

    if (value === null) return `${prefix}null`;
    if (value === undefined) return `${prefix}undefined`;

    if (typeof value === "string") {
      const truncated =
        value.length > 100 ? `${value.substring(0, 100)}...` : value;
      return `${prefix}"${truncated}"`;
    }

    if (typeof value === "number" || typeof value === "boolean") {
      return `${prefix}${value}`;
    }

    if (Array.isArray(value)) {
      if (value.length === 0) return `${prefix}[]`;
      if (value.length > 10) {
        return `${prefix}[Array(${value.length})]`;
      }
      const items = value
        .map((v) => formatValue(v, depth + 1))
        .join(",\n" + " ".repeat((depth + 1) * indent));
      return `${prefix}[\n${" ".repeat((depth + 1) * indent)}${items}\n${" ".repeat(depth * indent)}]`;
    }

    if (typeof value === "object") {
      const entries = Object.entries(value as Record<string, unknown>);
      if (entries.length === 0) return `${prefix}{}`;

      const formatted = entries
        .map(
          ([k, v]) =>
            `${" ".repeat((depth + 1) * indent)}${k}: ${formatValue(v, depth + 1, k)}`
        )
        .join(",\n");
      return `${prefix}{\n${formatted}\n${" ".repeat(depth * indent)}}`;
    }

    return `${prefix}${String(value)}`;
  }

  return formatValue(blueprint, 0);
}

/**
 * Create a summary string for a blueprint
 * @param blueprint - Blueprint to summarize
 * @returns Summary string
 */
export function summarizeBlueprint(blueprint: Blueprint): string {
  const analysis = analyzeBlueprint(blueprint);
  const lines: string[] = [
    `Blueprint Summary: ${blueprint.metadata.title || "Untitled"}`,
    `─────────────────────────────────────`,
    `Type: ${blueprint.type}`,
    `Version: ${blueprint.version}`,
    ``,
    `Content Statistics:`,
    `  • Blocks: ${analysis.stats.blocks}`,
    `  • Headings: ${analysis.stats.headings}`,
    `  • Tables: ${analysis.stats.tables}`,
    `  • Diagrams: ${analysis.stats.diagrams}`,
    `  • Images: ${analysis.stats.images}`,
    `  • Estimated Pages: ${analysis.stats.estimatedPages}`,
    ``,
  ];

  if (analysis.warnings.length > 0) {
    lines.push(`Warnings (${analysis.warnings.length}):`);
    analysis.warnings.forEach((w) => lines.push(`  ⚠ ${w}`));
    lines.push(``);
  }

  if (analysis.suggestions.length > 0) {
    lines.push(`Suggestions (${analysis.suggestions.length}):`);
    analysis.suggestions.forEach((s) => lines.push(`  💡 ${s}`));
  }

  return lines.join("\n");
}

// ============================================================================
// Debug Info Generation
// ============================================================================

/**
 * Generate debug info for a blueprint
 * @param blueprint - Blueprint to analyze
 * @param timings - Optional performance timings
 * @returns Debug information
 */
export function generateDebugInfo(
  blueprint: Blueprint,
  timings?: {
    validation?: number;
    factory?: number;
    render?: number;
  }
): DebugInfo {
  const analysis = analyzeBlueprint(blueprint);

  return {
    blueprint: {
      type: blueprint.type,
      blockCount: analysis.stats.blocks,
      estimatedPages: analysis.stats.estimatedPages,
    },
    performance: {
      validationTime: timings?.validation ?? 0,
      factoryTime: timings?.factory ?? 0,
      renderTime: timings?.render ?? 0,
      totalTime:
        (timings?.validation ?? 0) +
        (timings?.factory ?? 0) +
        (timings?.render ?? 0),
    },
    warnings: analysis.warnings,
    suggestions: analysis.suggestions,
  };
}

// ============================================================================
// Validation Helpers
// ============================================================================

/**
 * Format validation result for display
 * @param result - Validation result to format
 * @returns Formatted string
 */
export function formatValidationResult(result: ValidationResult): string {
  const lines: string[] = [];

  if (result.valid) {
    lines.push("✓ Blueprint is valid");
  } else {
    lines.push("✗ Blueprint validation failed");
  }

  if (result.errors.length > 0) {
    lines.push(`\nErrors (${result.errors.length}):`);
    result.errors.forEach((e) => {
      lines.push(`  • [${e.path}] ${e.message} (${e.code})`);
    });
  }

  if (result.warnings.length > 0) {
    lines.push(`\nWarnings (${result.warnings.length}):`);
    result.warnings.forEach((w) => {
      lines.push(`  • [${w.path}] ${w.message}`);
      if (w.suggestion) {
        lines.push(`    Suggestion: ${w.suggestion}`);
      }
    });
  }

  return lines.join("\n");
}

// ============================================================================
// Console Helpers
// ============================================================================

/**
 * Log blueprint debug info to console
 * @param blueprint - Blueprint to debug
 * @param label - Optional label for the log
 */
export function debugLog(blueprint: Blueprint, label?: string): void {
  const prefix = label ? `[${label}] ` : "";
  console.log(`${prefix}Blueprint Debug Info:`);
  console.log(summarizeBlueprint(blueprint));
}

/**
 * Log performance timings to console
 * @param timings - Timing array from tracker
 */
export function logTimings(timings: PerformanceTiming[]): void {
  console.log("Performance Timings:");
  console.log("────────────────────");
  timings.forEach((t) => {
    console.log(`  ${t.operation}: ${t.duration.toFixed(2)}ms`);
  });
  const total = timings.reduce((sum, t) => sum + t.duration, 0);
  console.log(`────────────────────`);
  console.log(`  Total: ${total.toFixed(2)}ms`);
}

// ============================================================================
// Environment Check
// ============================================================================

/**
 * Check if running in development mode
 * @returns True if in development mode
 */
export function isDevelopment(): boolean {
  return (
    process.env.NODE_ENV === "development" ||
    process.env.PDF_DEBUG === "true"
  );
}

/**
 * Only execute in development mode
 * @param fn - Function to execute in development
 */
export function devOnly(fn: () => void): void {
  if (isDevelopment()) {
    fn();
  }
}

// ============================================================================
// Default Export
// ============================================================================

export default {
  withTiming,
  withTimingAsync,
  createTimingTracker,
  analyzeBlueprint,
  formatBlueprint,
  summarizeBlueprint,
  generateDebugInfo,
  formatValidationResult,
  debugLog,
  logTimings,
  isDevelopment,
  devOnly,
};
