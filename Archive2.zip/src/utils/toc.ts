/**
 * Table of Contents Utilities
 * Extract and build TOC from blueprint content
 */

import type {
  Blueprint,
  ContentBlock,
  HeadingBlock,
  SectionBlock,
  isHeadingBlock,
  isSectionBlock,
} from "../blueprints/types.js";

// ============================================================================
// Types
// ============================================================================

/**
 * Single entry in the table of contents
 */
export interface TocEntry {
  /** Unique identifier for the entry */
  id: string;
  /** Heading text/title */
  title: string;
  /** Heading level (1-4) */
  level: number;
  /** Page number (calculated after render) */
  pageNumber?: number;
  /** Child entries for nested structure */
  children?: TocEntry[];
}

/**
 * Configuration for TOC generation
 */
export interface TocConfig {
  /** Maximum heading depth to include (default: 3) */
  maxDepth?: number;
  /** Include page numbers (default: true) */
  includePageNumbers?: boolean;
  /** TOC title (default: "Table of Contents") */
  title?: string;
  /** Custom ID prefix for generated IDs */
  idPrefix?: string;
}

/**
 * Result of TOC extraction
 */
export interface TocResult {
  /** Flat list of TOC entries */
  entries: TocEntry[];
  /** Nested tree structure */
  tree: TocEntry[];
  /** Total heading count */
  headingCount: number;
}

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Generate a URL-safe slug from text
 * @param text - Text to slugify
 * @returns URL-safe slug
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "") // Remove special characters
    .replace(/[\s_-]+/g, "-") // Replace spaces and underscores with hyphens
    .replace(/^-+|-+$/g, ""); // Remove leading/trailing hyphens
}

/**
 * Generate a unique ID for a heading
 * @param text - Heading text
 * @param index - Index for uniqueness
 * @param prefix - Optional prefix
 * @returns Unique heading ID
 */
export function generateHeadingId(
  text: string,
  index: number,
  prefix: string = "heading"
): string {
  const slug = slugify(text);
  const baseId = slug || `${prefix}-${index}`;
  return `${prefix}-${index}-${baseId}`;
}

/**
 * Check if a content block is a heading block
 */
function isHeading(block: ContentBlock): block is HeadingBlock {
  return block.type === "heading";
}

/**
 * Check if a content block is a section block
 */
function isSection(block: ContentBlock): block is SectionBlock {
  return block.type === "section";
}

// ============================================================================
// TOC Extraction
// ============================================================================

/**
 * Extract TOC entries from an array of content blocks
 * @param blocks - Content blocks to scan
 * @param config - TOC configuration
 * @param startIndex - Starting index for ID generation
 * @returns Array of TOC entries
 */
function extractFromBlocks(
  blocks: ContentBlock[],
  config: TocConfig,
  startIndex: number = 0
): TocEntry[] {
  const entries: TocEntry[] = [];
  const maxDepth = config.maxDepth ?? 3;
  const idPrefix = config.idPrefix ?? "toc";
  let currentIndex = startIndex;

  for (const block of blocks) {
    if (isHeading(block) && block.level <= maxDepth) {
      const id = block.id || generateHeadingId(block.text, currentIndex, idPrefix);
      entries.push({
        id,
        title: block.text,
        level: block.level,
        pageNumber: undefined,
      });
      currentIndex++;
    }

    // Recursively scan section children
    if (isSection(block) && block.children) {
      const childEntries = extractFromBlocks(
        block.children,
        config,
        currentIndex
      );
      entries.push(...childEntries);
      currentIndex += childEntries.length;
    }
  }

  return entries;
}

/**
 * Get content blocks from a blueprint based on its type
 * @param blueprint - Blueprint to extract content from
 * @returns Array of content blocks
 */
function getBlueprintContent(blueprint: Blueprint): ContentBlock[] {
  switch (blueprint.type) {
    case "report":
      return blueprint.content.sections || [];
    case "dashboard":
      // Dashboard doesn't have traditional sections with headings
      // but we can treat charts and tables as sections
      return [];
    case "invoice":
      // Invoices typically don't have a TOC
      return [];
    case "data-table":
      // Data tables don't have traditional TOC
      return [];
    default:
      return [];
  }
}

/**
 * Extract TOC entries from a blueprint
 * @param blueprint - Blueprint to extract TOC from
 * @param config - TOC configuration
 * @returns Array of TOC entries
 */
export function extractTocEntries(
  blueprint: Blueprint,
  config: TocConfig = {}
): TocEntry[] {
  const blocks = getBlueprintContent(blueprint);
  return extractFromBlocks(blocks, config);
}

/**
 * Build a nested tree structure from flat TOC entries
 * @param entries - Flat list of TOC entries
 * @returns Nested tree of TOC entries
 */
export function buildTocTree(entries: TocEntry[]): TocEntry[] {
  if (entries.length === 0) return [];

  const tree: TocEntry[] = [];
  const stack: TocEntry[] = [];

  for (const entry of entries) {
    const node: TocEntry = { ...entry, children: [] };

    // Pop items from stack until we find a parent (lower level)
    while (stack.length > 0 && stack[stack.length - 1].level >= entry.level) {
      stack.pop();
    }

    if (stack.length === 0) {
      // Top-level entry
      tree.push(node);
    } else {
      // Add as child to the last item in stack
      const parent = stack[stack.length - 1];
      if (!parent.children) parent.children = [];
      parent.children.push(node);
    }

    stack.push(node);
  }

  return tree;
}

/**
 * Generate complete TOC result from blueprint
 * @param blueprint - Blueprint to process
 * @param config - TOC configuration
 * @returns Complete TOC result with flat and nested structures
 */
export function generateToc(
  blueprint: Blueprint,
  config: TocConfig = {}
): TocResult {
  const entries = extractTocEntries(blueprint, config);
  const tree = buildTocTree(entries);

  return {
    entries,
    tree,
    headingCount: entries.length,
  };
}

/**
 * Update page numbers in TOC entries
 * @param entries - TOC entries to update
 * @param pageNumbers - Map of heading ID to page number
 * @returns Updated TOC entries
 */
export function updatePageNumbers(
  entries: TocEntry[],
  pageNumbers: Map<string, number>
): TocEntry[] {
  return entries.map((entry) => ({
    ...entry,
    pageNumber: pageNumbers.get(entry.id) ?? entry.pageNumber,
    children: entry.children
      ? updatePageNumbers(entry.children, pageNumbers)
      : undefined,
  }));
}

/**
 * Flatten a nested TOC tree into a flat list
 * @param tree - Nested TOC tree
 * @returns Flat list of entries
 */
export function flattenTocTree(tree: TocEntry[]): TocEntry[] {
  const result: TocEntry[] = [];

  function flatten(entries: TocEntry[]) {
    for (const entry of entries) {
      result.push({
        id: entry.id,
        title: entry.title,
        level: entry.level,
        pageNumber: entry.pageNumber,
      });
      if (entry.children && entry.children.length > 0) {
        flatten(entry.children);
      }
    }
  }

  flatten(tree);
  return result;
}

/**
 * Filter TOC entries by maximum depth
 * @param entries - TOC entries to filter
 * @param maxDepth - Maximum level to include
 * @returns Filtered entries
 */
export function filterByDepth(
  entries: TocEntry[],
  maxDepth: number
): TocEntry[] {
  return entries
    .filter((entry) => entry.level <= maxDepth)
    .map((entry) => ({
      ...entry,
      children: entry.children
        ? filterByDepth(entry.children, maxDepth)
        : undefined,
    }));
}

// ============================================================================
// Default Export
// ============================================================================

export default {
  extractTocEntries,
  buildTocTree,
  generateToc,
  updatePageNumbers,
  flattenTocTree,
  filterByDepth,
  generateHeadingId,
  slugify,
};
