/**
 * TreeLayoutEngine
 * 
 * Uses dagre (hierarchical graph layout library) to automatically position nodes
 * in a trust structure diagram using a top-down recursive approach.
 * 
 * Key Features:
 * - Automatic node positioning based on parent-child relationships
 * - Support for multiple node types (trusts, gifts, separators)
 * - Edge routing with proper SVG paths
 * - Percentage labels on edges
 */

import dagre from 'dagre';

// ============================================================================
// Type Definitions
// ============================================================================

export interface TreeNode {
  id: string;
  label: string;
  type: 'trust' | 'gift' | 'separator' | 'annotation';
  icon?: 'building' | 'gift' | 'document';
  color?: string;
  children?: TreeNode[];
  edgeLabel?: string; // e.g., "50%"
  metadata?: Record<string, any>;
}

export interface LayoutConfig {
  width: number;
  height: number;
  nodeWidth: number;
  nodeHeight: number;
  smallNodeWidth: number;
  smallNodeHeight: number;
  rankSeparation: number;  // Vertical spacing between levels
  nodeSeparation: number;  // Horizontal spacing between nodes
  edgeSeparation: number;  // Spacing between edges
  marginX: number;
  marginY: number;
}

export interface PositionedNode {
  id: string;
  x: number;  // Center x
  y: number;  // Center y
  width: number;
  height: number;
  label: string;
  type: TreeNode['type'];
  icon?: string;
  color?: string;
}

export interface PositionedEdge {
  id: string;
  source: string;
  target: string;
  sourceX: number;
  sourceY: number;
  targetX: number;
  targetY: number;
  label?: string;
  points?: { x: number; y: number }[];
}

export interface LayoutResult {
  nodes: PositionedNode[];
  edges: PositionedEdge[];
  width: number;
  height: number;
  viewBox: string;
}

// ============================================================================
// Default Configuration
// ============================================================================

const DEFAULT_CONFIG: LayoutConfig = {
  width: 500,
  height: 600,
  nodeWidth: 100,
  nodeHeight: 48,
  smallNodeWidth: 80,
  smallNodeHeight: 40,
  rankSeparation: 80,  // Vertical spacing
  nodeSeparation: 40,  // Horizontal spacing
  edgeSeparation: 20,
  marginX: 30,
  marginY: 30,
};

// ============================================================================
// Tree Layout Engine Class
// ============================================================================

export class TreeLayoutEngine {
  private config: LayoutConfig;
  
  constructor(config: Partial<LayoutConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Main layout function - converts a tree structure to positioned nodes/edges
   */
  layout(root: TreeNode): LayoutResult {
    // Create a new dagre graph
    const g = new dagre.graphlib.Graph();
    
    // Set graph options for top-to-bottom layout
    g.setGraph({
      rankdir: 'TB',  // Top to Bottom
      ranksep: this.config.rankSeparation,
      nodesep: this.config.nodeSeparation,
      edgesep: this.config.edgeSeparation,
      marginx: this.config.marginX,
      marginy: this.config.marginY,
    });
    
    // Default edge label (required by dagre)
    g.setDefaultEdgeLabel(() => ({}));

    // Recursively add nodes and edges to the graph
    const nodeMap = new Map<string, TreeNode>();
    const edgeLabels = new Map<string, string>();
    
    this.addNodeRecursive(g, root, null, nodeMap, edgeLabels);

    // Run dagre layout algorithm
    dagre.layout(g);

    // Extract positioned nodes
    const nodes: PositionedNode[] = [];
    g.nodes().forEach((nodeId) => {
      const node = g.node(nodeId);
      const treeNode = nodeMap.get(nodeId);
      if (node && treeNode && treeNode.type !== 'separator') {
        nodes.push({
          id: nodeId,
          x: node.x,
          y: node.y,
          width: node.width,
          height: node.height,
          label: treeNode.label,
          type: treeNode.type,
          icon: treeNode.icon,
          color: treeNode.color,
        });
      }
    });

    // Extract positioned edges with points
    const edges: PositionedEdge[] = [];
    g.edges().forEach((e) => {
      const edge = g.edge(e);
      const sourceNode = g.node(e.v);
      const targetNode = g.node(e.w);
      
      if (edge && sourceNode && targetNode) {
        edges.push({
          id: `${e.v}-${e.w}`,
          source: e.v,
          target: e.w,
          sourceX: sourceNode.x,
          sourceY: sourceNode.y + sourceNode.height / 2,
          targetX: targetNode.x,
          targetY: targetNode.y - targetNode.height / 2,
          label: edgeLabels.get(`${e.v}-${e.w}`),
          points: edge.points,
        });
      }
    });

    // Calculate actual bounds
    const graph = g.graph();
    const width = graph.width || this.config.width;
    const height = graph.height || this.config.height;

    return {
      nodes,
      edges,
      width,
      height,
      viewBox: `0 0 ${width} ${height}`,
    };
  }

  /**
   * Recursively add nodes and edges to dagre graph
   */
  private addNodeRecursive(
    g: dagre.graphlib.Graph,
    node: TreeNode,
    parentId: string | null,
    nodeMap: Map<string, TreeNode>,
    edgeLabels: Map<string, string>
  ): void {
    // Determine node dimensions based on type
    const isSmall = node.type === 'gift';
    const width = isSmall ? this.config.smallNodeWidth : this.config.nodeWidth;
    const height = isSmall ? this.config.smallNodeHeight : this.config.nodeHeight;

    // Skip separator nodes (they're rendered differently)
    if (node.type !== 'separator') {
      // Add node to graph
      g.setNode(node.id, {
        width,
        height,
        label: node.label,
      });
      nodeMap.set(node.id, node);

      // Add edge from parent if exists
      if (parentId && nodeMap.get(parentId)?.type !== 'separator') {
        g.setEdge(parentId, node.id);
        if (node.edgeLabel) {
          edgeLabels.set(`${parentId}-${node.id}`, node.edgeLabel);
        }
      }
    }

    // Process children recursively
    if (node.children) {
      for (const child of node.children) {
        // For separators, pass through the parent
        const effectiveParent = node.type === 'separator' ? parentId : node.id;
        this.addNodeRecursive(g, child, effectiveParent, nodeMap, edgeLabels);
      }
    }
  }

  /**
   * Generate SVG from layout result
   */
  generateSVG(layout: LayoutResult, options: { showGrid?: boolean } = {}): string {
    const { nodes, edges, viewBox } = layout;
    
    // SVG icons
    const icons = {
      building: `<g transform="translate(-12,-12)"><path d="M12 3L4 9v12h16V9l-8-6z" fill="white"/><rect x="7" y="12" width="3" height="3" fill="currentColor" opacity="0.5"/><rect x="11" y="12" width="3" height="3" fill="currentColor" opacity="0.5"/><rect x="10" y="17" width="4" height="4" fill="currentColor" opacity="0.5"/></g>`,
      gift: `<g transform="translate(-10,-10) scale(0.85)"><rect x="3" y="10" width="18" height="11" rx="1" fill="white"/><rect x="2" y="7" width="20" height="4" rx="1" fill="white"/><path d="M12 7v14" stroke="currentColor" stroke-width="2" opacity="0.6"/></g>`,
      document: `<g transform="translate(-10,-10) scale(0.85)"><rect x="5" y="3" width="14" height="18" rx="1" fill="white"/><rect x="7" y="7" width="10" height="2" rx="0.5" fill="currentColor" opacity="0.4"/><rect x="7" y="11" width="10" height="2" rx="0.5" fill="currentColor" opacity="0.4"/><rect x="7" y="15" width="6" height="2" rx="0.5" fill="currentColor" opacity="0.4"/></g>`,
    };

    let svg = `<svg viewBox="${viewBox}" xmlns="http://www.w3.org/2000/svg">`;
    
    // Defs for arrow markers
    svg += `
      <defs>
        <marker id="arrow" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto" markerUnits="strokeWidth">
          <polygon points="0 0, 10 3.5, 0 7" fill="#9CA3AF"/>
        </marker>
      </defs>
    `;

    // Draw edges first (so they're behind nodes)
    for (const edge of edges) {
      svg += this.renderEdge(edge);
    }

    // Draw nodes
    for (const node of nodes) {
      svg += this.renderNode(node, icons);
    }

    svg += '</svg>';
    return svg;
  }

  /**
   * Render a single node
   */
  private renderNode(node: PositionedNode, icons: Record<string, string>): string {
    const { x, y, width, height, label, type, icon, color } = node;
    const rx = 8;
    const bgColor = color || (type === 'gift' ? '#FF8A65' : '#2D9B9B');
    const iconSvg = icon ? icons[icon] || icons.document : icons.document;
    
    // Node rectangle
    let svg = `<rect x="${x - width/2}" y="${y - height/2}" width="${width}" height="${height}" rx="${rx}" fill="${bgColor}"/>`;
    
    // Icon
    svg += `<g transform="translate(${x}, ${y})" color="${bgColor}">${iconSvg}</g>`;
    
    // Label below node
    svg += `<text x="${x}" y="${y + height/2 + 14}" text-anchor="middle" font-family="Inter, sans-serif" font-size="9" font-weight="500" fill="#374151">${label}</text>`;
    
    return svg;
  }

  /**
   * Render a single edge with smoothstep path
   */
  private renderEdge(edge: PositionedEdge): string {
    const { sourceX, sourceY, targetX, targetY, label, points } = edge;
    
    let pathD: string;
    
    if (points && points.length >= 2) {
      // Use dagre's calculated points
      pathD = `M ${points[0].x},${points[0].y}`;
      for (let i = 1; i < points.length; i++) {
        pathD += ` L ${points[i].x},${points[i].y}`;
      }
    } else {
      // Fallback to smoothstep path
      const midY = sourceY + (targetY - sourceY) / 2;
      pathD = `M ${sourceX},${sourceY} L ${sourceX},${midY} L ${targetX},${midY} L ${targetX},${targetY}`;
    }
    
    let svg = `<path d="${pathD}" fill="none" stroke="#D1D5DB" stroke-width="2" marker-end="url(#arrow)"/>`;
    
    // Add label if present
    if (label) {
      const labelX = targetX;
      const labelY = targetY - 20;
      svg += `
        <rect x="${labelX - 18}" y="${labelY - 8}" width="36" height="16" rx="8" fill="white" stroke="#E5E7EB"/>
        <text x="${labelX}" y="${labelY + 4}" text-anchor="middle" font-family="Inter, sans-serif" font-size="8" fill="#6B7280">${label}</text>
      `;
    }
    
    return svg;
  }
}

// ============================================================================
// Helper: Convert flat trust structure to tree
// ============================================================================

export function convertToTree(trustStructure: any): TreeNode {
  // This converts the blueprint's trust structure to our TreeNode format
  const root: TreeNode = {
    id: 'root',
    label: trustStructure.trustName || 'Revocable Trust',
    type: 'trust',
    icon: 'building',
    color: '#2D9B9B',
    children: [],
  };

  // First separator
  const sep1: TreeNode = {
    id: 'sep1',
    label: 'Death of First Spouse',
    type: 'separator',
    children: [],
  };

  // Specific Gifts 1
  const gift1: TreeNode = {
    id: 'gift1',
    label: 'Specific Gifts',
    type: 'gift',
    icon: 'gift',
    color: '#FF8A65',
  };
  
  // Three trusts
  const survivorTrust: TreeNode = {
    id: 'survivor',
    label: "Survivor's Trust",
    type: 'trust',
    icon: 'document',
    color: '#A78BFA',
  };
  
  const bypassTrust: TreeNode = {
    id: 'bypass',
    label: 'Bypass Trust',
    type: 'trust',
    icon: 'document',
    color: '#60A5FA',
  };
  
  const maritalTrust: TreeNode = {
    id: 'marital',
    label: 'Marital Trust',
    type: 'trust',
    icon: 'document',
    color: '#5AB2B2',
    children: [],
  };

  // Second separator
  const sep2: TreeNode = {
    id: 'sep2',
    label: 'Death of Surviving Spouse',
    type: 'separator',
    children: [],
  };
  
  // Specific Gifts 2
  const gift2: TreeNode = {
    id: 'gift2',
    label: 'Specific Gifts',
    type: 'gift',
    icon: 'gift',
    color: '#FF8A65',
  };

  // Individual trusts
  const janeTrust: TreeNode = {
    id: 'jane',
    label: 'Jane Doe Trust',
    type: 'trust',
    icon: 'document',
    color: '#2D7B7B',
    edgeLabel: '50%',
  };
  
  const johnTrust: TreeNode = {
    id: 'john',
    label: 'John Doe Trust',
    type: 'trust',
    icon: 'document',
    color: '#2D7B7B',
    edgeLabel: '50%',
  };

  // Build tree structure
  sep2.children = [gift2, janeTrust, johnTrust];
  maritalTrust.children = [sep2];
  sep1.children = [gift1, survivorTrust, bypassTrust, maritalTrust];
  root.children = [sep1];

  return root;
}

// Export singleton layout engine
export const treeLayoutEngine = new TreeLayoutEngine();
