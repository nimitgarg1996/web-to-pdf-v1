/**
 * Bookmark Utilities
 * Generate PDF bookmarks/outline from blueprint content
 */

import type { TocEntry } from "./toc.js";
import { extractTocEntries, buildTocTree } from "./toc.js";
import type { Blueprint } from "../blueprints/types.js";

// ============================================================================
// Types
// ============================================================================

/**
 * PDF Bookmark structure
 * Compatible with React-PDF's bookmark prop format
 */
export interface Bookmark {
  /** Bookmark title displayed in PDF reader */
  title: string;
  /** Internal destination (element ID or anchor) */
  destination: string;
  /** Whether this bookmark is expanded by default */
  expanded?: boolean;
  /** Fit the destination view */
  fit?: boolean;
  /** Child bookmarks for nested structure */
  children?: Bookmark[];
}

/**
 * Configuration for bookmark generation
 */
export interface BookmarkConfig {
  /** Maximum depth of bookmarks (default: 3) */
  maxDepth?: number;
  /** Default expanded state (default: true for level 1) */
  defaultExpanded?: boolean;
  /** Expand all levels (default: false) */
  expandAll?: boolean;
  /** Fit view to bookmark destination */
  fitDestination?: boolean;
  /** Custom title transformer */
  titleTransform?: (title: string, level: number) => string;
}

/**
 * Default bookmark configuration
 */
export const defaultBookmarkConfig: BookmarkConfig = {
  maxDepth: 3,
  defaultExpanded: true,
  expandAll: false,
  fitDestination: false,
};

// ============================================================================
// Conversion Functions
// ============================================================================

/**
 * Convert a single TOC entry to a bookmark
 * @param entry - TOC entry to convert
 * @param config - Bookmark configuration
 * @returns Bookmark object
 */
export function tocEntryToBookmark(
  entry: TocEntry,
  config: BookmarkConfig = {}
): Bookmark {
  const {
    defaultExpanded = true,
    expandAll = false,
    fitDestination = false,
    titleTransform,
  } = config;

  const title = titleTransform
    ? titleTransform(entry.title, entry.level)
    : entry.title;

  const bookmark: Bookmark = {
    title,
    destination: entry.id,
    expanded: expandAll || (entry.level === 1 && defaultExpanded),
    fit: fitDestination,
  };

  // Recursively convert children
  if (entry.children && entry.children.length > 0) {
    bookmark.children = entry.children.map((child) =>
      tocEntryToBookmark(child, config)
    );
  }

  return bookmark;
}

/**
 * Build bookmark tree from flat TOC entries
 * @param entries - Flat list of TOC entries
 * @param config - Bookmark configuration
 * @returns Array of top-level bookmarks with nested children
 */
export function buildBookmarkTree(
  entries: TocEntry[],
  config: BookmarkConfig = {}
): Bookmark[] {
  const maxDepth = config.maxDepth ?? 3;

  // Filter by max depth
  const filteredEntries = entries.filter((entry) => entry.level <= maxDepth);

  if (filteredEntries.length === 0) return [];

  // Build nested structure using a stack
  const tree: Bookmark[] = [];
  const stack: Array<{ bookmark: Bookmark; level: number }> = [];

  for (const entry of filteredEntries) {
    const bookmark = tocEntryToBookmark(entry, config);
    bookmark.children = []; // Initialize children array

    // Pop items until we find a parent (lower level)
    while (stack.length > 0 && stack[stack.length - 1].level >= entry.level) {
      stack.pop();
    }

    if (stack.length === 0) {
      // Top-level bookmark
      tree.push(bookmark);
    } else {
      // Add as child to parent
      const parent = stack[stack.length - 1].bookmark;
      if (!parent.children) parent.children = [];
      parent.children.push(bookmark);
    }

    stack.push({ bookmark, level: entry.level });
  }

  // Clean up empty children arrays
  function cleanEmptyChildren(bookmarks: Bookmark[]): Bookmark[] {
    return bookmarks.map((b) => {
      const cleaned: Bookmark = { ...b };
      if (cleaned.children && cleaned.children.length > 0) {
        cleaned.children = cleanEmptyChildren(cleaned.children);
      } else {
        delete cleaned.children;
      }
      return cleaned;
    });
  }

  return cleanEmptyChildren(tree);
}

/**
 * Convert nested TOC tree to bookmark tree
 * @param tocTree - Nested TOC entries
 * @param config - Bookmark configuration
 * @returns Array of bookmarks
 */
export function tocTreeToBookmarks(
  tocTree: TocEntry[],
  config: BookmarkConfig = {}
): Bookmark[] {
  const maxDepth = config.maxDepth ?? 3;

  function convertLevel(entries: TocEntry[], currentDepth: number): Bookmark[] {
    if (currentDepth > maxDepth) return [];

    return entries.map((entry) => {
      const bookmark = tocEntryToBookmark(entry, config);

      if (entry.children && entry.children.length > 0 && currentDepth < maxDepth) {
        const childBookmarks = convertLevel(entry.children, currentDepth + 1);
        if (childBookmarks.length > 0) {
          bookmark.children = childBookmarks;
        }
      }

      return bookmark;
    });
  }

  return convertLevel(tocTree, 1);
}

// ============================================================================
// Blueprint Integration
// ============================================================================

/**
 * Generate bookmarks from a blueprint
 * @param blueprint - Blueprint to generate bookmarks from
 * @param config - Bookmark configuration
 * @returns Array of bookmarks
 */
export function generateBookmarks(
  blueprint: Blueprint,
  config: BookmarkConfig = {}
): Bookmark[] {
  const tocEntries = extractTocEntries(blueprint, {
    maxDepth: config.maxDepth ?? 3,
  });

  return buildBookmarkTree(tocEntries, config);
}

/**
 * Generate bookmarks from a nested TOC tree
 * @param tocTree - Pre-built TOC tree
 * @param config - Bookmark configuration
 * @returns Array of bookmarks
 */
export function bookmarksFromTocTree(
  tocTree: TocEntry[],
  config: BookmarkConfig = {}
): Bookmark[] {
  return tocTreeToBookmarks(tocTree, config);
}

// ============================================================================
// React-PDF Integration Helpers
// ============================================================================

/**
 * Create bookmark props for React-PDF View/Text components
 * @param title - Bookmark title
 * @param options - Optional bookmark options
 * @returns Bookmark prop value for React-PDF
 */
export function createBookmarkProp(
  title: string,
  options: { fit?: boolean; expanded?: boolean } = {}
): string | { title: string; fit?: boolean; expanded?: boolean } {
  const { fit, expanded } = options;

  // If no options, return just the title string
  if (fit === undefined && expanded === undefined) {
    return title;
  }

  // Return full object with options
  return {
    title,
    fit,
    expanded,
  };
}

/**
 * Flatten bookmark tree for iteration
 * @param bookmarks - Nested bookmark tree
 * @returns Flat array of all bookmarks
 */
export function flattenBookmarks(bookmarks: Bookmark[]): Bookmark[] {
  const result: Bookmark[] = [];

  function flatten(items: Bookmark[]) {
    for (const item of items) {
      result.push({
        title: item.title,
        destination: item.destination,
        expanded: item.expanded,
        fit: item.fit,
      });
      if (item.children) {
        flatten(item.children);
      }
    }
  }

  flatten(bookmarks);
  return result;
}

/**
 * Count total bookmarks including nested
 * @param bookmarks - Bookmark tree
 * @returns Total count
 */
export function countBookmarks(bookmarks: Bookmark[]): number {
  let count = 0;

  function countLevel(items: Bookmark[]) {
    for (const item of items) {
      count++;
      if (item.children) {
        countLevel(item.children);
      }
    }
  }

  countLevel(bookmarks);
  return count;
}

/**
 * Find a bookmark by destination ID
 * @param bookmarks - Bookmark tree
 * @param destination - Destination ID to find
 * @returns Found bookmark or undefined
 */
export function findBookmark(
  bookmarks: Bookmark[],
  destination: string
): Bookmark | undefined {
  for (const bookmark of bookmarks) {
    if (bookmark.destination === destination) {
      return bookmark;
    }
    if (bookmark.children) {
      const found = findBookmark(bookmark.children, destination);
      if (found) return found;
    }
  }
  return undefined;
}

// ============================================================================
// Default Export
// ============================================================================

export default {
  tocEntryToBookmark,
  buildBookmarkTree,
  tocTreeToBookmarks,
  generateBookmarks,
  bookmarksFromTocTree,
  createBookmarkProp,
  flattenBookmarks,
  countBookmarks,
  findBookmark,
  defaultBookmarkConfig,
};
