/**
 * Logger Utility
 * Winston logger configuration for the application
 */

import winston from "winston";

const { combine, timestamp, printf, colorize, errors } = winston.format;

// Custom format for console output
const consoleFormat = printf(({ level, message, timestamp, stack }) => {
  const logMessage = stack || message;
  return `${timestamp} [${level}]: ${logMessage}`;
});

// Custom format for file output
const fileFormat = printf(({ level, message, timestamp, stack, ...meta }) => {
  const logMessage = stack || message;
  const metaString = Object.keys(meta).length ? JSON.stringify(meta) : "";
  return `${timestamp} [${level}]: ${logMessage} ${metaString}`;
});

// Determine log level based on environment
const getLogLevel = (): string => {
  const env = process.env.NODE_ENV || "development";
  switch (env) {
    case "production":
      return "info";
    case "test":
      return "error";
    default:
      return "debug";
  }
};

// Create the logger instance
export const logger = winston.createLogger({
  level: getLogLevel(),
  format: combine(
    errors({ stack: true }),
    timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
  ),
  defaultMeta: { service: "report-builder" },
  transports: [
    // Console transport
    new winston.transports.Console({
      format: combine(
        colorize(),
        timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
        consoleFormat,
      ),
    }),
  ],
});

// Add file transport in production
if (process.env.NODE_ENV === "production") {
  logger.add(
    new winston.transports.File({
      filename: "logs/error.log",
      level: "error",
      format: combine(timestamp(), fileFormat),
    }),
  );
  logger.add(
    new winston.transports.File({
      filename: "logs/combined.log",
      format: combine(timestamp(), fileFormat),
    }),
  );
}

// Export convenience methods
export const logInfo = (message: string, meta?: object): void => {
  logger.info(message, meta);
};

export const logError = (
  message: string,
  error?: Error,
  meta?: object,
): void => {
  logger.error(message, { error, ...meta });
};

export const logWarn = (message: string, meta?: object): void => {
  logger.warn(message, meta);
};

export const logDebug = (message: string, meta?: object): void => {
  logger.debug(message, meta);
};

export default logger;
