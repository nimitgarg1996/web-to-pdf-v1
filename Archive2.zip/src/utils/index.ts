/**
 * Utils Index
 * Export all utility modules
 */

// Logger
export {
  logger,
  logInfo,
  logError,
  logWarn,
  logDebug,
} from "./logger.js";

// Table of Contents utilities
export {
  extractTocEntries,
  buildTocTree,
  generateToc,
  updatePageNumbers,
  flattenTocTree,
  filterByDepth,
  generateHeadingId,
  slugify,
  type TocEntry,
  type TocConfig,
  type TocResult,
} from "./toc.js";

// Page number utilities
export {
  toRoman,
  toRomanLower,
  toAlpha,
  toAlphaLower,
  convertPageNumber,
  formatPageNumber,
  formatPageOfTotal,
  formatSectionNumber,
  getPreset,
  validateConfig as validatePageNumberConfig,
  pageNumberPresets,
  defaultPageNumberConfig,
  type PageNumberFormat,
  type PageNumberConfig,
} from "./pageNumbers.js";

// Bookmark utilities
export {
  tocEntryToBookmark,
  buildBookmarkTree,
  tocTreeToBookmarks,
  generateBookmarks,
  bookmarksFromTocTree,
  createBookmarkProp,
  flattenBookmarks,
  countBookmarks,
  findBookmark,
  defaultBookmarkConfig,
  type Bookmark,
  type BookmarkConfig,
} from "./bookmarks.js";

// Print-ready utilities
export {
  mmToPoints,
  pointsToMm,
  inchesToPoints,
  pointsToInches,
  calculatePrintDimensions,
  getPageSizeWithBleed,
  getPrintReadyStyles,
  calculateCropMarks,
  calculateRegistrationMarks,
  calculateSafeZone,
  validatePrintConfig,
  PAGE_SIZES,
  defaultPrintConfig,
  professionalPrintConfig,
  digitalConfig,
  type ColorMode,
  type BleedConfig,
  type CropMarksConfig,
  type RegistrationMarksConfig,
  type PrintConfig,
  type PrintReadyStyles,
  type PageDimensions,
  type PrintDimensions,
  type CropMarkPosition,
} from "./printReady.js";

// Preview utilities
export {
  analyzeContent,
  estimatePageCount,
  getPreviewMetadata,
  createPreviewBlueprint,
  getQualitySettings,
  canGeneratePreview,
  defaultPreviewOptions,
  type PreviewQuality,
  type PreviewOptions,
  type ContentAnalysis,
  type PageEstimate,
  type PreviewResult,
} from "./preview.js";

// DevTools utilities
export {
  withTiming,
  withTimingAsync,
  createTimingTracker,
  analyzeBlueprint,
  formatBlueprint,
  summarizeBlueprint,
  generateDebugInfo,
  formatValidationResult,
  debugLog,
  logTimings,
  isDevelopment,
  devOnly,
  type BlueprintStats,
  type PerformanceTiming,
  type DebugInfo,
  type AnalysisResult,
  type TimerResult,
} from "./devtools.js";

// Default exports grouped by category
export { default as tocUtils } from "./toc.js";
export { default as pageNumberUtils } from "./pageNumbers.js";
export { default as bookmarkUtils } from "./bookmarks.js";
export { default as printReadyUtils } from "./printReady.js";
export { default as previewUtils } from "./preview.js";
export { default as devtoolsUtils } from "./devtools.js";
