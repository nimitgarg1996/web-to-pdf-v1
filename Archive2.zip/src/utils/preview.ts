/**
 * Preview Utilities
 * Fast preview generation and metadata extraction for blueprints
 */

import type {
  Blueprint,
  BlueprintMetadata,
  ContentBlock,
  TableBlock,
  DiagramBlock,
  ImageBlock,
} from "../blueprints/types.js";

// ============================================================================
// Types
// ============================================================================

/**
 * Preview quality levels
 */
export type PreviewQuality = "draft" | "normal" | "high";

/**
 * Options for preview generation
 */
export interface PreviewOptions {
  /** Maximum number of pages to include in preview */
  maxPages?: number;
  /** Preview quality level */
  quality?: PreviewQuality;
  /** Thumbnail width in pixels */
  width?: number;
  /** Thumbnail height in pixels */
  height?: number;
  /** Skip heavy elements (images, diagrams) */
  skipHeavyElements?: boolean;
  /** Reduce image quality for preview */
  reducedImageQuality?: boolean;
}

/**
 * Default preview options
 */
export const defaultPreviewOptions: PreviewOptions = {
  maxPages: 3,
  quality: "draft",
  width: 300,
  height: 400,
  skipHeavyElements: false,
  reducedImageQuality: true,
};

/**
 * Content analysis result
 */
export interface ContentAnalysis {
  /** Total number of content blocks */
  blockCount: number;
  /** Number of heading blocks */
  headingCount: number;
  /** Number of paragraph blocks */
  paragraphCount: number;
  /** Number of table blocks */
  tableCount: number;
  /** Total rows across all tables */
  totalTableRows: number;
  /** Number of diagram blocks */
  diagramCount: number;
  /** Number of image blocks */
  imageCount: number;
  /** Number of page break blocks */
  pageBreakCount: number;
  /** Estimated character count */
  estimatedCharacters: number;
  /** Has heavy content (diagrams, large tables) */
  hasHeavyContent: boolean;
}

/**
 * Page estimation result
 */
export interface PageEstimate {
  /** Estimated total pages */
  estimatedPages: number;
  /** Confidence level */
  confidence: "low" | "medium" | "high";
  /** Factors affecting estimate */
  factors: string[];
}

/**
 * Preview metadata result
 */
export interface PreviewResult {
  /** Blueprint metadata */
  metadata: BlueprintMetadata;
  /** Blueprint type */
  type: string;
  /** Content analysis */
  analysis: ContentAnalysis;
  /** Page estimate */
  pageEstimate: PageEstimate;
  /** Estimated file size in bytes */
  estimatedSize: number;
  /** Preview pages to render */
  previewPages: number;
  /** Is preview mode (limited content) */
  isPreview: boolean;
}

// ============================================================================
// Content Analysis
// ============================================================================

/**
 * Analyze content blocks to gather statistics
 * @param blocks - Content blocks to analyze
 * @returns Content analysis result
 */
export function analyzeContent(blocks: ContentBlock[]): ContentAnalysis {
  const analysis: ContentAnalysis = {
    blockCount: 0,
    headingCount: 0,
    paragraphCount: 0,
    tableCount: 0,
    totalTableRows: 0,
    diagramCount: 0,
    imageCount: 0,
    pageBreakCount: 0,
    estimatedCharacters: 0,
    hasHeavyContent: false,
  };

  function processBlocks(contentBlocks: ContentBlock[]) {
    for (const block of contentBlocks) {
      analysis.blockCount++;

      switch (block.type) {
        case "heading":
          analysis.headingCount++;
          analysis.estimatedCharacters += block.text.length;
          break;

        case "paragraph":
          analysis.paragraphCount++;
          analysis.estimatedCharacters += block.text.length;
          break;

        case "table":
          analysis.tableCount++;
          const tableBlock = block as TableBlock;
          analysis.totalTableRows += tableBlock.data.length;
          if (tableBlock.data.length > 50) {
            analysis.hasHeavyContent = true;
          }
          // Estimate characters from table
          analysis.estimatedCharacters +=
            tableBlock.data.length * tableBlock.columns.length * 20;
          break;

        case "diagram":
          analysis.diagramCount++;
          analysis.hasHeavyContent = true;
          break;

        case "image":
          analysis.imageCount++;
          break;

        case "page-break":
          analysis.pageBreakCount++;
          break;

        case "section":
          // Recursively process section children
          if (block.children) {
            processBlocks(block.children);
          }
          break;

        case "list":
          analysis.estimatedCharacters += block.items.join(" ").length;
          break;

        case "callout":
          analysis.estimatedCharacters += (block.title?.length || 0) + block.text.length;
          break;

        case "key-value":
          analysis.estimatedCharacters +=
            block.items.reduce((sum, item) => sum + item.key.length + item.value.length, 0);
          break;
      }
    }
  }

  processBlocks(blocks);

  return analysis;
}

/**
 * Get content blocks from blueprint
 * @param blueprint - Blueprint to extract content from
 * @returns Array of content blocks
 */
function getBlueprintBlocks(blueprint: Blueprint): ContentBlock[] {
  switch (blueprint.type) {
    case "report":
      return blueprint.content.sections || [];
    case "dashboard":
      // Combine tables and charts
      const dashboardBlocks: ContentBlock[] = [];
      if (blueprint.content.tables) {
        dashboardBlocks.push(...blueprint.content.tables);
      }
      if (blueprint.content.charts) {
        dashboardBlocks.push(...blueprint.content.charts);
      }
      return dashboardBlocks;
    case "data-table":
      // Create a single table block from content
      return [
        {
          type: "table",
          columns: blueprint.content.columns,
          data: blueprint.content.data,
        } as TableBlock,
      ];
    case "invoice":
      return [];
    default:
      return [];
  }
}

// ============================================================================
// Page Estimation
// ============================================================================

/**
 * Estimate page count based on content analysis
 * @param analysis - Content analysis result
 * @param hasExtraSections - Has cover page, TOC, etc.
 * @returns Page estimate
 */
export function estimatePageCount(
  analysis: ContentAnalysis,
  hasExtraSections: boolean = false
): PageEstimate {
  const factors: string[] = [];
  let basePages = 1;

  // Estimate based on explicit page breaks
  if (analysis.pageBreakCount > 0) {
    basePages = analysis.pageBreakCount + 1;
    factors.push(`${analysis.pageBreakCount} explicit page breaks`);
  }

  // Estimate based on character count (roughly 3000 chars per page)
  const charPages = Math.ceil(analysis.estimatedCharacters / 3000);
  if (charPages > basePages) {
    basePages = charPages;
    factors.push(`~${analysis.estimatedCharacters} characters`);
  }

  // Add pages for tables (large tables may span pages)
  const tablePages = Math.ceil(analysis.totalTableRows / 30); // ~30 rows per page
  if (tablePages > 1) {
    basePages += tablePages - 1;
    factors.push(`${analysis.totalTableRows} table rows`);
  }

  // Add pages for diagrams (typically one per page or partial)
  if (analysis.diagramCount > 0) {
    basePages += Math.ceil(analysis.diagramCount / 2);
    factors.push(`${analysis.diagramCount} diagrams`);
  }

  // Add extra sections
  let extraPages = 0;
  if (hasExtraSections) {
    extraPages += 2; // Cover + TOC typically
    factors.push("cover page and TOC");
  }

  const estimatedPages = Math.max(1, basePages + extraPages);

  // Determine confidence
  let confidence: "low" | "medium" | "high" = "medium";
  if (analysis.hasHeavyContent || analysis.diagramCount > 0) {
    confidence = "low";
    factors.push("contains dynamic content");
  } else if (
    analysis.estimatedCharacters > 10000 ||
    analysis.tableCount > 5
  ) {
    confidence = "low";
  } else if (
    analysis.pageBreakCount > 0 &&
    analysis.diagramCount === 0
  ) {
    confidence = "high";
  }

  return {
    estimatedPages,
    confidence,
    factors,
  };
}

// ============================================================================
// Preview Generation
// ============================================================================

/**
 * Generate preview metadata without full render
 * @param blueprint - Blueprint to analyze
 * @param options - Preview options
 * @returns Preview metadata result
 */
export function getPreviewMetadata(
  blueprint: Blueprint,
  options: PreviewOptions = {}
): PreviewResult {
  const opts = { ...defaultPreviewOptions, ...options };
  const blocks = getBlueprintBlocks(blueprint);
  const analysis = analyzeContent(blocks);

  // Check for extra sections (cover, TOC)
  let hasExtraSections = false;
  if (blueprint.type === "report") {
    hasExtraSections =
      blueprint.content.showCover === true ||
      blueprint.content.showToc === true;
  }

  const pageEstimate = estimatePageCount(analysis, hasExtraSections);

  // Estimate file size (rough: 50KB base + 10KB per page + extras)
  let estimatedSize = 50000 + pageEstimate.estimatedPages * 10000;
  if (analysis.imageCount > 0) {
    estimatedSize += analysis.imageCount * 100000; // ~100KB per image
  }
  if (analysis.diagramCount > 0) {
    estimatedSize += analysis.diagramCount * 20000; // ~20KB per diagram
  }

  return {
    metadata: blueprint.metadata,
    type: blueprint.type,
    analysis,
    pageEstimate,
    estimatedSize,
    previewPages: Math.min(opts.maxPages || 3, pageEstimate.estimatedPages),
    isPreview: true,
  };
}

/**
 * Create a simplified blueprint for fast preview rendering
 * @param blueprint - Original blueprint
 * @param options - Preview options
 * @returns Simplified blueprint for preview
 */
export function createPreviewBlueprint(
  blueprint: Blueprint,
  options: PreviewOptions = {}
): Blueprint {
  const opts = { ...defaultPreviewOptions, ...options };
  const previewBlueprint = JSON.parse(JSON.stringify(blueprint)) as Blueprint;

  // Limit content based on blueprint type
  switch (previewBlueprint.type) {
    case "report":
      // Limit sections for preview
      if (previewBlueprint.content.sections) {
        previewBlueprint.content.sections = limitContentBlocks(
          previewBlueprint.content.sections,
          opts
        );
      }
      break;

    case "dashboard":
      // Limit tables
      if (previewBlueprint.content.tables) {
        previewBlueprint.content.tables = previewBlueprint.content.tables
          .slice(0, 2)
          .map((table) => ({
            ...table,
            data: table.data.slice(0, 5),
          }));
      }
      // Limit metrics
      if (previewBlueprint.content.metrics) {
        previewBlueprint.content.metrics =
          previewBlueprint.content.metrics.slice(0, 4);
      }
      break;

    case "data-table":
      // Limit rows
      previewBlueprint.content.data = previewBlueprint.content.data.slice(0, 20);
      break;

    case "invoice":
      // Limit line items
      previewBlueprint.content.lineItems =
        previewBlueprint.content.lineItems.slice(0, 5);
      break;
  }

  return previewBlueprint;
}

/**
 * Limit content blocks for preview
 * @param blocks - Content blocks to limit
 * @param options - Preview options
 * @returns Limited content blocks
 */
function limitContentBlocks(
  blocks: ContentBlock[],
  options: PreviewOptions
): ContentBlock[] {
  const result: ContentBlock[] = [];
  let pageCount = 0;
  const maxPages = options.maxPages || 3;

  for (const block of blocks) {
    if (pageCount >= maxPages) break;

    if (block.type === "page-break") {
      pageCount++;
      if (pageCount < maxPages) {
        result.push(block);
      }
      continue;
    }

    // Skip heavy elements if configured
    if (options.skipHeavyElements) {
      if (block.type === "diagram" || block.type === "image") {
        continue;
      }
    }

    // Limit table rows
    if (block.type === "table") {
      const limitedTable: TableBlock = {
        ...block,
        data: block.data.slice(0, 10),
      };
      result.push(limitedTable);
      continue;
    }

    // Process sections recursively
    if (block.type === "section" && block.children) {
      result.push({
        ...block,
        children: limitContentBlocks(block.children, options),
      });
      continue;
    }

    result.push(block);
  }

  return result;
}

// ============================================================================
// Quality Settings
// ============================================================================

/**
 * Get quality settings for preview
 * @param quality - Quality level
 * @returns Quality configuration
 */
export function getQualitySettings(quality: PreviewQuality): {
  imageQuality: number;
  skipHeavyElements: boolean;
  maxTableRows: number;
  includeDiagrams: boolean;
} {
  switch (quality) {
    case "draft":
      return {
        imageQuality: 30,
        skipHeavyElements: true,
        maxTableRows: 5,
        includeDiagrams: false,
      };
    case "normal":
      return {
        imageQuality: 60,
        skipHeavyElements: false,
        maxTableRows: 20,
        includeDiagrams: true,
      };
    case "high":
      return {
        imageQuality: 90,
        skipHeavyElements: false,
        maxTableRows: 50,
        includeDiagrams: true,
      };
  }
}

// ============================================================================
// Validation
// ============================================================================

/**
 * Check if blueprint is suitable for preview
 * @param blueprint - Blueprint to check
 * @returns Validation result
 */
export function canGeneratePreview(blueprint: Blueprint): {
  canPreview: boolean;
  reason?: string;
} {
  if (!blueprint.metadata?.title) {
    return {
      canPreview: false,
      reason: "Blueprint must have a title",
    };
  }

  if (!blueprint.type) {
    return {
      canPreview: false,
      reason: "Blueprint must have a type",
    };
  }

  return { canPreview: true };
}

// ============================================================================
// Default Export
// ============================================================================

export default {
  analyzeContent,
  estimatePageCount,
  getPreviewMetadata,
  createPreviewBlueprint,
  getQualitySettings,
  canGeneratePreview,
  defaultPreviewOptions,
};
