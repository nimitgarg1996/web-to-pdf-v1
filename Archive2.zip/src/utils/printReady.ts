/**
 * Print-Ready Utilities
 * Generate print-ready PDF configurations with bleed, crop marks, etc.
 */

import type { Style } from "../components/types.js";

// ============================================================================
// Types
// ============================================================================

/**
 * Color mode for print output
 */
export type ColorMode = "rgb" | "cmyk";

/**
 * Bleed configuration (in points)
 */
export interface BleedConfig {
  /** Top bleed area */
  top: number;
  /** Right bleed area */
  right: number;
  /** Bottom bleed area */
  bottom: number;
  /** Left bleed area */
  left: number;
}

/**
 * Crop marks configuration
 */
export interface CropMarksConfig {
  /** Enable crop marks */
  enabled: boolean;
  /** Length of crop mark lines (in points) */
  length: number;
  /** Offset from page edge (in points) */
  offset: number;
  /** Stroke width of marks */
  strokeWidth: number;
  /** Color of marks */
  color: string;
}

/**
 * Registration marks configuration
 */
export interface RegistrationMarksConfig {
  /** Enable registration marks */
  enabled: boolean;
  /** Size of registration marks */
  size: number;
  /** Stroke width */
  strokeWidth: number;
}

/**
 * Print configuration
 */
export interface PrintConfig {
  /** Color mode (RGB for digital, CMYK for print) */
  colorMode: ColorMode;
  /** Bleed area configuration */
  bleed: BleedConfig;
  /** Crop marks configuration */
  cropMarks: CropMarksConfig;
  /** Registration marks configuration */
  registrationMarks: RegistrationMarksConfig;
  /** Output resolution in DPI */
  resolution: number;
  /** ICC color profile name */
  colorProfile?: string;
  /** Show color bars */
  showColorBars: boolean;
}

/**
 * Generated print-ready styles
 */
export interface PrintReadyStyles {
  /** Page wrapper style with bleed */
  page: Style;
  /** Content area style (safe zone) */
  contentArea: Style;
  /** Bleed area style */
  bleedArea: Style;
}

/**
 * Page dimensions
 */
export interface PageDimensions {
  /** Base page width in points */
  width: number;
  /** Base page height in points */
  height: number;
}

/**
 * Calculated print dimensions
 */
export interface PrintDimensions {
  /** Base page width */
  baseWidth: number;
  /** Base page height */
  baseHeight: number;
  /** Total width with bleed */
  totalWidth: number;
  /** Total height with bleed */
  totalHeight: number;
  /** Bleed configuration */
  bleed: BleedConfig;
}

/**
 * Crop mark position
 */
export interface CropMarkPosition {
  /** X coordinate */
  x1: number;
  /** Y coordinate */
  y1: number;
  /** X2 coordinate */
  x2: number;
  /** Y2 coordinate */
  y2: number;
}

// ============================================================================
// Constants
// ============================================================================

/**
 * Standard page sizes in points (72 points = 1 inch)
 */
export const PAGE_SIZES: Record<string, PageDimensions> = {
  A4: { width: 595.28, height: 841.89 },
  A3: { width: 841.89, height: 1190.55 },
  A5: { width: 419.53, height: 595.28 },
  LETTER: { width: 612, height: 792 },
  LEGAL: { width: 612, height: 1008 },
  TABLOID: { width: 792, height: 1224 },
};

/**
 * Convert millimeters to points
 */
export function mmToPoints(mm: number): number {
  return mm * 2.834645669;
}

/**
 * Convert points to millimeters
 */
export function pointsToMm(points: number): number {
  return points / 2.834645669;
}

/**
 * Convert inches to points
 */
export function inchesToPoints(inches: number): number {
  return inches * 72;
}

/**
 * Convert points to inches
 */
export function pointsToInches(points: number): number {
  return points / 72;
}

// ============================================================================
// Default Configuration
// ============================================================================

/**
 * Default print configuration
 */
export const defaultPrintConfig: PrintConfig = {
  colorMode: "rgb",
  bleed: {
    top: mmToPoints(3),
    right: mmToPoints(3),
    bottom: mmToPoints(3),
    left: mmToPoints(3),
  },
  cropMarks: {
    enabled: true,
    length: mmToPoints(10),
    offset: mmToPoints(3),
    strokeWidth: 0.25,
    color: "#000000",
  },
  registrationMarks: {
    enabled: false,
    size: mmToPoints(5),
    strokeWidth: 0.25,
  },
  resolution: 300,
  showColorBars: false,
};

/**
 * Professional print preset (high quality)
 */
export const professionalPrintConfig: PrintConfig = {
  colorMode: "cmyk",
  bleed: {
    top: mmToPoints(5),
    right: mmToPoints(5),
    bottom: mmToPoints(5),
    left: mmToPoints(5),
  },
  cropMarks: {
    enabled: true,
    length: mmToPoints(12),
    offset: mmToPoints(3),
    strokeWidth: 0.25,
    color: "#000000",
  },
  registrationMarks: {
    enabled: true,
    size: mmToPoints(6),
    strokeWidth: 0.25,
  },
  resolution: 300,
  colorProfile: "FOGRA39",
  showColorBars: true,
};

/**
 * Digital/screen preset
 */
export const digitalConfig: PrintConfig = {
  colorMode: "rgb",
  bleed: {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
  },
  cropMarks: {
    enabled: false,
    length: 0,
    offset: 0,
    strokeWidth: 0,
    color: "#000000",
  },
  registrationMarks: {
    enabled: false,
    size: 0,
    strokeWidth: 0,
  },
  resolution: 72,
  showColorBars: false,
};

// ============================================================================
// Dimension Calculations
// ============================================================================

/**
 * Calculate print dimensions with bleed
 * @param pageSize - Base page size
 * @param config - Print configuration
 * @returns Calculated dimensions
 */
export function calculatePrintDimensions(
  pageSize: PageDimensions | string,
  config: Partial<PrintConfig> = {}
): PrintDimensions {
  const fullConfig = { ...defaultPrintConfig, ...config };

  let baseDimensions: PageDimensions;
  if (typeof pageSize === "string") {
    baseDimensions = PAGE_SIZES[pageSize] || PAGE_SIZES.A4;
  } else {
    baseDimensions = pageSize;
  }

  const { bleed } = fullConfig;

  return {
    baseWidth: baseDimensions.width,
    baseHeight: baseDimensions.height,
    totalWidth: baseDimensions.width + bleed.left + bleed.right,
    totalHeight: baseDimensions.height + bleed.top + bleed.bottom,
    bleed,
  };
}

/**
 * Get page size with bleed for React-PDF Page component
 * @param pageSize - Base page size
 * @param config - Print configuration
 * @returns Object with width and height for Page size prop
 */
export function getPageSizeWithBleed(
  pageSize: PageDimensions | string,
  config: Partial<PrintConfig> = {}
): { width: number; height: number } {
  const dims = calculatePrintDimensions(pageSize, config);
  return {
    width: dims.totalWidth,
    height: dims.totalHeight,
  };
}

// ============================================================================
// Style Generation
// ============================================================================

/**
 * Generate print-ready styles for page layout
 * @param pageSize - Base page size
 * @param config - Print configuration
 * @returns Print-ready styles
 */
export function getPrintReadyStyles(
  pageSize: PageDimensions | string,
  config: Partial<PrintConfig> = {}
): PrintReadyStyles {
  const dims = calculatePrintDimensions(pageSize, config);

  return {
    page: {
      width: dims.totalWidth,
      height: dims.totalHeight,
      backgroundColor: "#ffffff",
    },
    contentArea: {
      position: "absolute",
      top: dims.bleed.top,
      left: dims.bleed.left,
      width: dims.baseWidth,
      height: dims.baseHeight,
    },
    bleedArea: {
      position: "absolute",
      top: 0,
      left: 0,
      width: dims.totalWidth,
      height: dims.totalHeight,
    },
  };
}

// ============================================================================
// Crop Mark Calculations
// ============================================================================

/**
 * Calculate crop mark positions
 * @param dimensions - Print dimensions
 * @param config - Crop marks configuration
 * @returns Array of crop mark line positions
 */
export function calculateCropMarks(
  dimensions: PrintDimensions,
  config: CropMarksConfig = defaultPrintConfig.cropMarks
): CropMarkPosition[] {
  if (!config.enabled) return [];

  const { totalWidth, totalHeight, bleed } = dimensions;
  const { length, offset } = config;

  const marks: CropMarkPosition[] = [];

  // Top-left corner (horizontal)
  marks.push({
    x1: bleed.left - offset - length,
    y1: bleed.top,
    x2: bleed.left - offset,
    y2: bleed.top,
  });

  // Top-left corner (vertical)
  marks.push({
    x1: bleed.left,
    y1: bleed.top - offset - length,
    x2: bleed.left,
    y2: bleed.top - offset,
  });

  // Top-right corner (horizontal)
  marks.push({
    x1: totalWidth - bleed.right + offset,
    y1: bleed.top,
    x2: totalWidth - bleed.right + offset + length,
    y2: bleed.top,
  });

  // Top-right corner (vertical)
  marks.push({
    x1: totalWidth - bleed.right,
    y1: bleed.top - offset - length,
    x2: totalWidth - bleed.right,
    y2: bleed.top - offset,
  });

  // Bottom-left corner (horizontal)
  marks.push({
    x1: bleed.left - offset - length,
    y1: totalHeight - bleed.bottom,
    x2: bleed.left - offset,
    y2: totalHeight - bleed.bottom,
  });

  // Bottom-left corner (vertical)
  marks.push({
    x1: bleed.left,
    y1: totalHeight - bleed.bottom + offset,
    x2: bleed.left,
    y2: totalHeight - bleed.bottom + offset + length,
  });

  // Bottom-right corner (horizontal)
  marks.push({
    x1: totalWidth - bleed.right + offset,
    y1: totalHeight - bleed.bottom,
    x2: totalWidth - bleed.right + offset + length,
    y2: totalHeight - bleed.bottom,
  });

  // Bottom-right corner (vertical)
  marks.push({
    x1: totalWidth - bleed.right,
    y1: totalHeight - bleed.bottom + offset,
    x2: totalWidth - bleed.right,
    y2: totalHeight - bleed.bottom + offset + length,
  });

  return marks;
}

/**
 * Calculate registration mark positions
 * @param dimensions - Print dimensions
 * @param config - Registration marks configuration
 * @returns Array of positions for registration marks
 */
export function calculateRegistrationMarks(
  dimensions: PrintDimensions,
  config: RegistrationMarksConfig = defaultPrintConfig.registrationMarks
): Array<{ x: number; y: number }> {
  if (!config.enabled) return [];

  const { totalWidth, totalHeight, bleed } = dimensions;

  // Place marks at center of each edge in the bleed area
  return [
    { x: totalWidth / 2, y: bleed.top / 2 }, // Top center
    { x: totalWidth / 2, y: totalHeight - bleed.bottom / 2 }, // Bottom center
    { x: bleed.left / 2, y: totalHeight / 2 }, // Left center
    { x: totalWidth - bleed.right / 2, y: totalHeight / 2 }, // Right center
  ];
}

// ============================================================================
// Safe Zone Calculations
// ============================================================================

/**
 * Calculate safe zone (area guaranteed not to be trimmed)
 * @param dimensions - Print dimensions
 * @param safeMargin - Additional margin from trim edge (default: 10pt)
 * @returns Safe zone boundaries
 */
export function calculateSafeZone(
  dimensions: PrintDimensions,
  safeMargin: number = 10
): {
  top: number;
  right: number;
  bottom: number;
  left: number;
  width: number;
  height: number;
} {
  const { bleed, baseWidth, baseHeight } = dimensions;

  return {
    top: bleed.top + safeMargin,
    left: bleed.left + safeMargin,
    right: bleed.right + safeMargin,
    bottom: bleed.bottom + safeMargin,
    width: baseWidth - safeMargin * 2,
    height: baseHeight - safeMargin * 2,
  };
}

// ============================================================================
// Validation
// ============================================================================

/**
 * Validate print configuration
 * @param config - Configuration to validate
 * @returns Validation result
 */
export function validatePrintConfig(config: Partial<PrintConfig>): {
  valid: boolean;
  errors: string[];
  warnings: string[];
} {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Validate bleed
  if (config.bleed) {
    const { top, right, bottom, left } = config.bleed;
    if (top < 0 || right < 0 || bottom < 0 || left < 0) {
      errors.push("Bleed values cannot be negative");
    }
    if (top > 72 || right > 72 || bottom > 72 || left > 72) {
      warnings.push("Bleed values over 1 inch (72pt) are unusually large");
    }
  }

  // Validate resolution
  if (config.resolution !== undefined) {
    if (config.resolution < 72) {
      warnings.push("Resolution below 72 DPI may result in poor print quality");
    }
    if (config.resolution > 600) {
      warnings.push("Resolution above 600 DPI is typically unnecessary");
    }
  }

  // Validate crop marks
  if (config.cropMarks?.enabled) {
    if (!config.bleed || Object.values(config.bleed).every((v) => v === 0)) {
      errors.push("Crop marks require bleed area to be set");
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

// ============================================================================
// Default Export
// ============================================================================

export default {
  mmToPoints,
  pointsToMm,
  inchesToPoints,
  pointsToInches,
  calculatePrintDimensions,
  getPageSizeWithBleed,
  getPrintReadyStyles,
  calculateCropMarks,
  calculateRegistrationMarks,
  calculateSafeZone,
  validatePrintConfig,
  PAGE_SIZES,
  defaultPrintConfig,
  professionalPrintConfig,
  digitalConfig,
};
