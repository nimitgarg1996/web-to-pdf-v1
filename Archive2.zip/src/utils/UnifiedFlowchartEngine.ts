/**
 * UnifiedFlowchartEngine
 * 
 * A comprehensive flowchart generation engine supporting both:
 * 1. Automatic Layout (Elk) - For dynamic/simple flowcharts
 * 2. Manual Pixel-Perfect - For exact design matching
 * 
 * Usage:
 * - Use 'auto' mode for quick flowcharts with automatic positioning
 * - Use 'manual' mode when you need pixel-perfect control
 * - Use 'hybrid' mode for auto-layout with manual position overrides
 */

import ELK, { ElkNode, ElkExtendedEdge, LayoutOptions } from 'elkjs';
import * as d3 from 'd3';
import { JSDOM } from 'jsdom';

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Absolute position in pixels
 */
export interface Position {
  x: number;
  y: number;
}

/**
 * Relative position (0-1 as percentage of canvas, or anchor-based)
 */
export interface RelativePosition {
  // Percentage-based (0-1 = 0%-100% of canvas)
  xPercent?: number;  // e.g., 0.5 = center
  yPercent?: number;
  
  // Anchor-based (relative to another node)
  anchorId?: string;  // Reference node ID
  offsetX?: number;   // Offset from anchor (in pixels)
  offsetY?: number;
  
  // Grid-based (row/column system)
  row?: number;       // Row index (0-based)
  col?: number;       // Column index (0-based)
  
  // Direct pixel values (fallback)
  x?: number;
  y?: number;
}

/**
 * Spacing configuration for relative positioning
 */
export interface SpacingConfig {
  rowHeight?: number;      // Height per row (default: 100)
  colWidth?: number;       // Width per column (default: 120)
  marginTop?: number;      // Top margin
  marginBottom?: number;
  marginLeft?: number;
  marginRight?: number;
  rows?: number;           // Total rows in grid
  cols?: number;           // Total columns in grid
}

export interface FlowchartNode {
  id: string;
  label: string;
  type?: 'default' | 'trust' | 'gift' | 'separator' | 'annotation';
  icon?: 'building' | 'gift' | 'document' | 'none';
  color?: string;
  width?: number;
  height?: number;
  // Positioning options (supports multiple formats)
  position?: Position;           // Absolute pixels
  relativePosition?: RelativePosition;  // Percentage/anchor/grid
  metadata?: Record<string, any>;
}

export interface FlowchartEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  type?: 'default' | 'orthogonal' | 'spline';
  // Manual path points (optional - for manual mode)
  points?: Position[];
  labelPosition?: Position;
}

export interface FlowchartSeparator {
  id: string;
  label: string;
  y: number;  // Y position for the separator line
  style?: 'dashed' | 'solid';
  gapWidth?: number;
}

export interface FlowchartAnnotation {
  id: string;
  lines: string[];
  position: Position;
  align?: 'left' | 'center' | 'right';
}

export interface FlowchartSideNote {
  id: string;
  lines: string[];
  position: Position;
}

export interface FlowchartBadge {
  id: string;
  text: string;
  position: Position;
}

export type LayoutMode = 'auto' | 'manual' | 'hybrid' | 'relative';

export interface FlowchartConfig {
  mode: LayoutMode;
  width: number;
  height: number;
  padding?: number;
  nodeSpacing?: number;
  layerSpacing?: number;
  edgeStyle?: 'orthogonal' | 'spline' | 'polyline';
  direction?: 'DOWN' | 'RIGHT' | 'UP' | 'LEFT';
  colors?: {
    line?: string;
    text?: string;
    muted?: string;
    background?: string;
    separator?: string;
  };
  fonts?: {
    family?: string;
    labelSize?: number;
    edgeLabelSize?: number;
    annotationSize?: number;
    sideNoteSize?: number;
  };
  nodeDefaults?: {
    width?: number;
    height?: number;
    borderRadius?: number;
  };
  // Relative positioning config
  spacing?: SpacingConfig;
}

export interface FlowchartData {
  nodes: FlowchartNode[];
  edges: FlowchartEdge[];
  separators?: FlowchartSeparator[];
  annotations?: FlowchartAnnotation[];
  sideNotes?: FlowchartSideNote[];
  badges?: FlowchartBadge[];
}

export interface GenerateResult {
  svg: string;
  width: number;
  height: number;
}

// ============================================================================
// Default Configuration
// ============================================================================

const DEFAULT_CONFIG: FlowchartConfig = {
  mode: 'auto',
  width: 580,
  height: 720,
  padding: 40,
  nodeSpacing: 50,
  layerSpacing: 100,
  edgeStyle: 'orthogonal',
  direction: 'DOWN',
  colors: {
    line: '#C9CDD3',
    text: '#374151',
    muted: '#6B7280',
    background: 'white',
    separator: '#9CA3AF',
  },
  fonts: {
    family: 'Inter, -apple-system, sans-serif',
    labelSize: 11,
    edgeLabelSize: 10,
    annotationSize: 10,
    sideNoteSize: 9,
  },
  nodeDefaults: {
    width: 68,
    height: 52,
    borderRadius: 12,
  },
};

const NODE_COLORS: Record<string, string> = {
  trust: '#2D9B9B',
  gift: '#FF8A65',
  survivor: '#A78BFA',
  bypass: '#60A5FA',
  marital: '#5AB2B2',
  child: '#2D7B7B',
  default: '#6B7280',
};

// ============================================================================
// SVG Icons
// ============================================================================

const ICONS: Record<string, (color: string) => string> = {
  building: (color: string) => `<g transform="scale(0.9)"><path d="M12 2L3 9v13h18V9L12 2z" fill="white"/><rect x="7" y="12" width="3" height="3" fill="${color}" opacity="0.5"/><rect x="11" y="12" width="3" height="3" fill="${color}" opacity="0.5"/><rect x="9" y="17" width="4" height="5" fill="${color}" opacity="0.5"/></g>`,
  gift: (color: string) => `<g transform="scale(0.85)"><rect x="4" y="11" width="16" height="9" rx="1" fill="white"/><rect x="3" y="8" width="18" height="4" rx="1" fill="white"/><line x1="12" y1="8" x2="12" y2="20" stroke="${color}" stroke-width="2.5"/></g>`,
  document: (color: string) => `<g transform="scale(0.85)"><rect x="5" y="2" width="14" height="18" rx="1.5" fill="white"/><rect x="7" y="6" width="10" height="2.5" rx="1" fill="${color}" opacity="0.3"/><rect x="7" y="10" width="10" height="2.5" rx="1" fill="${color}" opacity="0.3"/><rect x="7" y="14" width="6" height="2.5" rx="1" fill="${color}" opacity="0.3"/></g>`,
};

// ============================================================================
// Unified Flowchart Engine Class
// ============================================================================

export class UnifiedFlowchartEngine {
  private elk: ELK;
  private config: FlowchartConfig;

  constructor(config: Partial<FlowchartConfig> = {}) {
    this.elk = new ELK();
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Generate SVG from flowchart data
   * Automatically chooses rendering approach based on mode
   */
  async generate(data: FlowchartData): Promise<GenerateResult> {
    switch (this.config.mode) {
      case 'manual':
        return this.generateManual(data);
      case 'hybrid':
        return this.generateHybrid(data);
      case 'relative':
        return this.generateRelative(data);
      case 'auto':
      default:
        return this.generateAuto(data);
    }
  }

  /**
   * AUTO MODE: Use Elkjs for automatic layout
   */
  private async generateAuto(data: FlowchartData): Promise<GenerateResult> {
    const { nodes, edges, separators, annotations, sideNotes, badges } = data;
    
    // Build and run ELK layout
    const elkGraph = this.buildElkGraph(nodes, edges);
    const layoutedGraph = await this.elk.layout(elkGraph);
    
    // Build position map from layout results
    const nodePositions = this.extractPositionsFromElk(layoutedGraph);
    
    // Render SVG
    const svg = this.renderSVG(data, nodePositions, layoutedGraph.edges || []);
    
    return {
      svg,
      width: layoutedGraph.width || this.config.width,
      height: layoutedGraph.height || this.config.height,
    };
  }

  /**
   * MANUAL MODE: Use explicit positions from node/edge definitions
   */
  private async generateManual(data: FlowchartData): Promise<GenerateResult> {
    // Build position map from manual positions
    const nodePositions = new Map<string, Position>();
    for (const node of data.nodes) {
      if (node.position) {
        nodePositions.set(node.id, node.position);
      } else {
        console.warn(`Manual mode: Node ${node.id} missing position, placing at origin`);
        nodePositions.set(node.id, { x: 0, y: 0 });
      }
    }
    
    // Render SVG with manual positions
    const svg = this.renderSVG(data, nodePositions);
    
    return {
      svg,
      width: this.config.width,
      height: this.config.height,
    };
  }

  /**
   * RELATIVE MODE: Use relative/percentage-based positioning
   * Positions are calculated based on canvas dimensions
   */
  private async generateRelative(data: FlowchartData): Promise<GenerateResult> {
    const { width, height } = this.config;
    const nodePositions = new Map<string, Position>();
    
    // First pass: resolve all relative positions to absolute
    for (const node of data.nodes) {
      const pos = this.resolveRelativePosition(node, nodePositions, data.nodes);
      nodePositions.set(node.id, pos);
    }
    
    // Render SVG with resolved positions
    const svg = this.renderSVG(data, nodePositions);
    
    return {
      svg,
      width: this.config.width,
      height: this.config.height,
    };
  }

  /**
   * Resolve a node's relative position to absolute coordinates
   */
  private resolveRelativePosition(
    node: FlowchartNode,
    resolvedPositions: Map<string, Position>,
    allNodes: FlowchartNode[]
  ): Position {
    const { width, height, spacing, padding } = this.config;
    const p = padding || 40;
    const effectiveWidth = width - p * 2;
    const effectiveHeight = height - p * 2;
    
    // If absolute position provided, use it directly
    if (node.position) {
      return node.position;
    }
    
    const rel = node.relativePosition;
    if (!rel) {
      console.warn(`Node ${node.id} missing position, using center`);
      return { x: width / 2, y: height / 2 };
    }
    
    // Priority 1: Direct pixel values
    if (rel.x !== undefined && rel.y !== undefined) {
      return { x: rel.x, y: rel.y };
    }
    
    // Priority 2: Percentage-based (0-1 = 0%-100%)
    if (rel.xPercent !== undefined && rel.yPercent !== undefined) {
      return {
        x: p + effectiveWidth * rel.xPercent,
        y: p + effectiveHeight * rel.yPercent,
      };
    }
    
    // Priority 3: Grid-based (row/col)
    if (rel.row !== undefined && rel.col !== undefined) {
      const sp = spacing || {};
      const rows = sp.rows || 6;
      const cols = sp.cols || 5;
      const rowHeight = sp.rowHeight || (effectiveHeight / rows);
      const colWidth = sp.colWidth || (effectiveWidth / cols);
      const marginTop = sp.marginTop || p;
      const marginLeft = sp.marginLeft || p;
      
      return {
        x: marginLeft + colWidth * (rel.col + 0.5),
        y: marginTop + rowHeight * (rel.row + 0.5),
      };
    }
    
    // Priority 4: Anchor-based (relative to another node)
    if (rel.anchorId) {
      const anchorPos = resolvedPositions.get(rel.anchorId);
      if (anchorPos) {
        return {
          x: anchorPos.x + (rel.offsetX || 0),
          y: anchorPos.y + (rel.offsetY || 0),
        };
      }
      // Anchor not resolved yet - find and resolve it
      const anchorNode = allNodes.find(n => n.id === rel.anchorId);
      if (anchorNode) {
        const anchorResolved = this.resolveRelativePosition(anchorNode, resolvedPositions, allNodes);
        resolvedPositions.set(rel.anchorId, anchorResolved);
        return {
          x: anchorResolved.x + (rel.offsetX || 0),
          y: anchorResolved.y + (rel.offsetY || 0),
        };
      }
    }
    
    console.warn(`Could not resolve position for node ${node.id}`);
    return { x: width / 2, y: height / 2 };
  }

  /**
   * HYBRID MODE: Auto-layout with manual position overrides
   */
  private async generateHybrid(data: FlowchartData): Promise<GenerateResult> {
    const { nodes, edges } = data;
    
    // Separate nodes with and without manual positions
    const autoNodes = nodes.filter(n => !n.position);
    const manualNodes = nodes.filter(n => n.position);
    
    // Run ELK layout on auto nodes only
    const nodePositions = new Map<string, Position>();
    
    if (autoNodes.length > 0) {
      const elkGraph = this.buildElkGraph(autoNodes, edges);
      const layoutedGraph = await this.elk.layout(elkGraph);
      
      // Extract positions from ELK
      if (layoutedGraph.children) {
        for (const child of layoutedGraph.children) {
          const w = child.width || this.config.nodeDefaults!.width!;
          const h = child.height || this.config.nodeDefaults!.height!;
          nodePositions.set(child.id, {
            x: (child.x || 0) + w / 2,
            y: (child.y || 0) + h / 2,
          });
        }
      }
    }
    
    // Override with manual positions
    for (const node of manualNodes) {
      nodePositions.set(node.id, node.position!);
    }
    
    // Render SVG
    const svg = this.renderSVG(data, nodePositions);
    
    return {
      svg,
      width: this.config.width,
      height: this.config.height,
    };
  }

  /**
   * Build ELK graph structure
   */
  private buildElkGraph(nodes: FlowchartNode[], edges: FlowchartEdge[]): ElkNode {
    const layoutOptions: LayoutOptions = {
      'elk.algorithm': 'layered',
      'elk.direction': this.config.direction,
      'elk.spacing.nodeNode': String(this.config.nodeSpacing),
      'elk.layered.spacing.nodeNodeBetweenLayers': String(this.config.layerSpacing),
      'elk.edgeRouting': this.config.edgeStyle === 'orthogonal' ? 'ORTHOGONAL' : 'SPLINES',
      'elk.layered.nodePlacement.strategy': 'NETWORK_SIMPLEX',
      'elk.layered.crossingMinimization.strategy': 'LAYER_SWEEP',
    };

    const elkNodes: ElkNode[] = nodes.map((node) => ({
      id: node.id,
      width: node.width || this.config.nodeDefaults!.width,
      height: node.height || this.config.nodeDefaults!.height,
      labels: [{ text: node.label }],
    }));

    const validNodeIds = new Set(nodes.map(n => n.id));
    const elkEdges: ElkExtendedEdge[] = edges
      .filter(e => validNodeIds.has(e.source) && validNodeIds.has(e.target))
      .map((edge) => ({
        id: edge.id,
        sources: [edge.source],
        targets: [edge.target],
        labels: edge.label ? [{ text: edge.label }] : [],
      }));

    return {
      id: 'root',
      layoutOptions,
      children: elkNodes,
      edges: elkEdges,
    };
  }

  /**
   * Extract node positions from ELK layout result
   */
  private extractPositionsFromElk(graph: ElkNode): Map<string, Position> {
    const positions = new Map<string, Position>();
    
    if (graph.children) {
      for (const child of graph.children) {
        const w = child.width || this.config.nodeDefaults!.width!;
        const h = child.height || this.config.nodeDefaults!.height!;
        positions.set(child.id, {
          x: (child.x || 0) + w / 2,
          y: (child.y || 0) + h / 2,
        });
      }
    }
    
    return positions;
  }

  /**
   * Render complete SVG
   */
  private renderSVG(
    data: FlowchartData,
    nodePositions: Map<string, Position>,
    elkEdges?: ElkExtendedEdge[]
  ): string {
    const dom = new JSDOM('<!DOCTYPE html><html><body></body></html>');
    const document = dom.window.document;

    const { width, height, padding } = this.config;
    const p = padding || 40;

    const svg = d3.select(document.body)
      .append('svg')
      .attr('xmlns', 'http://www.w3.org/2000/svg')
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('style', `font-family: ${this.config.fonts?.family}; background: ${this.config.colors?.background}`);

    // Add defs
    const defs = svg.append('defs');
    defs.append('marker')
      .attr('id', 'arrowhead')
      .attr('markerWidth', 8)
      .attr('markerHeight', 6)
      .attr('refX', 7)
      .attr('refY', 3)
      .attr('orient', 'auto')
      .append('polygon')
      .attr('points', '0 0, 8 3, 0 6')
      .attr('fill', this.config.colors?.line);

    // Render layers in order
    this.renderSeparators(svg, data.separators || []);
    this.renderAnnotations(svg, data.annotations || []);
    
    if (this.config.mode === 'manual') {
      this.renderManualEdges(svg, data.edges, nodePositions, data.nodes);
    } else {
      this.renderAutoEdges(svg, elkEdges || [], data.edges);
    }
    
    this.renderNodes(svg, data.nodes, nodePositions);
    this.renderBadges(svg, data.badges || []);
    this.renderSideNotes(svg, data.sideNotes || []);

    return document.body.innerHTML;
  }

  /**
   * Render separator lines
   */
  private renderSeparators(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    separators: FlowchartSeparator[]
  ): void {
    const group = svg.append('g').attr('class', 'separators');
    const { width } = this.config;
    const lineColor = this.config.colors?.line || '#C9CDD3';
    const textColor = this.config.colors?.separator || '#9CA3AF';
    
    for (const sep of separators) {
      const gapWidth = sep.gapWidth || 90;
      const centerX = width / 2;
      const strokeDash = sep.style === 'solid' ? 'none' : '6,4';
      
      // Left line
      group.append('line')
        .attr('x1', 30)
        .attr('y1', sep.y)
        .attr('x2', centerX - gapWidth)
        .attr('y2', sep.y)
        .attr('stroke', lineColor)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', strokeDash);
      
      // Right line
      group.append('line')
        .attr('x1', centerX + gapWidth)
        .attr('y1', sep.y)
        .attr('x2', width - 30)
        .attr('y2', sep.y)
        .attr('stroke', lineColor)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', strokeDash);
      
      // Text
      group.append('text')
        .attr('x', centerX)
        .attr('y', sep.y + 4)
        .attr('text-anchor', 'middle')
        .attr('font-size', 11)
        .attr('fill', textColor)
        .text(sep.label);
    }
  }

  /**
   * Render annotation text blocks
   */
  private renderAnnotations(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    annotations: FlowchartAnnotation[]
  ): void {
    const group = svg.append('g').attr('class', 'annotations');
    const mutedColor = this.config.colors?.muted || '#6B7280';
    const fontSize = this.config.fonts?.annotationSize || 10;
    
    for (const annot of annotations) {
      const anchor = annot.align === 'left' ? 'start' : annot.align === 'right' ? 'end' : 'middle';
      
      annot.lines.forEach((line, i) => {
        group.append('text')
          .attr('x', annot.position.x)
          .attr('y', annot.position.y + i * (fontSize + 5))
          .attr('text-anchor', anchor)
          .attr('font-size', fontSize)
          .attr('fill', mutedColor)
          .text(line);
      });
    }
  }

  /**
   * Render edges with manual path points
   */
  private renderManualEdges(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    edges: FlowchartEdge[],
    nodePositions: Map<string, Position>,
    nodes: FlowchartNode[]
  ): void {
    const group = svg.append('g').attr('class', 'edges');
    const lineColor = this.config.colors?.line || '#C9CDD3';
    
    for (const edge of edges) {
      if (edge.points && edge.points.length >= 2) {
        // Use explicit path points
        const pathData = this.createPathFromPoints(edge.points);
        group.append('path')
          .attr('d', pathData)
          .attr('fill', 'none')
          .attr('stroke', lineColor)
          .attr('stroke-width', 2)
          .attr('marker-end', 'url(#arrowhead)');
      } else {
        // Generate simple direct path
        const sourcePos = nodePositions.get(edge.source);
        const targetPos = nodePositions.get(edge.target);
        
        if (sourcePos && targetPos) {
          const sourceNode = nodes.find(n => n.id === edge.source);
          const targetNode = nodes.find(n => n.id === edge.target);
          const sourceH = (sourceNode?.height || this.config.nodeDefaults!.height!) / 2;
          const targetH = (targetNode?.height || this.config.nodeDefaults!.height!) / 2;
          
          group.append('line')
            .attr('x1', sourcePos.x)
            .attr('y1', sourcePos.y + sourceH + 15) // Below label
            .attr('x2', targetPos.x)
            .attr('y2', targetPos.y - targetH - 5)
            .attr('stroke', lineColor)
            .attr('stroke-width', 2)
            .attr('marker-end', 'url(#arrowhead)');
        }
      }
      
      // Edge label
      if (edge.label && edge.labelPosition) {
        this.renderEdgeLabel(group, edge.label, edge.labelPosition);
      }
    }
  }

  /**
   * Render edges from ELK layout
   */
  private renderAutoEdges(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    elkEdges: ElkExtendedEdge[],
    originalEdges: FlowchartEdge[]
  ): void {
    const group = svg.append('g').attr('class', 'edges');
    const lineColor = this.config.colors?.line || '#C9CDD3';
    
    for (const elkEdge of elkEdges) {
      const original = originalEdges.find(e => e.id === elkEdge.id);
      
      if (elkEdge.sections && elkEdge.sections.length > 0) {
        const section = elkEdge.sections[0];
        const points = [
          section.startPoint,
          ...(section.bendPoints || []),
          section.endPoint,
        ];
        
        const pathData = this.createPathFromPoints(points);
        group.append('path')
          .attr('d', pathData)
          .attr('fill', 'none')
          .attr('stroke', lineColor)
          .attr('stroke-width', 2)
          .attr('marker-end', 'url(#arrowhead)');
        
        // Edge label
        if (original?.label && elkEdge.labels && elkEdge.labels.length > 0) {
          const labelPos = elkEdge.labels[0];
          if (labelPos.x !== undefined && labelPos.y !== undefined) {
            this.renderEdgeLabel(group, original.label, { x: labelPos.x, y: labelPos.y });
          }
        }
      }
    }
  }

  /**
   * Render edge label badge
   */
  private renderEdgeLabel(
    group: d3.Selection<SVGGElement, unknown, null, undefined>,
    label: string,
    position: Position
  ): void {
    group.append('rect')
      .attr('x', position.x - 24)
      .attr('y', position.y - 10)
      .attr('width', 48)
      .attr('height', 20)
      .attr('rx', 10)
      .attr('fill', 'white')
      .attr('stroke', '#E5E7EB')
      .attr('stroke-width', 1);
    
    group.append('text')
      .attr('x', position.x)
      .attr('y', position.y + 4)
      .attr('text-anchor', 'middle')
      .attr('font-size', this.config.fonts?.edgeLabelSize)
      .attr('fill', this.config.colors?.muted)
      .text(label);
  }

  /**
   * Create SVG path from points with rounded corners
   */
  private createPathFromPoints(points: Position[]): string {
    if (points.length < 2) return '';

    const radius = 8;
    let d = `M ${points[0].x},${points[0].y}`;

    for (let i = 1; i < points.length - 1; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const next = points[i + 1];

      const dx1 = curr.x - prev.x;
      const dy1 = curr.y - prev.y;
      const dx2 = next.x - curr.x;
      const dy2 = next.y - curr.y;

      const len1 = Math.sqrt(dx1 * dx1 + dy1 * dy1);
      const len2 = Math.sqrt(dx2 * dx2 + dy2 * dy2);

      if (len1 === 0 || len2 === 0) {
        d += ` L ${curr.x},${curr.y}`;
        continue;
      }

      const r = Math.min(radius, len1 / 2, len2 / 2);
      const x1 = curr.x - (dx1 / len1) * r;
      const y1 = curr.y - (dy1 / len1) * r;
      const x2 = curr.x + (dx2 / len2) * r;
      const y2 = curr.y + (dy2 / len2) * r;

      d += ` L ${x1},${y1}`;
      d += ` Q ${curr.x},${curr.y} ${x2},${y2}`;
    }

    const last = points[points.length - 1];
    d += ` L ${last.x},${last.y}`;

    return d;
  }

  /**
   * Render nodes
   */
  private renderNodes(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    nodes: FlowchartNode[],
    positions: Map<string, Position>
  ): void {
    const group = svg.append('g').attr('class', 'nodes');
    
    for (const node of nodes) {
      const pos = positions.get(node.id);
      if (!pos) continue;
      
      const w = node.width || this.config.nodeDefaults!.width!;
      const h = node.height || this.config.nodeDefaults!.height!;
      const r = this.config.nodeDefaults!.borderRadius!;
      const color = node.color || NODE_COLORS[node.type || 'default'];
      
      const g = group.append('g')
        .attr('transform', `translate(${pos.x}, ${pos.y})`);
      
      // Background rect
      g.append('rect')
        .attr('x', -w / 2)
        .attr('y', -h / 2)
        .attr('width', w)
        .attr('height', h)
        .attr('rx', r)
        .attr('fill', color);
      
      // Icon
      if (node.icon && node.icon !== 'none') {
        const iconFn = ICONS[node.icon] || ICONS.document;
        g.append('g')
          .attr('transform', 'translate(-12, -12)')
          .html(iconFn(color));
      }
      
      // Label
      g.append('text')
        .attr('y', h / 2 + 15)
        .attr('text-anchor', 'middle')
        .attr('font-size', this.config.fonts?.labelSize)
        .attr('font-weight', '500')
        .attr('fill', this.config.colors?.text)
        .text(node.label);
    }
  }

  /**
   * Render standalone badges
   */
  private renderBadges(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    badges: FlowchartBadge[]
  ): void {
    const group = svg.append('g').attr('class', 'badges');
    
    for (const badge of badges) {
      group.append('rect')
        .attr('x', badge.position.x - 24)
        .attr('y', badge.position.y - 10)
        .attr('width', 48)
        .attr('height', 20)
        .attr('rx', 10)
        .attr('fill', 'white')
        .attr('stroke', '#E5E7EB')
        .attr('stroke-width', 1);
      
      group.append('text')
        .attr('x', badge.position.x)
        .attr('y', badge.position.y + 4)
        .attr('text-anchor', 'middle')
        .attr('font-size', this.config.fonts?.edgeLabelSize)
        .attr('fill', this.config.colors?.muted)
        .text(badge.text);
    }
  }

  /**
   * Render side notes
   */
  private renderSideNotes(
    svg: d3.Selection<SVGSVGElement, unknown, null, undefined>,
    sideNotes: FlowchartSideNote[]
  ): void {
    const group = svg.append('g').attr('class', 'side-notes');
    const mutedColor = this.config.colors?.muted || '#6B7280';
    const fontSize = this.config.fonts?.sideNoteSize || 9;
    
    for (const note of sideNotes) {
      note.lines.forEach((line, i) => {
        group.append('text')
          .attr('x', note.position.x)
          .attr('y', note.position.y + i * (fontSize + 3))
          .attr('font-size', fontSize)
          .attr('fill', mutedColor)
          .text(line);
      });
    }
  }
}

// ============================================================================
// Factory Functions
// ============================================================================

/**
 * Create a pixel-perfect manual trust structure (matching wealth.com design)
 */
export function createManualTrustStructure(): FlowchartData {
  const CX = 290; // Center X
  
  // Precise Y coordinates
  const Y = {
    root: 55,
    sep1: 130,
    junct1: 165,
    annot: 200,
    trusts: 330,
    sep2: 420,
    junct2: 455,
    children: 600,
  };
  
  // Precise X coordinates
  const X = {
    root: CX,
    gift1: 520,
    survivor: 150,
    bypass: 320,
    marital: 490,
    gift2: 520,
    jane: 270,
    john: 410,
  };

  const nodes: FlowchartNode[] = [
    { id: 'root', label: 'Doe-Smith Revocable Trust', type: 'trust', icon: 'building', color: '#2D9B9B', position: { x: X.root, y: Y.root } },
    { id: 'gift1', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48, position: { x: X.gift1, y: Y.junct1 + 28 } },
    { id: 'survivor', label: "Survivor's Trust", type: 'trust', icon: 'document', color: '#A78BFA', position: { x: X.survivor, y: Y.trusts } },
    { id: 'bypass', label: 'Bypass Trust', type: 'trust', icon: 'document', color: '#60A5FA', position: { x: X.bypass, y: Y.trusts } },
    { id: 'marital', label: 'Marital Trust', type: 'trust', icon: 'document', color: '#5AB2B2', position: { x: X.marital, y: Y.trusts } },
    { id: 'gift2', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48, position: { x: X.gift2, y: Y.junct2 + 28 } },
    { id: 'jane', label: 'Jane Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B', position: { x: X.jane, y: Y.children } },
    { id: 'john', label: 'John Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B', position: { x: X.john, y: Y.children } },
  ];

  // Manual edge paths for pixel-perfect connections
  const edges: FlowchartEdge[] = [
    // Root → Gift1 (T-junction branch right)
    { id: 'e1', source: 'root', target: 'gift1', points: [
      { x: X.root, y: Y.sep1 + 8 },
      { x: X.root, y: Y.junct1 },
      { x: X.gift1 - 33, y: Y.junct1 },
      { x: X.gift1, y: Y.junct1 },
    ]},
    // Root → Survivor
    { id: 'e2', source: 'root', target: 'survivor', points: [
      { x: X.survivor, y: Y.annot + 40 },
      { x: X.survivor, y: Y.trusts - 31 },
    ]},
    // Root → Bypass
    { id: 'e3', source: 'root', target: 'bypass', points: [
      { x: X.bypass, y: Y.annot + 40 },
      { x: X.bypass, y: Y.trusts - 31 },
    ]},
    // Root → Marital
    { id: 'e4', source: 'root', target: 'marital', points: [
      { x: X.marital, y: Y.annot + 40 },
      { x: X.marital, y: Y.trusts - 31 },
    ]},
    // Bypass → Gift2 (T-junction branch right)
    { id: 'e5', source: 'bypass', target: 'gift2', points: [
      { x: X.bypass, y: Y.sep2 + 8 },
      { x: X.bypass, y: Y.junct2 },
      { x: X.gift2 - 33, y: Y.junct2 },
      { x: X.gift2, y: Y.junct2 },
    ]},
    // Bypass → Jane
    { id: 'e6', source: 'bypass', target: 'jane', label: '50%', points: [
      { x: X.jane, y: Y.junct2 + 65 },
      { x: X.jane, y: Y.children - 31 },
    ], labelPosition: { x: X.jane, y: Y.junct2 + 100 }},
    // Bypass → John  
    { id: 'e7', source: 'bypass', target: 'john', label: '50%', points: [
      { x: X.john, y: Y.junct2 + 65 },
      { x: X.john, y: Y.children - 31 },
    ], labelPosition: { x: X.john, y: Y.junct2 + 100 }},
  ];

  const separators: FlowchartSeparator[] = [
    { id: 'sep1', label: 'Death of First Spouse', y: Y.sep1, style: 'dashed' },
    { id: 'sep2', label: 'Death of Surviving Spouse', y: Y.sep2, style: 'dashed' },
  ];

  const annotations: FlowchartAnnotation[] = [
    { 
      id: 'annot1', 
      lines: ["Surviving Spouse's Separate", "Property and Share of Marital Property"],
      position: { x: 150, y: Y.annot },
      align: 'center'
    },
    { 
      id: 'annot2', 
      lines: ["Deceased Spouse's Separate Property", "and Share of Marital Property"],
      position: { x: 400, y: Y.annot },
      align: 'center'
    },
  ];

  const sideNotes: FlowchartSideNote[] = [
    {
      id: 'note1',
      lines: [
        "If a child of the Grantors has",
        "not yet attained 21 years of",
        "age, trust assets will be held",
        "in a pot trust for the benefit of",
        "the Grantors' descendants",
        "until such time as the",
        "youngest living child of the",
        "Grantors attains age 21."
      ],
      position: { x: 35, y: Y.junct2 + 10 }
    }
  ];

  return { nodes, edges, separators, annotations, sideNotes };
}

/**
 * Create a simple auto-layout trust structure
 */
export function createAutoTrustStructure(): FlowchartData {
  const nodes: FlowchartNode[] = [
    { id: 'root', label: 'Doe-Smith Revocable Trust', type: 'trust', icon: 'building', color: '#2D9B9B' },
    { id: 'gift1', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48 },
    { id: 'survivor', label: "Survivor's Trust", type: 'trust', icon: 'document', color: '#A78BFA' },
    { id: 'bypass', label: 'Bypass Trust', type: 'trust', icon: 'document', color: '#60A5FA' },
    { id: 'marital', label: 'Marital Trust', type: 'trust', icon: 'document', color: '#5AB2B2' },
    { id: 'gift2', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48 },
    { id: 'jane', label: 'Jane Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B' },
    { id: 'john', label: 'John Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B' },
  ];

  const edges: FlowchartEdge[] = [
    { id: 'e1', source: 'root', target: 'gift1' },
    { id: 'e2', source: 'root', target: 'survivor' },
    { id: 'e3', source: 'root', target: 'bypass' },
    { id: 'e4', source: 'root', target: 'marital' },
    { id: 'e5', source: 'bypass', target: 'gift2' },
    { id: 'e6', source: 'bypass', target: 'jane', label: '50%' },
    { id: 'e7', source: 'bypass', target: 'john', label: '50%' },
  ];

  return { nodes, edges };
}

/**
 * Create trust structure using RELATIVE positioning (percentage-based)
 * This scales automatically with canvas dimensions while maintaining structure
 */
export function createRelativeTrustStructure(): FlowchartData {
  // Define layout rows (as percentage of height 0-1)
  const ROW = {
    root: 0.08,      // Row 0: Root trust
    gift1: 0.24,     // Gift1 row
    trusts: 0.46,    // Three trusts row
    gift2: 0.65,     // Gift2 row
    children: 0.85,  // Final trusts
  };

  // Define layout columns (as percentage of width 0-1)
  const COL = {
    left: 0.25,       // Survivor's Trust
    centerLeft: 0.45, // Bypass Trust / center of final trusts
    center: 0.50,     // Center (root)
    centerRight: 0.70, // Marital Trust
    right: 0.88,      // Specific Gifts
    jane: 0.42,       // Jane Doe Trust
    john: 0.68,       // John Doe Trust
  };

  const nodes: FlowchartNode[] = [
    { id: 'root', label: 'Doe-Smith Revocable Trust', type: 'trust', icon: 'building', color: '#2D9B9B',
      relativePosition: { xPercent: COL.center, yPercent: ROW.root } },
    { id: 'gift1', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48,
      relativePosition: { xPercent: COL.right, yPercent: ROW.gift1 } },
    { id: 'survivor', label: "Survivor's Trust", type: 'trust', icon: 'document', color: '#A78BFA',
      relativePosition: { xPercent: COL.left, yPercent: ROW.trusts } },
    { id: 'bypass', label: 'Bypass Trust', type: 'trust', icon: 'document', color: '#60A5FA',
      relativePosition: { xPercent: COL.centerLeft, yPercent: ROW.trusts } },
    { id: 'marital', label: 'Marital Trust', type: 'trust', icon: 'document', color: '#5AB2B2',
      relativePosition: { xPercent: COL.centerRight, yPercent: ROW.trusts } },
    { id: 'gift2', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48,
      relativePosition: { xPercent: COL.right, yPercent: ROW.gift2 } },
    { id: 'jane', label: 'Jane Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B',
      relativePosition: { xPercent: COL.jane, yPercent: ROW.children } },
    { id: 'john', label: 'John Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B',
      relativePosition: { xPercent: COL.john, yPercent: ROW.children } },
  ];

  // Edges will be auto-generated from node positions
  const edges: FlowchartEdge[] = [
    { id: 'e1', source: 'root', target: 'gift1' },
    { id: 'e2', source: 'root', target: 'survivor' },
    { id: 'e3', source: 'root', target: 'bypass' },
    { id: 'e4', source: 'root', target: 'marital' },
    { id: 'e5', source: 'bypass', target: 'gift2' },
    { id: 'e6', source: 'bypass', target: 'jane', label: '50%' },
    { id: 'e7', source: 'bypass', target: 'john', label: '50%' },
  ];

  return { nodes, edges };
}

/**
 * Create trust structure using GRID-based positioning
 * Positions are calculated from row/column indices
 */
export function createGridTrustStructure(): FlowchartData {
  // Grid: 6 rows x 5 columns
  const nodes: FlowchartNode[] = [
    { id: 'root', label: 'Doe-Smith Revocable Trust', type: 'trust', icon: 'building', color: '#2D9B9B',
      relativePosition: { row: 0, col: 2 } },  // Center top
    { id: 'gift1', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48,
      relativePosition: { row: 1, col: 4 } },  // Right
    { id: 'survivor', label: "Survivor's Trust", type: 'trust', icon: 'document', color: '#A78BFA',
      relativePosition: { row: 2, col: 0 } },  // Left
    { id: 'bypass', label: 'Bypass Trust', type: 'trust', icon: 'document', color: '#60A5FA',
      relativePosition: { row: 2, col: 2 } },  // Center
    { id: 'marital', label: 'Marital Trust', type: 'trust', icon: 'document', color: '#5AB2B2',
      relativePosition: { row: 2, col: 3 } },  // Center-right
    { id: 'gift2', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48,
      relativePosition: { row: 3, col: 4 } },  // Right
    { id: 'jane', label: 'Jane Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B',
      relativePosition: { row: 5, col: 1 } },  // Bottom left-center
    { id: 'john', label: 'John Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B',
      relativePosition: { row: 5, col: 3 } },  // Bottom right-center
  ];

  const edges: FlowchartEdge[] = [
    { id: 'e1', source: 'root', target: 'gift1' },
    { id: 'e2', source: 'root', target: 'survivor' },
    { id: 'e3', source: 'root', target: 'bypass' },
    { id: 'e4', source: 'root', target: 'marital' },
    { id: 'e5', source: 'bypass', target: 'gift2' },
    { id: 'e6', source: 'bypass', target: 'jane', label: '50%' },
    { id: 'e7', source: 'bypass', target: 'john', label: '50%' },
  ];

  return { nodes, edges };
}

/**
 * Create trust structure using ANCHOR-based positioning
 * Nodes are positioned relative to other nodes with fixed offsets
 */
export function createAnchorTrustStructure(): FlowchartData {
  const nodes: FlowchartNode[] = [
    // Root is fixed at center-top using percentage
    { id: 'root', label: 'Doe-Smith Revocable Trust', type: 'trust', icon: 'building', color: '#2D9B9B',
      relativePosition: { xPercent: 0.5, yPercent: 0.08 } },
    
    // Gift1 is to the right of root
    { id: 'gift1', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48,
      relativePosition: { anchorId: 'root', offsetX: 200, offsetY: 110 } },
    
    // Three trusts anchored relative to root
    { id: 'survivor', label: "Survivor's Trust", type: 'trust', icon: 'document', color: '#A78BFA',
      relativePosition: { anchorId: 'root', offsetX: -150, offsetY: 270 } },
    { id: 'bypass', label: 'Bypass Trust', type: 'trust', icon: 'document', color: '#60A5FA',
      relativePosition: { anchorId: 'root', offsetX: 0, offsetY: 270 } },
    { id: 'marital', label: 'Marital Trust', type: 'trust', icon: 'document', color: '#5AB2B2',
      relativePosition: { anchorId: 'root', offsetX: 150, offsetY: 270 } },
    
    // Gift2 relative to bypass
    { id: 'gift2', label: 'Specific Gifts', type: 'gift', icon: 'gift', color: '#FF8A65', width: 56, height: 48,
      relativePosition: { anchorId: 'bypass', offsetX: 200, offsetY: 120 } },
    
    // Children relative to bypass
    { id: 'jane', label: 'Jane Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B',
      relativePosition: { anchorId: 'bypass', offsetX: -70, offsetY: 270 } },
    { id: 'john', label: 'John Doe Trust', type: 'trust', icon: 'document', color: '#2D7B7B',
      relativePosition: { anchorId: 'bypass', offsetX: 70, offsetY: 270 } },
  ];

  const edges: FlowchartEdge[] = [
    { id: 'e1', source: 'root', target: 'gift1' },
    { id: 'e2', source: 'root', target: 'survivor' },
    { id: 'e3', source: 'root', target: 'bypass' },
    { id: 'e4', source: 'root', target: 'marital' },
    { id: 'e5', source: 'bypass', target: 'gift2' },
    { id: 'e6', source: 'bypass', target: 'jane', label: '50%' },
    { id: 'e7', source: 'bypass', target: 'john', label: '50%' },
  ];

  return { nodes, edges };
}

// ============================================================================
// Export
// ============================================================================

export const unifiedFlowchartEngine = new UnifiedFlowchartEngine();
