/**
 * PDF Service
 * Core service that handles PDF generation from blueprints
 */

import { renderToStream, renderToBuffer, type DocumentProps } from "@react-pdf/renderer";
import React from "react";
import { createDocument, validateBlueprint } from "../factories/index.js";
import type { Blueprint, ValidationResult } from "../blueprints/types.js";
import { logger } from "../utils/logger.js";

/**
 * Output format for PDF generation
 */
export type PdfOutputFormat = "stream" | "buffer";

/**
 * Options for PDF generation
 */
export interface GeneratePdfOptions {
  /** Blueprint to render */
  blueprint: Blueprint;
  /** Output format (stream for responses, buffer for storage) */
  format?: PdfOutputFormat;
  /** Custom filename for the generated PDF */
  filename?: string;
}

/**
 * Metadata about the generated PDF
 */
export interface PdfMetadata {
  /** Generation time in milliseconds */
  generationTime: number;
  /** Estimated page count (if available) */
  pageCount?: number;
  /** Generated filename */
  filename: string;
  /** Blueprint type */
  blueprintType: string;
  /** Blueprint ID */
  blueprintId: string;
}

/**
 * Result of PDF generation
 */
export interface PdfResult {
  /** Whether generation was successful */
  success: boolean;
  /** Generated PDF data (stream or buffer) */
  data?: NodeJS.ReadableStream | Buffer;
  /** Error message if generation failed */
  error?: string;
  /** Validation result with errors and warnings */
  validation?: ValidationResult;
  /** PDF metadata */
  metadata?: PdfMetadata;
}

/**
 * Result of validation-only operation
 */
export interface ValidateResult {
  /** Whether the blueprint is valid */
  valid: boolean;
  /** Validation errors */
  errors: Array<{ path: string; message: string; code: string }>;
  /** Validation warnings */
  warnings: Array<{ path: string; message: string; suggestion?: string }>;
}

/**
 * PDF Service class
 * Handles all PDF generation operations
 */
export class PdfService {
  /**
   * Generate a PDF from a blueprint
   */
  async generatePdf(options: GeneratePdfOptions): Promise<PdfResult> {
    const startTime = Date.now();
    const { blueprint, format = "stream", filename } = options;

    try {
      // Validate blueprint first
      const validation = validateBlueprint(blueprint);
      
      if (!validation.valid) {
        logger.warn("Blueprint validation failed", {
          blueprintId: blueprint.id,
          errors: validation.errors,
        });
        
        return {
          success: false,
          error: `Blueprint validation failed: ${validation.errors.map(e => e.message).join(", ")}`,
          validation,
        };
      }

      // Log warnings if any
      if (validation.warnings.length > 0) {
        logger.debug("Blueprint validation warnings", {
          blueprintId: blueprint.id,
          warnings: validation.warnings,
        });
      }

      // Create the document
      const document = createDocument({ blueprint });
      
      // Cast to expected type for react-pdf renderer
      const typedDocument = document as React.ReactElement<DocumentProps>;

      // Generate the PDF based on format
      let data: NodeJS.ReadableStream | Buffer;
      
      if (format === "buffer") {
        data = await renderToBuffer(typedDocument);
      } else {
        data = await renderToStream(typedDocument);
      }

      const generationTime = Date.now() - startTime;
      const generatedFilename = filename || this.generateFilename(blueprint);

      logger.info("PDF generated successfully", {
        blueprintId: blueprint.id,
        blueprintType: blueprint.type,
        format,
        generationTime,
        filename: generatedFilename,
      });

      return {
        success: true,
        data,
        validation,
        metadata: {
          generationTime,
          filename: generatedFilename,
          blueprintType: blueprint.type,
          blueprintId: blueprint.id,
        },
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
      
      logger.error("PDF generation failed", error as Error, {
        blueprintId: blueprint.id,
        blueprintType: blueprint.type,
      });

      return {
        success: false,
        error: `PDF generation failed: ${errorMessage}`,
      };
    }
  }

  /**
   * Validate a blueprint without generating a PDF
   */
  async validateBlueprint(blueprint: Blueprint): Promise<ValidateResult> {
    try {
      const validation = validateBlueprint(blueprint);
      
      logger.debug("Blueprint validated", {
        blueprintId: blueprint.id,
        valid: validation.valid,
        errorCount: validation.errors.length,
        warningCount: validation.warnings.length,
      });

      return {
        valid: validation.valid,
        errors: validation.errors,
        warnings: validation.warnings,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown validation error";
      
      logger.error("Blueprint validation error", error as Error);

      return {
        valid: false,
        errors: [
          {
            path: "",
            message: errorMessage,
            code: "VALIDATION_ERROR",
          },
        ],
        warnings: [],
      };
    }
  }

  /**
   * Generate a filename for the PDF based on blueprint metadata
   */
  private generateFilename(blueprint: Blueprint): string {
    const sanitizedTitle = blueprint.metadata.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
    
    const timestamp = new Date().toISOString().split("T")[0];
    
    return `${sanitizedTitle}-${timestamp}.pdf`;
  }

  /**
   * Get available template types
   */
  getAvailableTemplates(): string[] {
    return ["report", "dashboard", "invoice", "data-table"];
  }
}

// Export singleton instance
export const pdfService = new PdfService();

export default pdfService;
