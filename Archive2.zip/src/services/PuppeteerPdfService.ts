import puppeteer, { Browser, Page, PDFOptions } from 'puppeteer';
import { Blueprint, EstatePlanningBlueprint } from '../blueprints/types';
import { logger } from '../utils/logger';
import { TreeLayoutEngine, TreeNode, LayoutResult, PositionedNode, PositionedEdge } from '../utils/TreeLayoutEngine';

export interface PuppeteerPdfOptions {
  format?: 'A4' | 'Letter' | 'Legal';
  landscape?: boolean;
  margin?: {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
  };
  printBackground?: boolean;
  displayHeaderFooter?: boolean;
  headerTemplate?: string;
  footerTemplate?: string;
}

export interface PdfGenerationResult {
  success: boolean;
  buffer?: Buffer;
  error?: string;
  metadata?: {
    pageCount?: number;
    generationTime: number;
  };
}

/**
 * Puppeteer-based PDF Service
 * Generates PDFs from blueprints using headless Chrome for pixel-perfect CSS rendering
 */
export class PuppeteerPdfService {
  private browser: Browser | null = null;

  /**
   * Initialize the browser instance
   */
  async initialize(): Promise<void> {
    if (!this.browser) {
      this.browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
      });
      logger.info('Puppeteer browser initialized');
    }
  }

  /**
   * Close the browser instance
   */
  async close(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      logger.info('Puppeteer browser closed');
    }
  }

  /**
   * Generate PDF from blueprint
   */
  async generatePdf(
    blueprint: Blueprint,
    options: PuppeteerPdfOptions = {}
  ): Promise<PdfGenerationResult> {
    const startTime = Date.now();

    try {
      await this.initialize();

      if (!this.browser) {
        throw new Error('Browser not initialized');
      }

      const page = await this.browser.newPage();

      // Generate HTML from blueprint
      const html = this.blueprintToHtml(blueprint);

      // Set content
      await page.setContent(html, { waitUntil: 'networkidle0' });

      // Configure PDF options
      const pdfOptions: PDFOptions = {
        format: options.format || 'A4',
        landscape: options.landscape || false,
        printBackground: options.printBackground !== false,
        margin: options.margin || {
          top: '0.5in',
          right: '0.5in',
          bottom: '0.75in',
          left: '0.5in',
        },
        displayHeaderFooter: options.displayHeaderFooter || false,
        headerTemplate: options.headerTemplate || '',
        footerTemplate: options.footerTemplate || '',
      };

      // Generate PDF
      const buffer = await page.pdf(pdfOptions);

      await page.close();

      return {
        success: true,
        buffer: Buffer.from(buffer),
        metadata: {
          generationTime: Date.now() - startTime,
        },
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PDF generation failed:', errorMessage);
      return {
        success: false,
        error: errorMessage,
        metadata: {
          generationTime: Date.now() - startTime,
        },
      };
    }
  }

  /**
   * Convert blueprint to HTML
   */
  private blueprintToHtml(blueprint: Blueprint): string {
    switch (blueprint.type) {
      case 'estate-planning':
        return this.estatePlanningToHtml(blueprint as EstatePlanningBlueprint);
      default:
        return this.genericBlueprintToHtml(blueprint);
    }
  }

  /**
   * Generate HTML for Estate Planning blueprint
   */
  private estatePlanningToHtml(blueprint: EstatePlanningBlueprint): string {
    const { metadata, content, theme } = blueprint;
    const colors = {
      primary: theme?.primary || '#2D9B9B',
      secondary: theme?.secondary || '#60A5FA',
      accent: theme?.accent || '#A78BFA',
      danger: theme?.danger || '#EF4444',
      success: theme?.success || '#10B981',
      warning: theme?.warning || '#FF8A65',
      charity: theme?.charity || '#EC4899',
    };

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${metadata.title}</title>
  <style>
    ${this.getBaseStyles()}
    ${this.getEstatePlanningStyles(colors)}
  </style>
</head>
<body>
  ${this.renderCoverPage(metadata, content.client, colors)}
  ${this.renderTrustStructurePage(content.trustStructure, colors)}
  ${this.renderEstateOverviewPage(content, colors)}
  ${this.renderBeneficiariesPage(content.beneficiaries, colors)}
</body>
</html>
    `;
  }

  /**
   * Base CSS styles
   */
  private getBaseStyles(): string {
    return `
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
      
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
      
      body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 12px;
        line-height: 1.5;
        color: #111827;
        background: white;
      }
      
      .page {
        width: 100%;
        min-height: 100vh;
        padding: 40px;
        page-break-after: always;
        position: relative;
      }
      
      .page:last-child {
        page-break-after: avoid;
      }
      
      h1 { font-size: 28px; font-weight: 700; margin-bottom: 8px; }
      h2 { font-size: 20px; font-weight: 600; margin-bottom: 16px; }
      h3 { font-size: 16px; font-weight: 600; margin-bottom: 12px; }
      
      .text-muted { color: #6B7280; }
      .text-center { text-align: center; }
      
      .flex { display: flex; }
      .flex-col { flex-direction: column; }
      .flex-wrap { flex-wrap: wrap; }
      .items-center { align-items: center; }
      .justify-center { justify-content: center; }
      .justify-between { justify-content: space-between; }
      .gap-2 { gap: 8px; }
      .gap-4 { gap: 16px; }
      .gap-6 { gap: 24px; }
      
      .grid { display: grid; }
      .grid-cols-2 { grid-template-columns: repeat(2, 1fr); }
      .grid-cols-3 { grid-template-columns: repeat(3, 1fr); }
      
      .mt-4 { margin-top: 16px; }
      .mt-8 { margin-top: 32px; }
      .mb-4 { margin-bottom: 16px; }
      .mb-8 { margin-bottom: 32px; }
      .p-4 { padding: 16px; }
      .p-6 { padding: 24px; }
      
      .rounded { border-radius: 8px; }
      .rounded-lg { border-radius: 12px; }
      .shadow { box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
      
      .bg-white { background: white; }
      .bg-gray-50 { background: #F9FAFB; }
      .bg-gray-100 { background: #F3F4F6; }
      
      .border { border: 1px solid #E5E7EB; }
      
      .footer {
        position: fixed;
        bottom: 20px;
        left: 40px;
        right: 40px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 10px;
        color: #6B7280;
        border-top: 1px solid #E5E7EB;
        padding-top: 10px;
      }
      
      @media print {
        .page {
          page-break-after: always;
        }
        .page:last-child {
          page-break-after: avoid;
        }
        .no-print { display: none; }
      }
    `;
  }

  /**
   * Estate Planning specific styles
   */
  private getEstatePlanningStyles(colors: Record<string, string>): string {
    return `
      :root {
        --primary: ${colors.primary};
        --secondary: ${colors.secondary};
        --accent: ${colors.accent};
        --danger: ${colors.danger};
        --success: ${colors.success};
        --warning: ${colors.warning};
        --charity: ${colors.charity};
      }
      
      .cover-page {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: calc(100vh - 80px);
        text-align: center;
      }
      
      .cover-logo {
        font-size: 24px;
        font-weight: 700;
        color: var(--primary);
        margin-bottom: 60px;
      }
      
      .cover-title {
        font-size: 36px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 12px;
      }
      
      .cover-subtitle {
        font-size: 18px;
        color: #6B7280;
        margin-bottom: 40px;
      }
      
      .cover-info {
        font-size: 14px;
        color: #6B7280;
      }
      
      /* Trust Flow Chart - SVG based for proper connections */
      .trust-chart-container {
        width: 100%;
        display: flex;
        justify-content: center;
        padding: 20px 0;
      }
      
      .trust-chart-svg {
        width: 100%;
        max-width: 700px;
        height: auto;
      }
      
      .trust-separator-line {
        width: 100%;
        display: flex;
        align-items: center;
        gap: 16px;
        color: #9CA3AF;
        font-size: 12px;
        margin: 8px 0;
      }
      
      .trust-separator-line::before,
      .trust-separator-line::after {
        content: '';
        flex: 1;
        border-top: 2px dashed #D1D5DB;
      }
      
      /* Donut Chart */
      .donut-container {
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      
      .donut-chart {
        position: relative;
        width: 200px;
        height: 200px;
      }
      
      .donut-chart svg {
        transform: rotate(-90deg);
      }
      
      .donut-center {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
      }
      
      .donut-center-label {
        font-size: 10px;
        color: #6B7280;
      }
      
      .donut-center-value {
        font-size: 20px;
        font-weight: 700;
        color: #111827;
      }
      
      .donut-legend {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 16px;
      }
      
      .legend-item {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 11px;
      }
      
      .legend-dot {
        width: 10px;
        height: 10px;
        border-radius: 50%;
      }
      
      /* Tables */
      .data-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 11px;
      }
      
      .data-table th {
        background: #1F2937;
        color: white;
        padding: 10px 12px;
        text-align: left;
        font-weight: 600;
      }
      
      .data-table td {
        padding: 10px 12px;
        border-bottom: 1px solid #E5E7EB;
      }
      
      .data-table tr:nth-child(even) {
        background: #F9FAFB;
      }
      
      .amount {
        font-family: 'SF Mono', 'Monaco', 'Inconsolata', monospace;
        text-align: right;
      }
      
      /* Beneficiary Cards */
      .beneficiary-header {
        background: var(--primary);
        color: white;
        padding: 16px 32px;
        border-radius: 24px;
        font-size: 16px;
        font-weight: 600;
        text-align: center;
        margin-bottom: 32px;
      }
      
      .beneficiary-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
      }
      
      .beneficiary-card {
        background: white;
        border: 1px solid #E5E7EB;
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        break-inside: avoid;
      }
      
      .beneficiary-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 12px;
        font-size: 20px;
      }
      
      .beneficiary-name {
        font-size: 14px;
        font-weight: 600;
        color: var(--primary);
        margin-bottom: 12px;
      }
      
      .beneficiary-amounts {
        display: flex;
        gap: 16px;
        justify-content: center;
      }
      
      .beneficiary-amount {
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      
      .beneficiary-amount-label {
        font-size: 10px;
        color: #6B7280;
        margin-bottom: 4px;
      }
      
      .beneficiary-amount-value {
        font-size: 13px;
        font-weight: 600;
        color: #111827;
      }
      
      .in-trust {
        color: var(--primary);
        border-left: 3px solid var(--primary);
        padding-left: 8px;
      }
    `;
  }

  /**
   * Render cover page
   */
  private renderCoverPage(
    metadata: any,
    client: any,
    colors: Record<string, string>
  ): string {
    return `
      <div class="page cover-page">
        <div class="cover-logo">wealth.com</div>
        <h1 class="cover-title">${client?.names?.join(' & ') || metadata.title}</h1>
        <p class="cover-subtitle">${client?.trustName || metadata.subtitle || ''}</p>
        <p class="cover-info">${metadata.date || new Date().toLocaleDateString()}</p>
      </div>
    `;
  }

  /**
   * Render trust structure page - EXACT match to original wealth.com design
   *
   * Analyzing the original image precisely:
   * 1. Root trust at top center with building icon
   * 2. Vertical line → "Death of First Spouse" separator
   * 3. T-junction: main flow continues DOWN, branch RIGHT to Specific Gifts
   * 4. Second T-junction splits LEFT for Survivor's Trust, RIGHT for Bypass+Marital
   * 5. Annotations positioned above each branch
   * 6. "Death of Surviving Spouse" separator
   * 7. T-junction: branch RIGHT to Specific Gifts, DOWN to 50/50 split
   * 8. Jane/John Doe Trusts at bottom
   */
  private renderTrustStructurePage(
    trustStructure: any,
    colors: Record<string, string>
  ): string {
    if (!trustStructure?.nodes) {
      return '';
    }

    // Canvas dimensions
    const W = 580;
    const H = 720;
    
    // Colors matching original exactly
    const C = {
      line: '#C9CDD3',
      text: '#374151',
      muted: '#6B7280',
      separator: '#9CA3AF',
      root: '#2D9B9B',
      gift: '#FF8A65',
      survivor: '#A78BFA',
      bypass: '#60A5FA',
      marital: '#5AB2B2',
      child: '#2D7B7B',
    };

    // Node dimensions
    const NODE = { w: 68, h: 52, r: 12 };
    const SMALL = { w: 56, h: 48, r: 10 };

    // Precise Y coordinates from original
    const Y = {
      root: 55,
      sep1: 130,
      junct1: 165,      // T-junction after sep1
      annot: 200,       // Annotation text
      hline1: 265,      // Horizontal line for 3-trust split
      trusts: 330,      // Three trusts row
      sep2: 420,        // Second separator
      junct2: 455,      // T-junction after sep2
      hline2: 520,      // Horizontal line for 2-trust split
      children: 600,    // Final trusts
    };

    // Precise X coordinates from original
    const CX = W / 2;  // ~290
    const X = {
      root: CX,
      mainLine: CX,     // Main vertical flow line
      gift1: 520,       // Specific Gifts 1 (far right)
      leftAnnot: 150,   // Left annotation center
      rightAnnot: 380,  // Right annotation center (moved left to avoid overlap)
      survivor: 150,    // Survivor's Trust (more left)
      bypass: 320,      // Bypass Trust
      marital: 490,     // Marital Trust
      gift2: 520,       // Specific Gifts 2
      jane: 270,        // Jane Doe Trust
      john: 410,        // John Doe Trust
    };

    // SVG Icons (matching original style)
    const icons = {
      building: `<g transform="scale(0.9)"><path d="M12 2L3 9v13h18V9L12 2z" fill="white"/><rect x="7" y="12" width="3" height="3" fill="${C.root}" opacity="0.5"/><rect x="11" y="12" width="3" height="3" fill="${C.root}" opacity="0.5"/><rect x="9" y="17" width="4" height="5" fill="${C.root}" opacity="0.5"/></g>`,
      gift: `<g transform="scale(0.85)"><rect x="4" y="11" width="16" height="9" rx="1" fill="white"/><rect x="3" y="8" width="18" height="4" rx="1" fill="white"/><line x1="12" y1="8" x2="12" y2="20" stroke="${C.gift}" stroke-width="2.5"/></g>`,
      doc: `<g transform="scale(0.85)"><rect x="5" y="2" width="14" height="18" rx="1.5" fill="white"/><rect x="7" y="6" width="10" height="2.5" rx="1" fill="currentColor" opacity="0.3"/><rect x="7" y="10" width="10" height="2.5" rx="1" fill="currentColor" opacity="0.3"/><rect x="7" y="14" width="6" height="2.5" rx="1" fill="currentColor" opacity="0.3"/></g>`,
    };

    // Helper: Draw node with icon and label
    const drawNode = (x: number, y: number, w: number, h: number, color: string, icon: string, label: string) => `
      <g>
        <rect x="${x - w/2}" y="${y - h/2}" width="${w}" height="${h}" rx="${NODE.r}" fill="${color}" />
        <g transform="translate(${x - 12}, ${y - 11})">${icon}</g>
        <text x="${x}" y="${y + h/2 + 15}" text-anchor="middle" font-size="11" font-weight="500" fill="${C.text}">${label}</text>
      </g>
    `;

    // Helper: Draw line (optionally with arrow)
    const drawLine = (x1: number, y1: number, x2: number, y2: number, arrow = false) =>
      `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${C.line}" stroke-width="2" ${arrow ? 'marker-end="url(#arrowGray)"' : ''}/>`;

    // Helper: Draw dashed separator line
    const drawSeparator = (y: number, text: string) => `
      <line x1="30" y1="${y}" x2="${CX - 90}" y2="${y}" stroke="${C.line}" stroke-width="1.5" stroke-dasharray="6,4"/>
      <text x="${CX}" y="${y + 4}" text-anchor="middle" font-size="11" fill="${C.separator}">${text}</text>
      <line x1="${CX + 90}" y1="${y}" x2="${W - 30}" y2="${y}" stroke="${C.line}" stroke-width="1.5" stroke-dasharray="6,4"/>
    `;

    // Helper: Multi-line annotation
    const drawAnnotation = (x: number, y: number, lines: string[], anchor = 'middle') =>
      lines.map((t, i) => `<text x="${x}" y="${y + i * 15}" text-anchor="${anchor}" font-size="10" fill="${C.muted}">${t}</text>`).join('');

    // Helper: Badge (50% labels)
    const drawBadge = (x: number, y: number, text: string) => `
      <rect x="${x - 24}" y="${y - 10}" width="48" height="20" rx="10" fill="white" stroke="#E5E7EB" stroke-width="1"/>
      <text x="${x}" y="${y + 4}" text-anchor="middle" font-size="11" fill="${C.muted}">${text}</text>
    `;

    return `
      <div class="page" style="padding: 10px 15px; background: white;">
        <svg viewBox="0 0 ${W} ${H}" style="width: 100%; max-width: 580px; margin: 0 auto; display: block; font-family: Inter, -apple-system, sans-serif;">
          
          <!-- Marker definitions -->
          <defs>
            <marker id="arrowGray" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
              <polygon points="0 0, 8 3, 0 6" fill="${C.line}"/>
            </marker>
          </defs>
          
          <!-- ═══════════════ ROOT TRUST ═══════════════ -->
          ${drawNode(X.root, Y.root, NODE.w, NODE.h, C.root, icons.building, 'Doe-Smith Revocable Trust')}
          
          <!-- Vertical line: Root → Separator 1 -->
          ${drawLine(X.root, Y.root + NODE.h/2 + 15, X.root, Y.sep1 - 10)}
          
          <!-- ═══════════════ SEPARATOR 1: Death of First Spouse ═══════════════ -->
          ${drawSeparator(Y.sep1, 'Death of First Spouse')}
          
          <!-- ═══════════════ T-JUNCTION 1: Branch to Specific Gifts ═══════════════ -->
          <!-- Vertical: sep1 → junction point -->
          ${drawLine(X.root, Y.sep1 + 8, X.root, Y.junct1)}
          
          <!-- Horizontal branch RIGHT to Specific Gifts 1 -->
          ${drawLine(X.root, Y.junct1, X.gift1 - SMALL.w/2 - 5, Y.junct1)}
          ${drawLine(X.gift1 - SMALL.w/2 - 5, Y.junct1, X.gift1, Y.junct1, true)}
          
          <!-- SPECIFIC GIFTS 1 -->
          ${drawNode(X.gift1, Y.junct1 + 28, SMALL.w, SMALL.h, C.gift, icons.gift, 'Specific Gifts')}
          
          <!-- ═══════════════ SECOND SPLIT: To 3 Trusts ═══════════════ -->
          <!-- Continue down from junction to annotation level -->
          ${drawLine(X.root, Y.junct1, X.root, Y.annot + 40)}
          
          <!-- LEFT branch: goes to Survivor's Trust area -->
          <!-- Horizontal from center to left annotation position -->
          ${drawLine(X.survivor, Y.annot + 40, X.root, Y.annot + 40)}
          
          <!-- RIGHT branch continuation: to bypass/marital area -->
          ${drawLine(X.root, Y.annot + 40, X.bypass + (X.marital - X.bypass)/2, Y.annot + 40)}
          
          <!-- Sub-branch for bypass and marital -->
          ${drawLine(X.bypass, Y.annot + 40, X.marital, Y.annot + 40)}
          
          <!-- LEFT ANNOTATION (Surviving Spouse's Property) -->
          ${drawAnnotation(X.leftAnnot, Y.annot, ["Surviving Spouse's Separate", "Property and Share of Marital Property"], 'middle')}
          
          <!-- RIGHT ANNOTATION (Deceased Spouse's Property) -->
          ${drawAnnotation(X.rightAnnot, Y.annot, ["Deceased Spouse's Separate Property", "and Share of Marital Property"], 'middle')}
          
          <!-- Vertical drops to each trust -->
          ${drawLine(X.survivor, Y.annot + 40, X.survivor, Y.trusts - NODE.h/2 - 5, true)}
          ${drawLine(X.bypass, Y.annot + 40, X.bypass, Y.trusts - NODE.h/2 - 5, true)}
          ${drawLine(X.marital, Y.annot + 40, X.marital, Y.trusts - NODE.h/2 - 5, true)}
          
          <!-- ═══════════════ LEVEL 1: THREE TRUSTS ═══════════════ -->
          ${drawNode(X.survivor, Y.trusts, NODE.w, NODE.h, C.survivor, icons.doc, "Survivor's Trust")}
          ${drawNode(X.bypass, Y.trusts, NODE.w, NODE.h, C.bypass, icons.doc, 'Bypass Trust')}
          ${drawNode(X.marital, Y.trusts, NODE.w, NODE.h, C.marital, icons.doc, 'Marital Trust')}
          
          <!-- Vertical from Bypass down to Separator 2 -->
          ${drawLine(X.bypass, Y.trusts + NODE.h/2 + 15, X.bypass, Y.sep2 - 10)}
          
          <!-- ═══════════════ SEPARATOR 2: Death of Surviving Spouse ═══════════════ -->
          ${drawSeparator(Y.sep2, 'Death of Surviving Spouse')}
          
          <!-- ═══════════════ T-JUNCTION 2: Branch to Specific Gifts 2 ═══════════════ -->
          <!-- Vertical: sep2 → junction point -->
          ${drawLine(X.bypass, Y.sep2 + 8, X.bypass, Y.junct2)}
          
          <!-- Horizontal branch RIGHT to Specific Gifts 2 -->
          ${drawLine(X.bypass, Y.junct2, X.gift2 - SMALL.w/2 - 5, Y.junct2)}
          ${drawLine(X.gift2 - SMALL.w/2 - 5, Y.junct2, X.gift2, Y.junct2, true)}
          
          <!-- SPECIFIC GIFTS 2 -->
          ${drawNode(X.gift2, Y.junct2 + 28, SMALL.w, SMALL.h, C.gift, icons.gift, 'Specific Gifts')}
          
          <!-- ═══════════════ FINAL SPLIT: To 2 Individual Trusts ═══════════════ -->
          <!-- Continue down from junction 2 -->
          ${drawLine(X.bypass, Y.junct2, X.bypass, Y.hline2)}
          
          <!-- Horizontal branch for Jane and John -->
          ${drawLine(X.jane, Y.hline2, X.john, Y.hline2)}
          
          <!-- Vertical drops to Jane and John trusts -->
          ${drawLine(X.jane, Y.hline2, X.jane, Y.children - NODE.h/2 - 5, true)}
          ${drawLine(X.john, Y.hline2, X.john, Y.children - NODE.h/2 - 5, true)}
          
          <!-- 50% badges -->
          ${drawBadge(X.jane, Y.hline2 + 35, '50%')}
          ${drawBadge(X.john, Y.hline2 + 35, '50%')}
          
          <!-- ═══════════════ LEVEL 2: INDIVIDUAL TRUSTS ═══════════════ -->
          ${drawNode(X.jane, Y.children, NODE.w, NODE.h, C.child, icons.doc, 'Jane Doe Trust')}
          ${drawNode(X.john, Y.children, NODE.w, NODE.h, C.child, icons.doc, 'John Doe Trust')}
          
          <!-- ═══════════════ SIDE NOTE ═══════════════ -->
          <text x="35" y="${Y.junct2 + 10}" font-size="9" fill="${C.muted}">If a child of the Grantors has</text>
          <text x="35" y="${Y.junct2 + 22}" font-size="9" fill="${C.muted}">not yet attained 21 years of</text>
          <text x="35" y="${Y.junct2 + 34}" font-size="9" fill="${C.muted}">age, trust assets will be held</text>
          <text x="35" y="${Y.junct2 + 46}" font-size="9" fill="${C.muted}">in a pot trust for the benefit of</text>
          <text x="35" y="${Y.junct2 + 58}" font-size="9" fill="${C.muted}">the Grantors' descendants</text>
          <text x="35" y="${Y.junct2 + 70}" font-size="9" fill="${C.muted}">until such time as the</text>
          <text x="35" y="${Y.junct2 + 82}" font-size="9" fill="${C.muted}">youngest living child of the</text>
          <text x="35" y="${Y.junct2 + 94}" font-size="9" fill="${C.muted}">Grantors attains age 21.</text>
          
        </svg>
      </div>
    `;
  }

  /**
   * Render estate overview page
   */
  private renderEstateOverviewPage(content: any, colors: Record<string, string>): string {
    const { keyPeople, estateOverview } = content;
    const total = estateOverview?.total || 0;
    const breakdown = estateOverview?.breakdown || [];

    // Calculate donut chart
    const donutSegments = this.calculateDonutSegments(breakdown, total);

    return `
      <div class="page">
        <h2>Estate Overview</h2>
        
        <div class="flex gap-6">
          <!-- Key People Table -->
          <div style="flex: 1;">
            <h3>Key People</h3>
            <table class="data-table">
              <thead>
                <tr>
                  <th>Document</th>
                  <th>Role</th>
                  <th>Designation</th>
                </tr>
              </thead>
              <tbody>
                ${(keyPeople?.documents || []).map((doc: any) => `
                  <tr>
                    <td>${doc.name}</td>
                    <td>${doc.role}</td>
                    <td>${doc.designation}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <!-- Donut Chart -->
          <div style="flex: 1;">
            <h3>Total Estate Value</h3>
            <div class="donut-container">
              <div class="donut-chart">
                <svg width="200" height="200" viewBox="0 0 200 200">
                  ${donutSegments}
                </svg>
                <div class="donut-center">
                  <div class="donut-center-label">Estimated Total Estate</div>
                  <div class="donut-center-value">${this.formatCurrency(total)}</div>
                </div>
              </div>
              <div class="donut-legend">
                ${breakdown.map((segment: any) => `
                  <div class="legend-item">
                    <div class="legend-dot" style="background: ${segment.color}"></div>
                    <span>${segment.label}: ${this.formatCurrency(segment.value)}</span>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        </div>
        
        <!-- Breakdown Tables -->
        <div class="flex gap-6 mt-8">
          <div style="flex: 1;">
            <h3>Inside Taxable Estate</h3>
            <table class="data-table">
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                ${(estateOverview?.insideTaxable || []).map((item: any) => `
                  <tr>
                    <td>${item.category}</td>
                    <td class="amount">${this.formatCurrency(item.amount)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <div style="flex: 1;">
            <h3>Outside Taxable Estate</h3>
            <table class="data-table">
              <thead>
                <tr>
                  <th>Category</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                ${(estateOverview?.outsideTaxable || []).map((item: any) => `
                  <tr>
                    <td>${item.category}</td>
                    <td class="amount">${this.formatCurrency(item.amount)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Render beneficiaries page
   */
  private renderBeneficiariesPage(
    beneficiaries: any[],
    colors: Record<string, string>
  ): string {
    if (!beneficiaries?.length) {
      return '';
    }

    return `
      <div class="page" style="background: #F3F4F6;">
        <div class="beneficiary-header">
          Beneficiaries Upon Death of Surviving Spouse
        </div>
        
        <div class="beneficiary-grid">
          ${beneficiaries.map((b: any) => `
            <div class="beneficiary-card">
              <div class="beneficiary-icon" style="background: ${b.icon === 'charity' ? '#FCE7F3' : '#E6F7F7'}">
                ${b.icon === 'charity' ? '❤️' : '👤'}
              </div>
              <div class="beneficiary-name">${b.name}</div>
              <div class="beneficiary-amounts">
                ${b.inTrust !== undefined ? `
                  <div class="beneficiary-amount in-trust">
                    <div class="beneficiary-amount-label">In Trust</div>
                    <div class="beneficiary-amount-value">${this.formatCurrency(b.inTrust)}</div>
                  </div>
                ` : ''}
                ${b.outright !== undefined ? `
                  <div class="beneficiary-amount">
                    <div class="beneficiary-amount-label">Outright</div>
                    <div class="beneficiary-amount-value">${this.formatCurrency(b.outright)}</div>
                  </div>
                ` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  /**
   * Render footer
   */
  private renderFooter(company?: string): string {
    return `
      <style>
        .page-footer {
          position: fixed;
          bottom: 20px;
          left: 40px;
          right: 40px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 10px;
          color: #6B7280;
          border-top: 1px solid #E5E7EB;
          padding-top: 10px;
        }
      </style>
      <div class="page-footer">
        <span style="color: var(--primary); font-weight: 600;">${company || 'wealth.com'}</span>
        <span>This information is being provided for illustrative purposes only. Please refer to your original sourcing documents for the most accurate information.</span>
      </div>
    `;
  }

  /**
   * Calculate SVG donut segments
   */
  private calculateDonutSegments(breakdown: any[], total: number): string {
    if (!breakdown.length || total === 0) {
      return '';
    }

    const cx = 100;
    const cy = 100;
    const outerR = 90;
    const innerR = 60;
    let currentAngle = 0;

    return breakdown.map((segment: any) => {
      const percentage = segment.value / total;
      const angle = percentage * 360;
      
      // Calculate arc
      const startAngle = currentAngle;
      const endAngle = currentAngle + angle;
      
      const startOuter = this.polarToCartesian(cx, cy, outerR, startAngle);
      const endOuter = this.polarToCartesian(cx, cy, outerR, endAngle);
      const startInner = this.polarToCartesian(cx, cy, innerR, endAngle);
      const endInner = this.polarToCartesian(cx, cy, innerR, startAngle);
      
      const largeArc = angle > 180 ? 1 : 0;
      
      const path = [
        `M ${startOuter.x} ${startOuter.y}`,
        `A ${outerR} ${outerR} 0 ${largeArc} 1 ${endOuter.x} ${endOuter.y}`,
        `L ${startInner.x} ${startInner.y}`,
        `A ${innerR} ${innerR} 0 ${largeArc} 0 ${endInner.x} ${endInner.y}`,
        'Z'
      ].join(' ');
      
      currentAngle = endAngle;
      
      return `<path d="${path}" fill="${segment.color}" />`;
    }).join('');
  }

  /**
   * Convert polar to cartesian coordinates
   */
  private polarToCartesian(cx: number, cy: number, r: number, angle: number) {
    const rad = (angle - 90) * Math.PI / 180;
    return {
      x: cx + r * Math.cos(rad),
      y: cy + r * Math.sin(rad)
    };
  }

  /**
   * Get icon SVG/emoji
   */
  private getIcon(icon: string): string {
    const icons: Record<string, string> = {
      building: '🏛️',
      gift: '🎁',
      document: '📄',
      person: '👤',
      charity: '❤️',
    };
    return icons[icon] || '📄';
  }

  /**
   * Format currency
   */
  private formatCurrency(value: number): string {
    if (value === 0) return '$0';
    if (value >= 1000000000) {
      return `$${(value / 1000000000).toFixed(2)}B`;
    }
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(2)}M`;
    }
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(0)}K`;
    }
    return `$${value.toLocaleString()}`;
  }

  /**
   * Generic blueprint to HTML converter
   */
  private genericBlueprintToHtml(blueprint: Blueprint): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${blueprint.metadata.title}</title>
        <style>${this.getBaseStyles()}</style>
      </head>
      <body>
        <div class="page">
          <h1>${blueprint.metadata.title}</h1>
          <p>${blueprint.metadata.subtitle || ''}</p>
          <pre>${JSON.stringify(blueprint.content, null, 2)}</pre>
        </div>
      </body>
      </html>
    `;
  }
}

// Export singleton instance
export const puppeteerPdfService = new PuppeteerPdfService();
