/**
 * Table Component Types
 * Type definitions for the Table system with multi-page support
 */

import type { Style } from "../types.js";

/**
 * Column definition for table columns
 */
export interface ColumnDefinition {
  /** Data field name - key to access row data */
  key: string;
  /** Display header text shown in the table header */
  header: string;
  /** Column width - can be percentage (e.g., '40%'), points (e.g., 100), or number */
  width: string | number;
  /** Text alignment for cell content */
  align?: "left" | "center" | "right";
  /** Text alignment for header (defaults to align if not specified) */
  headerAlign?: "left" | "center" | "right";
  /** Value formatter function - converts value to display string */
  format?: (value: unknown, row: Record<string, unknown>) => string;
  /** Custom render function - allows custom React nodes in cells */
  render?: (
    value: unknown,
    row: Record<string, unknown>,
    index: number
  ) => React.ReactNode;
  /** Allow text wrapping in this column */
  wrap?: boolean;
  /** Minimum width for the column (in points) */
  minWidth?: number;
  /** Maximum width for the column (in points) */
  maxWidth?: number;
}

/**
 * Table variant styles
 */
export type TableVariant = "default" | "striped" | "bordered" | "minimal";

/**
 * Main Table component props
 */
export interface TableProps {
  /** Column definitions */
  columns: ColumnDefinition[];
  /** Array of row data objects */
  data: Record<string, unknown>[];

  // Multi-page features
  /** Repeat header on each page (default: true) */
  repeatHeader?: boolean;
  /** Fixed position header for repetition */
  fixedHeader?: boolean;

  // Orphan/widow protection
  /** Minimum rows before page break (default: 3) */
  minRowsOnPage?: number;
  /** Prevent row splitting across pages (default: true) */
  keepRowsTogether?: boolean;

  // Styling
  /** Table style variant */
  variant?: TableVariant;
  /** Custom header style override */
  headerStyle?: Style;
  /** Custom row style override (applied to all rows) */
  rowStyle?: Style;
  /** Custom cell style override (applied to all cells) */
  cellStyle?: Style;
  /** Style for even-indexed rows (0, 2, 4...) */
  evenRowStyle?: Style;
  /** Style for odd-indexed rows (1, 3, 5...) */
  oddRowStyle?: Style;

  // Sizing
  /** Total table width (default: '100%') */
  tableWidth?: string | number;

  // Events (for tracking)
  /** Callback when table breaks to a new page */
  onPageBreak?: (pageNumber: number) => void;

  // Debug
  /** Enable debug borders */
  debug?: boolean;
}

/**
 * TableRow component props
 */
export interface TableRowProps {
  /** Row data object */
  data: Record<string, unknown>;
  /** Column definitions */
  columns: ColumnDefinition[];
  /** Row index in the data array */
  index: number;
  /** Whether this is an even-indexed row */
  isEven: boolean;
  /** Table variant for styling */
  variant: TableVariant;
  /** Custom row style override */
  style?: Style;
  /** Custom cell style override */
  cellStyle?: Style;
  /** Minimum presence ahead for orphan protection */
  minPresenceAhead?: number;
  /** Debug mode */
  debug?: boolean;
}

/**
 * TableCell component props
 */
export interface TableCellProps {
  /** Cell value (raw data) */
  value: unknown;
  /** Column definition for this cell */
  column: ColumnDefinition;
  /** Full row data object */
  row: Record<string, unknown>;
  /** Row index */
  index: number;
  /** Custom cell style override */
  style?: Style;
  /** Whether this is an even-indexed row */
  isEven?: boolean;
  /** Table variant for styling */
  variant?: TableVariant;
  /** Debug mode */
  debug?: boolean;
}

/**
 * TableHeader component props
 */
export interface TableHeaderProps {
  /** Column definitions */
  columns: ColumnDefinition[];
  /** Custom header style override */
  style?: Style;
  /** Fixed header for page repetition (uses fixed prop) */
  fixed?: boolean;
  /** Table variant for styling */
  variant?: TableVariant;
  /** Debug mode */
  debug?: boolean;
}

/**
 * Table style configuration for a variant
 */
export interface TableStyleConfig {
  /** Container/table wrapper styles */
  container: Style;
  /** Header row styles */
  header: Style;
  /** Header cell styles */
  headerCell: Style;
  /** Base row styles */
  row: Style;
  /** Base cell styles */
  cell: Style;
  /** Even row styles (for striped variant) */
  evenRow?: Style;
  /** Odd row styles (for striped variant) */
  oddRow?: Style;
}

/**
 * All table styles configuration
 */
export type TableStyles = Record<TableVariant, TableStyleConfig>;
