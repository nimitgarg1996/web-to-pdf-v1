/**
 * TableCell Component
 * Renders individual table cells with formatting and alignment support
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import type { TableCellProps } from "./types.js";
import { getTableStyles, debugBorder } from "./styles.js";
import { formatCellValue, getRowValue, getTextAlign } from "./utils.js";
import { mergeStyles, type Style } from "../types.js";

/**
 * TableCell renders a single cell in a table row
 *
 * Features:
 * - Automatic value formatting using column.format
 * - Custom render function support via column.render
 * - Text alignment (left, center, right)
 * - Text wrapping control
 * - Flexible width based on column definition
 *
 * @example
 * ```tsx
 * <TableCell
 *   value={99.99}
 *   column={{ key: 'price', header: 'Price', width: '20%', align: 'right' }}
 *   row={{ id: 1, name: 'Product', price: 99.99 }}
 *   index={0}
 * />
 * ```
 */
export const TableCell: React.FC<TableCellProps> = ({
  value,
  column,
  row,
  index,
  style,
  variant = "default",
  debug = false,
}) => {
  const styles = getTableStyles(variant);

  // Calculate width style
  const widthStyle: Style = {};
  if (typeof column.width === "string") {
    if (column.width.endsWith("%")) {
      // For percentage widths, use flex
      const percentage = parseFloat(column.width.slice(0, -1));
      widthStyle.flex = percentage / 100;
    } else {
      // Fixed width
      widthStyle.width = parseFloat(column.width) || undefined;
    }
  } else if (typeof column.width === "number") {
    widthStyle.width = column.width;
  }

  // Apply min/max width constraints
  if (column.minWidth) {
    widthStyle.minWidth = column.minWidth;
  }
  if (column.maxWidth) {
    widthStyle.maxWidth = column.maxWidth;
  }

  // Text alignment
  const alignStyle: Style = {
    textAlign: getTextAlign(column.align),
  };

  // Get the actual value from the row (supporting dot notation)
  const actualValue = getRowValue(row, column.key);

  // Handle custom render function
  if (column.render) {
    const customContent = column.render(actualValue, row, index);

    return (
      <View
        style={mergeStyles(
          styles.cell,
          widthStyle,
          style,
          debug ? debugBorder : undefined
        )}
      >
        {customContent}
      </View>
    );
  }

  // Format the value
  const displayValue = formatCellValue(actualValue, column, row);

  return (
    <View
      style={mergeStyles(
        styles.cell,
        widthStyle,
        style,
        debug ? debugBorder : undefined
      )}
    >
      <Text
        style={mergeStyles(alignStyle, column.wrap === false ? { flexWrap: "nowrap" } : undefined)}
      >
        {displayValue}
      </Text>
    </View>
  );
};

export default TableCell;
