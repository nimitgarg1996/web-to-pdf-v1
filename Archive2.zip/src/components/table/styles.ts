/**
 * Table Styles
 * Pre-defined style configurations for table variants
 */

import { neutralColors, backgroundColors, borderColors } from "../../primitives/colors.js";
import { spacing, borderWidth } from "../../primitives/spacing.js";
import { textStyles, fontWeights } from "../../primitives/typography.js";
import type { TableStyles, TableStyleConfig } from "./types.js";

/**
 * Default table styles
 * Clean, professional look with subtle borders
 */
const defaultStyles: TableStyleConfig = {
  container: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
  },
  header: {
    backgroundColor: neutralColors[100],
    flexDirection: "row",
    borderBottomWidth: borderWidth.thin,
    borderBottomColor: borderColors.default,
    borderBottomStyle: "solid",
  },
  headerCell: {
    padding: spacing.sm,
    ...textStyles.tableHeader,
    fontWeight: fontWeights.semibold,
    color: neutralColors[700],
  },
  row: {
    flexDirection: "row",
    borderBottomWidth: borderWidth.hairline,
    borderBottomColor: borderColors.subtle,
    borderBottomStyle: "solid",
  },
  cell: {
    padding: spacing.sm,
    ...textStyles.tableCell,
    color: neutralColors[800],
  },
};

/**
 * Striped table styles
 * Alternating row backgrounds for better readability
 */
const stripedStyles: TableStyleConfig = {
  container: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
  },
  header: {
    backgroundColor: neutralColors[200],
    flexDirection: "row",
    borderBottomWidth: borderWidth.thin,
    borderBottomColor: borderColors.default,
    borderBottomStyle: "solid",
  },
  headerCell: {
    padding: spacing.sm,
    ...textStyles.tableHeader,
    fontWeight: fontWeights.semibold,
    color: neutralColors[800],
  },
  row: {
    flexDirection: "row",
  },
  cell: {
    padding: spacing.sm,
    ...textStyles.tableCell,
    color: neutralColors[800],
  },
  evenRow: {
    backgroundColor: backgroundColors.primary,
  },
  oddRow: {
    backgroundColor: neutralColors[50],
  },
};

/**
 * Bordered table styles
 * Full borders on all cells
 */
const borderedStyles: TableStyleConfig = {
  container: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    borderWidth: borderWidth.thin,
    borderColor: borderColors.default,
    borderStyle: "solid",
  },
  header: {
    backgroundColor: neutralColors[100],
    flexDirection: "row",
    borderBottomWidth: borderWidth.thin,
    borderBottomColor: borderColors.default,
    borderBottomStyle: "solid",
  },
  headerCell: {
    padding: spacing.sm,
    ...textStyles.tableHeader,
    fontWeight: fontWeights.semibold,
    color: neutralColors[700],
    borderRightWidth: borderWidth.thin,
    borderRightColor: borderColors.default,
    borderRightStyle: "solid",
  },
  row: {
    flexDirection: "row",
    borderBottomWidth: borderWidth.thin,
    borderBottomColor: borderColors.default,
    borderBottomStyle: "solid",
  },
  cell: {
    padding: spacing.sm,
    ...textStyles.tableCell,
    color: neutralColors[800],
    borderRightWidth: borderWidth.thin,
    borderRightColor: borderColors.default,
    borderRightStyle: "solid",
  },
};

/**
 * Minimal table styles
 * Very subtle styling, clean look
 */
const minimalStyles: TableStyleConfig = {
  container: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
  },
  header: {
    flexDirection: "row",
    borderBottomWidth: borderWidth.normal,
    borderBottomColor: neutralColors[300],
    borderBottomStyle: "solid",
    marginBottom: spacing.xs,
  },
  headerCell: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    ...textStyles.tableHeader,
    fontWeight: fontWeights.semibold,
    color: neutralColors[600],
  },
  row: {
    flexDirection: "row",
  },
  cell: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    ...textStyles.tableCell,
    color: neutralColors[700],
  },
};

/**
 * All table style variants
 */
export const tableStyles: TableStyles = {
  default: defaultStyles,
  striped: stripedStyles,
  bordered: borderedStyles,
  minimal: minimalStyles,
};

/**
 * Gets styles for a specific table variant
 * @param variant - The table variant name
 * @returns The style configuration for that variant
 */
export function getTableStyles(variant: keyof TableStyles): TableStyleConfig {
  return tableStyles[variant];
}

/**
 * Debug border style for development
 */
export const debugBorder = {
  borderWidth: 1,
  borderColor: "#ff0000",
  borderStyle: "solid" as const,
};
