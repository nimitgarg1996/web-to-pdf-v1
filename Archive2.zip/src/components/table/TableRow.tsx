/**
 * TableRow Component
 * Renders a single table row with orphan protection
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import type { TableRowProps } from "./types.js";
import { getTableStyles, debugBorder } from "./styles.js";
import { TableCell } from "./TableCell.js";
import { mergeStyles } from "../types.js";

/**
 * TableRow renders a single data row in a table
 *
 * Features:
 * - wrap={false} prevents row splitting across pages
 * - minPresenceAhead for orphan protection
 * - Zebra striping support (even/odd row styles)
 * - Custom style overrides
 *
 * @example
 * ```tsx
 * <TableRow
 *   data={{ id: 1, name: 'Product', price: 99.99 }}
 *   columns={columns}
 *   index={0}
 *   isEven={true}
 *   variant="striped"
 * />
 * ```
 */
export const TableRow: React.FC<TableRowProps> = ({
  data,
  columns,
  index,
  isEven,
  variant = "default",
  style,
  cellStyle,
  minPresenceAhead = 0,
  debug = false,
}) => {
  const styles = getTableStyles(variant);

  // Get the appropriate row style based on even/odd
  const zebraStyle = isEven ? styles.evenRow : styles.oddRow;

  return (
    <View
      style={mergeStyles(
        styles.row,
        zebraStyle,
        style,
        debug ? debugBorder : undefined
      )}
      wrap={false}
      minPresenceAhead={minPresenceAhead}
    >
      {columns.map((column, colIndex) => (
        <TableCell
          key={`cell-${column.key}-${colIndex}`}
          value={data[column.key]}
          column={column}
          row={data}
          index={index}
          style={cellStyle}
          isEven={isEven}
          variant={variant}
          debug={debug}
        />
      ))}
    </View>
  );
};

export default TableRow;
