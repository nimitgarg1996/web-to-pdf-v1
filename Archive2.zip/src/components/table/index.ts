/**
 * Table Component Module
 * Comprehensive table system for PDF reports with multi-page support
 *
 * Features:
 * - Header repetition across pages
 * - Orphan/widow protection
 * - Row integrity (no splitting)
 * - Multiple style variants
 * - Custom formatters
 * - Custom cell renderers
 */

// Types
export type {
  ColumnDefinition,
  TableProps,
  TableRowProps,
  TableCellProps,
  TableHeaderProps,
  TableVariant,
  TableStyleConfig,
  TableStyles,
} from "./types.js";

// Components
export { Table, default as TableDefault } from "./Table.js";
export { TableHeader } from "./TableHeader.js";
export { TableRow } from "./TableRow.js";
export { TableCell } from "./TableCell.js";

// Styles
export { tableStyles, getTableStyles, debugBorder } from "./styles.js";

// Utilities
export {
  parseWidth,
  calculateColumnWidths,
  calculateFlexValues,
  formatCellValue,
  getRowValue,
  formatters,
  getTextAlign,
  calculateMinPresenceAhead,
} from "./utils.js";
