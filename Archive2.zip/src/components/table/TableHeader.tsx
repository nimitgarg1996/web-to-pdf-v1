/**
 * TableHeader Component
 * Renders the table header row with column headers
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import type { TableHeaderProps } from "./types.js";
import { getTableStyles, debugBorder } from "./styles.js";
import { getTextAlign } from "./utils.js";
import { mergeStyles, type Style } from "../types.js";

/**
 * TableHeader renders the header row of a table
 *
 * Features:
 * - Fixed positioning for header repetition across pages
 * - Column header alignment (uses headerAlign or falls back to align)
 * - Styled based on table variant
 * - Supports custom style overrides
 *
 * @example
 * ```tsx
 * <TableHeader
 *   columns={[
 *     { key: 'name', header: 'Name', width: '40%' },
 *     { key: 'price', header: 'Price', width: '30%', headerAlign: 'right' },
 *   ]}
 *   fixed={true}
 *   variant="striped"
 * />
 * ```
 */
export const TableHeader: React.FC<TableHeaderProps> = ({
  columns,
  style,
  fixed = false,
  variant = "default",
  debug = false,
}) => {
  const styles = getTableStyles(variant);

  return (
    <View
      style={mergeStyles(styles.header, style, debug ? debugBorder : undefined)}
      fixed={fixed}
    >
      {columns.map((column, index) => {
        // Calculate width style for header cell
        const widthStyle: Style = {};
        if (typeof column.width === "string") {
          if (column.width.endsWith("%")) {
            const percentage = parseFloat(column.width.slice(0, -1));
            widthStyle.flex = percentage / 100;
          } else {
            widthStyle.width = parseFloat(column.width) || undefined;
          }
        } else if (typeof column.width === "number") {
          widthStyle.width = column.width;
        }

        // Apply min/max width constraints
        if (column.minWidth) {
          widthStyle.minWidth = column.minWidth;
        }
        if (column.maxWidth) {
          widthStyle.maxWidth = column.maxWidth;
        }

        // Header alignment (use headerAlign if specified, otherwise use align)
        const alignment = column.headerAlign || column.align || "left";
        const alignStyle: Style = {
          textAlign: getTextAlign(alignment),
        };

        return (
          <View
            key={`header-${column.key}-${index}`}
            style={mergeStyles(
              styles.headerCell,
              widthStyle,
              debug ? debugBorder : undefined
            )}
          >
            <Text style={alignStyle}>{column.header}</Text>
          </View>
        );
      })}
    </View>
  );
};

export default TableHeader;
