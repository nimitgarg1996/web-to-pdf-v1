/**
 * Table Component
 * Main table component that orchestrates table rendering with multi-page support
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import type { TableProps } from "./types.js";
import { getTableStyles, debugBorder } from "./styles.js";
import { TableHeader } from "./TableHeader.js";
import { TableRow } from "./TableRow.js";
import { calculateMinPresenceAhead } from "./utils.js";
import { mergeStyles, type Style } from "../types.js";

/**
 * Table renders a complete data table with multi-page support
 *
 * Features:
 * - Header repetition on each page (repeatHeader)
 * - Fixed header positioning (fixedHeader)
 * - Orphan protection (minRowsOnPage)
 * - Row integrity - prevents row splitting (keepRowsTogether)
 * - Multiple style variants (default, striped, bordered, minimal)
 * - Zebra striping for alternating row colors
 * - Custom style overrides at all levels
 *
 * @example
 * ```tsx
 * <Table
 *   columns={[
 *     { key: 'name', header: 'Product Name', width: '40%' },
 *     { key: 'quantity', header: 'Qty', width: '15%', align: 'center' },
 *     { key: 'price', header: 'Price', width: '20%', align: 'right',
 *       format: (v) => formatters.currency(v) },
 *     { key: 'total', header: 'Total', width: '25%', align: 'right',
 *       format: (v) => formatters.currency(v) },
 *   ]}
 *   data={orderItems}
 *   variant="striped"
 *   repeatHeader={true}
 * />
 * ```
 */
export const Table: React.FC<TableProps> = ({
  columns,
  data,
  repeatHeader = true,
  fixedHeader = false,
  minRowsOnPage = 3,
  keepRowsTogether = true,
  variant = "default",
  headerStyle,
  rowStyle,
  cellStyle,
  evenRowStyle,
  oddRowStyle,
  tableWidth = "100%",
  debug = false,
}) => {
  const styles = getTableStyles(variant);

  // Determine container width style
  const containerWidthStyle: Style =
    typeof tableWidth === "string"
      ? { width: tableWidth as Style["width"] }
      : { width: tableWidth };

  // Determine if header should be fixed (for repetition on each page)
  const isHeaderFixed = repeatHeader || fixedHeader;

  return (
    <View
      style={mergeStyles(
        styles.container,
        containerWidthStyle,
        debug ? debugBorder : undefined
      )}
    >
      {/* Table Header */}
      <TableHeader
        columns={columns}
        style={headerStyle}
        fixed={isHeaderFixed}
        variant={variant}
        debug={debug}
      />

      {/* Table Body - Data Rows */}
      {data.map((rowData, rowIndex) => {
        const isEven = rowIndex % 2 === 0;

        // Calculate minPresenceAhead for orphan protection
        const presenceAhead = keepRowsTogether
          ? calculateMinPresenceAhead(data.length, rowIndex, minRowsOnPage)
          : 0;

        // Determine row style based on even/odd - merge into single object
        const customRowStyle: Style | undefined = isEven
          ? evenRowStyle
            ? { ...rowStyle, ...evenRowStyle }
            : rowStyle
          : oddRowStyle
            ? { ...rowStyle, ...oddRowStyle }
            : rowStyle;

        return (
          <TableRow
            key={`row-${rowIndex}`}
            data={rowData}
            columns={columns}
            index={rowIndex}
            isEven={isEven}
            variant={variant}
            style={customRowStyle}
            cellStyle={cellStyle}
            minPresenceAhead={presenceAhead}
            debug={debug}
          />
        );
      })}
    </View>
  );
};

export default Table;
