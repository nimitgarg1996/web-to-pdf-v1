/**
 * Table Utilities
 * Helper functions for table calculations and formatting
 */

import type { ColumnDefinition } from "./types.js";

// ============================================================================
// Column Width Calculations
// ============================================================================

/**
 * Parses a width value to a numeric point value
 * @param width - Width as string (e.g., '40%', '100pt') or number
 * @param totalWidth - Total available width for percentage calculations
 * @returns Width in points
 */
export function parseWidth(
  width: string | number,
  totalWidth: number
): number {
  if (typeof width === "number") {
    return width;
  }

  const trimmed = width.trim();

  // Percentage
  if (trimmed.endsWith("%")) {
    const percentage = parseFloat(trimmed.slice(0, -1));
    return (percentage / 100) * totalWidth;
  }

  // Points (pt)
  if (trimmed.endsWith("pt")) {
    return parseFloat(trimmed.slice(0, -2));
  }

  // Assume it's a number string
  return parseFloat(trimmed) || 0;
}

/**
 * Calculates column widths from column definitions
 * @param columns - Array of column definitions
 * @param tableWidth - Total table width in points
 * @returns Array of calculated widths in points
 */
export function calculateColumnWidths(
  columns: ColumnDefinition[],
  tableWidth: number
): number[] {
  return columns.map((col) => parseWidth(col.width, tableWidth));
}

/**
 * Calculates flex values for columns based on widths
 * This is useful for React-PDF's flexbox layout
 * @param columns - Array of column definitions
 * @returns Array of flex values (proportional to widths)
 */
export function calculateFlexValues(columns: ColumnDefinition[]): number[] {
  // If widths are percentages, use them directly as flex values
  return columns.map((col) => {
    if (typeof col.width === "string" && col.width.endsWith("%")) {
      return parseFloat(col.width.slice(0, -1)) / 100;
    }
    // For fixed widths, use 0 (will be sized by width prop)
    return 0;
  });
}

// ============================================================================
// Cell Value Formatting
// ============================================================================

/**
 * Formats a cell value using the column's format function or default formatting
 * @param value - Raw cell value
 * @param column - Column definition
 * @param row - Full row data
 * @returns Formatted string value
 */
export function formatCellValue(
  value: unknown,
  column: ColumnDefinition,
  row: Record<string, unknown>
): string {
  // Use custom format function if provided
  if (column.format) {
    return column.format(value, row);
  }

  // Handle null/undefined
  if (value === null || value === undefined) {
    return "";
  }

  // Handle different types
  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }

  if (value instanceof Date) {
    return value.toLocaleDateString();
  }

  // Default: convert to string
  return String(value);
}

/**
 * Gets the value from a row using a dot-notation key
 * @param row - Row data object
 * @param key - Key string (supports dot notation like 'user.name')
 * @returns The value at that key path
 */
export function getRowValue(
  row: Record<string, unknown>,
  key: string
): unknown {
  const keys = key.split(".");
  let current: unknown = row;

  for (const k of keys) {
    if (current === null || current === undefined) {
      return undefined;
    }
    if (typeof current === "object") {
      current = (current as Record<string, unknown>)[k];
    } else {
      return undefined;
    }
  }

  return current;
}

// ============================================================================
// Default Formatters
// ============================================================================

/**
 * Pre-built formatters for common data types
 */
export const formatters = {
  /**
   * Formats a number as currency
   * @param value - Numeric value
   * @param currency - Currency code (default: 'USD')
   * @param locale - Locale string (default: 'en-US')
   * @returns Formatted currency string
   */
  currency: (
    value: number | null | undefined,
    currency: string = "USD",
    locale: string = "en-US"
  ): string => {
    if (value === null || value === undefined || isNaN(value)) {
      return "";
    }
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency,
    }).format(value);
  },

  /**
   * Formats a date value
   * @param value - Date value (string, Date, or timestamp)
   * @param options - Intl.DateTimeFormat options
   * @param locale - Locale string (default: 'en-US')
   * @returns Formatted date string
   */
  date: (
    value: string | Date | number | null | undefined,
    options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "short",
      day: "numeric",
    },
    locale: string = "en-US"
  ): string => {
    if (value === null || value === undefined) {
      return "";
    }
    const date = value instanceof Date ? value : new Date(value);
    if (isNaN(date.getTime())) {
      return String(value);
    }
    return new Intl.DateTimeFormat(locale, options).format(date);
  },

  /**
   * Formats a date and time value
   * @param value - Date value (string, Date, or timestamp)
   * @param locale - Locale string (default: 'en-US')
   * @returns Formatted datetime string
   */
  datetime: (
    value: string | Date | number | null | undefined,
    locale: string = "en-US"
  ): string => {
    return formatters.date(
      value,
      {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      },
      locale
    );
  },

  /**
   * Formats a number with specified decimal places
   * @param value - Numeric value
   * @param decimals - Number of decimal places (default: 2)
   * @param locale - Locale string (default: 'en-US')
   * @returns Formatted number string
   */
  number: (
    value: number | null | undefined,
    decimals: number = 2,
    locale: string = "en-US"
  ): string => {
    if (value === null || value === undefined || isNaN(value)) {
      return "";
    }
    return new Intl.NumberFormat(locale, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  },

  /**
   * Formats a number as an integer (no decimal places)
   * @param value - Numeric value
   * @param locale - Locale string (default: 'en-US')
   * @returns Formatted integer string
   */
  integer: (
    value: number | null | undefined,
    locale: string = "en-US"
  ): string => {
    return formatters.number(value, 0, locale);
  },

  /**
   * Formats a number as a percentage
   * @param value - Numeric value (0.5 = 50%)
   * @param decimals - Number of decimal places (default: 0)
   * @param locale - Locale string (default: 'en-US')
   * @returns Formatted percentage string
   */
  percentage: (
    value: number | null | undefined,
    decimals: number = 0,
    locale: string = "en-US"
  ): string => {
    if (value === null || value === undefined || isNaN(value)) {
      return "";
    }
    return new Intl.NumberFormat(locale, {
      style: "percent",
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  },

  /**
   * Formats a boolean value
   * @param value - Boolean value
   * @param trueText - Text for true (default: 'Yes')
   * @param falseText - Text for false (default: 'No')
   * @returns Formatted boolean string
   */
  boolean: (
    value: boolean | null | undefined,
    trueText: string = "Yes",
    falseText: string = "No"
  ): string => {
    if (value === null || value === undefined) {
      return "";
    }
    return value ? trueText : falseText;
  },

  /**
   * Truncates text to a maximum length
   * @param value - Text value
   * @param maxLength - Maximum length (default: 50)
   * @param suffix - Suffix for truncated text (default: '...')
   * @returns Truncated string
   */
  truncate: (
    value: string | null | undefined,
    maxLength: number = 50,
    suffix: string = "..."
  ): string => {
    if (value === null || value === undefined) {
      return "";
    }
    const str = String(value);
    if (str.length <= maxLength) {
      return str;
    }
    return str.slice(0, maxLength - suffix.length) + suffix;
  },

  /**
   * Formats a phone number (US format)
   * @param value - Phone number (10 digits)
   * @returns Formatted phone string
   */
  phone: (value: string | number | null | undefined): string => {
    if (value === null || value === undefined) {
      return "";
    }
    const digits = String(value).replace(/\D/g, "");
    if (digits.length === 10) {
      return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
    }
    if (digits.length === 11 && digits[0] === "1") {
      return `+1 (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7)}`;
    }
    return String(value);
  },
};

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Determines the text alignment style value
 * @param align - Alignment setting
 * @returns React-PDF compatible alignment value
 */
export function getTextAlign(
  align?: "left" | "center" | "right"
): "left" | "center" | "right" {
  return align || "left";
}

/**
 * Calculates the minimum presence ahead value for orphan protection
 * @param totalRows - Total number of rows
 * @param currentIndex - Current row index
 * @param minRows - Minimum rows to keep together
 * @returns The minPresenceAhead value to use
 */
export function calculateMinPresenceAhead(
  totalRows: number,
  currentIndex: number,
  minRows: number
): number {
  // For the last few rows, we need higher minPresenceAhead
  // to prevent orphaned rows on a new page
  const remainingRows = totalRows - currentIndex - 1;

  if (remainingRows < minRows && remainingRows > 0) {
    // If there are fewer rows remaining than minRows,
    // set minPresenceAhead to keep them all together
    return remainingRows;
  }

  // Default: ensure at least minRows stay together
  return Math.min(minRows, remainingRows);
}
