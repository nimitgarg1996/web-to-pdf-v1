/**
 * MetricCard Component
 * Displays a key metric with label, value, and optional trend indicator
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import {
  textStyles,
  semanticColors,
  statusColors,
  backgroundColors,
  spacing,
  borderRadius,
} from "../../primitives/index.js";
import { Icon } from "../media/Icon.js";
import type { IconName } from "../../primitives/index.js";

export interface MetricCardTrend {
  /** Numeric change value */
  value: number;
  /** Direction of change */
  direction: "up" | "down";
}

export interface MetricCardProps {
  /** Metric label */
  label: string;
  /** Metric value */
  value: string | number;
  /** Optional trend indicator */
  trend?: MetricCardTrend;
  /** Optional icon to display */
  icon?: IconName;
  /** Additional style overrides */
  style?: Style;
}

/**
 * MetricCard component for displaying key metrics in PDF documents.
 * Ideal for dashboards, reports, and data summaries.
 *
 * @example
 * ```tsx
 * <MetricCard label="Total Revenue" value="$125,430" />
 *
 * <MetricCard
 *   label="Active Users"
 *   value="1,234"
 *   trend={{ value: 12, direction: "up" }}
 * />
 *
 * <MetricCard
 *   label="Conversion Rate"
 *   value="3.2%"
 *   trend={{ value: 0.5, direction: "down" }}
 *   icon="chartLine"
 * />
 * ```
 */
export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  trend,
  icon,
  style,
}) => {
  const containerStyle: Style = {
    backgroundColor: backgroundColors.secondary,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    flexDirection: "column",
    gap: spacing.xs,
  };

  const headerStyle: Style = {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  };

  const labelStyle: Style = {
    ...textStyles.metricLabel,
    color: semanticColors.text.secondary,
  };

  const valueStyle: Style = {
    ...textStyles.metricValue,
    color: semanticColors.text.primary,
  };

  const trendContainerStyle: Style = {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xxs,
    marginTop: spacing.xxs,
  };

  const getTrendColor = (direction: "up" | "down") => {
    return direction === "up" ? statusColors.success : statusColors.error;
  };

  const getTrendIcon = (direction: "up" | "down"): IconName => {
    return direction === "up" ? "arrowUp" : "arrowDown";
  };

  const trendTextStyle = (direction: "up" | "down"): Style => ({
    ...textStyles.caption,
    color: getTrendColor(direction),
  });

  return (
    <View style={mergeStyles(containerStyle, style)}>
      <View style={headerStyle}>
        <Text style={labelStyle}>{label}</Text>
        {icon && (
          <Icon name={icon} size={16} color={semanticColors.text.muted} />
        )}
      </View>
      <Text style={valueStyle}>{String(value)}</Text>
      {trend && (
        <View style={trendContainerStyle}>
          <Icon
            name={getTrendIcon(trend.direction)}
            size={12}
            color={getTrendColor(trend.direction)}
          />
          <Text style={trendTextStyle(trend.direction)}>
            {trend.value > 0 ? "+" : ""}{trend.value}%
          </Text>
        </View>
      )}
    </View>
  );
};

export default MetricCard;
