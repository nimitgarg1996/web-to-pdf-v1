/**
 * KeyValue Component
 * Displays label-value pairs for data presentation
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors, spacing } from "../../primitives/index.js";

export interface KeyValueProps {
  /** Label text */
  label: string;
  /** Value to display */
  value: string | number;
  /** Width of the label column (for alignment) */
  labelWidth?: string | number;
  /** Display inline (horizontal) or stacked (vertical) */
  inline?: boolean;
  /** Gap between label and value */
  gap?: number;
  /** Label color override */
  labelColor?: string;
  /** Value color override */
  valueColor?: string;
  /** Additional style overrides */
  style?: Style;
}

/**
 * KeyValue component for displaying labeled data in PDF documents.
 * Useful for data tables, detail views, and form summaries.
 *
 * @example
 * ```tsx
 * <KeyValue label="Name" value="John Doe" />
 * <KeyValue label="Email" value="john@example.com" inline labelWidth={100} />
 * <KeyValue label="Status" value="Active" valueColor="#22c55e" />
 * ```
 */
export const KeyValue: React.FC<KeyValueProps> = ({
  label,
  value,
  labelWidth,
  inline = false,
  gap = spacing.xs,
  labelColor,
  valueColor,
  style,
}) => {
  const containerStyle: Style = inline
    ? {
        flexDirection: "row",
        alignItems: "baseline",
        gap,
      }
    : {
        flexDirection: "column",
        gap: spacing.xxs,
      };

  const labelStyle: Style = {
    ...textStyles.label,
    color: labelColor || semanticColors.text.secondary,
    ...(inline && labelWidth !== undefined && { width: labelWidth }),
  };

  const valueStyle: Style = {
    ...textStyles.body,
    color: valueColor || semanticColors.text.primary,
    ...(inline && { flex: 1 }),
  };

  return (
    <View style={mergeStyles(containerStyle, style)}>
      <Text style={labelStyle}>{label}</Text>
      <Text style={valueStyle}>{String(value)}</Text>
    </View>
  );
};

export default KeyValue;
