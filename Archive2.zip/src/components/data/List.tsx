/**
 * List Component
 * Renders bullet, numbered, or plain lists
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors, spacing } from "../../primitives/index.js";

export interface ListProps {
  /** Array of items to display */
  items: string[];
  /** List type */
  type?: "bullet" | "number" | "none";
  /** Space between list items */
  spacing?: number;
  /** Indent for the list marker */
  markerIndent?: number;
  /** Text color */
  color?: string;
  /** Bullet character (for bullet type) */
  bulletChar?: string;
  /** Additional style overrides */
  style?: Style;
}

/**
 * List component for displaying itemized content in PDF documents.
 * Supports bulleted, numbered, and plain list styles.
 *
 * @example
 * ```tsx
 * <List items={["First item", "Second item", "Third item"]} />
 *
 * <List
 *   items={["Step one", "Step two", "Step three"]}
 *   type="number"
 *   spacing={8}
 * />
 *
 * <List
 *   items={["Feature A", "Feature B"]}
 *   type="bullet"
 *   bulletChar="→"
 * />
 * ```
 */
export const List: React.FC<ListProps> = ({
  items,
  type = "bullet",
  spacing: itemSpacing = spacing.xs,
  markerIndent = spacing.sm,
  color,
  bulletChar = "•",
  style,
}) => {
  const containerStyle: Style = {
    flexDirection: "column",
  };

  const itemContainerStyle: Style = {
    flexDirection: "row",
    marginBottom: itemSpacing,
  };

  const markerStyle: Style = {
    ...textStyles.body,
    color: color || semanticColors.text.secondary,
    width: markerIndent,
    textAlign: "left",
  };

  const textStyle: Style = {
    ...textStyles.body,
    color: color || semanticColors.text.primary,
    flex: 1,
  };

  /**
   * Get the marker text for a list item
   */
  const getMarker = (index: number): string => {
    switch (type) {
      case "bullet":
        return bulletChar;
      case "number":
        return `${index + 1}.`;
      case "none":
        return "";
      default:
        return bulletChar;
    }
  };

  return (
    <View style={mergeStyles(containerStyle, style)}>
      {items.map((item, index) => (
        <View key={index} style={itemContainerStyle}>
          {type !== "none" && <Text style={markerStyle}>{getMarker(index)}</Text>}
          <Text style={textStyle}>{item}</Text>
        </View>
      ))}
    </View>
  );
};

export default List;
