/**
 * Navigation Components Index
 * Export all navigation-related components
 */

// Table of Contents
export {
  TableOfContents,
  CompactToc,
  type TableOfContentsProps,
  type CompactTocProps,
} from "./TableOfContents.js";

// Crop Marks and Print Marks
export {
  CropMarks,
  RegistrationMarks,
  PrintMarks,
  type CropMarksProps,
  type RegistrationMarksProps,
  type PrintMarksProps,
} from "./CropMarks.js";

// Default export
export { default as TableOfContentsDefault } from "./TableOfContents.js";
