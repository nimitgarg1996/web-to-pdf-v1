/**
 * CropMarks Component
 * React-PDF component for rendering print crop marks
 */

import React from "react";
import { View, Svg, Line, Circle, StyleSheet } from "@react-pdf/renderer";
import type { Style } from "../types.js";
import type {
  PrintDimensions,
  CropMarksConfig,
  RegistrationMarksConfig,
  CropMarkPosition,
} from "../../utils/printReady.js";
import {
  calculateCropMarks,
  calculateRegistrationMarks,
  defaultPrintConfig,
} from "../../utils/printReady.js";

// ============================================================================
// Types
// ============================================================================

/**
 * Props for CropMarks component
 */
export interface CropMarksProps {
  /** Total page width (including bleed) */
  pageWidth: number;
  /** Total page height (including bleed) */
  pageHeight: number;
  /** Bleed configuration */
  bleed: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
  /** Crop marks configuration */
  config?: CropMarksConfig;
  /** Custom style */
  style?: Style;
}

/**
 * Props for RegistrationMarks component
 */
export interface RegistrationMarksProps {
  /** Total page width (including bleed) */
  pageWidth: number;
  /** Total page height (including bleed) */
  pageHeight: number;
  /** Bleed configuration */
  bleed: {
    top: number;
    right: number;
    bottom: number;
    left: number;
  };
  /** Registration marks configuration */
  config?: RegistrationMarksConfig;
  /** Custom style */
  style?: Style;
}

/**
 * Props for combined print marks
 */
export interface PrintMarksProps {
  /** Print dimensions */
  dimensions: PrintDimensions;
  /** Show crop marks */
  showCropMarks?: boolean;
  /** Show registration marks */
  showRegistrationMarks?: boolean;
  /** Crop marks configuration */
  cropMarksConfig?: CropMarksConfig;
  /** Registration marks configuration */
  registrationMarksConfig?: RegistrationMarksConfig;
  /** Custom style */
  style?: Style;
}

// ============================================================================
// CropMarks Component
// ============================================================================

/**
 * Renders crop marks at the corners of a print-ready page.
 * These marks indicate where the page should be trimmed.
 *
 * @example
 * ```tsx
 * <Page size={{ width: totalWidth, height: totalHeight }}>
 *   <CropMarks
 *     pageWidth={totalWidth}
 *     pageHeight={totalHeight}
 *     bleed={{ top: 8.5, right: 8.5, bottom: 8.5, left: 8.5 }}
 *   />
 *   <View style={contentAreaStyle}>
 *     {children}
 *   </View>
 * </Page>
 * ```
 */
export const CropMarks: React.FC<CropMarksProps> = ({
  pageWidth,
  pageHeight,
  bleed,
  config = defaultPrintConfig.cropMarks,
  style,
}) => {
  if (!config.enabled) {
    return null;
  }

  const dimensions: PrintDimensions = {
    baseWidth: pageWidth - bleed.left - bleed.right,
    baseHeight: pageHeight - bleed.top - bleed.bottom,
    totalWidth: pageWidth,
    totalHeight: pageHeight,
    bleed,
  };

  const marks = calculateCropMarks(dimensions, config);

  const styles = StyleSheet.create({
    container: {
      position: "absolute",
      top: 0,
      left: 0,
      width: pageWidth,
      height: pageHeight,
    },
  });

  // Combine styles, filtering out undefined
  const containerStyle = style ? [styles.container, style] : styles.container;

  return (
    <View style={containerStyle} fixed>
      <Svg width={pageWidth} height={pageHeight}>
        {marks.map((mark, index) => (
          <Line
            key={`crop-${index}`}
            x1={mark.x1}
            y1={mark.y1}
            x2={mark.x2}
            y2={mark.y2}
            stroke={config.color}
            strokeWidth={config.strokeWidth}
          />
        ))}
      </Svg>
    </View>
  );
};

// ============================================================================
// RegistrationMarks Component
// ============================================================================

/**
 * Renders registration marks for print alignment.
 * These marks help align color separations during printing.
 *
 * @example
 * ```tsx
 * <Page size={{ width: totalWidth, height: totalHeight }}>
 *   <RegistrationMarks
 *     pageWidth={totalWidth}
 *     pageHeight={totalHeight}
 *     bleed={{ top: 8.5, right: 8.5, bottom: 8.5, left: 8.5 }}
 *   />
 *   {content}
 * </Page>
 * ```
 */
export const RegistrationMarks: React.FC<RegistrationMarksProps> = ({
  pageWidth,
  pageHeight,
  bleed,
  config = defaultPrintConfig.registrationMarks,
  style,
}) => {
  if (!config.enabled) {
    return null;
  }

  const dimensions: PrintDimensions = {
    baseWidth: pageWidth - bleed.left - bleed.right,
    baseHeight: pageHeight - bleed.top - bleed.bottom,
    totalWidth: pageWidth,
    totalHeight: pageHeight,
    bleed,
  };

  const positions = calculateRegistrationMarks(dimensions, config);
  const markSize = config.size;
  const halfSize = markSize / 2;

  const styles = StyleSheet.create({
    container: {
      position: "absolute",
      top: 0,
      left: 0,
      width: pageWidth,
      height: pageHeight,
    },
  });

  // Combine styles, filtering out undefined
  const containerStyle = style ? [styles.container, style] : styles.container;

  return (
    <View style={containerStyle} fixed>
      <Svg width={pageWidth} height={pageHeight}>
        {positions.map((pos, index) => (
          <React.Fragment key={`reg-${index}`}>
            {/* Horizontal line */}
            <Line
              x1={pos.x - halfSize}
              y1={pos.y}
              x2={pos.x + halfSize}
              y2={pos.y}
              stroke="black"
              strokeWidth={config.strokeWidth}
            />
            {/* Vertical line */}
            <Line
              x1={pos.x}
              y1={pos.y - halfSize}
              x2={pos.x}
              y2={pos.y + halfSize}
              stroke="black"
              strokeWidth={config.strokeWidth}
            />
            {/* Circle */}
            <Circle
              cx={pos.x}
              cy={pos.y}
              r={markSize / 3}
              stroke="black"
              strokeWidth={config.strokeWidth}
              fill="none"
            />
          </React.Fragment>
        ))}
      </Svg>
    </View>
  );
};

// ============================================================================
// Combined PrintMarks Component
// ============================================================================

/**
 * Combined component that renders both crop marks and registration marks.
 *
 * @example
 * ```tsx
 * <Page size={{ width: dims.totalWidth, height: dims.totalHeight }}>
 *   <PrintMarks
 *     dimensions={dims}
 *     showCropMarks={true}
 *     showRegistrationMarks={true}
 *   />
 *   <View style={contentAreaStyle}>
 *     {content}
 *   </View>
 * </Page>
 * ```
 */
export const PrintMarks: React.FC<PrintMarksProps> = ({
  dimensions,
  showCropMarks = true,
  showRegistrationMarks = false,
  cropMarksConfig,
  registrationMarksConfig,
  style,
}) => {
  const { totalWidth, totalHeight, bleed } = dimensions;

  return (
    <>
      {showCropMarks && (
        <CropMarks
          pageWidth={totalWidth}
          pageHeight={totalHeight}
          bleed={bleed}
          config={cropMarksConfig}
          style={style}
        />
      )}
      {showRegistrationMarks && (
        <RegistrationMarks
          pageWidth={totalWidth}
          pageHeight={totalHeight}
          bleed={bleed}
          config={registrationMarksConfig}
          style={style}
        />
      )}
    </>
  );
};

// ============================================================================
// Default Export
// ============================================================================

export default CropMarks;
