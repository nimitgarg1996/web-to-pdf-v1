/**
 * TableOfContents Component
 * React-PDF component for rendering table of contents
 */

import React from "react";
import { View, Text, Link, StyleSheet } from "@react-pdf/renderer";
import type { Style } from "../types.js";
import type { TocEntry } from "../../utils/toc.js";
import { defaultTheme } from "../../primitives/theme.js";
import type { Theme } from "../../primitives/theme.js";

// ============================================================================
// Types
// ============================================================================

/**
 * Props for TableOfContents component
 */
export interface TableOfContentsProps {
  /** TOC entries to render */
  entries: TocEntry[];
  /** TOC title (default: "Table of Contents") */
  title?: string;
  /** Show page numbers */
  showPageNumbers?: boolean;
  /** Maximum depth of entries to show */
  maxDepth?: number;
  /** Show dotted leaders between title and page */
  showDotLeader?: boolean;
  /** Custom styles */
  style?: Style;
  /** Theme for styling */
  theme?: Theme;
}

/**
 * Props for a single TOC entry row
 */
interface TocEntryRowProps {
  entry: TocEntry;
  indentSize: number;
  showPageNumbers: boolean;
  showDotLeader: boolean;
  theme: Theme;
}

// ============================================================================
// Styles
// ============================================================================

/**
 * Create styles for TOC component
 */
const createStyles = (theme: Theme = defaultTheme) =>
  StyleSheet.create({
    container: {
      marginBottom: 30,
    },
    title: {
      fontSize: theme.typography.fontSizes.xl,
      fontFamily: theme.typography.fontFamilies.primary,
      fontWeight: theme.typography.fontWeights.bold,
      color: theme.colors.semantic.text.primary,
      marginBottom: 20,
      textAlign: "center",
    },
    entriesContainer: {
      marginTop: 10,
    },
    entryRow: {
      flexDirection: "row",
      alignItems: "flex-end",
      marginBottom: 6,
      minHeight: 18,
    },
    entryLink: {
      textDecoration: "none",
      flex: 1,
      flexDirection: "row",
      alignItems: "flex-end",
    },
    entryText: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.primary,
    },
    entryTextLevel1: {
      fontWeight: theme.typography.fontWeights.semibold,
    },
    entryTextLevel2: {
      fontWeight: theme.typography.fontWeights.medium,
    },
    entryTextLevel3: {
      fontWeight: theme.typography.fontWeights.regular,
    },
    entryTextLevel4: {
      fontWeight: theme.typography.fontWeights.regular,
      fontStyle: "italic",
    },
    dotLeader: {
      flex: 1,
      marginHorizontal: 4,
      borderBottomWidth: 1,
      borderBottomStyle: "dotted",
      borderBottomColor: theme.colors.semantic.border.subtle,
      marginBottom: 2,
    },
    pageNumber: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      minWidth: 24,
      textAlign: "right",
    },
    noEntries: {
      fontSize: theme.typography.fontSizes.sm,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      fontStyle: "italic",
      textAlign: "center",
    },
  });

// ============================================================================
// Helper Components
// ============================================================================

/**
 * Single TOC entry row component
 */
const TocEntryRow: React.FC<TocEntryRowProps> = ({
  entry,
  indentSize,
  showPageNumbers,
  showDotLeader,
  theme,
}) => {
  const styles = createStyles(theme);

  // Get level-specific text style
  const getLevelStyle = (level: number): Style => {
    switch (level) {
      case 1:
        return styles.entryTextLevel1;
      case 2:
        return styles.entryTextLevel2;
      case 3:
        return styles.entryTextLevel3;
      default:
        return styles.entryTextLevel4;
    }
  };

  const indentStyle: Style = {
    marginLeft: (entry.level - 1) * indentSize,
  };

  return (
    <View style={[styles.entryRow, indentStyle]}>
      <Link src={`#${entry.id}`} style={styles.entryLink}>
        <Text style={[styles.entryText, getLevelStyle(entry.level)]}>
          {entry.title}
        </Text>
        {showDotLeader && showPageNumbers && <View style={styles.dotLeader} />}
      </Link>
      {showPageNumbers && entry.pageNumber !== undefined && (
        <Text style={styles.pageNumber}>{entry.pageNumber}</Text>
      )}
    </View>
  );
};

// ============================================================================
// Main Component
// ============================================================================

/**
 * TableOfContents component for rendering a formatted TOC in PDF documents.
 * Supports multiple heading levels, page numbers, and dot leaders.
 *
 * @example
 * ```tsx
 * import { TableOfContents } from './components/navigation/TableOfContents';
 *
 * const entries = [
 *   { id: 'intro', title: 'Introduction', level: 1, pageNumber: 1 },
 *   { id: 'overview', title: 'Overview', level: 2, pageNumber: 2 },
 *   { id: 'details', title: 'Details', level: 2, pageNumber: 5 },
 * ];
 *
 * <Page>
 *   <TableOfContents
 *     entries={entries}
 *     title="Contents"
 *     showPageNumbers={true}
 *     showDotLeader={true}
 *   />
 * </Page>
 * ```
 */
export const TableOfContents: React.FC<TableOfContentsProps> = ({
  entries,
  title = "Table of Contents",
  showPageNumbers = true,
  maxDepth = 3,
  showDotLeader = true,
  style,
  theme = defaultTheme,
}) => {
  const styles = createStyles(theme);

  // Filter entries by max depth
  const filteredEntries = entries.filter((entry) => entry.level <= maxDepth);

  // Indent size in points per level
  const indentSize = 15;

  // Combine styles, filtering out undefined
  const containerStyle = style ? [styles.container, style] : styles.container;

  return (
    <View style={containerStyle} wrap={false}>
      {title && <Text style={styles.title}>{title}</Text>}

      <View style={styles.entriesContainer}>
        {filteredEntries.length === 0 ? (
          <Text style={styles.noEntries}>No entries</Text>
        ) : (
          filteredEntries.map((entry) => (
            <TocEntryRow
              key={entry.id}
              entry={entry}
              indentSize={indentSize}
              showPageNumbers={showPageNumbers}
              showDotLeader={showDotLeader}
              theme={theme}
            />
          ))
        )}
      </View>
    </View>
  );
};

// ============================================================================
// Compact Variant
// ============================================================================

/**
 * Props for compact TOC variant
 */
export interface CompactTocProps {
  /** TOC entries to render */
  entries: TocEntry[];
  /** Maximum entries to show */
  maxEntries?: number;
  /** Custom styles */
  style?: Style;
  /** Theme for styling */
  theme?: Theme;
}

/**
 * Compact TOC variant for sidebars or headers
 */
export const CompactToc: React.FC<CompactTocProps> = ({
  entries,
  maxEntries = 5,
  style,
  theme = defaultTheme,
}) => {
  const styles = StyleSheet.create({
    container: {
      padding: 8,
    },
    entry: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      marginBottom: 4,
    },
    more: {
      fontSize: theme.typography.fontSizes.xs,
      fontFamily: theme.typography.fontFamilies.primary,
      color: theme.colors.semantic.text.muted,
      fontStyle: "italic",
    },
  });

  const displayEntries = entries.slice(0, maxEntries);
  const remainingCount = entries.length - maxEntries;

  // Combine styles, filtering out undefined
  const containerStyle = style ? [styles.container, style] : styles.container;

  return (
    <View style={containerStyle}>
      {displayEntries.map((entry) => (
        <Link key={entry.id} src={`#${entry.id}`}>
          <Text style={styles.entry}>• {entry.title}</Text>
        </Link>
      ))}
      {remainingCount > 0 && (
        <Text style={styles.more}>...and {remainingCount} more</Text>
      )}
    </View>
  );
};

// ============================================================================
// Default Export
// ============================================================================

export default TableOfContents;
