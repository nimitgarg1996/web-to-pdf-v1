/**
 * Component Types
 * Shared type definitions for React-PDF components
 */

import type { Style as ReactPDFStyle } from "@react-pdf/types";

/**
 * Style type for React-PDF components
 * Re-exported from @react-pdf/types for convenience
 */
export type Style = ReactPDFStyle;

/**
 * Merges multiple style objects, filtering out undefined values
 * @param styles - Array of style objects or undefined values
 * @returns Merged style array safe for React-PDF components
 */
export function mergeStyles(...styles: (Style | undefined)[]): Style[] {
  return styles.filter((s): s is Style => s !== undefined);
}
