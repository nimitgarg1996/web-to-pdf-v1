/**
 * Icon Component
 * Renders SVG icons from the icon registry
 */

import React from "react";
import { Svg, Path } from "@react-pdf/renderer";
import type { Style } from "../types.js";
import { icons, semanticColors } from "../../primitives/index.js";
import type { IconName } from "../../primitives/index.js";

export interface IconProps {
  /** Icon name from the registry */
  name: IconName;
  /** Icon size in points (width and height) */
  size?: number;
  /** Icon color */
  color?: string;
  /** Additional style overrides for the container */
  style?: Style;
}

/**
 * Icon component for rendering SVG icons in PDF documents.
 * Uses the icon registry from primitives for consistent iconography.
 *
 * @example
 * ```tsx
 * <Icon name="check" />
 * <Icon name="warning" color="#f59e0b" size={24} />
 * <Icon name="chartBar" size={32} color="#3b82f6" />
 * ```
 */
export const Icon: React.FC<IconProps> = ({
  name,
  size = 16,
  color = semanticColors.text.primary,
  style,
}) => {
  const icon = icons[name];

  if (!icon) {
    // Return empty view if icon not found
    return null;
  }

  return (
    <Svg
      width={size}
      height={size}
      viewBox={icon.viewBox}
      style={style}
    >
      <Path
        d={icon.path}
        fill={color}
      />
    </Svg>
  );
};

export default Icon;
