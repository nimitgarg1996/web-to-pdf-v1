/**
 * Logo Component
 * Displays company/brand logo with aspect ratio preservation
 */

import React from "react";
import { Image, View } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";

export interface LogoProps {
  /** Image source - URL or local path */
  src: string;
  /** Logo width in points */
  width?: number;
  /** Logo height in points */
  height?: number;
  /** Alt text for accessibility (used as title) */
  alt?: string;
  /** Alignment within container */
  align?: "left" | "center" | "right";
  /** Additional style overrides */
  style?: Style;
}

/**
 * Maps alignment prop to flexbox justifyContent value
 */
const alignMap = {
  left: "flex-start",
  center: "center",
  right: "flex-end",
} as const;

/**
 * Logo component for displaying brand images in PDF documents.
 * Automatically preserves aspect ratio based on provided dimensions.
 *
 * @example
 * ```tsx
 * <Logo src="/assets/logo.png" width={120} />
 * <Logo src="https://example.com/logo.png" height={40} align="center" />
 * <Logo src="/assets/brand.svg" width={100} height={50} />
 * ```
 */
export const Logo: React.FC<LogoProps> = ({
  src,
  width,
  height,
  alt,
  align = "left",
  style,
}) => {
  const containerStyle: Style = {
    flexDirection: "row",
    justifyContent: alignMap[align],
    width: "100%",
  };

  const imageStyle: Style = {
    ...(width !== undefined && { width }),
    ...(height !== undefined && { height }),
    objectFit: "contain",
  };

  // If only width or height is provided, let the image auto-scale
  // If both are provided, the image will fit within those bounds

  return (
    <View style={containerStyle}>
      <Image
        src={src}
        style={mergeStyles(imageStyle, style)}
      />
    </View>
  );
};

export default Logo;
