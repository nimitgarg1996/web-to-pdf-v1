/**
 * ProgressBar Component
 * Visual progress indicator using SVG for precise rendering
 */

import React from "react";
import { Svg, Rect, View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import {
  brandColors,
  neutralColors,
  statusColors,
  textColors,
  spacing,
  fontSizes,
  borderRadius,
} from "../../primitives/index.js";

export interface ProgressBarProps {
  /** Progress value (0-100) */
  value: number;
  /** Maximum value (defaults to 100) */
  max?: number;
  /** Width of the progress bar in points */
  width?: number;
  /** Height of the progress bar in points */
  height?: number;
  /** Color variant */
  variant?: "default" | "success" | "warning" | "error";
  /** Whether to show the percentage label */
  showLabel?: boolean;
  /** Custom label text (overrides percentage) */
  label?: string;
  /** Additional style overrides for the container */
  style?: Style;
}

/**
 * Color mapping for progress bar variants
 */
const variantColors = {
  default: brandColors[500],
  success: statusColors.success,
  warning: statusColors.warning,
  error: statusColors.error,
} as const;

/**
 * ProgressBar component for showing completion status in PDF documents.
 * Uses SVG for precise rendering with smooth edges.
 *
 * @example
 * ```tsx
 * <ProgressBar value={75} />
 * <ProgressBar value={50} showLabel />
 * <ProgressBar value={30} variant="warning" width={200} />
 * <ProgressBar value={100} variant="success" label="Complete" />
 * ```
 */
export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  max = 100,
  width = 150,
  height = 8,
  variant = "default",
  showLabel = false,
  label,
  style,
}) => {
  // Clamp value between 0 and max
  const clampedValue = Math.max(0, Math.min(value, max));
  const percentage = (clampedValue / max) * 100;
  const fillWidth = (percentage / 100) * width;
  
  const barColor = variantColors[variant];
  const trackColor = neutralColors[200];
  const radius = Math.min(height / 2, borderRadius.sm);

  const containerStyle: Style = {
    flexDirection: "column",
    gap: spacing.xxs,
  };

  const labelStyle: Style = {
    fontSize: fontSizes.xs,
    color: textColors.secondary,
  };

  const displayLabel = label || `${Math.round(percentage)}%`;

  return (
    <View style={mergeStyles(containerStyle, style)}>
      <Svg width={width} height={height}>
        {/* Track (background) */}
        <Rect
          x={0}
          y={0}
          width={width}
          height={height}
          rx={radius}
          ry={radius}
          fill={trackColor}
        />
        {/* Fill (progress) */}
        {fillWidth > 0 && (
          <Rect
            x={0}
            y={0}
            width={fillWidth}
            height={height}
            rx={radius}
            ry={radius}
            fill={barColor}
          />
        )}
      </Svg>
      {showLabel && <Text style={labelStyle}>{displayLabel}</Text>}
    </View>
  );
};

export default ProgressBar;
