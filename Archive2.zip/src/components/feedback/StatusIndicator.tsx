/**
 * StatusIndicator Component
 * Colored dot with optional label for status display
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import {
  statusColors,
  textColors,
  neutralColors,
  spacing,
  fontSizes,
} from "../../primitives/index.js";

export interface StatusIndicatorProps {
  /** Status variant determining the dot color */
  status: "success" | "warning" | "error" | "info" | "neutral";
  /** Optional label text */
  label?: string;
  /** Dot size in points */
  size?: number;
  /** Gap between dot and label */
  gap?: number;
  /** Label color override */
  labelColor?: string;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Color mapping for each status variant
 */
const statusColorMap = {
  success: statusColors.success,
  warning: statusColors.warning,
  error: statusColors.error,
  info: statusColors.info,
  neutral: neutralColors[400],
} as const;

/**
 * StatusIndicator component for status display in PDF documents.
 * Shows a colored dot with an optional text label.
 *
 * @example
 * ```tsx
 * <StatusIndicator status="success" label="Active" />
 * <StatusIndicator status="warning" label="Pending Review" />
 * <StatusIndicator status="error" size={10} />
 * <StatusIndicator status="neutral" label="Inactive" />
 * ```
 */
export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  label,
  size = 8,
  gap = spacing.xs,
  labelColor,
  style,
}) => {
  const dotColor = statusColorMap[status];

  const containerStyle: Style = {
    flexDirection: "row",
    alignItems: "center",
    gap,
  };

  const dotStyle: Style = {
    width: size,
    height: size,
    borderRadius: size / 2,
    backgroundColor: dotColor,
  };

  const labelStyle: Style = {
    fontSize: fontSizes.sm,
    color: labelColor || textColors.secondary,
  };

  return (
    <View style={mergeStyles(containerStyle, style)}>
      <View style={dotStyle} />
      {label && <Text style={labelStyle}>{label}</Text>}
    </View>
  );
};

export default StatusIndicator;
