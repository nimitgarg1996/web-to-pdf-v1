/**
 * Badge Component
 * Small status indicator with text for categorization and labeling
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import {
  statusColors,
  backgroundColors,
  textColors,
  borderRadius,
  spacing,
  fontSizes,
  fontWeights,
} from "../../primitives/index.js";

export interface BadgeProps {
  /** Badge text content */
  children: string;
  /** Visual variant */
  variant?: "default" | "success" | "warning" | "error" | "info";
  /** Badge size */
  size?: "sm" | "md";
  /** Additional style overrides */
  style?: Style;
}

/**
 * Color configuration for each badge variant
 */
const variantColors = {
  default: {
    background: backgroundColors.muted,
    text: textColors.secondary,
  },
  success: {
    background: statusColors.successBackground,
    text: statusColors.success,
  },
  warning: {
    background: statusColors.warningBackground,
    text: statusColors.warning,
  },
  error: {
    background: statusColors.errorBackground,
    text: statusColors.error,
  },
  info: {
    background: statusColors.infoBackground,
    text: statusColors.info,
  },
} as const;

/**
 * Size configuration for badges
 */
const sizeConfig = {
  sm: {
    fontSize: fontSizes.xs,
    paddingHorizontal: spacing.xs,
    paddingVertical: spacing.xxs,
  },
  md: {
    fontSize: fontSizes.sm,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
} as const;

/**
 * Badge component for status indicators and labels in PDF documents.
 * Used for categorization, status display, and small labels.
 *
 * @example
 * ```tsx
 * <Badge>Default</Badge>
 * <Badge variant="success">Approved</Badge>
 * <Badge variant="warning" size="sm">Pending</Badge>
 * <Badge variant="error">Rejected</Badge>
 * ```
 */
export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = "default",
  size = "md",
  style,
}) => {
  const colors = variantColors[variant];
  const sizeStyles = sizeConfig[size];

  const containerStyle: Style = {
    backgroundColor: colors.background,
    borderRadius: borderRadius.sm,
    paddingHorizontal: sizeStyles.paddingHorizontal,
    paddingVertical: sizeStyles.paddingVertical,
    alignSelf: "flex-start",
  };

  const textStyle: Style = {
    color: colors.text,
    fontSize: sizeStyles.fontSize,
    fontWeight: fontWeights.medium,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  };

  return (
    <View style={mergeStyles(containerStyle, style)}>
      <Text style={textStyle}>{children}</Text>
    </View>
  );
};

export default Badge;
