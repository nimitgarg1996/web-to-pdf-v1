/**
 * Circle Shape
 * Simple circular node shape for diagrams
 */

import React from "react";
import { Circle as SvgCircle } from "@react-pdf/renderer";
import { ShapeProps } from "../types.js";

/**
 * Props for Circle shape (extends ShapeProps)
 * Width and height determine the ellipse radii
 */
export interface CircleShapeProps extends ShapeProps {
  /** If true, forces a perfect circle using the smaller dimension */
  perfectCircle?: boolean;
}

/**
 * Circle/Ellipse shape component for diagram nodes
 * Renders as an SVG Circle element
 */
export const CircleShape: React.FC<CircleShapeProps> = ({
  width,
  height,
  fill = "#ffffff",
  stroke = "#e2e8f0",
  strokeWidth = 1,
  perfectCircle = true,
}) => {
  // Calculate center and radius
  const cx = width / 2;
  const cy = height / 2;

  // For perfect circle, use smaller dimension
  const radius = perfectCircle
    ? Math.min(width, height) / 2
    : Math.min(width, height) / 2;

  return (
    <SvgCircle
      cx={cx}
      cy={cy}
      r={radius - strokeWidth / 2}
      fill={fill}
      stroke={stroke}
      strokeWidth={strokeWidth}
    />
  );
};

export { CircleShape as Circle };
export default CircleShape;
