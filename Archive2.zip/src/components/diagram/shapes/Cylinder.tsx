/**
 * Cylinder Shape
 * Database/storage node shape for diagrams
 */

import React from "react";
import { Path, Ellipse, G } from "@react-pdf/renderer";
import { ShapeProps } from "../types.js";

/**
 * Props for Cylinder shape
 */
export interface CylinderShapeProps extends ShapeProps {
  /** Height of the elliptical cap (default: 15% of height) */
  capHeight?: number;
}

/**
 * Cylinder shape component for database/storage nodes
 * Renders as an SVG Group with ellipse caps and body
 */
export const Cylinder: React.FC<CylinderShapeProps> = ({
  width,
  height,
  fill = "#ffffff",
  stroke = "#e2e8f0",
  strokeWidth = 1,
  capHeight,
}) => {
  // Calculate ellipse dimensions
  const rx = width / 2;
  const ellipseRy = capHeight ?? height * 0.15;
  const ry = Math.min(ellipseRy, height / 4); // Cap at 25% of height

  // Body dimensions
  const bodyTop = ry;
  const bodyBottom = height - ry;

  // Path for the cylinder body (left side, bottom ellipse, right side)
  const bodyPath = `
    M 0,${bodyTop}
    L 0,${bodyBottom}
    A ${rx},${ry} 0 0 0 ${width},${bodyBottom}
    L ${width},${bodyTop}
  `;

  return (
    <G>
      {/* Body with bottom ellipse */}
      <Path
        d={bodyPath}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
      />

      {/* Top ellipse (full, visible) */}
      <Ellipse
        cx={rx}
        cy={ry}
        rx={rx - strokeWidth / 2}
        ry={ry - strokeWidth / 2}
        fill={fill}
        stroke={stroke}
        strokeWidth={strokeWidth}
      />
    </G>
  );
};

export default Cylinder;
