/**
 * Shape Components Index
 * Exports all diagram node shapes
 */

export { Rectangle } from "./Rectangle.js";
export { Diamond } from "./Diamond.js";
export { CircleShape, Circle } from "./Circle.js";
export { Cylinder } from "./Cylinder.js";

// Re-export types
export type { CircleShapeProps } from "./Circle.js";
export type { CylinderShapeProps } from "./Cylinder.js";

// Shape mapping for dynamic rendering
import { Rectangle } from "./Rectangle.js";
import { Diamond } from "./Diamond.js";
import { CircleShape } from "./Circle.js";
import { Cylinder } from "./Cylinder.js";
import { NodeShape, ShapeProps } from "../types.js";

/**
 * Map of shape names to components
 */
export const shapeComponents: Record<
  NodeShape,
  React.FC<ShapeProps>
> = {
  rectangle: Rectangle,
  diamond: Diamond,
  circle: CircleShape,
  cylinder: Cylinder,
};

/**
 * Get shape component by name
 * @param shape - Shape name
 * @returns Shape component or Rectangle as default
 */
export function getShapeComponent(
  shape: NodeShape | undefined
): React.FC<ShapeProps> {
  return shapeComponents[shape ?? "rectangle"] ?? Rectangle;
}
