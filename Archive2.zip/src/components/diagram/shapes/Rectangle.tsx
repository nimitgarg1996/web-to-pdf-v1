/**
 * Rectangle Shape
 * Default rectangular node shape for diagrams
 */

import React from "react";
import { Rect } from "@react-pdf/renderer";
import { ShapeProps } from "../types.js";

/**
 * Rectangle shape component for diagram nodes
 * Renders as an SVG Rect element with optional rounded corners
 */
export const Rectangle: React.FC<ShapeProps> = ({
  width,
  height,
  fill = "#ffffff",
  stroke = "#e2e8f0",
  strokeWidth = 1,
  rx = 8,
  ry,
}) => {
  return (
    <Rect
      x={0}
      y={0}
      width={width}
      height={height}
      fill={fill}
      stroke={stroke}
      strokeWidth={strokeWidth}
      rx={rx}
      ry={ry ?? rx}
    />
  );
};

export default Rectangle;
