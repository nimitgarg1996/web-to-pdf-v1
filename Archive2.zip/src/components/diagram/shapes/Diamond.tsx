/**
 * Diamond Shape
 * Decision node shape (rotated square) for diagrams
 */

import React from "react";
import { Path } from "@react-pdf/renderer";
import { ShapeProps } from "../types.js";

/**
 * Diamond shape component for decision nodes
 * Renders as an SVG Path element forming a rotated square
 */
export const Diamond: React.FC<ShapeProps> = ({
  width,
  height,
  fill = "#ffffff",
  stroke = "#e2e8f0",
  strokeWidth = 1,
}) => {
  // Calculate diamond vertices (centered at width/2, height/2)
  const cx = width / 2;
  const cy = height / 2;

  // Diamond points
  const top = `${cx},0`;
  const right = `${width},${cy}`;
  const bottom = `${cx},${height}`;
  const left = `0,${cy}`;

  // Create path
  const d = `M ${top} L ${right} L ${bottom} L ${left} Z`;

  return (
    <Path
      d={d}
      fill={fill}
      stroke={stroke}
      strokeWidth={strokeWidth}
    />
  );
};

export default Diamond;
