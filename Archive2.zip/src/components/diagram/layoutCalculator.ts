/**
 * Layout Calculator
 * Utility functions for calculating diagram bounds, scale, and positions
 */

import {
  DiagramNodeType,
  DiagramBounds,
  Point,
  PortPosition,
  DEFAULT_NODE_WIDTH,
  DEFAULT_NODE_HEIGHT,
} from "./types.js";

// ============================================================================
// Bounds Calculation
// ============================================================================

/**
 * Calculate the bounding box containing all nodes
 * @param nodes - Array of diagram nodes
 * @returns Bounding box dimensions
 */
export function calculateBounds(nodes: DiagramNodeType[]): DiagramBounds {
  if (nodes.length === 0) {
    return {
      minX: 0,
      minY: 0,
      maxX: 0,
      maxY: 0,
      width: 0,
      height: 0,
    };
  }

  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const node of nodes) {
    const width = node.style?.width ?? DEFAULT_NODE_WIDTH;
    const height = node.style?.height ?? DEFAULT_NODE_HEIGHT;

    const nodeMinX = node.position.x;
    const nodeMinY = node.position.y;
    const nodeMaxX = node.position.x + width;
    const nodeMaxY = node.position.y + height;

    minX = Math.min(minX, nodeMinX);
    minY = Math.min(minY, nodeMinY);
    maxX = Math.max(maxX, nodeMaxX);
    maxY = Math.max(maxY, nodeMaxY);
  }

  return {
    minX,
    minY,
    maxX,
    maxY,
    width: maxX - minX,
    height: maxY - minY,
  };
}

// ============================================================================
// Scale Calculation
// ============================================================================

/**
 * Calculate scale factor to fit diagram within container
 * @param bounds - Diagram bounding box
 * @param containerWidth - Available container width
 * @param containerHeight - Available container height
 * @param padding - Padding around content
 * @returns Scale factor (1 = no scaling)
 */
export function calculateScale(
  bounds: DiagramBounds,
  containerWidth: number,
  containerHeight: number,
  padding: number = 20
): number {
  if (bounds.width === 0 || bounds.height === 0) {
    return 1;
  }

  const availableWidth = containerWidth - padding * 2;
  const availableHeight = containerHeight - padding * 2;

  const scaleX = availableWidth / bounds.width;
  const scaleY = availableHeight / bounds.height;

  // Use the smaller scale to ensure content fits
  return Math.min(scaleX, scaleY, 1); // Cap at 1 to avoid enlarging
}

// ============================================================================
// ViewBox Calculation
// ============================================================================

/**
 * Calculate SVG viewBox string from bounds
 * @param bounds - Diagram bounding box
 * @param padding - Padding around content
 * @returns ViewBox string "minX minY width height"
 */
export function calculateViewBox(
  bounds: DiagramBounds,
  padding: number = 20
): string {
  const minX = bounds.minX - padding;
  const minY = bounds.minY - padding;
  const width = bounds.width + padding * 2;
  const height = bounds.height + padding * 2;

  return `${minX} ${minY} ${width} ${height}`;
}

/**
 * Calculate viewBox with auto-fit to container
 * @param bounds - Diagram bounding box
 * @param containerWidth - Container width
 * @param containerHeight - Container height
 * @param padding - Padding around content
 * @returns ViewBox string optimized for container
 */
export function calculateAutoFitViewBox(
  bounds: DiagramBounds,
  containerWidth: number,
  containerHeight: number,
  padding: number = 20
): string {
  if (bounds.width === 0 || bounds.height === 0) {
    return `0 0 ${containerWidth} ${containerHeight}`;
  }

  // Include padding in bounds
  const contentWidth = bounds.width + padding * 2;
  const contentHeight = bounds.height + padding * 2;

  // Calculate aspect ratios
  const containerAspect = containerWidth / containerHeight;
  const contentAspect = contentWidth / contentHeight;

  let viewWidth: number;
  let viewHeight: number;
  let viewX: number;
  let viewY: number;

  if (contentAspect > containerAspect) {
    // Content is wider - fit to width
    viewWidth = contentWidth;
    viewHeight = contentWidth / containerAspect;
    viewX = bounds.minX - padding;
    viewY = bounds.minY - padding - (viewHeight - contentHeight) / 2;
  } else {
    // Content is taller - fit to height
    viewHeight = contentHeight;
    viewWidth = contentHeight * containerAspect;
    viewX = bounds.minX - padding - (viewWidth - contentWidth) / 2;
    viewY = bounds.minY - padding;
  }

  return `${viewX} ${viewY} ${viewWidth} ${viewHeight}`;
}

// ============================================================================
// Position Transformation
// ============================================================================

/**
 * Transform node position for PDF coordinate system
 * @param position - Original position
 * @param bounds - Diagram bounds
 * @param scale - Scale factor
 * @param padding - Padding offset
 * @returns Transformed position
 */
export function transformPosition(
  position: Point,
  bounds: DiagramBounds,
  scale: number,
  padding: number
): Point {
  return {
    x: (position.x - bounds.minX) * scale + padding,
    y: (position.y - bounds.minY) * scale + padding,
  };
}

// ============================================================================
// Node Geometry
// ============================================================================

/**
 * Get the center point of a node
 * @param node - Diagram node
 * @returns Center point coordinates
 */
export function getNodeCenter(node: DiagramNodeType): Point {
  const width = node.style?.width ?? DEFAULT_NODE_WIDTH;
  const height = node.style?.height ?? DEFAULT_NODE_HEIGHT;

  return {
    x: node.position.x + width / 2,
    y: node.position.y + height / 2,
  };
}

/**
 * Get the port/connection point position on a node
 * @param node - Diagram node
 * @param side - Which side of the node
 * @returns Port position coordinates
 */
export function getNodePort(node: DiagramNodeType, side: PortPosition): Point {
  const width = node.style?.width ?? DEFAULT_NODE_WIDTH;
  const height = node.style?.height ?? DEFAULT_NODE_HEIGHT;
  const centerX = node.position.x + width / 2;
  const centerY = node.position.y + height / 2;

  switch (side) {
    case "top":
      return { x: centerX, y: node.position.y };
    case "right":
      return { x: node.position.x + width, y: centerY };
    case "bottom":
      return { x: centerX, y: node.position.y + height };
    case "left":
      return { x: node.position.x, y: centerY };
    default:
      return { x: centerX, y: centerY };
  }
}

/**
 * Determine the best connection ports between two nodes
 * based on their relative positions
 * @param sourceNode - Source node
 * @param targetNode - Target node
 * @returns Source and target ports
 */
export function getBestPorts(
  sourceNode: DiagramNodeType,
  targetNode: DiagramNodeType
): { sourcePort: PortPosition; targetPort: PortPosition } {
  const sourceCenter = getNodeCenter(sourceNode);
  const targetCenter = getNodeCenter(targetNode);

  const dx = targetCenter.x - sourceCenter.x;
  const dy = targetCenter.y - sourceCenter.y;

  // Determine dominant direction
  if (Math.abs(dx) > Math.abs(dy)) {
    // Horizontal connection
    if (dx > 0) {
      return { sourcePort: "right", targetPort: "left" };
    } else {
      return { sourcePort: "left", targetPort: "right" };
    }
  } else {
    // Vertical connection
    if (dy > 0) {
      return { sourcePort: "bottom", targetPort: "top" };
    } else {
      return { sourcePort: "top", targetPort: "bottom" };
    }
  }
}

// ============================================================================
// Grid Helpers
// ============================================================================

/**
 * Snap a position to the nearest grid point
 * @param position - Original position
 * @param gridSize - Grid spacing
 * @returns Snapped position
 */
export function snapToGrid(position: Point, gridSize: number): Point {
  return {
    x: Math.round(position.x / gridSize) * gridSize,
    y: Math.round(position.y / gridSize) * gridSize,
  };
}

/**
 * Generate grid lines for background
 * @param bounds - Area to cover with grid
 * @param gridSize - Grid spacing
 * @param padding - Extra padding around bounds
 * @returns Arrays of vertical and horizontal line positions
 */
export function generateGridLines(
  bounds: DiagramBounds,
  gridSize: number,
  padding: number = 20
): { verticalLines: number[]; horizontalLines: number[] } {
  const startX = Math.floor((bounds.minX - padding) / gridSize) * gridSize;
  const endX = Math.ceil((bounds.maxX + padding) / gridSize) * gridSize;
  const startY = Math.floor((bounds.minY - padding) / gridSize) * gridSize;
  const endY = Math.ceil((bounds.maxY + padding) / gridSize) * gridSize;

  const verticalLines: number[] = [];
  const horizontalLines: number[] = [];

  for (let x = startX; x <= endX; x += gridSize) {
    verticalLines.push(x);
  }

  for (let y = startY; y <= endY; y += gridSize) {
    horizontalLines.push(y);
  }

  return { verticalLines, horizontalLines };
}
