/**
 * SVG Definitions
 * Reusable SVG definitions for diagram rendering (markers, gradients, patterns)
 */

import React from "react";
import {
  Defs,
  LinearGradient,
  RadialGradient,
  Stop,
  G,
  Path,
  Line,
} from "@react-pdf/renderer";
import { NodeStatus, STATUS_COLORS } from "./types.js";

// ============================================================================
// Arrowhead Markers
// ============================================================================

/**
 * Props for ArrowheadDef
 */
export interface ArrowheadDefProps {
  /** Unique ID for the marker */
  id?: string;
  /** Arrow color */
  color?: string;
  /** Arrow size multiplier */
  size?: number;
}

/**
 * SVG Arrowhead marker definition
 * Note: React-PDF doesn't support <marker> directly, so we create arrow shapes manually
 */
export const ArrowheadDef: React.FC<ArrowheadDefProps> = ({
  color = "#94a3b8",
  size = 1,
}) => {
  // Arrowhead dimensions
  const width = 10 * size;
  const height = 7 * size;

  return (
    <G>
      <Path
        d={`M 0 0 L ${width} ${height / 2} L 0 ${height} Z`}
        fill={color}
      />
    </G>
  );
};

// ============================================================================
// Status Gradients
// ============================================================================

/**
 * Props for StatusGradient
 */
export interface StatusGradientDefProps {
  /** Node status for gradient colors */
  status: NodeStatus;
  /** Unique ID suffix */
  idSuffix?: string;
}

/**
 * Generate a linear gradient for node status
 */
export const StatusGradientDef: React.FC<StatusGradientDefProps> = ({
  status,
  idSuffix = "",
}) => {
  const colors = STATUS_COLORS[status];
  const id = `gradient-${status}${idSuffix}`;

  return (
    <LinearGradient id={id} x1="0%" y1="0%" x2="0%" y2="100%">
      <Stop offset="0%" stopColor={colors.background} />
      <Stop offset="100%" stopColor={colors.border} stopOpacity={0.3} />
    </LinearGradient>
  );
};

// ============================================================================
// Grid Pattern
// ============================================================================

/**
 * Props for GridPattern
 */
export interface GridPatternProps {
  /** Grid cell size */
  size?: number;
  /** Grid line color */
  color?: string;
  /** Grid line opacity */
  opacity?: number;
}

/**
 * Grid lines for diagram background
 * Note: React-PDF doesn't support <pattern>, so we render lines directly
 */
export const GridLines: React.FC<
  GridPatternProps & {
    width: number;
    height: number;
    offsetX?: number;
    offsetY?: number;
  }
> = ({
  size = 20,
  color = "#e2e8f0",
  opacity = 0.5,
  width,
  height,
  offsetX = 0,
  offsetY = 0,
}) => {
  const verticalLines: React.ReactNode[] = [];
  const horizontalLines: React.ReactNode[] = [];

  // Generate vertical lines
  for (let x = offsetX; x <= width; x += size) {
    verticalLines.push(
      <Line
        key={`v-${x}`}
        x1={x}
        y1={0}
        x2={x}
        y2={height}
        stroke={color}
        strokeWidth={0.5}
        strokeOpacity={opacity}
      />
    );
  }

  // Generate horizontal lines
  for (let y = offsetY; y <= height; y += size) {
    horizontalLines.push(
      <Line
        key={`h-${y}`}
        x1={0}
        y1={y}
        x2={width}
        y2={y}
        stroke={color}
        strokeWidth={0.5}
        strokeOpacity={opacity}
      />
    );
  }

  return (
    <G>
      {verticalLines}
      {horizontalLines}
    </G>
  );
};

// ============================================================================
// Complete Diagram Definitions
// ============================================================================

/**
 * Props for DiagramDefs
 */
export interface DiagramDefsProps {
  /** Include status gradients */
  includeGradients?: boolean;
  /** Include arrowhead markers */
  includeArrowheads?: boolean;
  /** Custom gradient ID suffix */
  idSuffix?: string;
  /** Arrow color */
  arrowColor?: string;
}

/**
 * Complete set of SVG definitions for diagrams
 */
export const DiagramDefs: React.FC<DiagramDefsProps> = ({
  includeGradients = true,
  idSuffix = "",
}) => {
  const statuses: NodeStatus[] = [
    "default",
    "active",
    "success",
    "warning",
    "error",
  ];

  return (
    <Defs>
      {/* Status gradients */}
      {includeGradients &&
        statuses.map((status) => (
          <StatusGradientDef
            key={status}
            status={status}
            idSuffix={idSuffix}
          />
        ))}

      {/* Default node gradient */}
      <LinearGradient id={`node-gradient${idSuffix}`} x1="0%" y1="0%" x2="0%" y2="100%">
        <Stop offset="0%" stopColor="#ffffff" />
        <Stop offset="100%" stopColor="#f8fafc" />
      </LinearGradient>

      {/* Active node gradient */}
      <LinearGradient id={`node-gradient-active${idSuffix}`} x1="0%" y1="0%" x2="0%" y2="100%">
        <Stop offset="0%" stopColor="#eff6ff" />
        <Stop offset="100%" stopColor="#dbeafe" />
      </LinearGradient>

      {/* Success node gradient */}
      <LinearGradient id={`node-gradient-success${idSuffix}`} x1="0%" y1="0%" x2="0%" y2="100%">
        <Stop offset="0%" stopColor="#dcfce7" />
        <Stop offset="100%" stopColor="#bbf7d0" />
      </LinearGradient>

      {/* Warning node gradient */}
      <LinearGradient id={`node-gradient-warning${idSuffix}`} x1="0%" y1="0%" x2="0%" y2="100%">
        <Stop offset="0%" stopColor="#fef3c7" />
        <Stop offset="100%" stopColor="#fde68a" />
      </LinearGradient>

      {/* Error node gradient */}
      <LinearGradient id={`node-gradient-error${idSuffix}`} x1="0%" y1="0%" x2="0%" y2="100%">
        <Stop offset="0%" stopColor="#fee2e2" />
        <Stop offset="100%" stopColor="#fecaca" />
      </LinearGradient>

      {/* Radial highlight gradient for special effects */}
      <RadialGradient id={`highlight${idSuffix}`} cx="50%" cy="0%" r="100%">
        <Stop offset="0%" stopColor="#ffffff" stopOpacity={0.8} />
        <Stop offset="100%" stopColor="#ffffff" stopOpacity={0} />
      </RadialGradient>
    </Defs>
  );
};

/**
 * Get gradient ID for a status
 * @param status - Node status
 * @param idSuffix - Optional ID suffix
 * @returns Gradient reference URL
 */
export function getStatusGradientId(
  status: NodeStatus | undefined,
  idSuffix: string = ""
): string {
  const statusKey = status ?? "default";
  return `url(#node-gradient-${statusKey}${idSuffix})`;
}

/**
 * Get simple gradient ID (no status)
 * @param idSuffix - Optional ID suffix
 * @returns Gradient reference URL
 */
export function getNodeGradientId(idSuffix: string = ""): string {
  return `url(#node-gradient${idSuffix})`;
}

export default DiagramDefs;
