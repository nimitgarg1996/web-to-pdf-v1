/**
 * Diagram Module Index
 * Exports all diagram-related components, utilities, and types
 */

// ============================================================================
// Types
// ============================================================================

export {
  // Core types
  type Point,
  type NodeType,
  type NodeStatus,
  type NodeShape,
  type EdgeType,
  type PortPosition,
  // Node types
  type DiagramNodeData,
  type DiagramNodeStyle,
  type DiagramNodeType,
  // Edge types
  type DiagramEdgeStyle,
  type DiagramEdgeType,
  // Layout types
  type DiagramBounds,
  type DiagramViewport,
  // Component props types
  type NodeDefaults,
  type EdgeDefaults,
  type DiagramProps,
  type DiagramNodeComponentProps,
  type DiagramEdgeComponentProps,
  type ShapeProps,
  // Constants
  DEFAULT_NODE_WIDTH,
  DEFAULT_NODE_HEIGHT,
  DEFAULT_NODE_STYLE,
  DEFAULT_EDGE_STYLE,
  STATUS_COLORS,
} from "./types.js";

// ============================================================================
// Layout Calculator
// ============================================================================

export {
  calculateBounds,
  calculateScale,
  calculateViewBox,
  calculateAutoFitViewBox,
  transformPosition,
  getNodeCenter,
  getNodePort,
  getBestPorts,
  snapToGrid,
  generateGridLines,
} from "./layoutCalculator.js";

// ============================================================================
// Edge Path Generator
// ============================================================================

export {
  generateEdgePath,
  straightPath,
  bezierPath,
  stepPath,
  smoothstepPath,
  selfLoopPath,
  getEdgeLabelPosition,
  getEdgeLabelRotation,
  getArrowheadTransform,
  estimatePathLength,
} from "./edgePathGenerator.js";

// ============================================================================
// Shape Components
// ============================================================================

export {
  Rectangle,
  Diamond,
  CircleShape,
  Circle,
  Cylinder,
  shapeComponents,
  getShapeComponent,
  type CircleShapeProps,
  type CylinderShapeProps,
} from "./shapes/index.js";

// ============================================================================
// SVG Definitions
// ============================================================================

export {
  DiagramDefs,
  ArrowheadDef,
  StatusGradientDef,
  GridLines,
  getStatusGradientId,
  getNodeGradientId,
  type ArrowheadDefProps,
  type StatusGradientDefProps,
  type GridPatternProps,
  type DiagramDefsProps,
} from "./SvgDefs.js";

// ============================================================================
// Node Components
// ============================================================================

export {
  DiagramNodeComponent,
  DiagramNode,
  SimpleNode,
} from "./DiagramNode.js";

// ============================================================================
// Edge Components
// ============================================================================

export {
  DiagramEdgeComponent,
  DiagramEdge,
  SimpleEdge,
} from "./DiagramEdge.js";

// ============================================================================
// Main Diagram Component
// ============================================================================

export {
  Diagram,
  CompactDiagram,
  createFlowDiagram,
  type CompactDiagramProps,
  type FlowConfig,
} from "./Diagram.js";

// ============================================================================
// Default Export
// ============================================================================

export { Diagram as default } from "./Diagram.js";
