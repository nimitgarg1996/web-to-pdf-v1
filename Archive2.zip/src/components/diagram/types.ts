/**
 * Diagram Types
 * xyflow-compatible type definitions for the diagram transformation system
 */

// ============================================================================
// Core Types
// ============================================================================

/**
 * Point in 2D space
 */
export interface Point {
  x: number;
  y: number;
}

/**
 * Node type variants
 */
export type NodeType = "default" | "input" | "output" | "custom";

/**
 * Node status variants for visual styling
 */
export type NodeStatus = "default" | "active" | "success" | "warning" | "error";

/**
 * Node shape variants
 */
export type NodeShape = "rectangle" | "diamond" | "circle" | "cylinder";

/**
 * Edge type variants
 */
export type EdgeType = "default" | "straight" | "step" | "smoothstep" | "bezier";

/**
 * Port/handle position on a node
 */
export type PortPosition = "top" | "right" | "bottom" | "left";

// ============================================================================
// Node Types
// ============================================================================

/**
 * Data payload for a diagram node
 */
export interface DiagramNodeData {
  /** Display label for the node */
  label: string;
  /** Optional icon identifier (from icon system) */
  icon?: string;
  /** Visual status of the node */
  status?: NodeStatus;
  /** Optional description text */
  description?: string;
  /** Optional custom shape override */
  shape?: NodeShape;
}

/**
 * Style overrides for a node
 */
export interface DiagramNodeStyle {
  /** Node width in points */
  width?: number;
  /** Node height in points */
  height?: number;
  /** Background fill color */
  backgroundColor?: string;
  /** Border stroke color */
  borderColor?: string;
  /** Border stroke width */
  borderWidth?: number;
  /** Border radius for rounded corners */
  borderRadius?: number;
  /** Text color */
  textColor?: string;
  /** Font size */
  fontSize?: number;
}

/**
 * xyflow-compatible node structure
 */
export interface DiagramNodeType {
  /** Unique node identifier */
  id: string;
  /** Node type category */
  type?: NodeType;
  /** Position in diagram coordinates */
  position: Point;
  /** Node data payload */
  data: DiagramNodeData;
  /** Optional style overrides */
  style?: DiagramNodeStyle;
}

// ============================================================================
// Edge Types
// ============================================================================

/**
 * Style overrides for an edge
 */
export interface DiagramEdgeStyle {
  /** Stroke color */
  stroke?: string;
  /** Stroke width */
  strokeWidth?: number;
  /** Dash pattern (e.g., "5,5" for dashed) */
  strokeDasharray?: string;
}

/**
 * xyflow-compatible edge structure
 */
export interface DiagramEdgeType {
  /** Unique edge identifier */
  id: string;
  /** Source node ID */
  source: string;
  /** Target node ID */
  target: string;
  /** Source handle/port identifier */
  sourceHandle?: string;
  /** Target handle/port identifier */
  targetHandle?: string;
  /** Edge path type */
  type?: EdgeType;
  /** Optional label text */
  label?: string;
  /** Whether edge should appear animated (dashed) */
  animated?: boolean;
  /** Optional style overrides */
  style?: DiagramEdgeStyle;
}

// ============================================================================
// Layout Types
// ============================================================================

/**
 * Bounding box for diagram content
 */
export interface DiagramBounds {
  /** Minimum X coordinate */
  minX: number;
  /** Minimum Y coordinate */
  minY: number;
  /** Maximum X coordinate */
  maxX: number;
  /** Maximum Y coordinate */
  maxY: number;
  /** Total width (maxX - minX) */
  width: number;
  /** Total height (maxY - minY) */
  height: number;
}

/**
 * Viewport configuration for SVG rendering
 */
export interface DiagramViewport {
  /** X offset for centering */
  x: number;
  /** Y offset for centering */
  y: number;
  /** Zoom/scale factor */
  zoom: number;
}

// ============================================================================
// Component Props Types
// ============================================================================

/**
 * Default values for nodes
 */
export interface NodeDefaults {
  /** Default node width */
  width?: number;
  /** Default node height */
  height?: number;
  /** Default background color */
  backgroundColor?: string;
  /** Default border color */
  borderColor?: string;
  /** Default border width */
  borderWidth?: number;
  /** Default border radius */
  borderRadius?: number;
  /** Default text color */
  textColor?: string;
  /** Default font size */
  fontSize?: number;
  /** Default shape */
  shape?: NodeShape;
}

/**
 * Default values for edges
 */
export interface EdgeDefaults {
  /** Default edge type */
  type?: EdgeType;
  /** Default stroke color */
  stroke?: string;
  /** Default stroke width */
  strokeWidth?: number;
  /** Whether edges are animated by default */
  animated?: boolean;
}

/**
 * Main Diagram component props
 */
export interface DiagramProps {
  /** Array of nodes to render */
  nodes: DiagramNodeType[];
  /** Array of edges to render */
  edges: DiagramEdgeType[];
  /** Container width in points */
  width?: number;
  /** Container height in points */
  height?: number;
  /** Padding around diagram content */
  padding?: number;
  /** Whether to show grid background */
  showGrid?: boolean;
  /** Grid size (spacing between grid lines) */
  gridSize?: number;
  /** Auto-scale to fit content in container */
  autoFit?: boolean;
  /** Default values for nodes */
  nodeDefaults?: NodeDefaults;
  /** Default values for edges */
  edgeDefaults?: EdgeDefaults;
  /** Background color */
  backgroundColor?: string;
}

/**
 * DiagramNode component props
 */
export interface DiagramNodeComponentProps {
  /** Node data */
  node: DiagramNodeType;
  /** Default values to apply */
  defaults?: NodeDefaults;
}

/**
 * DiagramEdge component props
 */
export interface DiagramEdgeComponentProps {
  /** Edge data */
  edge: DiagramEdgeType;
  /** Source node for position calculation */
  sourceNode: DiagramNodeType;
  /** Target node for position calculation */
  targetNode: DiagramNodeType;
  /** Default values to apply */
  defaults?: EdgeDefaults;
}

// ============================================================================
// Shape Component Props
// ============================================================================

/**
 * Common props for all shape components
 */
export interface ShapeProps {
  /** Shape width */
  width: number;
  /** Shape height */
  height: number;
  /** Fill color */
  fill?: string;
  /** Stroke color */
  stroke?: string;
  /** Stroke width */
  strokeWidth?: number;
  /** Border radius (for rectangles) */
  rx?: number;
  /** Vertical border radius (for rectangles) */
  ry?: number;
}

// ============================================================================
// Constants
// ============================================================================

/**
 * Default node dimensions
 */
export const DEFAULT_NODE_WIDTH = 150;
export const DEFAULT_NODE_HEIGHT = 50;

/**
 * Default styling values
 */
export const DEFAULT_NODE_STYLE: Required<DiagramNodeStyle> = {
  width: DEFAULT_NODE_WIDTH,
  height: DEFAULT_NODE_HEIGHT,
  backgroundColor: "#ffffff",
  borderColor: "#e2e8f0",
  borderWidth: 1,
  borderRadius: 8,
  textColor: "#1e293b",
  fontSize: 11,
};

export const DEFAULT_EDGE_STYLE: Required<DiagramEdgeStyle> = {
  stroke: "#94a3b8",
  strokeWidth: 1.5,
  strokeDasharray: "",
};

/**
 * Status color mapping
 */
export const STATUS_COLORS: Record<
  NodeStatus,
  { background: string; border: string; text: string }
> = {
  default: {
    background: "#ffffff",
    border: "#e2e8f0",
    text: "#1e293b",
  },
  active: {
    background: "#eff6ff",
    border: "#3b82f6",
    text: "#1d4ed8",
  },
  success: {
    background: "#dcfce7",
    border: "#22c55e",
    text: "#15803d",
  },
  warning: {
    background: "#fef3c7",
    border: "#f59e0b",
    text: "#b45309",
  },
  error: {
    background: "#fee2e2",
    border: "#ef4444",
    text: "#b91c1c",
  },
};
