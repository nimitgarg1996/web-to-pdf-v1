/**
 * Edge Path Generator
 * Utility functions for generating SVG paths for different edge types
 */

import { Point, EdgeType } from "./types.js";

// ============================================================================
// Main Path Generator
// ============================================================================

/**
 * Generate SVG path string for an edge
 * @param source - Source connection point
 * @param target - Target connection point
 * @param type - Edge type (path style)
 * @returns SVG path d attribute string
 */
export function generateEdgePath(
  source: Point,
  target: Point,
  type: EdgeType = "default"
): string {
  switch (type) {
    case "straight":
      return straightPath(source, target);
    case "bezier":
      return bezierPath(source, target);
    case "step":
      return stepPath(source, target);
    case "smoothstep":
      return smoothstepPath(source, target);
    case "default":
    default:
      // Default to smoothstep for a modern look
      return smoothstepPath(source, target);
  }
}

// ============================================================================
// Specific Path Generators
// ============================================================================

/**
 * Generate a straight line path
 * @param source - Start point
 * @param target - End point
 * @returns SVG path string
 */
export function straightPath(source: Point, target: Point): string {
  return `M ${source.x},${source.y} L ${target.x},${target.y}`;
}

/**
 * Generate a cubic bezier curve path
 * @param source - Start point
 * @param target - End point
 * @param curvature - Curvature factor (0-1, default 0.5)
 * @returns SVG path string
 */
export function bezierPath(
  source: Point,
  target: Point,
  curvature: number = 0.5
): string {
  const dx = target.x - source.x;
  const dy = target.y - source.y;

  // Control point offset based on distance and curvature
  const offset = Math.min(Math.abs(dx), Math.abs(dy), 150) * curvature;

  // Determine control point direction based on dominant axis
  let cx1: number, cy1: number, cx2: number, cy2: number;

  if (Math.abs(dx) >= Math.abs(dy)) {
    // Horizontal dominant - control points extend horizontally
    cx1 = source.x + offset;
    cy1 = source.y;
    cx2 = target.x - offset;
    cy2 = target.y;
  } else {
    // Vertical dominant - control points extend vertically
    cx1 = source.x;
    cy1 = source.y + offset;
    cx2 = target.x;
    cy2 = target.y - offset;
  }

  return `M ${source.x},${source.y} C ${cx1},${cy1} ${cx2},${cy2} ${target.x},${target.y}`;
}

/**
 * Generate a step (orthogonal) path
 * @param source - Start point
 * @param target - End point
 * @returns SVG path string
 */
export function stepPath(source: Point, target: Point): string {
  const midX = source.x + (target.x - source.x) / 2;

  // Create orthogonal path: horizontal -> vertical -> horizontal
  return `M ${source.x},${source.y} H ${midX} V ${target.y} H ${target.x}`;
}

/**
 * Generate a smoothstep (orthogonal with rounded corners) path
 * @param source - Start point
 * @param target - End point
 * @param borderRadius - Radius for rounded corners (default 8)
 * @returns SVG path string
 */
export function smoothstepPath(
  source: Point,
  target: Point,
  borderRadius: number = 8
): string {
  const dx = target.x - source.x;
  const dy = target.y - source.y;

  // Calculate midpoint for the step
  const midX = source.x + dx / 2;

  // Clamp radius to half the minimum distance
  const radius = Math.min(borderRadius, Math.abs(dx) / 4, Math.abs(dy) / 2);

  if (radius <= 0 || Math.abs(dy) < 1) {
    // No room for curves, fall back to straight or simple step
    if (Math.abs(dy) < 1) {
      return straightPath(source, target);
    }
    return stepPath(source, target);
  }

  // Determine directions
  const dirX = dx >= 0 ? 1 : -1;
  const dirY = dy >= 0 ? 1 : -1;

  // Build path with rounded corners
  // Start at source
  let path = `M ${source.x},${source.y}`;

  // Horizontal line to first corner
  path += ` H ${midX - radius * dirX}`;

  // First rounded corner (arc)
  path += ` Q ${midX},${source.y} ${midX},${source.y + radius * dirY}`;

  // Vertical line to second corner
  path += ` V ${target.y - radius * dirY}`;

  // Second rounded corner (arc)
  path += ` Q ${midX},${target.y} ${midX + radius * dirX},${target.y}`;

  // Horizontal line to target
  path += ` H ${target.x}`;

  return path;
}

/**
 * Generate a self-referencing loop path (when source === target node)
 * @param center - Center point of the node
 * @param size - Size of the loop
 * @returns SVG path string
 */
export function selfLoopPath(center: Point, size: number = 40): string {
  const x = center.x;
  const y = center.y;

  // Create a loop that goes up and around
  return `M ${x},${y - 20} 
          C ${x - size},${y - size - 20} 
            ${x + size},${y - size - 20} 
            ${x},${y - 20}`;
}

// ============================================================================
// Label Position Calculation
// ============================================================================

/**
 * Calculate the position for an edge label
 * @param source - Source point
 * @param target - Target point
 * @param type - Edge type
 * @returns Position for the label (center of edge)
 */
export function getEdgeLabelPosition(
  source: Point,
  target: Point,
  type: EdgeType = "default"
): Point {
  switch (type) {
    case "straight":
    case "bezier":
      // Place at midpoint
      return {
        x: (source.x + target.x) / 2,
        y: (source.y + target.y) / 2,
      };

    case "step":
    case "smoothstep":
    case "default":
    default:
      // Place at midpoint of the middle vertical segment
      const midX = source.x + (target.x - source.x) / 2;
      const midY = (source.y + target.y) / 2;
      return { x: midX, y: midY };
  }
}

/**
 * Calculate rotation angle for edge label alignment
 * @param source - Source point
 * @param target - Target point
 * @param type - Edge type
 * @returns Rotation angle in degrees
 */
export function getEdgeLabelRotation(
  source: Point,
  target: Point,
  type: EdgeType = "default"
): number {
  // Only rotate for straight and bezier edges
  if (type === "straight" || type === "bezier") {
    const dx = target.x - source.x;
    const dy = target.y - source.y;
    let angle = Math.atan2(dy, dx) * (180 / Math.PI);

    // Keep text readable (flip if upside down)
    if (angle > 90) angle -= 180;
    if (angle < -90) angle += 180;

    return angle;
  }

  // No rotation for orthogonal edges
  return 0;
}

// ============================================================================
// Arrowhead Calculation
// ============================================================================

/**
 * Calculate the position and rotation for an arrowhead at the end of a path
 * @param source - Source point
 * @param target - Target point
 * @param type - Edge type
 * @returns Position and angle for the arrowhead
 */
export function getArrowheadTransform(
  source: Point,
  target: Point,
  type: EdgeType = "default"
): { position: Point; angle: number } {
  let angle: number;

  switch (type) {
    case "straight":
    case "bezier":
      // Calculate angle from source to target
      const dx = target.x - source.x;
      const dy = target.y - source.y;
      angle = Math.atan2(dy, dx) * (180 / Math.PI);
      break;

    case "step":
    case "smoothstep":
    case "default":
    default:
      // Arrowhead points in the direction of the final segment (horizontal)
      if (target.x >= source.x) {
        angle = 0; // Pointing right
      } else {
        angle = 180; // Pointing left
      }
      break;
  }

  return {
    position: target,
    angle,
  };
}

// ============================================================================
// Path Length Estimation
// ============================================================================

/**
 * Estimate the length of an edge path (approximate)
 * @param source - Source point
 * @param target - Target point
 * @param type - Edge type
 * @returns Estimated path length
 */
export function estimatePathLength(
  source: Point,
  target: Point,
  type: EdgeType = "default"
): number {
  const dx = Math.abs(target.x - source.x);
  const dy = Math.abs(target.y - source.y);

  switch (type) {
    case "straight":
      return Math.sqrt(dx * dx + dy * dy);

    case "bezier":
      // Approximate bezier length (slightly longer than straight)
      return Math.sqrt(dx * dx + dy * dy) * 1.2;

    case "step":
    case "smoothstep":
    case "default":
    default:
      // Manhattan distance for orthogonal paths
      return dx + dy;
  }
}
