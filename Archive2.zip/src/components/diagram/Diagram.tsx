/**
 * Diagram Component
 * Main container component for rendering xyflow-compatible diagrams as PDF SVG
 */

import React from "react";
import { Svg, G, Rect } from "@react-pdf/renderer";
import {
  DiagramProps,
  DiagramNodeType,
  DiagramEdgeType,
} from "./types.js";
import {
  calculateBounds,
  calculateAutoFitViewBox,
} from "./layoutCalculator.js";
import { DiagramDefs, GridLines } from "./SvgDefs.js";
import { DiagramNodeComponent } from "./DiagramNode.js";
import { DiagramEdgeComponent } from "./DiagramEdge.js";

// ============================================================================
// Default Values
// ============================================================================

const DEFAULT_WIDTH = 500;
const DEFAULT_HEIGHT = 400;
const DEFAULT_PADDING = 20;
const DEFAULT_GRID_SIZE = 20;

// ============================================================================
// Main Component
// ============================================================================

/**
 * Diagram Component
 * Renders a complete diagram with nodes, edges, and optional grid
 */
export const Diagram: React.FC<DiagramProps> = ({
  nodes,
  edges,
  width = DEFAULT_WIDTH,
  height = DEFAULT_HEIGHT,
  padding = DEFAULT_PADDING,
  showGrid = false,
  gridSize = DEFAULT_GRID_SIZE,
  autoFit = true,
  nodeDefaults,
  edgeDefaults,
  backgroundColor = "#ffffff",
}) => {
  // Calculate bounds from nodes
  const bounds = calculateBounds(nodes);

  // Calculate viewBox based on autoFit setting
  const viewBox = autoFit
    ? calculateAutoFitViewBox(bounds, width, height, padding)
    : `0 0 ${width} ${height}`;

  // Parse viewBox for grid rendering
  const viewBoxParts = viewBox.split(" ").map(Number);
  const [vbX, vbY, vbWidth, vbHeight] = viewBoxParts;

  // Create node lookup map for edge rendering
  const nodeMap = new Map<string, DiagramNodeType>();
  for (const node of nodes) {
    nodeMap.set(node.id, node);
  }

  // Filter valid edges (both source and target must exist)
  const validEdges = edges.filter(
    (edge: DiagramEdgeType) => nodeMap.has(edge.source) && nodeMap.has(edge.target)
  );

  return (
    <Svg
      width={width}
      height={height}
      viewBox={viewBox}
      preserveAspectRatio="xMidYMid meet"
    >
      {/* SVG Definitions (gradients, etc.) */}
      <DiagramDefs />

      {/* Background */}
      <Rect
        x={vbX}
        y={vbY}
        width={vbWidth}
        height={vbHeight}
        fill={backgroundColor}
      />

      {/* Grid (rendered behind everything) */}
      {showGrid && (
        <G opacity={0.5}>
          <GridLines
            size={gridSize}
            width={vbWidth}
            height={vbHeight}
            offsetX={Math.ceil(vbX / gridSize) * gridSize - vbX}
            offsetY={Math.ceil(vbY / gridSize) * gridSize - vbY}
            color="#e2e8f0"
            opacity={0.5}
          />
        </G>
      )}

      {/* Edges (rendered before nodes so they appear behind) */}
      <G>
        {validEdges.map((edge: DiagramEdgeType) => {
          const sourceNode = nodeMap.get(edge.source)!;
          const targetNode = nodeMap.get(edge.target)!;

          return (
            <DiagramEdgeComponent
              key={edge.id}
              edge={edge}
              sourceNode={sourceNode}
              targetNode={targetNode}
              defaults={edgeDefaults}
            />
          );
        })}
      </G>

      {/* Nodes (rendered on top of edges) */}
      <G>
        {nodes.map((node: DiagramNodeType) => (
          <DiagramNodeComponent
            key={node.id}
            node={node}
            defaults={nodeDefaults}
          />
        ))}
      </G>
    </Svg>
  );
};

// ============================================================================
// Compact Diagram Variant
// ============================================================================

/**
 * Props for CompactDiagram
 */
export interface CompactDiagramProps {
  /** Array of node labels (positions auto-calculated) */
  labels: string[];
  /** Arrangement direction */
  direction?: "horizontal" | "vertical";
  /** Container width */
  width?: number;
  /** Container height */
  height?: number;
  /** Gap between nodes */
  gap?: number;
  /** Whether to show connections between sequential nodes */
  showConnections?: boolean;
}

/**
 * Compact diagram with auto-layout
 * Useful for simple linear flows
 */
export const CompactDiagram: React.FC<CompactDiagramProps> = ({
  labels,
  direction = "horizontal",
  width = 500,
  height = 100,
  gap = 30,
  showConnections = true,
}) => {
  // Node dimensions
  const nodeWidth = 120;
  const nodeHeight = 40;

  // Calculate positions
  const nodes: DiagramNodeType[] = labels.map((label, index) => {
    const position =
      direction === "horizontal"
        ? { x: index * (nodeWidth + gap), y: 0 }
        : { x: 0, y: index * (nodeHeight + gap) };

    return {
      id: `node-${index}`,
      position,
      data: { label },
      style: { width: nodeWidth, height: nodeHeight },
    };
  });

  // Create edges between sequential nodes
  const edges: DiagramEdgeType[] = showConnections
    ? labels.slice(0, -1).map((_, index) => ({
        id: `edge-${index}`,
        source: `node-${index}`,
        target: `node-${index + 1}`,
        type: "smoothstep" as const,
      }))
    : [];

  return (
    <Diagram
      nodes={nodes}
      edges={edges}
      width={width}
      height={height}
      autoFit={true}
      padding={10}
    />
  );
};

// ============================================================================
// Flow Diagram Helper
// ============================================================================

/**
 * Configuration for flow diagram creation
 */
export interface FlowConfig {
  /** Starting X position */
  startX?: number;
  /** Starting Y position */
  startY?: number;
  /** Horizontal spacing between nodes */
  horizontalGap?: number;
  /** Vertical spacing between nodes */
  verticalGap?: number;
  /** Default node width */
  nodeWidth?: number;
  /** Default node height */
  nodeHeight?: number;
}

/**
 * Helper to create a flow diagram from a simple structure
 */
export function createFlowDiagram(
  steps: Array<{
    id: string;
    label: string;
    status?: "default" | "active" | "success" | "warning" | "error";
    row?: number;
    col?: number;
  }>,
  connections: Array<{ from: string; to: string; label?: string }>,
  config: FlowConfig = {}
): { nodes: DiagramNodeType[]; edges: DiagramEdgeType[] } {
  const {
    startX = 0,
    startY = 0,
    horizontalGap = 180,
    verticalGap = 80,
    nodeWidth = 150,
    nodeHeight = 50,
  } = config;

  // Create nodes
  const nodes: DiagramNodeType[] = steps.map((step) => ({
    id: step.id,
    position: {
      x: startX + (step.col ?? 0) * horizontalGap,
      y: startY + (step.row ?? 0) * verticalGap,
    },
    data: {
      label: step.label,
      status: step.status,
    },
    style: {
      width: nodeWidth,
      height: nodeHeight,
    },
  }));

  // Create edges
  const edges: DiagramEdgeType[] = connections.map((conn, index) => ({
    id: `edge-${index}`,
    source: conn.from,
    target: conn.to,
    label: conn.label,
    type: "smoothstep",
  }));

  return { nodes, edges };
}

export default Diagram;
