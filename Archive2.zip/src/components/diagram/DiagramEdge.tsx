/**
 * DiagramEdge Component
 * Renders a connection edge between two nodes
 */

import React from "react";
import { G, Path, Text as SvgText, Polygon } from "@react-pdf/renderer";
import {
  DiagramEdgeType,
  DiagramEdgeComponentProps,
  EdgeDefaults,
  DEFAULT_EDGE_STYLE,
  Point,
} from "./types.js";
import {
  generateEdgePath,
  getEdgeLabelPosition,
  getArrowheadTransform,
} from "./edgePathGenerator.js";
import { getNodePort, getBestPorts } from "./layoutCalculator.js";

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Merge edge style with defaults
 */
function getMergedStyle(
  edge: DiagramEdgeType,
  defaults?: EdgeDefaults
): Required<typeof DEFAULT_EDGE_STYLE> {
  return {
    stroke: edge.style?.stroke ?? defaults?.stroke ?? DEFAULT_EDGE_STYLE.stroke,
    strokeWidth:
      edge.style?.strokeWidth ??
      defaults?.strokeWidth ??
      DEFAULT_EDGE_STYLE.strokeWidth,
    strokeDasharray:
      edge.style?.strokeDasharray ??
      (edge.animated || defaults?.animated ? "5,5" : DEFAULT_EDGE_STYLE.strokeDasharray),
  };
}

// ============================================================================
// Arrowhead Component
// ============================================================================

interface ArrowheadProps {
  position: Point;
  angle: number;
  size?: number;
  color?: string;
}

/**
 * Arrowhead rendered at edge endpoint
 */
const Arrowhead: React.FC<ArrowheadProps> = ({
  position,
  angle,
  size = 8,
  color = "#94a3b8",
}) => {
  // Arrow points (triangle)
  const halfHeight = size * 0.6;
  const points = `0,${-halfHeight} ${size},0 0,${halfHeight}`;

  return (
    <G transform={`translate(${position.x}, ${position.y}) rotate(${angle})`}>
      <Polygon
        points={points}
        fill={color}
      />
    </G>
  );
};

// ============================================================================
// Edge Label Component
// ============================================================================

interface EdgeLabelProps {
  label: string;
  position: Point;
  rotation?: number;
  fontSize?: number;
  color?: string;
}

/**
 * Label displayed on an edge
 */
const EdgeLabel: React.FC<EdgeLabelProps> = ({
  label,
  position,
  rotation = 0,
  fontSize = 9,
  color = "#64748b",
}) => {
  return (
    <G transform={`translate(${position.x}, ${position.y}) rotate(${rotation})`}>
      {/* Label text */}
      <SvgText
        x={0}
        y={fontSize / 3}
        style={{
          fontSize,
          textAnchor: "middle",
        }}
        fill={color}
      >
        {label}
      </SvgText>
    </G>
  );
};

// ============================================================================
// Main Component
// ============================================================================

/**
 * DiagramEdge Component
 * Renders a connection between two nodes with optional arrowhead and label
 */
export const DiagramEdgeComponent: React.FC<DiagramEdgeComponentProps> = ({
  edge,
  sourceNode,
  targetNode,
  defaults,
}) => {
  const style = getMergedStyle(edge, defaults);
  const edgeType = edge.type ?? defaults?.type ?? "default";

  // Calculate connection points
  const { sourcePort, targetPort } = getBestPorts(sourceNode, targetNode);
  const sourcePoint = getNodePort(sourceNode, sourcePort);
  const targetPoint = getNodePort(targetNode, targetPort);

  // Adjust target point to account for arrowhead
  const arrowSize = 8;
  const { angle } = getArrowheadTransform(sourcePoint, targetPoint, edgeType);
  const angleRad = (angle * Math.PI) / 180;
  const adjustedTarget: Point = {
    x: targetPoint.x - Math.cos(angleRad) * arrowSize,
    y: targetPoint.y - Math.sin(angleRad) * arrowSize,
  };

  // Generate path
  const pathD = generateEdgePath(sourcePoint, adjustedTarget, edgeType);

  // Get label position if needed
  const labelPosition = edge.label
    ? getEdgeLabelPosition(sourcePoint, targetPoint, edgeType)
    : null;

  return (
    <G>
      {/* Edge path */}
      <Path
        d={pathD}
        stroke={style.stroke}
        strokeWidth={style.strokeWidth}
        strokeDasharray={style.strokeDasharray || undefined}
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Arrowhead at target */}
      <Arrowhead
        position={targetPoint}
        angle={angle}
        size={arrowSize}
        color={style.stroke}
      />

      {/* Edge label */}
      {edge.label && labelPosition && (
        <EdgeLabel
          label={edge.label}
          position={labelPosition}
          color={style.stroke}
        />
      )}
    </G>
  );
};

// ============================================================================
// Simple Edge Variant
// ============================================================================

/**
 * Simplified edge component for basic connections
 */
export const SimpleEdge: React.FC<{
  source: Point;
  target: Point;
  type?: "straight" | "smoothstep";
  color?: string;
  strokeWidth?: number;
  showArrow?: boolean;
}> = ({
  source,
  target,
  type = "smoothstep",
  color = "#94a3b8",
  strokeWidth = 1.5,
  showArrow = true,
}) => {
  const { angle } = getArrowheadTransform(source, target, type);
  const angleRad = (angle * Math.PI) / 180;
  const arrowSize = 8;

  const adjustedTarget: Point = showArrow
    ? {
        x: target.x - Math.cos(angleRad) * arrowSize,
        y: target.y - Math.sin(angleRad) * arrowSize,
      }
    : target;

  const pathD = generateEdgePath(source, adjustedTarget, type);

  return (
    <G>
      <Path
        d={pathD}
        stroke={color}
        strokeWidth={strokeWidth}
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {showArrow && (
        <Arrowhead
          position={target}
          angle={angle}
          size={arrowSize}
          color={color}
        />
      )}
    </G>
  );
};

export { DiagramEdgeComponent as DiagramEdge };
export default DiagramEdgeComponent;
