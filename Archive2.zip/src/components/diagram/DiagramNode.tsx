/**
 * DiagramNode Component
 * Renders a single node in the diagram as an SVG group
 */

import React from "react";
import { G, Text as SvgText, Rect, Circle } from "@react-pdf/renderer";
import {
  DiagramNodeType,
  DiagramNodeComponentProps,
  NodeDefaults,
  DEFAULT_NODE_STYLE,
  STATUS_COLORS,
} from "./types.js";
import { getShapeComponent } from "./shapes/index.js";
import { getStatusGradientId } from "./SvgDefs.js";

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Merge node style with defaults
 */
function getMergedStyle(
  node: DiagramNodeType,
  defaults?: NodeDefaults
): Required<typeof DEFAULT_NODE_STYLE> {
  const status = node.data.status ?? "default";
  const statusColors = STATUS_COLORS[status];

  return {
    width: node.style?.width ?? defaults?.width ?? DEFAULT_NODE_STYLE.width,
    height: node.style?.height ?? defaults?.height ?? DEFAULT_NODE_STYLE.height,
    backgroundColor:
      node.style?.backgroundColor ??
      defaults?.backgroundColor ??
      statusColors.background,
    borderColor:
      node.style?.borderColor ?? defaults?.borderColor ?? statusColors.border,
    borderWidth:
      node.style?.borderWidth ?? defaults?.borderWidth ?? DEFAULT_NODE_STYLE.borderWidth,
    borderRadius:
      node.style?.borderRadius ?? defaults?.borderRadius ?? DEFAULT_NODE_STYLE.borderRadius,
    textColor:
      node.style?.textColor ?? defaults?.textColor ?? statusColors.text,
    fontSize:
      node.style?.fontSize ?? defaults?.fontSize ?? DEFAULT_NODE_STYLE.fontSize,
  };
}

// ============================================================================
// Status Indicator Component
// ============================================================================

interface StatusIndicatorProps {
  status: string;
  x: number;
  y: number;
  size?: number;
}

/**
 * Small colored dot indicating node status
 */
const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  x,
  y,
  size = 6,
}) => {
  if (status === "default") {
    return null;
  }

  const colors = STATUS_COLORS[status as keyof typeof STATUS_COLORS] ?? STATUS_COLORS.default;

  return (
    <G>
      {/* Outer ring */}
      <Circle
        cx={x}
        cy={y}
        r={size}
        fill={colors.border}
        fillOpacity={0.2}
      />
      {/* Inner dot */}
      <Circle
        cx={x}
        cy={y}
        r={size * 0.6}
        fill={colors.border}
      />
    </G>
  );
};

// ============================================================================
// Main Component
// ============================================================================

/**
 * DiagramNode Component
 * Renders a diagram node with shape, label, icon, and status indicator
 */
export const DiagramNodeComponent: React.FC<DiagramNodeComponentProps> = ({
  node,
  defaults,
}) => {
  const style = getMergedStyle(node, defaults);
  const shape = node.data.shape ?? defaults?.shape ?? "rectangle";
  const status = node.data.status ?? "default";

  // Get the shape component
  const ShapeComponent = getShapeComponent(shape);

  // Calculate text positioning
  const textX = style.width / 2;
  const textY = style.height / 2;

  // Use gradient fill for background
  const useGradient = status !== "default";
  const fillColor = useGradient
    ? getStatusGradientId(status)
    : style.backgroundColor;

  return (
    <G transform={`translate(${node.position.x}, ${node.position.y})`}>
      {/* Background shape */}
      <ShapeComponent
        width={style.width}
        height={style.height}
        fill={fillColor}
        stroke={style.borderColor}
        strokeWidth={style.borderWidth}
        rx={style.borderRadius}
      />

      {/* Status indicator (top-right corner) */}
      {status !== "default" && (
        <StatusIndicator
          status={status}
          x={style.width - 10}
          y={10}
          size={5}
        />
      )}

      {/* Icon placeholder - position above label if present */}
      {node.data.icon && (
        <SvgText
          x={textX}
          y={textY - 8}
          style={{
            fontSize: 14,
            textAnchor: "middle",
          }}
          fill={style.textColor}
        >
          {"●"}
        </SvgText>
      )}

      {/* Label text */}
      <SvgText
        x={textX}
        y={node.data.icon ? textY + 6 : textY + 4}
        style={{
          fontSize: style.fontSize,
          fontWeight: 500,
          textAnchor: "middle",
        }}
        fill={style.textColor}
      >
        {node.data.label}
      </SvgText>

      {/* Description (if provided and space allows) */}
      {node.data.description && style.height > 50 && (
        <SvgText
          x={textX}
          y={textY + 18}
          style={{
            fontSize: style.fontSize - 2,
            textAnchor: "middle",
          }}
          fill={style.textColor}
          fillOpacity={0.7}
        >
          {node.data.description.length > 20
            ? `${node.data.description.substring(0, 20)}...`
            : node.data.description}
        </SvgText>
      )}
    </G>
  );
};

// ============================================================================
// Simple Node Variant
// ============================================================================

/**
 * Simplified node component for minimal rendering
 */
export const SimpleNode: React.FC<{
  x: number;
  y: number;
  width?: number;
  height?: number;
  label: string;
  fill?: string;
  stroke?: string;
  textColor?: string;
}> = ({
  x,
  y,
  width = 150,
  height = 50,
  label,
  fill = "#ffffff",
  stroke = "#e2e8f0",
  textColor = "#1e293b",
}) => {
  return (
    <G transform={`translate(${x}, ${y})`}>
      <Rect
        x={0}
        y={0}
        width={width}
        height={height}
        fill={fill}
        stroke={stroke}
        strokeWidth={1}
        rx={8}
      />
      <SvgText
        x={width / 2}
        y={height / 2 + 4}
        style={{
          fontSize: 11,
          textAnchor: "middle",
        }}
        fill={textColor}
      >
        {label}
      </SvgText>
    </G>
  );
};

export { DiagramNodeComponent as DiagramNode };
export default DiagramNodeComponent;
