/**
 * Section Component
 * Semantic content grouping with optional title
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors, spacing } from "../../primitives/index.js";

export interface SectionProps {
  /** Section content */
  children: React.ReactNode;
  /** Optional section title */
  title?: string;
  /** Title heading level (affects styling) */
  titleLevel?: 2 | 3 | 4;
  /** Space below the section */
  marginBottom?: number;
  /** Space below the title (when present) */
  titleMarginBottom?: number;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Maps title levels to text styles
 */
const titleStyleMap = {
  2: textStyles.h2,
  3: textStyles.h3,
  4: textStyles.h4,
} as const;

/**
 * Section component for grouping related content in PDF documents.
 * Provides semantic structure with optional titled sections.
 *
 * @example
 * ```tsx
 * <Section title="Overview">
 *   <Paragraph>Section content goes here</Paragraph>
 * </Section>
 *
 * <Section title="Details" titleLevel={3} marginBottom={32}>
 *   <List items={["Item 1", "Item 2"]} />
 * </Section>
 *
 * <Section>
 *   <Text>Section without a title</Text>
 * </Section>
 * ```
 */
export const Section: React.FC<SectionProps> = ({
  children,
  title,
  titleLevel = 3,
  marginBottom = spacing.xl,
  titleMarginBottom = spacing.md,
  style,
}) => {
  const containerStyle: Style = {
    marginBottom,
  };

  const titleStyle: Style = {
    ...titleStyleMap[titleLevel],
    color: semanticColors.text.primary,
    marginBottom: titleMarginBottom,
  };

  return (
    <View style={mergeStyles(containerStyle, style)}>
      {title && <Text style={titleStyle}>{title}</Text>}
      {children}
    </View>
  );
};

export default Section;
