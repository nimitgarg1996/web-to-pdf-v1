/**
 * Callout Component
 * Highlighted information box with optional icon
 */

import React from "react";
import { View, Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import {
  statusColors,
  textColors,
  spacing,
  borderRadius,
  borderWidth,
  fontSizes,
  lineHeights,
} from "../../primitives/index.js";
import { Icon } from "../media/Icon.js";
import type { IconName } from "../../primitives/index.js";

export interface CalloutProps {
  /** Callout content */
  children: React.ReactNode;
  /** Visual variant */
  variant?: "info" | "success" | "warning" | "error";
  /** Optional title text */
  title?: string;
  /** Optional icon name (defaults based on variant) */
  icon?: IconName | null;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Configuration for each callout variant
 */
const variantConfig = {
  info: {
    background: statusColors.infoBackground,
    border: statusColors.info,
    text: textColors.primary,
    icon: "info" as IconName,
  },
  success: {
    background: statusColors.successBackground,
    border: statusColors.success,
    text: textColors.primary,
    icon: "checkCircle" as IconName,
  },
  warning: {
    background: statusColors.warningBackground,
    border: statusColors.warning,
    text: textColors.primary,
    icon: "warning" as IconName,
  },
  error: {
    background: statusColors.errorBackground,
    border: statusColors.error,
    text: textColors.primary,
    icon: "error" as IconName,
  },
} as const;

/**
 * Callout component for highlighted information in PDF documents.
 * Used for tips, warnings, notes, and important information.
 *
 * @example
 * ```tsx
 * <Callout variant="info">
 *   This is an informational note.
 * </Callout>
 *
 * <Callout variant="warning" title="Attention">
 *   Please review before proceeding.
 * </Callout>
 *
 * <Callout variant="success" icon="check">
 *   Task completed successfully!
 * </Callout>
 *
 * <Callout variant="error" icon={null}>
 *   Error without an icon.
 * </Callout>
 * ```
 */
export const Callout: React.FC<CalloutProps> = ({
  children,
  variant = "info",
  title,
  icon,
  style,
}) => {
  const config = variantConfig[variant];
  
  // Determine which icon to show (null = no icon, undefined = default icon)
  const iconToShow = icon === null ? null : (icon ?? config.icon);

  const containerStyle: Style = {
    backgroundColor: config.background,
    borderLeftWidth: borderWidth.extraThick,
    borderLeftColor: config.border,
    borderLeftStyle: "solid",
    borderRadius: borderRadius.sm,
    padding: spacing.md,
    flexDirection: "row",
    gap: spacing.sm,
  };

  const contentContainerStyle: Style = {
    flex: 1,
  };

  const titleStyle: Style = {
    fontSize: fontSizes.base,
    fontWeight: "bold",
    color: config.text,
    marginBottom: spacing.xxs,
  };

  const textStyle: Style = {
    fontSize: fontSizes.sm,
    lineHeight: lineHeights.normal,
    color: config.text,
  };

  return (
    <View style={mergeStyles(containerStyle, style)}>
      {iconToShow && (
        <Icon name={iconToShow} size={18} color={config.border} />
      )}
      <View style={contentContainerStyle}>
        {title && <Text style={titleStyle}>{title}</Text>}
        {typeof children === "string" ? (
          <Text style={textStyle}>{children}</Text>
        ) : (
          children
        )}
      </View>
    </View>
  );
};

export default Callout;
