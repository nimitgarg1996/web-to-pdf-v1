/**
 * Card Component
 * Container with visual distinction from surrounding content
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import {
  backgroundColors,
  borderColors,
  borderRadius,
  spacing,
  borderWidth,
} from "../../primitives/index.js";

export interface CardProps {
  /** Card content */
  children: React.ReactNode;
  /** Visual variant */
  variant?: "default" | "outlined" | "elevated";
  /** Internal padding */
  padding?: "none" | "sm" | "md" | "lg";
  /** Background color override */
  backgroundColor?: string;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Padding configuration for card sizes
 */
const paddingConfig = {
  none: 0,
  sm: spacing.sm,
  md: spacing.md,
  lg: spacing.lg,
} as const;

/**
 * Card component for creating distinct content containers in PDF documents.
 * Supports different visual styles for various use cases.
 *
 * @example
 * ```tsx
 * <Card>
 *   <Heading level={3}>Card Title</Heading>
 *   <Paragraph>Card content here</Paragraph>
 * </Card>
 *
 * <Card variant="outlined" padding="lg">
 *   <Text>Outlined card with large padding</Text>
 * </Card>
 *
 * <Card variant="elevated">
 *   <Text>Elevated card style</Text>
 * </Card>
 * ```
 */
export const Card: React.FC<CardProps> = ({
  children,
  variant = "default",
  padding = "md",
  backgroundColor,
  style,
}) => {
  const paddingValue = paddingConfig[padding];

  // Base styles for all variants
  const baseStyle: Style = {
    padding: paddingValue,
    borderRadius: borderRadius.md,
  };

  // Variant-specific styles
  const variantStyles: Record<string, Style> = {
    default: {
      backgroundColor: backgroundColor || backgroundColors.secondary,
    },
    outlined: {
      backgroundColor: backgroundColor || backgroundColors.primary,
      borderWidth: borderWidth.thin,
      borderColor: borderColors.default,
      borderStyle: "solid",
    },
    elevated: {
      backgroundColor: backgroundColor || backgroundColors.elevated,
      borderWidth: borderWidth.hairline,
      borderColor: borderColors.subtle,
      borderStyle: "solid",
      // Note: React-PDF doesn't support box-shadow, so we use a subtle border instead
    },
  };

  const computedStyle: Style = {
    ...baseStyle,
    ...variantStyles[variant],
  };

  return (
    <View style={mergeStyles(computedStyle, style)}>
      {children}
    </View>
  );
};

export default Card;
