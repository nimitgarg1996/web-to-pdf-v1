/**
 * Divider Component
 * Horizontal or vertical line separator
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { borderColors, spacing } from "../../primitives/index.js";
import type { SpacingKey } from "../../primitives/index.js";

export interface DividerProps {
  /** Orientation of the divider */
  orientation?: "horizontal" | "vertical";
  /** Divider color */
  color?: string;
  /** Divider thickness in points */
  thickness?: number;
  /** Margin around the divider - can be a spacing key or number in points */
  margin?: SpacingKey | number;
  /** Length of the divider (width for horizontal, height for vertical) */
  length?: number | string;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Resolves a spacing value from either a key or a number
 */
function resolveSpacing(value: SpacingKey | number | undefined): number {
  if (value === undefined) return 0;
  if (typeof value === "number") return value;
  return spacing[value];
}

/**
 * Divider component for visual separation in PDF documents.
 * Creates horizontal or vertical lines between content sections.
 *
 * @example
 * ```tsx
 * <Divider />
 *
 * <Divider color="#3b82f6" thickness={2} margin="lg" />
 *
 * <Row>
 *   <Text>Left</Text>
 *   <Divider orientation="vertical" length={20} margin="sm" />
 *   <Text>Right</Text>
 * </Row>
 * ```
 */
export const Divider: React.FC<DividerProps> = ({
  orientation = "horizontal",
  color = borderColors.default,
  thickness = 1,
  margin = "sm",
  length = "100%",
  style,
}) => {
  const resolvedMargin = resolveSpacing(margin);

  const isHorizontal = orientation === "horizontal";

  const computedStyle: Style = isHorizontal
    ? {
        width: length,
        height: thickness,
        backgroundColor: color,
        marginVertical: resolvedMargin,
      }
    : {
        width: thickness,
        height: length,
        backgroundColor: color,
        marginHorizontal: resolvedMargin,
      };

  return <View style={mergeStyles(computedStyle, style)} />;
};

export default Divider;
