/**
 * Spacer Component
 * Fixed-size whitespace for precise layout control
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { spacing } from "../../primitives/index.js";
import type { SpacingKey } from "../../primitives/index.js";

export interface SpacerProps {
  /** Height of the spacer - can be a spacing key or number in points */
  height?: SpacingKey | number;
  /** Width of the spacer - can be a spacing key or number in points */
  width?: SpacingKey | number;
  /** Shorthand for both height and width */
  size?: SpacingKey | number;
  /** Whether to flex-grow to fill available space */
  flex?: boolean;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Resolves a spacing value from either a key or a number
 */
function resolveSpacing(value: SpacingKey | number | undefined): number | undefined {
  if (value === undefined) return undefined;
  if (typeof value === "number") return value;
  return spacing[value];
}

/**
 * Spacer component for creating whitespace in PDF documents.
 * Provides fixed-size spacing for precise layout control.
 *
 * @example
 * ```tsx
 * <Stack>
 *   <Heading level={1}>Title</Heading>
 *   <Spacer height="xl" />
 *   <Paragraph>Content after extra space</Paragraph>
 * </Stack>
 *
 * <Row>
 *   <Text>Left</Text>
 *   <Spacer flex />
 *   <Text>Right (pushed to end)</Text>
 * </Row>
 *
 * <Spacer size="md" /> // Square spacer
 * ```
 */
export const Spacer: React.FC<SpacerProps> = ({
  height,
  width,
  size,
  flex = false,
  style,
}) => {
  const resolvedHeight = resolveSpacing(size ?? height);
  const resolvedWidth = resolveSpacing(size ?? width);

  const computedStyle: Style = {
    ...(resolvedHeight !== undefined && { height: resolvedHeight }),
    ...(resolvedWidth !== undefined && { width: resolvedWidth }),
    ...(flex && { flexGrow: 1 }),
  };

  return <View style={mergeStyles(computedStyle, style)} />;
};

export default Spacer;
