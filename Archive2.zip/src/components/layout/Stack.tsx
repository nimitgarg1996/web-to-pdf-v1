/**
 * Stack Component
 * Vertical stack layout with configurable gap between children
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { spacing } from "../../primitives/index.js";
import type { SpacingKey } from "../../primitives/index.js";

export interface StackProps {
  /** Stack content */
  children: React.ReactNode;
  /** Gap between items - can be a spacing key or number in points */
  gap?: SpacingKey | number;
  /** Horizontal alignment of children */
  align?: "start" | "center" | "end" | "stretch";
  /** Additional style overrides */
  style?: Style;
}

/**
 * Resolves a spacing value from either a key or a number
 */
function resolveSpacing(value: SpacingKey | number | undefined): number {
  if (value === undefined) return 0;
  if (typeof value === "number") return value;
  return spacing[value];
}

/**
 * Maps alignment prop to flexbox alignItems value
 */
const alignMap = {
  start: "flex-start",
  center: "center",
  end: "flex-end",
  stretch: "stretch",
} as const;

/**
 * Stack component for vertical layouts in PDF documents.
 * Arranges children vertically with consistent spacing.
 *
 * @example
 * ```tsx
 * <Stack gap="md">
 *   <Heading level={2}>Title</Heading>
 *   <Paragraph>First paragraph</Paragraph>
 *   <Paragraph>Second paragraph</Paragraph>
 * </Stack>
 *
 * <Stack gap={16} align="center">
 *   <Text>Centered content</Text>
 * </Stack>
 * ```
 */
export const Stack: React.FC<StackProps> = ({
  children,
  gap = "sm",
  align = "stretch",
  style,
}) => {
  const resolvedGap = resolveSpacing(gap);

  const computedStyle: Style = {
    flexDirection: "column",
    alignItems: alignMap[align],
    gap: resolvedGap,
  };

  return (
    <View style={mergeStyles(computedStyle, style)}>
      {children}
    </View>
  );
};

export default Stack;
