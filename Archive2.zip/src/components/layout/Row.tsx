/**
 * Row Component
 * Horizontal row layout with configurable gap and alignment
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { spacing } from "../../primitives/index.js";
import type { SpacingKey } from "../../primitives/index.js";

export interface RowProps {
  /** Row content */
  children: React.ReactNode;
  /** Gap between items - can be a spacing key or number in points */
  gap?: SpacingKey | number;
  /** Horizontal alignment/distribution of children */
  justify?: "start" | "center" | "end" | "between" | "around" | "evenly";
  /** Vertical alignment of children */
  align?: "start" | "center" | "end" | "stretch" | "baseline";
  /** Whether to wrap children to next line */
  wrap?: boolean;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Resolves a spacing value from either a key or a number
 */
function resolveSpacing(value: SpacingKey | number | undefined): number {
  if (value === undefined) return 0;
  if (typeof value === "number") return value;
  return spacing[value];
}

/**
 * Maps justify prop to flexbox justifyContent value
 */
const justifyMap = {
  start: "flex-start",
  center: "center",
  end: "flex-end",
  between: "space-between",
  around: "space-around",
  evenly: "space-evenly",
} as const;

/**
 * Maps align prop to flexbox alignItems value
 */
const alignMap = {
  start: "flex-start",
  center: "center",
  end: "flex-end",
  stretch: "stretch",
  baseline: "baseline",
} as const;

/**
 * Row component for horizontal layouts in PDF documents.
 * Arranges children horizontally with configurable spacing and alignment.
 *
 * @example
 * ```tsx
 * <Row gap="md" justify="between">
 *   <Text>Left</Text>
 *   <Text>Right</Text>
 * </Row>
 *
 * <Row gap={8} align="center">
 *   <Icon name="check" />
 *   <Text>Aligned with icon</Text>
 * </Row>
 * ```
 */
export const Row: React.FC<RowProps> = ({
  children,
  gap = "sm",
  justify = "start",
  align = "center",
  wrap = false,
  style,
}) => {
  const resolvedGap = resolveSpacing(gap);

  const computedStyle: Style = {
    flexDirection: "row",
    justifyContent: justifyMap[justify],
    alignItems: alignMap[align],
    flexWrap: wrap ? "wrap" : "nowrap",
    gap: resolvedGap,
  };

  return (
    <View style={mergeStyles(computedStyle, style)}>
      {children}
    </View>
  );
};

export default Row;
