/**
 * Box Component
 * Generic container component with padding, margin, border, and background support
 */

import React from "react";
import { View } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { spacing, borderRadius, borderWidth, borderColors } from "../../primitives/index.js";
import type { SpacingKey, BorderRadiusKey } from "../../primitives/index.js";

export interface BoxBorderProps {
  /** Border width */
  width?: number;
  /** Border color */
  color?: string;
  /** Border style - Note: React-PDF may have limited support */
  style?: "solid" | "dashed" | "dotted";
  /** Border radius */
  radius?: number | BorderRadiusKey;
}

export interface BoxProps {
  /** Box content */
  children: React.ReactNode;
  /** Padding - can be a spacing key or a number in points */
  padding?: SpacingKey | number;
  /** Horizontal padding override */
  paddingHorizontal?: SpacingKey | number;
  /** Vertical padding override */
  paddingVertical?: SpacingKey | number;
  /** Margin - can be a spacing key or a number in points */
  margin?: SpacingKey | number;
  /** Horizontal margin override */
  marginHorizontal?: SpacingKey | number;
  /** Vertical margin override */
  marginVertical?: SpacingKey | number;
  /** Background color */
  backgroundColor?: string;
  /** Border configuration */
  border?: BoxBorderProps;
  /** Fixed width */
  width?: number | string;
  /** Fixed height */
  height?: number | string;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Resolves a spacing value from either a key or a number
 */
function resolveSpacing(value: SpacingKey | number | undefined): number | undefined {
  if (value === undefined) return undefined;
  if (typeof value === "number") return value;
  return spacing[value];
}

/**
 * Resolves a border radius value from either a key or a number
 */
function resolveBorderRadius(value: BorderRadiusKey | number | undefined): number | undefined {
  if (value === undefined) return undefined;
  if (typeof value === "number") return value;
  return borderRadius[value];
}

/**
 * Box component for creating container elements in PDF documents.
 * Provides a flexible container with padding, margin, border, and background support.
 *
 * @example
 * ```tsx
 * <Box padding="md" backgroundColor="#f8fafc">
 *   <Text>Content inside a box</Text>
 * </Box>
 *
 * <Box
 *   padding="lg"
 *   border={{ width: 1, color: "#e2e8f0", radius: "md" }}
 * >
 *   <Text>Bordered box</Text>
 * </Box>
 * ```
 */
export const Box: React.FC<BoxProps> = ({
  children,
  padding,
  paddingHorizontal,
  paddingVertical,
  margin,
  marginHorizontal,
  marginVertical,
  backgroundColor,
  border,
  width,
  height,
  style,
}) => {
  const resolvedPadding = resolveSpacing(padding);
  const resolvedMargin = resolveSpacing(margin);

  const computedStyle: Style = {
    // Padding
    ...(resolvedPadding !== undefined && { padding: resolvedPadding }),
    ...(paddingHorizontal !== undefined && { paddingHorizontal: resolveSpacing(paddingHorizontal) }),
    ...(paddingVertical !== undefined && { paddingVertical: resolveSpacing(paddingVertical) }),
    
    // Margin
    ...(resolvedMargin !== undefined && { margin: resolvedMargin }),
    ...(marginHorizontal !== undefined && { marginHorizontal: resolveSpacing(marginHorizontal) }),
    ...(marginVertical !== undefined && { marginVertical: resolveSpacing(marginVertical) }),
    
    // Background
    ...(backgroundColor && { backgroundColor }),
    
    // Dimensions
    ...(width !== undefined && { width }),
    ...(height !== undefined && { height }),
    
    // Border
    ...(border?.width !== undefined && { borderWidth: border.width }),
    ...(border?.color && { borderColor: border.color }),
    ...(border?.style && { borderStyle: border.style }),
    ...(border?.radius !== undefined && { borderRadius: resolveBorderRadius(border.radius) }),
  };

  return (
    <View style={mergeStyles(computedStyle, style)}>
      {children}
    </View>
  );
};

export default Box;
