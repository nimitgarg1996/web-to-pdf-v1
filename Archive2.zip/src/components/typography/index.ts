/**
 * Typography Components Index
 * Exports all typography-related components
 */

export { Text, type TextProps } from "./Text.js";
export { Heading, type HeadingProps } from "./Heading.js";
export { Paragraph, type ParagraphProps } from "./Paragraph.js";
export { Label, type LabelProps } from "./Label.js";
export { Caption, type CaptionProps } from "./Caption.js";
