/**
 * Heading Component
 * Renders semantic heading levels (h1-h6) with consistent typography styles
 */

import React from "react";
import { Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors } from "../../primitives/index.js";

export interface HeadingProps {
  /** Heading level (1-6) */
  level: 1 | 2 | 3 | 4 | 5 | 6;
  /** Heading content */
  children: React.ReactNode;
  /** Custom text color */
  color?: string;
  /** Text alignment */
  align?: "left" | "center" | "right";
  /** Additional style overrides */
  style?: Style;
}

/**
 * Maps heading levels to their corresponding text styles
 */
const levelStyleMap = {
  1: textStyles.h1,
  2: textStyles.h2,
  3: textStyles.h3,
  4: textStyles.h4,
  5: textStyles.h5,
  6: textStyles.h6,
} as const;

/**
 * Heading component for PDF documents.
 * Provides semantic heading levels with consistent typography.
 *
 * @example
 * ```tsx
 * <Heading level={1}>Main Page Title</Heading>
 * <Heading level={2} align="center">Centered Section Title</Heading>
 * <Heading level={3} color="#3b82f6">Colored Heading</Heading>
 * ```
 */
export const Heading: React.FC<HeadingProps> = ({
  level,
  children,
  color,
  align = "left",
  style,
}) => {
  const baseStyle = levelStyleMap[level];

  const computedStyle: Style = {
    ...baseStyle,
    color: color || semanticColors.text.primary,
    textAlign: align,
  };

  return (
    <Text style={mergeStyles(computedStyle, style)}>
      {children}
    </Text>
  );
};

export default Heading;
