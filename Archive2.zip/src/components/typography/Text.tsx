/**
 * Text Component
 * Base text component that serves as the foundation for other typography components
 */

import React from "react";
import { Text as PDFText } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors } from "../../primitives/index.js";
import type { TextStyleKey } from "../../primitives/index.js";

export interface TextProps {
  /** Content to render */
  children: React.ReactNode;
  /** Pre-defined text style variant */
  variant?: TextStyleKey;
  /** Custom text color */
  color?: string;
  /** Text alignment */
  align?: "left" | "center" | "right" | "justify";
  /** Font weight override */
  fontWeight?: "normal" | "bold" | number;
  /** Text decoration */
  decoration?: "none" | "underline" | "line-through";
  /** Text transform */
  transform?: "none" | "uppercase" | "lowercase" | "capitalize";
  /** Additional style overrides */
  style?: Style;
}

/**
 * Base Text component for rendering text in PDF documents.
 * Provides consistent styling and supports all typography variants.
 *
 * @example
 * ```tsx
 * <Text variant="body">Regular paragraph text</Text>
 * <Text variant="label" transform="uppercase">Label text</Text>
 * <Text color="#ff0000" fontWeight="bold">Custom styled text</Text>
 * ```
 */
export const Text: React.FC<TextProps> = ({
  children,
  variant = "body",
  color,
  align = "left",
  fontWeight,
  decoration,
  transform,
  style,
}) => {
  const baseStyle = textStyles[variant];

  const computedStyle: Style = {
    ...baseStyle,
    color: color || semanticColors.text.primary,
    textAlign: align,
    ...(fontWeight !== undefined && { fontWeight }),
    ...(decoration && { textDecoration: decoration }),
    ...(transform && { textTransform: transform }),
  };

  return (
    <PDFText style={mergeStyles(computedStyle, style)}>
      {children}
    </PDFText>
  );
};

export default Text;
