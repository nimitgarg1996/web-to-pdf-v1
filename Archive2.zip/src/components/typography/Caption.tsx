/**
 * Caption Component
 * Small text for annotations, footnotes, and supplementary information
 */

import React from "react";
import { Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors } from "../../primitives/index.js";

export interface CaptionProps {
  /** Caption content */
  children: React.ReactNode;
  /** Custom text color */
  color?: string;
  /** Text alignment */
  align?: "left" | "center" | "right";
  /** Visual emphasis level */
  emphasis?: "normal" | "muted" | "strong";
  /** Additional style overrides */
  style?: Style;
}

/**
 * Maps emphasis levels to colors
 */
const emphasisColorMap = {
  normal: semanticColors.text.secondary,
  muted: semanticColors.text.muted,
  strong: semanticColors.text.primary,
} as const;

/**
 * Caption component for small text in PDF documents.
 * Used for image captions, footnotes, annotations, and supplementary text.
 *
 * @example
 * ```tsx
 * <Caption>Figure 1: Sales Overview</Caption>
 * <Caption emphasis="muted">Last updated: Jan 2024</Caption>
 * <Caption align="center" emphasis="strong">Important note</Caption>
 * ```
 */
export const Caption: React.FC<CaptionProps> = ({
  children,
  color,
  align = "left",
  emphasis = "normal",
  style,
}) => {
  const computedStyle: Style = {
    ...textStyles.caption,
    color: color || emphasisColorMap[emphasis],
    textAlign: align,
  };

  return (
    <Text style={mergeStyles(computedStyle, style)}>
      {children}
    </Text>
  );
};

export default Caption;
