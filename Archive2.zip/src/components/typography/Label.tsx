/**
 * Label Component
 * Form/data labels with optional uppercase styling
 */

import React from "react";
import { Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors } from "../../primitives/index.js";

export interface LabelProps {
  /** Label content */
  children: React.ReactNode;
  /** Whether to render in uppercase */
  uppercase?: boolean;
  /** Custom text color */
  color?: string;
  /** Text alignment */
  align?: "left" | "center" | "right";
  /** Label size variant */
  size?: "sm" | "md";
  /** Whether this is a required field indicator */
  required?: boolean;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Label component for form fields and data labels in PDF documents.
 * Commonly used for key-value pairs, form fields, and table headers.
 *
 * @example
 * ```tsx
 * <Label>First Name</Label>
 * <Label uppercase>Category</Label>
 * <Label required>Email Address</Label>
 * <Label size="sm" color="#6b7280">Secondary label</Label>
 * ```
 */
export const Label: React.FC<LabelProps> = ({
  children,
  uppercase = false,
  color,
  align = "left",
  size = "md",
  required = false,
  style,
}) => {
  const baseStyle = size === "sm" ? textStyles.caption : textStyles.label;

  const computedStyle: Style = {
    ...baseStyle,
    color: color || semanticColors.text.secondary,
    textAlign: align,
    textTransform: uppercase ? "uppercase" : "none",
  };

  return (
    <Text style={mergeStyles(computedStyle, style)}>
      {children}
      {required && <Text style={{ color: semanticColors.status.error }}> *</Text>}
    </Text>
  );
};

export default Label;
