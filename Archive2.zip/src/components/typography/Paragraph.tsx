/**
 * Paragraph Component
 * Body text component with optional first-line indent and spacing
 */

import React from "react";
import { Text } from "@react-pdf/renderer";
import { mergeStyles, type Style } from "../types.js";
import { textStyles, semanticColors, spacing } from "../../primitives/index.js";

export interface ParagraphProps {
  /** Paragraph content */
  children: React.ReactNode;
  /** Text size variant */
  size?: "sm" | "md" | "lg";
  /** Custom text color */
  color?: string;
  /** Text alignment */
  align?: "left" | "center" | "right" | "justify";
  /** First-line indent (in points) */
  indent?: number;
  /** Margin bottom (in points) */
  marginBottom?: number;
  /** Additional style overrides */
  style?: Style;
}

/**
 * Maps size variants to text styles
 */
const sizeStyleMap = {
  sm: textStyles.bodySmall,
  md: textStyles.body,
  lg: textStyles.bodyLarge,
} as const;

/**
 * Paragraph component for body text in PDF documents.
 * Supports multiple sizes, first-line indentation, and text alignment.
 *
 * @example
 * ```tsx
 * <Paragraph>Standard paragraph text</Paragraph>
 * <Paragraph size="lg" align="justify">Large justified text</Paragraph>
 * <Paragraph indent={24}>Indented first line paragraph</Paragraph>
 * ```
 */
export const Paragraph: React.FC<ParagraphProps> = ({
  children,
  size = "md",
  color,
  align = "left",
  indent,
  marginBottom = spacing.sm,
  style,
}) => {
  const baseStyle = sizeStyleMap[size];

  const computedStyle: Style = {
    ...baseStyle,
    color: color || semanticColors.text.primary,
    textAlign: align,
    marginBottom,
    ...(indent !== undefined && { textIndent: indent }),
  };

  return (
    <Text style={mergeStyles(computedStyle, style)}>
      {children}
    </Text>
  );
};

export default Paragraph;
