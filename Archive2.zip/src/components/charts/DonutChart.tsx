import React from 'react';
import { View, Text, Svg, Path, Circle } from '@react-pdf/renderer';

export interface DonutSegment {
  value: number;
  color: string;
  label: string;
}

export interface DonutChartProps {
  segments: DonutSegment[];
  total: number | string;
  centerLabel?: string;
  size?: number;
  thickness?: number;
  showLegend?: boolean;
}

/**
 * Convert polar coordinates to cartesian
 */
function polarToCartesian(
  centerX: number,
  centerY: number,
  radius: number,
  angleInDegrees: number
): { x: number; y: number } {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
  return {
    x: centerX + radius * Math.cos(angleInRadians),
    y: centerY + radius * Math.sin(angleInRadians),
  };
}

/**
 * Create SVG path for a donut (annular) segment
 * This creates a closed path with outer arc, line to inner, inner arc (reverse), and close
 */
function describeDonutArc(
  cx: number,
  cy: number,
  innerRadius: number,
  outerRadius: number,
  startAngle: number,
  endAngle: number
): string {
  // Handle edge case for full circle (or near full)
  if (endAngle - startAngle >= 359.99) {
    // For a full circle, we need two arcs
    const outerStart = polarToCartesian(cx, cy, outerRadius, 0);
    const innerStart = polarToCartesian(cx, cy, innerRadius, 0);
    
    return [
      `M ${outerStart.x} ${outerStart.y}`,
      `A ${outerRadius} ${outerRadius} 0 1 1 ${outerStart.x - 0.01} ${outerStart.y}`,
      `L ${innerStart.x - 0.01} ${innerStart.y}`,
      `A ${innerRadius} ${innerRadius} 0 1 0 ${innerStart.x} ${innerStart.y}`,
      'Z'
    ].join(' ');
  }

  // Outer arc: goes from endAngle to startAngle (clockwise visually, counterclockwise in SVG)
  const outerStart = polarToCartesian(cx, cy, outerRadius, endAngle);
  const outerEnd = polarToCartesian(cx, cy, outerRadius, startAngle);
  
  // Inner arc: goes from startAngle to endAngle (reverse direction)
  const innerStart = polarToCartesian(cx, cy, innerRadius, startAngle);
  const innerEnd = polarToCartesian(cx, cy, innerRadius, endAngle);
  
  const largeArcFlag = endAngle - startAngle <= 180 ? 0 : 1;

  return [
    `M ${outerStart.x} ${outerStart.y}`,
    `A ${outerRadius} ${outerRadius} 0 ${largeArcFlag} 0 ${outerEnd.x} ${outerEnd.y}`,
    `L ${innerStart.x} ${innerStart.y}`,
    `A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 1 ${innerEnd.x} ${innerEnd.y}`,
    'Z'
  ].join(' ');
}

/**
 * DonutChart component for financial visualizations
 * Renders an SVG donut chart with segments, center total, and optional legend
 */
export const DonutChart: React.FC<DonutChartProps> = ({
  segments,
  total,
  centerLabel = '',
  size = 300,
  thickness = 40,
  showLegend = true,
}) => {
  // Calculate total value from segments
  const totalValue = segments.reduce((sum, seg) => sum + seg.value, 0);

  // Calculate percentages and angles
  let currentAngle = 0;
  const segmentsWithAngles = segments.map((segment) => {
    const percentage = (segment.value / totalValue) * 100;
    const angle = (segment.value / totalValue) * 360;
    const startAngle = currentAngle;
    const endAngle = currentAngle + angle;
    currentAngle = endAngle;

    return {
      ...segment,
      percentage,
      startAngle,
      endAngle,
    };
  });

  const centerX = size / 2;
  const centerY = size / 2;
  const radius = (size - thickness) / 2;
  const innerRadius = radius - thickness;

  // Format total value
  const formattedTotal =
    typeof total === 'number'
      ? `$${total.toLocaleString('en-US')}`
      : total;

  return (
    <View style={{ flexDirection: showLegend ? 'row' : 'column', alignItems: 'flex-start' }}>
      {/* Donut Chart SVG */}
      <View style={{ width: size, height: size, position: 'relative', marginRight: showLegend ? 20 : 0, marginBottom: showLegend ? 0 : 20 }}>
        <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {/* Background circle */}
          <Circle
            cx={centerX}
            cy={centerY}
            r={radius - thickness / 2}
            fill="none"
            stroke="#F3F4F6"
            strokeWidth={thickness}
          />

          {/* Donut segments */}
          {segmentsWithAngles.map((segment, index) => {
            // Use the proper donut arc function
            const pathData = describeDonutArc(
              centerX,
              centerY,
              innerRadius,
              radius,
              segment.startAngle,
              segment.endAngle
            );

            return (
              <Path
                key={index}
                d={pathData}
                fill={segment.color}
              />
            );
          })}
        </Svg>

        {/* Center text */}
        <View
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: size,
            height: size,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Text
            style={{
              fontSize: 28,
              fontWeight: 'bold',
              color: '#111827',
              textAlign: 'center',
            }}
          >
            {formattedTotal}
          </Text>
          {centerLabel && (
            <Text
              style={{
                fontSize: 12,
                color: '#6B7280',
                marginTop: 4,
                textAlign: 'center',
              }}
            >
              {centerLabel}
            </Text>
          )}
        </View>
      </View>

      {/* Legend */}
      {showLegend && (
        <View style={{ flex: 1, justifyContent: 'center' }}>
          {segmentsWithAngles.map((segment, index) => (
            <View
              key={index}
              style={{ flexDirection: 'row', alignItems: 'center', marginBottom: index < segmentsWithAngles.length - 1 ? 12 : 0 }}
            >
              {/* Color dot */}
              <View
                style={{
                  width: 12,
                  height: 12,
                  borderRadius: 6,
                  backgroundColor: segment.color,
                  marginRight: 10,
                }}
              />
              
              {/* Label and value */}
              <View style={{ flex: 1, flexDirection: 'column' }}>
                <Text style={{ fontSize: 11, color: '#374151', marginBottom: 2 }}>
                  {segment.label}
                </Text>
                <Text style={{ fontSize: 13, fontWeight: 'bold', color: '#111827' }}>
                  ${segment.value.toLocaleString('en-US')}
                </Text>
                <Text style={{ fontSize: 10, color: '#6B7280' }}>
                  {segment.percentage.toFixed(1)}%
                </Text>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );
};
