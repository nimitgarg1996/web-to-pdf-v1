/**
 * Components Index
 * Exports all reusable React-PDF components for the report builder
 *
 * Components are organized into categories:
 * - Typography: Text rendering components (Heading, Paragraph, Label, Caption, Text)
 * - Layout: Structural components (Box, Stack, Row, Divider, Spacer)
 * - Feedback: Status and progress indicators (Badge, StatusIndicator, ProgressBar)
 * - Media: Images and icons (Icon, Logo)
 * - Containers: Content grouping (Card, Section, Callout)
 * - Data: Data display components (KeyValue, List, MetricCard)
 * - Navigation: TOC, bookmarks, print marks (TableOfContents, CropMarks)
 */

// ============================================================================
// Typography Components
// ============================================================================

export {
  Text,
  type TextProps,
  Heading,
  type HeadingProps,
  Paragraph,
  type ParagraphProps,
  Label,
  type LabelProps,
  Caption,
  type CaptionProps,
} from "./typography/index.js";

// ============================================================================
// Layout Components
// ============================================================================

export {
  Box,
  type BoxProps,
  type BoxBorderProps,
  Stack,
  type StackProps,
  Row,
  type RowProps,
  Divider,
  type DividerProps,
  Spacer,
  type SpacerProps,
} from "./layout/index.js";

// ============================================================================
// Feedback Components
// ============================================================================

export {
  Badge,
  type BadgeProps,
  StatusIndicator,
  type StatusIndicatorProps,
  ProgressBar,
  type ProgressBarProps,
} from "./feedback/index.js";

// ============================================================================
// Media Components
// ============================================================================

export {
  Icon,
  type IconProps,
  Logo,
  type LogoProps,
} from "./media/index.js";

// ============================================================================
// Container Components
// ============================================================================

export {
  Card,
  type CardProps,
  Section,
  type SectionProps,
  Callout,
  type CalloutProps,
} from "./containers/index.js";

// ============================================================================
// Data Display Components
// ============================================================================

export {
  KeyValue,
  type KeyValueProps,
  List,
  type ListProps,
  MetricCard,
  type MetricCardProps,
  type MetricCardTrend,
} from "./data/index.js";

// ============================================================================
// Table Components
// ============================================================================

export {
  // Main Table Component
  Table,
  TableHeader,
  TableRow,
  TableCell,
  // Types
  type ColumnDefinition,
  type TableProps,
  type TableRowProps,
  type TableCellProps,
  type TableHeaderProps,
  type TableVariant,
  type TableStyleConfig,
  type TableStyles,
  // Styles
  tableStyles,
  getTableStyles,
  // Utilities
  formatters,
  formatCellValue,
  getRowValue,
  calculateColumnWidths,
} from "./table/index.js";

// ============================================================================
// Diagram Components
// ============================================================================

export {
  // Main Diagram Component
  Diagram,
  CompactDiagram,
  createFlowDiagram,
  // Node Components
  DiagramNode,
  DiagramNodeComponent,
  SimpleNode,
  // Edge Components
  DiagramEdge,
  DiagramEdgeComponent,
  SimpleEdge,
  // SVG Definitions
  DiagramDefs,
  ArrowheadDef,
  StatusGradientDef,
  GridLines,
  getStatusGradientId,
  getNodeGradientId,
  // Shape Components
  Rectangle,
  Diamond,
  Circle,
  Cylinder,
  getShapeComponent,
  shapeComponents,
  // Layout Utilities
  calculateBounds,
  calculateScale,
  calculateViewBox,
  calculateAutoFitViewBox,
  transformPosition,
  getNodeCenter,
  getNodePort,
  getBestPorts,
  snapToGrid,
  generateGridLines,
  // Edge Path Utilities
  generateEdgePath,
  straightPath,
  bezierPath,
  stepPath,
  smoothstepPath,
  selfLoopPath,
  getEdgeLabelPosition,
  getEdgeLabelRotation,
  getArrowheadTransform,
  estimatePathLength,
  // Types
  type DiagramProps,
  type DiagramNodeType,
  type DiagramEdgeType,
  type DiagramNodeData,
  type DiagramNodeStyle,
  type DiagramEdgeStyle,
  type DiagramBounds,
  type DiagramViewport,
  type NodeDefaults,
  type EdgeDefaults,
  type DiagramNodeComponentProps,
  type DiagramEdgeComponentProps,
  type ShapeProps,
  type Point,
  type NodeType,
  type NodeStatus,
  type NodeShape,
  type EdgeType,
  type PortPosition,
  type CompactDiagramProps,
  type FlowConfig,
  // Constants
  DEFAULT_NODE_WIDTH,
  DEFAULT_NODE_HEIGHT,
  DEFAULT_NODE_STYLE,
  DEFAULT_EDGE_STYLE,
  STATUS_COLORS,
} from "./diagram/index.js";

// ============================================================================
// Chart Components
// ============================================================================

export {
  DonutChart,
  type DonutChartProps,
  type DonutSegment,
} from "./charts/index.js";

// ============================================================================
// Estate Planning Components
// ============================================================================

export {
  BeneficiaryCard,
  type BeneficiaryCardProps,
  BeneficiaryGrid,
  type BeneficiaryGridProps,
  TrustFlowChart,
  type TrustFlowChartProps,
  type TrustNode,
  type TrustConnection,
  type TrustSeparator,
} from "./estate/index.js";

// ============================================================================
// Navigation Components
// ============================================================================

export {
  // Table of Contents
  TableOfContents,
  CompactToc,
  type TableOfContentsProps,
  type CompactTocProps,
  // Print Marks
  CropMarks,
  RegistrationMarks,
  PrintMarks,
  type CropMarksProps,
  type RegistrationMarksProps,
  type PrintMarksProps,
} from "./navigation/index.js";

// ============================================================================
// Shared Types
// ============================================================================

export { type Style, mergeStyles } from "./types.js";
