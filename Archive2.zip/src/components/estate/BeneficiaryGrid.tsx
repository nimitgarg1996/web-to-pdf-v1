import React from 'react';
import { View, Text } from '@react-pdf/renderer';
import { BeneficiaryCard, BeneficiaryCardProps } from './BeneficiaryCard.js';

export interface BeneficiaryGridProps {
  title: string;
  beneficiaries: BeneficiaryCardProps[];
  columns?: 2 | 3 | 4;
}

/**
 * BeneficiaryGrid component
 * Displays a grid of beneficiary cards with a header banner
 */
export const BeneficiaryGrid: React.FC<BeneficiaryGridProps> = ({
  title,
  beneficiaries,
  columns = 3,
}) => {
  // Calculate card width based on columns
  const gap = 16;
  const containerWidth = 520; // Approximate page width minus margins
  const cardWidth = (containerWidth - gap * (columns - 1)) / columns;

  // Group beneficiaries into rows
  const rows: BeneficiaryCardProps[][] = [];
  for (let i = 0; i < beneficiaries.length; i += columns) {
    rows.push(beneficiaries.slice(i, i + columns));
  }

  return (
    <View style={{ marginTop: 20, marginBottom: 20 }}>
      {/* Header banner */}
      <View
        style={{
          backgroundColor: '#2D9B9B',
          borderRadius: 12,
          padding: 16,
          marginBottom: 20,
        }}
      >
        <Text
          style={{
            fontSize: 18,
            fontWeight: 'bold',
            color: '#FFFFFF',
            textAlign: 'center',
          }}
        >
          {title}
        </Text>
      </View>

      {/* Grid of cards */}
      <View style={{ flexDirection: 'column' }}>
        {rows.map((row, rowIndex) => (
          <View
            key={rowIndex}
            style={{
              flexDirection: 'row',
              flexWrap: 'wrap',
              marginBottom: rowIndex < rows.length - 1 ? gap : 0,
            }}
          >
            {row.map((beneficiary, cardIndex) => (
              <View key={cardIndex} style={{ width: cardWidth, marginRight: cardIndex < row.length - 1 ? gap : 0 }}>
                <BeneficiaryCard {...beneficiary} />
              </View>
            ))}
            {/* Add empty placeholders if last row is incomplete */}
            {row.length < columns &&
              Array.from({ length: columns - row.length }).map((_, idx) => (
                <View key={`placeholder-${idx}`} style={{ width: cardWidth, marginRight: idx < columns - row.length - 1 ? gap : 0 }} />
              ))}
          </View>
        ))}
      </View>
    </View>
  );
};
