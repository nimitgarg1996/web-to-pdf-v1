import React from 'react';
import { View, Text, Svg, Circle, Path } from '@react-pdf/renderer';

export interface BeneficiaryCardProps {
  name: string;
  icon?: 'person' | 'charity';
  iconColor?: string;
  inTrust?: number;
  outright?: number;
}

/**
 * Format number in compact notation (e.g., 50M, 1.5B)
 */
function formatCompact(value: number): string {
  if (value >= 1_000_000_000) {
    const formatted = (value / 1_000_000_000).toFixed(1);
    return `$${formatted.replace(/\.0$/, '')}B`;
  }
  if (value >= 1_000_000) {
    const formatted = (value / 1_000_000).toFixed(1);
    return `$${formatted.replace(/\.0$/, '')}M`;
  }
  if (value >= 1_000) {
    const formatted = (value / 1_000).toFixed(1);
    return `$${formatted.replace(/\.0$/, '')}K`;
  }
  return `$${value.toLocaleString('en-US')}`;
}

/**
 * Person icon SVG
 */
const PersonIcon: React.FC<{ color: string; size: number }> = ({ color, size }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24">
    {/* Head */}
    <Circle cx="12" cy="8" r="4" fill={color} />
    {/* Body */}
    <Path
      d="M12 14c-4 0-7 2-7 4v2h14v-2c0-2-3-4-7-4z"
      fill={color}
    />
  </Svg>
);

/**
 * Charity/heart icon SVG
 */
const CharityIcon: React.FC<{ color: string; size: number }> = ({ color, size }) => (
  <Svg width={size} height={size} viewBox="0 0 24 24">
    <Path
      d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
      fill={color}
    />
  </Svg>
);

/**
 * BeneficiaryCard component
 * Displays beneficiary information with icon, name, and distribution amounts
 */
export const BeneficiaryCard: React.FC<BeneficiaryCardProps> = ({
  name,
  icon = 'person',
  iconColor = '#2D9B9B',
  inTrust,
  outright,
}) => {
  const hasInTrust = inTrust !== undefined && inTrust > 0;
  const hasOutright = outright !== undefined && outright > 0;

  return (
    <View
      style={{
        border: '1px solid #E5E7EB',
        borderRadius: 8,
        padding: 16,
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
        minWidth: 140,
      }}
    >
      {/* Icon circle */}
      <View
        style={{
          width: 48,
          height: 48,
          borderRadius: 24,
          backgroundColor: '#E6F7F7',
          justifyContent: 'center',
          alignItems: 'center',
          marginBottom: 12,
        }}
      >
        {icon === 'person' ? (
          <PersonIcon color={iconColor} size={28} />
        ) : (
          <CharityIcon color={iconColor} size={28} />
        )}
      </View>

      {/* Name */}
      <Text
        style={{
          fontSize: 12,
          fontWeight: 'bold',
          color: '#111827',
          textAlign: 'center',
          marginBottom: 12,
        }}
      >
        {name}
      </Text>

      {/* Amounts */}
      <View style={{ width: '100%', flexDirection: 'column' }}>
        {/* In Trust */}
        {hasInTrust && !hasOutright && (
          <View style={{ marginBottom: 8 }}>
            <Text
              style={{
                fontSize: 9,
                color: '#6B7280',
                marginBottom: 2,
                textAlign: 'center',
              }}
            >
              In Trust
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: 'bold',
                color: iconColor,
                textAlign: 'center',
              }}
            >
              ${inTrust!.toLocaleString('en-US')}
            </Text>
          </View>
        )}

        {/* Outright */}
        {hasOutright && !hasInTrust && (
          <View style={{ marginBottom: 8 }}>
            <Text
              style={{
                fontSize: 9,
                color: '#6B7280',
                marginBottom: 2,
                textAlign: 'center',
              }}
            >
              Outright
            </Text>
            <Text
              style={{
                fontSize: 13,
                fontWeight: 'bold',
                color: '#6B7280',
                textAlign: 'center',
              }}
            >
              ${outright!.toLocaleString('en-US')}
            </Text>
          </View>
        )}

        {/* Both amounts side by side if both exist */}
        {hasInTrust && hasOutright && (
          <View
            style={{
              flexDirection: 'row',
              marginTop: 4,
              paddingTop: 8,
              borderTop: '1px solid #E5E7EB',
              width: '100%',
            }}
          >
            <View style={{ flex: 1, alignItems: 'center' }}>
              <Text
                style={{
                  fontSize: 8,
                  color: '#9CA3AF',
                  marginBottom: 2,
                }}
              >
                In Trust
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontWeight: 'bold',
                  color: iconColor,
                }}
              >
                {formatCompact(inTrust!)}
              </Text>
            </View>
            <View
              style={{
                width: 1,
                backgroundColor: '#E5E7EB',
                marginHorizontal: 4,
              }}
            />
            <View style={{ flex: 1, alignItems: 'center' }}>
              <Text
                style={{
                  fontSize: 8,
                  color: '#9CA3AF',
                  marginBottom: 2,
                }}
              >
                Outright
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  fontWeight: 'bold',
                  color: '#6B7280',
                }}
              >
                {formatCompact(outright!)}
              </Text>
            </View>
          </View>
        )}

        {/* No amounts case */}
        {!hasInTrust && !hasOutright && (
          <Text
            style={{
              fontSize: 10,
              color: '#9CA3AF',
              textAlign: 'center',
              fontStyle: 'italic',
            }}
          >
            No distribution
          </Text>
        )}
      </View>
    </View>
  );
};
