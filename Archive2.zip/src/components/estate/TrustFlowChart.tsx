import React from 'react';
import { View, Text, Svg, Path, Rect, G, StyleSheet } from '@react-pdf/renderer';

export interface TrustNode {
  id: string;
  label: string;
  icon: string;
  color: string;
}

export interface TrustConnection {
  from: string;
  to: string;
  label?: string;
}

export interface TrustSeparator {
  afterNode: string;
  text: string;
}

export interface TrustFlowChartProps {
  nodes: TrustNode[];
  connections: TrustConnection[];
  separators?: TrustSeparator[];
  layout?: 'vertical' | 'hierarchical';
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    width: 520,
    marginTop: 20,
    marginBottom: 20,
    flexDirection: 'column',
  },
  nodeLabel: {
    fontSize: 9,
    color: '#111827',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 4,
  },
  connectionLabel: {
    position: 'absolute',
    fontSize: 9,
    color: '#6B7280',
    fontWeight: 'bold',
    backgroundColor: 'white',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 3,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    textAlign: 'center',
  },
  separatorLabel: {
    position: 'absolute',
    fontSize: 10,
    color: '#4B5563',
    fontWeight: 'bold',
    backgroundColor: 'white',
    paddingHorizontal: 8,
    paddingVertical: 4,
    textAlign: 'center',
  },
});

/**
 * TrustFlowChart component
 * Renders hierarchical trust structure with nodes, connections, and separators
 */
export const TrustFlowChart: React.FC<TrustFlowChartProps> = ({
  nodes,
  connections,
  separators = [],
}) => {
  // Node dimensions
  const nodeWidth = 120;
  const nodeHeight = 40;
  const labelHeight = 20;
  const nodeWithLabelHeight = nodeHeight + labelHeight;
  const horizontalGap = 20;
  const verticalGap = 50;

  // Calculate layout positions
  const nodePositions = new Map<string, { x: number; y: number; level: number }>();

  // Build adjacency list for hierarchy
  const childrenMap = new Map<string, string[]>();
  const parentMap = new Map<string, string>();

  connections.forEach((conn) => {
    if (!childrenMap.has(conn.from)) {
      childrenMap.set(conn.from, []);
    }
    childrenMap.get(conn.from)!.push(conn.to);
    parentMap.set(conn.to, conn.from);
  });

  // Find root nodes (nodes with no parents)
  const rootNodes = nodes.filter((node) => !parentMap.has(node.id));

  // BFS to assign levels
  const levelMap = new Map<string, number>();
  const queue: Array<{ id: string; level: number }> = [];

  rootNodes.forEach((node) => {
    queue.push({ id: node.id, level: 0 });
    levelMap.set(node.id, 0);
  });

  while (queue.length > 0) {
    const { id, level } = queue.shift()!;
    const children = childrenMap.get(id) || [];
    children.forEach((childId) => {
      if (!levelMap.has(childId)) {
        levelMap.set(childId, level + 1);
        queue.push({ id: childId, level: level + 1 });
      }
    });
  }

  // Group nodes by level
  const nodesByLevel = new Map<number, TrustNode[]>();
  nodes.forEach((node) => {
    const level = levelMap.get(node.id) || 0;
    if (!nodesByLevel.has(level)) {
      nodesByLevel.set(level, []);
    }
    nodesByLevel.get(level)!.push(node);
  });

  // Calculate positions
  const maxLevel = Math.max(...Array.from(levelMap.values()), 0);
  let currentY = 20;

  const separatorPositions: Array<{ y: number; text: string }> = [];

  for (let level = 0; level <= maxLevel; level++) {
    const levelNodes = nodesByLevel.get(level) || [];
    const levelWidth = levelNodes.length * nodeWidth + (levelNodes.length - 1) * horizontalGap;
    const startX = Math.max(20, (520 - levelWidth) / 2); // Center horizontally

    levelNodes.forEach((node, index) => {
      const x = startX + index * (nodeWidth + horizontalGap);
      nodePositions.set(node.id, { x, y: currentY, level });
    });

    // Check if there's a separator after this level
    const separator = separators.find((sep) =>
      levelNodes.some((node) => node.id === sep.afterNode)
    );

    currentY += nodeWithLabelHeight + verticalGap;

    if (separator) {
      separatorPositions.push({ y: currentY - verticalGap / 2, text: separator.text });
      currentY += 20; // Extra space for separator
    }
  }

  // Calculate total height
  const totalHeight = currentY + 20;
  const totalWidth = 520;

  // Prepare connection label positions
  const connectionLabelData: Array<{
    text: string;
    x: number;
    y: number;
    width: number;
  }> = [];

  connections.forEach((conn) => {
    if (conn.label) {
      const fromPos = nodePositions.get(conn.from);
      const toPos = nodePositions.get(conn.to);
      if (fromPos && toPos) {
        const midY = (fromPos.y + nodeWithLabelHeight + toPos.y) / 2;
        const toX = toPos.x + nodeWidth / 2;
        connectionLabelData.push({
          text: conn.label,
          x: toX - 20,
          y: midY - 8,
          width: 40,
        });
      }
    }
  });

  // Prepare separator label positions
  const separatorLabelData: Array<{
    text: string;
    x: number;
    y: number;
    width: number;
  }> = [];

  separatorPositions.forEach((sep) => {
    separatorLabelData.push({
      text: sep.text,
      x: totalWidth / 2 - 80,
      y: sep.y - 8,
      width: 160,
    });
  });

  // Build node rendering data with positions
  const nodeRenderData = nodes.map((node) => {
    const pos = nodePositions.get(node.id);
    return { node, pos };
  }).filter((item) => item.pos !== undefined);

  return (
    <View style={styles.container}>
      {/* Render each level as a row */}
      {Array.from({ length: maxLevel + 1 }, (_, level) => {
        const levelNodes = nodesByLevel.get(level) || [];
        
        return (
          <View key={`level-${level}`} style={{ marginBottom: verticalGap }}>
            {/* Nodes row */}
            <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
              {levelNodes.map((node, nodeIndex) => (
                <View
                  key={node.id}
                  style={{
                    alignItems: 'center',
                    width: nodeWidth,
                    marginHorizontal: horizontalGap / 2,
                  }}
                >
                  {/* Colored box */}
                  <View
                    style={{
                      width: nodeWidth,
                      height: nodeHeight,
                      backgroundColor: node.color,
                      borderRadius: 8,
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    {/* Icon placeholder - small white circle */}
                    <View
                      style={{
                        width: 20,
                        height: 20,
                        borderRadius: 10,
                        backgroundColor: 'rgba(255,255,255,0.3)',
                      }}
                    />
                  </View>
                  {/* Label below the box */}
                  <Text style={styles.nodeLabel}>
                    {node.label.length > 18 ? `${node.label.substring(0, 16)}...` : node.label}
                  </Text>
                </View>
              ))}
            </View>
            
            {/* Check for separator after this level */}
            {separators.find((sep) => levelNodes.some((n) => n.id === sep.afterNode)) && (
              <View style={{ marginTop: 20, marginBottom: 10, alignItems: 'center' }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', width: '100%' }}>
                  <View style={{ flex: 1, height: 1, backgroundColor: '#9CA3AF' }} />
                  <Text style={{
                    fontSize: 10,
                    color: '#4B5563',
                    fontWeight: 'bold',
                    paddingHorizontal: 12,
                    backgroundColor: 'white',
                  }}>
                    {separators.find((sep) => levelNodes.some((n) => n.id === sep.afterNode))?.text}
                  </Text>
                  <View style={{ flex: 1, height: 1, backgroundColor: '#9CA3AF' }} />
                </View>
              </View>
            )}
          </View>
        );
      })}
      
      {/* Connection lines SVG overlay */}
      <Svg
        width={totalWidth}
        height={totalHeight}
        viewBox={`0 0 ${totalWidth} ${totalHeight}`}
        style={{ position: 'absolute', top: 0, left: 0 }}
      >
        {connections.map((conn, index) => {
          const fromPos = nodePositions.get(conn.from);
          const toPos = nodePositions.get(conn.to);

          if (!fromPos || !toPos) return null;

          const fromX = fromPos.x + nodeWidth / 2;
          const fromY = fromPos.y + nodeHeight;
          const toX = toPos.x + nodeWidth / 2;
          const toY = toPos.y;

          // Check if there's a separator between these nodes
          const hasSeparator = separators.some((sep) => sep.afterNode === conn.from);
          const midY = hasSeparator ? (fromY + toY) / 2 + 15 : (fromY + toY) / 2;

          return (
            <G key={`connection-${index}`}>
              {/* Connection line */}
              <Path
                d={`M ${fromX} ${fromY} L ${fromX} ${midY} L ${toX} ${midY} L ${toX} ${toY}`}
                stroke="#CBD5E1"
                strokeWidth={2}
                fill="none"
              />

              {/* Arrow head */}
              <Path
                d={`M ${toX} ${toY} L ${toX - 4} ${toY - 8} L ${toX + 4} ${toY - 8} Z`}
                fill="#CBD5E1"
              />
            </G>
          );
        })}
      </Svg>

      {/* Connection labels */}
      {connectionLabelData.map((label, index) => (
        <Text
          key={`conn-label-${index}`}
          style={[
            styles.connectionLabel,
            {
              position: 'absolute',
              left: label.x,
              top: label.y,
              width: label.width,
            },
          ]}
        >
          {label.text}
        </Text>
      ))}
    </View>
  );
};
