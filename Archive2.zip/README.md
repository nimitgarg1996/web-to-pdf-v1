# Report Builder - React-PDF Generation Pipeline

A powerful, autonomous server-side PDF generation system built with React-PDF. This system provides a complete factory pattern architecture for generating professional PDFs from JSON blueprints.

## Features

- 🏗️ **Factory Pattern Architecture** - Blueprint → Template → Component → Primitive pipeline
- 📊 **xyflow Diagram Support** - Convert node graphs to SVG diagrams in PDFs
- 📋 **Multi-page Tables** - Automatic pagination with header repetition
- 📑 **Auto-generated Table of Contents** - Extract headings and build TOC automatically
- 🖨️ **Print-Ready Output** - Support for crop marks and bleed areas
- 🎨 **Theming & Branding** - Complete design system with customizable themes
- 🔌 **REST API** - Full CRUD endpoints for PDF generation
- 📝 **Multiple Templates** - Report, Dashboard, Invoice, DataTable templates
- ✅ **Blueprint Validation** - Zod-based schema validation with helpful error messages

## Quick Start

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd report-builder-poc

# Install dependencies
npm install

# Start development server
npm run dev
```

### Generate Your First PDF

```bash
# Using the API - Generate a sample report
curl -X POST http://localhost:3000/api/pdf/samples/report/generate \
  -o sample-report.pdf

# Or validate a blueprint first
curl -X POST http://localhost:3000/api/pdf/validate \
  -H "Content-Type: application/json" \
  -d @path/to/blueprint.json
```

### Using the Factory Directly

```typescript
import { createDocument } from './src/factories';
import { renderToStream } from '@react-pdf/renderer';

const blueprint = {
  id: 'my-report',
  version: '1.0',
  type: 'report',
  metadata: {
    title: 'My Report',
    author: 'Team',
  },
  content: {
    showCover: true,
    sections: [
      { type: 'heading', level: 1, text: 'Introduction' },
      { type: 'paragraph', text: 'Welcome to my report...' },
    ],
  },
};

const doc = createDocument({ blueprint });
const stream = await renderToStream(doc);
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         API Layer                                │
│  Express.js REST API with validation, error handling, CORS      │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Document Factory                            │
│  Validates blueprint and routes to appropriate template          │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                         Templates                                │
│  Report │ Dashboard │ Invoice │ DataTable                       │
│  (Page layout, headers, footers, cover pages)                   │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Components                                │
│  Typography │ Layout │ Tables │ Diagrams │ Feedback │ etc.     │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Primitives                                │
│  Colors │ Typography │ Spacing │ Icons │ Theme                  │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                       React-PDF                                  │
│  Renders React components to PDF stream/buffer                  │
└─────────────────────────────────────────────────────────────────┘
```

## API Endpoints

### Health Checks

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Basic health check |
| GET | `/health/ready` | Readiness probe (for Kubernetes) |
| GET | `/health/live` | Liveness probe |
| GET | `/health/info` | Application info and version |

### PDF Generation

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/pdf/generate` | Generate PDF from blueprint |
| POST | `/api/pdf/validate` | Validate blueprint without generating |
| GET | `/api/pdf/templates` | List available templates |
| GET | `/api/pdf/samples` | List available sample blueprints |
| GET | `/api/pdf/samples/:type` | Get sample blueprint by type |
| POST | `/api/pdf/samples/:type/generate` | Generate PDF from sample |

### Example: Generate PDF

```bash
curl -X POST http://localhost:3000/api/pdf/generate \
  -H "Content-Type: application/json" \
  -d '{
    "id": "report-001",
    "version": "1.0",
    "type": "report",
    "metadata": {
      "title": "Quarterly Report",
      "author": "Analytics Team"
    },
    "content": {
      "showCover": true,
      "sections": [...]
    }
  }' \
  -o output.pdf
```

## Blueprint Schema

Blueprints are JSON documents that define the structure and content of your PDF.

### Structure

```typescript
interface Blueprint {
  id: string;           // Unique identifier
  version: string;      // Schema version
  type: 'report' | 'dashboard' | 'invoice' | 'data-table';
  metadata: {
    title: string;
    subtitle?: string;
    author?: string;
    date?: string;
    logo?: string;
    pageSize?: 'A4' | 'Letter' | 'Legal';
    orientation?: 'portrait' | 'landscape';
  };
  content: {
    // Content varies by template type
    // See specific template documentation
  };
}
```

### Report Blueprint

```json
{
  "id": "report-001",
  "version": "1.0",
  "type": "report",
  "metadata": {
    "title": "Q4 2024 Business Review",
    "subtitle": "Annual Performance Analysis",
    "author": "Strategy Team"
  },
  "content": {
    "showCover": true,
    "showToc": true,
    "executiveSummary": "This report provides...",
    "sections": [
      { "type": "heading", "level": 1, "text": "Introduction" },
      { "type": "paragraph", "text": "Content here..." },
      { "type": "table", "columns": [...], "data": [...] },
      { "type": "callout", "variant": "info", "title": "Note", "text": "..." }
    ]
  }
}
```

### Content Block Types

| Type | Description |
|------|-------------|
| `heading` | Section heading (levels 1-4) |
| `paragraph` | Text paragraph |
| `table` | Data table with columns and rows |
| `list` | Ordered or unordered list |
| `callout` | Highlighted box (info, warning, success, error) |
| `metrics` | Grid of metric cards |
| `key-value` | Key-value pair display |
| `diagram` | xyflow-style node graph |
| `image` | Image with optional caption |
| `spacer` | Vertical spacing |
| `divider` | Horizontal divider line |
| `page-break` | Force page break |
| `section` | Nested content section |

## Components

### Typography
- `Heading` - H1-H4 headings
- `Paragraph` - Body text
- `Text` - Inline text
- `Label` - Form labels
- `Caption` - Image captions

### Layout
- `Box` - Basic container
- `Stack` - Vertical stack layout
- `Row` - Horizontal row layout
- `Spacer` - Spacing utility
- `Divider` - Horizontal/vertical divider

### Data Display
- `Table` - Full-featured data table
- `List` - Ordered/unordered lists
- `KeyValue` - Key-value pairs
- `MetricCard` - KPI display cards

### Feedback
- `Badge` - Status badges
- `StatusIndicator` - Status dots/icons
- `ProgressBar` - Progress indicators
- `Callout` - Alert boxes

### Containers
- `Card` - Content card
- `Section` - Titled section
- `Callout` - Highlighted content box

### Media
- `Icon` - SVG icons
- `Logo` - Company logo

### Navigation
- `TableOfContents` - Auto-generated TOC
- `CropMarks` - Print-ready crop marks

### Diagrams
- `Diagram` - xyflow-compatible node graphs
- `DiagramNode` - Graph nodes (rectangle, circle, diamond, cylinder)
- `DiagramEdge` - Connection lines with arrows

## Examples

See the [`examples/`](./examples) directory for complete examples:

- `basic-usage.ts` - Generate PDFs programmatically
- `api-client.ts` - Using the REST API

## Development

### Project Structure

```
src/
├── api/                 # Express API layer
│   ├── middleware/     # CORS, validation, error handling
│   └── routes/         # API route handlers
├── blueprints/         # Blueprint types and samples
│   ├── types.ts        # TypeScript interfaces
│   └── samples/        # Sample blueprint JSON files
├── components/         # React-PDF components
│   ├── typography/     # Text components
│   ├── layout/         # Layout components
│   ├── table/          # Table components
│   ├── diagram/        # Diagram components
│   ├── feedback/       # Feedback components
│   ├── containers/     # Container components
│   ├── data/           # Data display components
│   ├── media/          # Media components
│   └── navigation/     # Navigation components
├── config/             # App configuration
├── factories/          # Document factory and validators
├── primitives/         # Design tokens
├── services/           # Business logic services
├── templates/          # Page templates
│   └── components/     # Template sub-components
├── types/              # Shared TypeScript types
├── utils/              # Utility functions
├── index.ts            # App entry point
└── server.ts           # Express server setup
```

### Scripts

```bash
# Development
npm run dev          # Start with hot reload
npm run build        # Build for production
npm run start        # Run production build

# Testing
npm run test         # Run tests
npm run test:watch   # Run tests in watch mode
npm run test:coverage # Run tests with coverage

# Code Quality
npm run lint         # Run ESLint
npm run typecheck    # Run TypeScript type checking
```

### Environment Variables

Copy `.env.example` to `.env` and configure:

```env
PORT=3000
HOST=0.0.0.0
NODE_ENV=development
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
PDF_MAX_SIZE_MB=50
PDF_TIMEOUT_MS=30000
```

## Docker

### Build and Run

```bash
# Build the image
docker build -t report-builder .

# Run the container
docker run -p 3000:3000 report-builder
```

### Docker Compose

```bash
# Start the service
docker-compose up -d

# View logs
docker-compose logs -f

# Stop the service
docker-compose down
```

## Testing

```bash
# Run all tests
npm run test

# Run tests in watch mode
npm run test:watch

# Generate coverage report
npm run test:coverage
```

## Theming

Customize the look and feel by providing a theme:

```typescript
import { createDocumentWithTheme } from './src/factories';

const customTheme = {
  colors: {
    palette: {
      brand: {
        500: '#ff6600', // Orange brand color
      },
    },
  },
  typography: {
    fontFamilies: {
      primary: 'Helvetica',
    },
  },
};

const doc = createDocumentWithTheme({
  blueprint,
  theme: customTheme,
});
```

## Performance Considerations

- **Streaming**: PDFs are generated as streams by default for memory efficiency
- **Caching**: Blueprint validation results can be cached
- **Timeouts**: Configure `PDF_TIMEOUT_MS` for large documents
- **Size Limits**: Configure `PDF_MAX_SIZE_MB` for upload limits

## Troubleshooting

### Common Issues

**PDF generation timeout**
- Increase `PDF_TIMEOUT_MS` in environment
- Simplify complex diagrams
- Reduce image sizes

**Memory issues with large documents**
- Use streaming output instead of buffer
- Process tables in chunks
- Optimize image sizes

**Font rendering issues**
- Ensure fonts are registered in `src/config/fonts.ts`
- Use standard PDF-safe fonts for cross-platform compatibility

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

ISC License - See [LICENSE](./LICENSE) for details.

## Acknowledgments

- [React-PDF](https://react-pdf.org/) - React renderer for creating PDF files
- [Express.js](https://expressjs.com/) - Web framework for the API layer
- [Zod](https://zod.dev/) - TypeScript-first schema validation
